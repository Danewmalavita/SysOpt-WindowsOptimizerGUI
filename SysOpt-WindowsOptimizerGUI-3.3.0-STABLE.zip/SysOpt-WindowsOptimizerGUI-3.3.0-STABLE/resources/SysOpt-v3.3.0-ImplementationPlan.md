﻿# SysOpt v3.3.0 — Plan de Implementación Unificado

> **Fecha:** 2026-03-09 | **Filosofía:** Modular, ligero, estilo Tanium  
> **Basado en:** Roadmap v3.3.0 + Session Reports + Full Analysis (6,850 líneas C#, 8,097 PS1)

---

## 📊 Estado Actual del Proyecto

| Métrica | Valor |
|---------|-------|
| SysOpt.ps1 | 8,097 líneas |
| C# source | 6,850 líneas (12 archivos) |
| DLLs compiladas | 11 (Core+Collector+Cleanup split) |
| Core.dll (split) | Core 624 + Collector 863 + Cleanup 891 líneas |
| Funciones PS1 | 64 + 1 scriptblock |
| Clases C# | 57 |
| XAML windows | 11 (310 KB) |
| Idiomas | 3 (904 claves cada uno) |
| Temas | 68 |

---

## FASE 0: COMPLETADO ✅ (Sesiones 1–3)

| Item | Estado |
|------|--------|
| DiagnosticWindow pills compactos | ✅ |
| Score circle proporcional + traducido | ✅ |
| Detección AV/Firewall terceros | ✅ |
| Servicios: exclusión inteligente WinDefend + mpssvc | ✅ |
| Toggle switch dry-run | ✅ |
| Botón Analizar auto-selecciona todo | ✅ |
| Reporte HTML → `.\output\` automático | ✅ |
| Claves traducción firewall + servicios | ✅ |
| MinWidth/MinHeight responsive | ✅ |

---

## FASE 1: Split Core.dll + Lazy Loading ✅ COMPLETADO (Sesión 4)

**Objetivo:** Reducir Core.dll de 2,265 → ~590 líneas (74% reducción). Arquitectura modular.

### 1.1 — Split Core.cs en 3 archivos

| Nuevo archivo | Clases | Líneas | DLL resultante |
|---------------|--------|--------|----------------|
| **SysOpt.Core.cs** (kernel) | Loc, LangEngine, XamlLoader, SettingsHelper, ScanTokenManager, SysOptFallbacks, LogEngine, Formatter | ~590 | SysOpt.Core.dll |
| **SysOpt.Collector.cs** (nuevo) | SystemDataCollector, SystemSnapshot, CpuSnapshot, RamSnapshot, RamModuleInfo, DiskSnapshot, DiskDriveInfo, DiskVolumeInfo, NetworkSnapshot, NetworkAdapterInfo, GpuSnapshot, GpuInfo, PortSnapshot, OpenPortInfo, AgentThresholds, IAgentTransport, AgentBus | ~860 | SysOpt.Collector.dll |
| **SysOpt.Cleanup.cs** (nuevo) | CleanupEngine, CleanupResult | ~795 | SysOpt.Cleanup.dll |

### 1.2 — Lista de funciones por DLL (detalle)

#### SysOpt.Core.dll — Kernel (8 clases, ~590 líneas)

```
├── Loc                    (L39–52,   15 lín)  → SetDict(), T()
├── LangEngine             (L54–124,  72 lín)  → ParseLangFile(), GetLangMeta(), ListLanguages()
├── XamlLoader             (L126–156, 32 lín)  → Load(), ListXaml()
├── SettingsHelper         (L158–189, 33 lín)  → ReadKey()
├── ScanTokenManager       (L191–270, 80 lín)  → Create(), Cancel(), Dispose(), IsCancelled()
├── SysOptFallbacks        (L1287–1423, 138 lín) → InitMutex(), AcquireMutex(), ReleaseMutex(),
│                                                   DisposeMutex(), IsLoaded(), RegisterLoaded(),
│                                                   LoadDll(), RunspacePoolAvailable
├── LogEngine              (L1114–1285, 173 lín) → Initialize(), Header(), Write(), Close(),
│                                                   DebugEnabled
└── Formatter              (L1425–1469, 46 lín)  → FormatBytes(), FormatRate(), ParseLinkBps(),
                                                    FormatPercent(), FormatUptime()
```

**Guard type:** `LangEngine`  
**Load phase:** Startup (splash 24%) — HARD  
**Dependencias:** System.IO, System.Diagnostics, System.Threading

#### SysOpt.Collector.dll — Data Collector (17 clases, ~860 líneas)

```
├── SystemDataCollector    (L467–1000, 534 lín) → GetCpuSnapshot(), GetRamSnapshot(),
│                                                  GetDiskSnapshot(), GetNetworkSnapshot(),
│                                                  GetGpuSnapshot(), GetPortSnapshot(),
│                                                  GetFullSnapshot(), GetSmartData(),
│                                                  GetBatteryInfo()
├── SystemSnapshot         (L433–465,  33 lín)  → Cpu, Ram, Disk, Network, Gpu, Ports, Timestamp
├── CpuSnapshot            (L272–286,  15 lín)  → Name, Cores, Threads, Speed, Load, Temperature
├── RamSnapshot            (L288–301,  14 lín)  → Total, Used, Free, Percent, Modules[]
├── RamModuleInfo          (L303–313,  11 lín)  → Manufacturer, Size, Speed, Type, Slot
├── DiskSnapshot           (L315–329,  15 lín)  → Drives[], Volumes[]
├── DiskDriveInfo          (L331–342,  12 lín)  → Model, Size, Type, SmartStatus, Serial
├── DiskVolumeInfo         (L344–355,  12 lín)  → Letter, Label, Size, Free, FileSystem
├── NetworkSnapshot        (L357–363,   7 lín)  → Adapters[]
├── NetworkAdapterInfo     (L365–382,  18 lín)  → Name, Mac, Speed, IP, Gateway, DNS, Status
├── GpuSnapshot            (L384–390,   7 lín)  → Gpus[]
├── GpuInfo                (L392–403,  12 lín)  → Name, Driver, VRAM, Resolution, RefreshRate
├── PortSnapshot           (L405–416,  12 lín)  → OpenPorts[]
├── OpenPortInfo           (L418–431,  14 lín)  → Port, Protocol, Process, PID, State
├── AgentThresholds        (L1002–1025, 24 lín) → CpuWarn, CpuCrit, RamWarn, etc.
├── IAgentTransport        (L1027–1044, 18 lín) → Send(), Receive() interface
└── AgentBus               (L1046–1112, 67 lín) → Register(), Unregister(), Publish()
```

**Guard type:** `SystemDataCollector`  
**Load phase:** Startup (splash 26%) — HARD  
**Dependencias:** System.Management (WMI), System.Net.NetworkInformation

#### SysOpt.Cleanup.dll — Cleanup Engine (2 clases, ~795 líneas)

```
├── CleanupEngine          (L1491–2263, 775 lín) → CleanTempFiles(), CleanBrowserCache(),
│                                                   CleanWindowsUpdate(), CleanThumbnails(),
│                                                   CleanPrefetch(), CleanRecycleBin(),
│                                                   CleanEventLogs(), CleanOldLogs(),
│                                                   CleanDnsCache(), GetTotalCleaned(),
│                                                   RunFullCleanup()
└── CleanupResult          (L1471–1489,  19 lín) → Category, FilesDeleted, BytesCleaned, Errors
```

**Guard type:** `CleanupEngine`  
**Load phase:** LAZY ⚡ — solo al optimizar  
**Dependencias:** System.IO, System.Diagnostics

### 1.3 — Cambios en SysOpt.ps1

```powershell
# ANTES (línea 167): Una sola carga
Load-SysOptDll "Core" "LangEngine"

# DESPUÉS: Split en 3
Load-SysOptDll "Core"      "LangEngine"           # 24% - Kernel (siempre)
Load-SysOptDll "Collector" "SystemDataCollector"   # 26% - Data (siempre)
# CleanupEngine se carga LAZY en $OptimizationScript y Show-DiagnosticReport

# NUEVO: Función Ensure-Dll para lazy loading
function Ensure-Dll {
    param([string]$Name, [string]$Guard)
    if (-not [SysOptFallbacks]::IsLoaded($Guard)) {
        Load-SysOptDll $Name $Guard
    }
}

# En $OptimizationScript (L7177):
Ensure-Dll "Cleanup" "CleanupEngine"
```

### 1.4 — Cambios en Optimizer.dll

```csharp
// Optimizer.cs actualmente referencia CleanupEngine directamente.
// Después del split, Optimizer.dll debe referenciar SysOpt.Cleanup.dll en compilación.
// O mejor: pasar CleanupResult via interfaz desde PS1 para desacoplar.
```

### 1.5 — Migración checklist

- [ ] Crear `SysOpt.Collector.cs` — mover 17 clases de Core.cs
- [ ] Crear `SysOpt.Cleanup.cs` — mover 2 clases de Core.cs
- [ ] Reducir `SysOpt.Core.cs` a 8 clases kernel
- [ ] Actualizar `compile-dlls.ps1` con nuevos targets
- [ ] Crear `SysOpt.Collector.csproj` y `SysOpt.Cleanup.csproj`
- [ ] Actualizar `SysOpt.ps1` líneas 155-210 (load order)
- [ ] Añadir `Ensure-Dll` function
- [ ] Actualizar `$OptimizationScript` para lazy-load Cleanup
- [ ] Actualizar `SysOpt.Optimizer.cs` referencia a Cleanup
- [ ] Test: arranque sin optimizar (Cleanup NO cargada)
- [ ] Test: optimización completa (Cleanup cargada lazy)
- [ ] Test: diagnóstico (verificar que no necesita Cleanup)

**Resultado esperado:**
- Core.dll: 64KB → ~18KB
- Nuevo Collector.dll: ~28KB
- Nuevo Cleanup.dll: ~22KB
- Memoria idle: ~45MB → ~35MB (Cleanup no cargada)

---

## FASE 2: Deduplicación + Refactoring ✅ COMPLETADA

> **Completada:** Sesión 11 (2026-03-10)
> - Loc deduplicada: 3 copias → 1 en Core.dll (global namespace)
> - 3 wrappers PS1 eliminados (Get-LinkBps, Format-SnapshotSize, Get-VisualChildren)
> - Versión dinámica: `$script:AppVersion` propagada a MainWindow + AboutWindow + reports
> - Resultado: −30 líneas C#, −3 líneas PS1

### 2.1 — Deduplicar clase Loc (3 copias → 1)

**Problema:** `Loc` está duplicada en Core.cs (L39), Diagnostics.cs (L17), y Optimizer.cs (L38).

**Solución:** Mantener solo en Core.dll. Diagnostics y Optimizer referencian Core.dll.

```csharp
// Diagnostics.cs y Optimizer.cs: ELIMINAR la clase Loc local
// Añadir: referencia a SysOpt.Core.dll en compilación
// Cambiar: Loc.T() → usa la del Core directamente
```

**Impacto:** -30 líneas C#, 1 punto de verdad para traducciones.

### 2.2 — Unificar contenedores de resultado

| Clase actual | DLL | Campos |
|-------------|-----|--------|
| `CleanupResult` | Core | Category, FilesDeleted, BytesCleaned, Errors |
| `DiagResult` | Diagnostics | Score, Items[], Summary |
| `OptimizeResult` | Optimizer | Tasks[], TotalTime, Errors |
| `DiskResult` | DiskEngine | Path, Size, Items[] |
| `TaskResult` | Optimizer | Name, Status, Duration, Error |
| `ApplyResult` | StartupManager | Applied[], Failed[] |

**Decisión:** NO unificar — cada uno tiene campos distintos con significado propio. La duplicación aparente es conceptual, no real.

### 2.3 — Eliminar wrappers triviales en PS1

9 funciones PS1 que son aliases de 1 línea a C#:

| PS1 Function | C# Call | Acción |
|-------------|---------|--------|
| `Format-Bytes` | `[Formatter]::FormatBytes()` | ⚠️ Mantener (usado 20+ veces) |
| `Format-Rate` | `[Formatter]::FormatRate()` | ⚠️ Mantener (legibilidad) |
| `Get-LinkBps` | `[Formatter]::ParseLinkBps()` | Eliminar — 1 uso |
| `Format-SnapshotSize` | `[Formatter]::FormatBytes()` | Eliminar — duplicado de Format-Bytes |
| `Get-VisualChildren` | `[ThemeApplier]::GetVisualChildren()` | Eliminar — 1 uso |

**Impacto:** -15 líneas PS1, simplificación mínima pero limpia.

---

## FASE 3: Feature Completion + Optimización ✅ COMPLETADA

> **Completada:** Fase 3 incluye features, exports multi-formato, filtros avanzados y optimizaciones de rendimiento.
> - Snapshots mejorado: ~95% funcional (save/load/delete/compare)
> - Dedup Window: ~90% funcional (SHA256, cancel/pause/resume, grupos)
> - Export CSV/JSON/HTML: ✅ COMPLETO (6 formatos × 2 contextos)
> - Folder Scanner con filtros: ✅ COMPLETO (tamaño, fecha, extensión)
> - Optimizaciones de rendimiento: ✅ 22 cambios aplicados
> - Carpeta output/: ✅ Destino por defecto para todos los exports

### 3.1 — Exports multi-formato

| Export | Contexto | Formato | Estado |
|--------|----------|---------|--------|
| Disco CSV | MainWindow | `.csv` | ✅ Ya existía |
| Disco HTML | MainWindow | `.html` | ✅ Ya existía |
| Disco JSON | MainWindow | `.json` | ✅ NUEVO — preparado para server sync |
| Diagnóstico TXT | DiagWindow | `.txt` | ✅ Ya existía |
| Diagnóstico CSV | DiagWindow | `.csv` | ✅ NUEVO — secciones + escape comillas |
| Diagnóstico JSON | DiagWindow | `.json` | ✅ NUEVO — preparado para server sync |
| Diagnóstico HTML | DiagWindow | `.html` | ✅ Ya existía |

### 3.2 — Filtros avanzados del Folder Scanner

| Filtro | Descripción | Controles |
|--------|-------------|-----------|
| 📏 Tamaño | Min/Max en MB | 2 TextBox |
| 📅 Fecha | Desde/Hasta (dd/MM/aaaa) | 2 TextBox con parsing tolerante |
| 🏷️ Extensión | Categorías predefinidas | 6 CheckBox (Video, Audio, Imagen, Docs, Archivo, Otro) |
| 🔄 Limpiar | Reset todos los filtros | Botón |
| ⚙️ Toggle | Panel colapsable | Botón con contador de filtros activos |

- Todos los filtros se aplican en un solo `foreach` (rendimiento óptimo)
- 30 claves de idioma nuevas × 3 idiomas (EN/ES/PT)
- UI con `DynamicResource` + `Get-TC` para 68 temas

### 3.3 — Optimizaciones de rendimiento (22 cambios)

| Área | Optimización | Impacto |
|------|-------------|---------|
| ThemeEngine.cs | Cache PropertyInfo por Type | ~3x más rápido |
| Apply-Theme | PASS 1+2 fusionados + batch 50 | -60% overhead UI |
| RunspacePool | Pool 3→5 threads | ~2x arranque |
| DiskScan FIFO | Batch adaptativo (200-1200) | Más fluido |
| Snapshot FIFO | Batch adaptativo (200-1000) | Más fluido |
| Boot: 5 DLLs diferidas | WseTrim, Optimizer, StartupMgr, Diagnostics, Toast post-splash | -2-3s splash |
| Boot: PerfTab | DispatcherTimer 300ms | UI no bloqueada |
| Boot: Import-Module | Lazy (flag $_perfModulesLoaded) | -3s refreshes |

### 3.4 — Carpeta output/

Todos los exports (CSV, JSON, HTML, TXT) ahora guardan por defecto en `.\output\`.
- `$script:OutputDir` se inicializa en boot y auto-crea el directorio.
- Log export se mantiene en `.\logs\` (correcto).
- El usuario puede cambiar la ruta vía SaveFileDialog.

---

## FASE 4: Rendimiento del Diagnóstico ✅ COMPLETADA

> **Completada:** 10/03/2026 — Diagnóstico paralelo con 5 collectors via RunspacePool.
> Reducción de ~13s a ~3-5s. BootMs type-safe con fallback DateTime.


**Objetivo:** Reducir tiempo de análisis de ~13s a ~5s

### 4.1 — Quick Wins (sin cambiar arquitectura)

| Cambio | Ahorro |
|--------|--------|
| `Test-Connection` → `[System.Net.NetworkInformation.Ping]::new().Send()` | ~3s |
| `Get-CimInstance` (cachear 1ª llamada) → reusar snapshot | ~2s |
| `Get-Service` una sola vez → filtrar en memoria | ~1s |
| `Test-Path` batch → `[System.IO.Directory]::Exists()` | ~0.5s |

### 4.2 — Runspaces paralelos

```powershell
# Agrupar checks en 3 lotes paralelos:
# Lote 1: Hardware (CPU, RAM, Disk, GPU)
# Lote 2: Network (connectivity, DNS, firewall, ports)
# Lote 3: Software (services, updates, AV, startup)
# Cada lote en un runspace → 3 paralelos vs 30+ secuenciales
```

**Resultado:** ~13s → ~4-5s

### 4.4 — Fix SFC/DISM (deadlock + progreso en tiempo real)

> **Fecha:** 10/03/2026 | **Bug detectado en ejecución real**

**Problemas encontrados:**
1. 🔴 **Deadlock**: `RedirectStandardOutput` + `WaitForExit()` sin leer stdout
2. 🔴 **Sin progreso**: SFC imprime "Verification X% complete" pero nadie lo lee
3. 🔴 **Sin callback**: `DoSfc(dryRun)` no recibía `onProgress`
4. 🔴 **CBS.log lock**: `File.ReadAllLines()` falla si CBS.log está bloqueado

**Cambios aplicados:**

| Archivo | Cambio | Líneas |
|---------|--------|--------|
| SysOpt.Cleanup.cs | `RunSfc()`: async stdout + `BeginOutputReadLine()` + timeout 60min + `FileShare.ReadWrite` para CBS.log | +71 |
| SysOpt.Cleanup.cs | `RunDism()`: async stdout + timeout 45min/paso + onLine callback | +30 |
| SysOpt.Optimizer.cs | `DoSfc()`: propagación de `onProgress` + parse regex de % | +25 |
| SysOpt.Optimizer.cs | `DoDism()`: propagación de `onProgress` + parse regex de % | +22 |
| SysOpt.Optimizer.cs | `ExecuteTask()`: wiring de onProgress a SFC/DISM | +2 |
| 3 × .lang | +16 keys SFC/DISM (SfcNote, SfcDryRun, DismStep1, etc.) | +48 |

**Flujo actual:**
```
ExecuteTask("SFC") → DoSfc(dryRun, onProgress, basePct)
  → CleanupEngine.RunSfc(dryRun, onLine)
    → proc.BeginOutputReadLine()     ← async
    → OutputDataReceived → parse %   ← progreso real
    → proc.WaitForExit(60 min)       ← con timeout
    → outputDone.Wait(5000)          ← flush buffer
    → FileStream(CBS.log, ReadWrite) ← sin lock
```

### 4.3 — Futuro: migrar recolección a C#

Mover toda la lógica de `Show-DiagnosticReport` que hace WMI/CIM a `DiagnosticsEngine.cs` usando `Task.WhenAll`. Resultado: ~2-3s.

---

## FASE 5: Toast Notifications

Según roadmap:
- Toast al completar optimización
- Toast al completar diagnóstico
- Toast al completar disk scan
- Opciones de posición (esquina)
- Duración configurable

---

## FASE 6: Sistema de Módulos

**Visión Tanium-like:**

```
.\modules\
  ├── SysOpt.Module.Office.dll    → Diagnóstico/optimización Office
  ├── SysOpt.Module.Browser.dll   → Limpieza avanzada navegadores
  ├── SysOpt.Module.Security.dll  → Audit de seguridad
  └── SysOpt.Module.Network.dll   → Diagnóstico red avanzado
```

Cada módulo:
- Se descubre automáticamente al arrancar
- Implementa interfaz `ISysOptModule`
- Se carga lazy cuando el usuario entra en su tab
- Tiene su propio XAML panel

---

## FASE 7: Módulo Office

Primer módulo del sistema:
- Detectar instalaciones Office (365, 2021, 2019)
- Limpieza de caché Office
- Reparación de complementos
- Diagnóstico de licencia

---

## FASE 8: Responsive UI Fixes

**Objetivo:** Corregir problemas de layout en pantallas pequeñas / ventanas redimensionadas.

| # | Zona | Problema | Fix |
|---|------|----------|-----|
| 1 | Window | Sin MinWidth/MinHeight | `MinWidth="940" MinHeight="680"` |
| 2 | Header (Row 0) | StackPanel Horizontal clips en < 1100px | WrapPanel para botones derechos |
| 3 | Footer (Row 4) | 9 botones Auto se cortan | WrapPanel con HorizontalAlignment |
| 4 | Tab Rendimiento | `ColumnDefinition Width="320"` fija | `Auto MinWidth="280" MaxWidth="360"` |
| 5 | Tab Disco Explorer | `Width="260"` fija para detalle | `Auto MinWidth="220" MaxWidth="300"` |
| 6 | Tab Disco Explorer | Sub-columnas 100+70+90 px fijas | Usar MinWidth en vez de Width |
| 7 | Consola (Row 3) | `Height="200"` fija | `MinHeight="120" MaxHeight="250"` |

**Archivos a modificar:**
- `assets/xaml/MainWindow.xaml` — Todos los fixes de layout

---

## FASE 9: Polish + v3.3.0-STABLE

- Testing final completo
- Actualización de documentación
- Revisión de traducción (860 claves × 3 idiomas)
- Release v3.3.0-STABLE

---


## FASE 10: Restore Points (~1h, Baja)

Crear y gestionar puntos de restauración del sistema antes de ejecutar optimizaciones.

### 10.1 — Crear punto de restauración
- Usar `Checkpoint-Computer` para crear restore point con nombre descriptivo
- Formato: `SysOpt_v{version}_{timestamp}`
- Validar permisos de administrador antes de crear
- Toast notification al completar

### 10.2 — Listar y gestionar
- Listar puntos existentes con `Get-ComputerRestorePoint`
- Mostrar en DataGrid: Fecha, Descripción, Tipo, Tamaño estimado
- Opción para eliminar puntos antiguos (> 30 días configurable)

### 10.3 — Auto-restore antes de optimización
- Checkbox "Crear punto de restauración antes de optimizar" (default: ON)
- Integrar en `$OptimizationScript` como primer paso

**Archivos a modificar:**
- `SysOpt.ps1` — Nuevas funciones `New-SysOptRestorePoint`, `Get-SysOptRestorePoints`
- `assets/lang/*.json` — Claves de traducción (~15 nuevas)
- `assets/xaml/MainWindow.xaml` — Sección en tab Herramientas

---

## FASE 11: Limpieza Programada (~1h, Baja)

Scheduler interno que ejecuta optimización automática con notificación toast.

### 11.1 — Configuración de schedule
- UI: ComboBox con opciones (Cada 6h, 12h, 1 día, 3 días, 7 días, Desactivado)
- Persistir en registro: `HKCU:\Software\SysOpt\Schedule`
- Toggle ON/OFF visible en tab principal

### 11.2 — Task Scheduler integration
- Crear/actualizar `ScheduledTask` de Windows con `Register-ScheduledTaskDefinition`
- Trigger: según intervalo seleccionado
- Action: `powershell.exe -File SysOpt.ps1 -Silent -AutoClean`
- Agregar parámetro `-Silent` y `-AutoClean` al script

### 11.3 — Notificaciones
- Toast al completar limpieza automática (via SysOpt.Toast.dll)
- Log de ejecuciones en `logs/auto-cleanup.log`

**Archivos a modificar:**
- `SysOpt.ps1` — Parámetros `-Silent`, `-AutoClean`, funciones de scheduling
- `assets/lang/*.json` — ~20 claves nuevas
- `assets/xaml/MainWindow.xaml` — Panel de configuración de schedule

---

## FASE 12: Game Mode (~1.5h, Baja)

Perfil que mata servicios innecesarios, ajusta prioridades y libera RAM para gaming.

### 12.1 — Perfil de servicios a detener
- Lista predefinida de servicios no-críticos:
  - Windows Search, SysMain (Superfetch), DiagTrack, Print Spooler
  - Windows Update (temporal), Connected User Experiences
  - Themes, TabletInputService, WMPNetworkSvc
- Guardar estado previo para restaurar al desactivar

### 12.2 — Optimizaciones de rendimiento
- Ajustar prioridad del proceso de juego a `AboveNormal`
- Desactivar Nagle's algorithm temporalmente
- Limpiar standby list (MemoryHelper)
- Desactivar visual effects temporalmente

### 12.3 — UI Toggle
- Botón prominente "🎮 Game Mode" en toolbar principal
- Indicador visual cuando está activo (color accent pulsante)
- Timer mostrando duración activa
- Botón "Restaurar" para volver al estado normal

### 12.4 — DLL: SysOpt.GameMode.dll
- `GameModeProfile` — clase con lista de servicios y su estado previo
- `GameModeManager` — Start/Stop con rollback automático

**Archivos a crear:**
- `libs/csproj/SysOpt.GameMode.cs` — Lógica de perfiles
- `libs/csproj/SysOpt.GameMode.csproj`

**Archivos a modificar:**
- `SysOpt.ps1` — Funciones Enable/Disable-GameMode
- `assets/lang/*.json` — ~25 claves
- `assets/xaml/MainWindow.xaml` — Botón + indicador

---

## FASE 13: DNS Optimizer (~1h, Baja)

Benchmark de servidores DNS y configuración automática del más rápido.

### 13.1 — Benchmark DNS
- Lista de servidores a testear:
  - Google (8.8.8.8, 8.8.4.4)
  - Cloudflare (1.1.1.1, 1.0.0.1)
  - OpenDNS (208.67.222.222, 208.67.220.220)
  - Quad9 (9.9.9.9, 149.112.112.112)
  - DNS actual del usuario
- Medir latencia con `[System.Net.Dns]::GetHostEntry()` + Stopwatch
- 5 iteraciones por servidor → promedio

### 13.2 — Visualización
- DataGrid: Servidor, IP Primario, IP Secundario, Latencia (ms), Estado
- Barra de progreso durante benchmark
- Highlight del más rápido en verde

### 13.3 — Aplicar DNS
- Botón "Aplicar DNS más rápido" → `Set-DnsClientServerAddress`
- Guardar DNS original para rollback
- Botón "Restaurar DNS original"

**Archivos a modificar:**
- `SysOpt.ps1` — Funciones Test-DnsServers, Set-OptimalDns
- `assets/lang/*.json` — ~15 claves
- `assets/xaml/MainWindow.xaml` — Panel en tab Red/Herramientas

---

## FASE 14: Battery Health — Laptops (~1h, Baja)

Estado de batería, ciclos, capacidad real vs diseño, perfil de energía.

### 14.1 — Recolección de datos
- WMI: `Win32_Battery`, `BatteryStatus`, `BatteryStaticData`
- `powercfg /batteryreport /output battery.html` → parsear XML
- Datos: Capacidad diseño, capacidad actual, ciclos, wear level %

### 14.2 — Visualización
- Gauge circular: Salud de batería (0-100%)
- Info cards: Ciclos, Capacidad diseño vs actual, Wear level
- Perfil de energía actual (Balanced, High Performance, Power Saver)
- Estimación de vida útil restante

### 14.3 — Optimización
- Botón "Optimizar para batería" → cambiar a Power Saver + ajustes
- Botón "Optimizar para rendimiento" → High Performance
- Detección automática: si es laptop, mostrar tab Battery

**Archivos a modificar:**
- `SysOpt.ps1` — Funciones Get-BatteryHealth, Set-PowerProfile
- `assets/lang/*.json` — ~20 claves
- `assets/xaml/MainWindow.xaml` — Tab/Panel Battery (condicional)

---

## FASE 15: Gestor de Bloatware (~2h, Media)

Detectar y desinstalar apps preinstaladas de Windows.

### 15.1 — Detección de bloatware
- Lista categorizada de apps conocidas:
  - **Microsoft**: Cortana, Xbox apps, Mixed Reality, People, Maps, Weather
  - **OEM**: Dell SupportAssist, HP Wolf, Lenovo Vantage (detectar fabricante)
  - **Juegos**: Candy Crush, Bubble Witch, Farm Heroes
  - **Otros**: TikTok, Spotify (preinstalado), Disney+
- Usar `Get-AppxPackage` y `Get-AppxProvisionedPackage`
- Clasificar: Seguro eliminar / Precaución / No recomendado

### 15.2 — UI
- ListView con checkbox, icono, nombre, tamaño, categoría, riesgo
- Filtros: Categoría, Riesgo, Tamaño
- Botón "Seleccionar todo seguro" (solo verde)
- Preview de espacio a liberar

### 15.3 — Desinstalación
- `Remove-AppxPackage` para usuario actual
- `Remove-AppxProvisionedPackage` para evitar re-instalación
- Opción "Prevenir re-instalación" (registro)
- Log detallado de cada acción
- Restore point automático antes de desinstalar

### 15.4 — DLL: SysOpt.Bloatware.dll
- `BloatwareItem` — modelo con Name, PackageName, Category, Risk, Size
- `BloatwareScanner` — detección y clasificación
- `BloatwareRemover` — desinstalación segura

**Archivos a crear:**
- `libs/csproj/SysOpt.Bloatware.cs`
- `libs/csproj/SysOpt.Bloatware.csproj`
- `assets/xaml/BloatwareWindow.xaml` (nueva ventana)

---

## FASE 16: Privacy Scanner (~2h, Media)

Detectar y limpiar telemetría de Windows, cookies y tracking apps.

### 16.1 — Categorías de privacidad
- **Telemetría Windows**: DiagTrack, Connected User Experiences, Feedback
- **Tracking**: Advertising ID, Activity History, Location tracking
- **Datos**: Clipboard history, Inking & typing, Speech recognition
- **Browser**: Cookies, autofill, history (Edge, Chrome, Firefox)
- **Apps**: Permisos de cámara, micrófono, ubicación por app

### 16.2 — Scanner
- Escanear registro para configuraciones de telemetría
- Detectar servicios de tracking activos
- Listar permisos de apps (Privacy settings)
- Puntaje de privacidad (0-100, similar al score de optimización)

### 16.3 — Correcciones
- Toggle por categoría: Desactivar telemetría, limpiar tracking, etc.
- Perfil "Privacidad máxima" (aplica todo)
- Perfil "Equilibrado" (mantiene funcionalidad básica)
- Cada fix muestra qué se pierde al desactivar

### 16.4 — DLL: SysOpt.Privacy.dll
- `PrivacyItem` — modelo con Category, Name, Status, Risk
- `PrivacyScanner` — detección
- `PrivacyFixer` — aplicar correcciones con rollback

**Archivos a crear:**
- `libs/csproj/SysOpt.Privacy.cs`
- `libs/csproj/SysOpt.Privacy.csproj`
- `assets/xaml/PrivacyWindow.xaml`

---

## FASE 17: Monitor en Tiempo Real (~2h, Media)

Widget flotante mini con CPU/RAM/Disco siempre visible en esquina del escritorio.

### 17.1 — Ventana flotante
- WPF Window: `Topmost=True`, `WindowStyle=None`, `AllowsTransparency=True`
- Tamaño compacto: ~200x120px
- Draggable (MouseDragMove)
- Opacity configurable (60-100%)
- Posición persistida en registro

### 17.2 — Métricas en tiempo real
- CPU %: PerformanceCounter o WMI con DispatcherTimer (1s interval)
- RAM %: `[MemoryHelper]::GetUsedRamPercent()`
- Disco %: actividad de disco vía PerformanceCounter
- Red: velocidad de descarga/subida actual
- Mini gráficas sparkline (últimos 30 segundos)

### 17.3 — Interacción
- Click derecho → menú contextual (Abrir SysOpt, Cerrar monitor, Configurar)
- Doble click → abrir ventana principal
- Hotkey configurable para mostrar/ocultar (ej: Ctrl+Shift+M)
- Se minimiza a system tray si se cierra

### 17.4 — XAML
- `MonitorWidget.xaml` — ventana flotante
- Theme-aware: usa colores del tema activo

**Archivos a crear:**
- `assets/xaml/MonitorWidget.xaml`

**Archivos a modificar:**
- `SysOpt.ps1` — Funciones Show/Hide-MonitorWidget, Update-MonitorData
- `assets/lang/*.json` — ~15 claves

---

## FASE 18: Temperaturas + Salud de Disco (~2h, Media)

Leer S.M.A.R.T. del SSD/HDD y mostrar temperatura CPU vía WMI.

### 18.1 — Temperatura CPU
- WMI: `MSAcpi_ThermalZoneTemperature` (requiere admin)
- Fallback: `Win32_TemperatureProbe`
- Mostrar en °C y °F (configurable)
- Color coding: Verde (<60°C), Amarillo (60-80°C), Rojo (>80°C)

### 18.2 — S.M.A.R.T. Disco
- WMI: `MSStorageDriver_FailurePredictStatus`, `MSStorageDriver_FailurePredictData`
- Atributos clave:
  - Reallocated Sectors Count
  - Power-On Hours
  - Temperature
  - Remaining Life (SSD)
  - Total Bytes Written (SSD)
- Puntaje de salud del disco (0-100%)

### 18.3 — Visualización
- Panel con gauge para cada disco detectado
- Tabla de atributos S.M.A.R.T. con status
- Alerta si algún atributo está en estado crítico
- Historial de temperatura (mini gráfico últimas 24h si monitor activo)

### 18.4 — DLL: SysOpt.HwMonitor.dll
- `CpuTemperature` — lectura de temperatura CPU
- `SmartData` — parser de datos S.M.A.R.T.
- `DiskHealth` — cálculo de salud del disco

**Archivos a crear:**
- `libs/csproj/SysOpt.HwMonitor.cs`
- `libs/csproj/SysOpt.HwMonitor.csproj`

**Archivos a modificar:**
- `SysOpt.ps1` — Integración en tab Rendimiento
- `assets/lang/*.json` — ~30 claves

---

## FASE 19: Historial de Rendimiento (~3h, Alta)

Guardar snapshots en SQLite local + gráficas de tendencia.

### 19.1 — Base de datos local
- SQLite via `System.Data.SQLite` (NuGet) o fichero JSON simple
- Esquema:
  ```sql
  CREATE TABLE metrics (
      id INTEGER PRIMARY KEY,
      timestamp TEXT,
      cpu_percent REAL,
      ram_percent REAL,
      ram_used_mb INTEGER,
      disk_percent REAL,
      disk_read_bps INTEGER,
      disk_write_bps INTEGER,
      net_down_bps INTEGER,
      net_up_bps INTEGER,
      score INTEGER
  );
  ```
- Retención configurable (7, 30, 90 días)

### 19.2 — Recolección automática
- Si Monitor en Tiempo Real activo → guardar cada 5 minutos
- Si Limpieza Programada → guardar snapshot antes y después
- Snapshot manual desde tab Rendimiento

### 19.3 — Gráficas
- LineChart con ejes X (tiempo) e Y (valor)
- Series: CPU, RAM, Disco, Red, Score
- Rangos: Última hora, 24h, 7 días, 30 días
- Zoom y pan interactivo
- WPF nativo: usar Polyline + Canvas (sin dependencias externas)

### 19.4 — DLL: SysOpt.MetricsStore.dll
- `MetricsDb` — CRUD SQLite o JSON
- `MetricsAggregator` — promedios, min/max, tendencias
- `ChartDataBuilder` — preparar datos para renderizado

### 19.5 — Exportación
- Exportar historial a CSV/JSON/HTML (reusar export de Fase 3)
- Gráfica exportable como PNG

**Archivos a crear:**
- `libs/csproj/SysOpt.MetricsStore.cs`
- `libs/csproj/SysOpt.MetricsStore.csproj`

**Archivos a modificar:**
- `SysOpt.ps1` — Tab Rendimiento con sección Historial
- `assets/lang/*.json` — ~35 claves
- `assets/xaml/MainWindow.xaml` — Panel de gráficas


## 📝 Registro de Sesiones

| Fecha | Sesión | Fase | Duración | Cambios principales |
|-------|--------|------|----------|---------------------|
| Feb 2025 | 1–3 | 0 | ~6h | Pills, score circle, AV detection, dry-run, HTML reports |
| Feb 2025 | 4 | 1 | ~2h | Split Core.dll → Core + Collector + Cleanup, lazy loading |
| Feb 2025 | 5–6 | 2 | ~1.5h | Deduplicación Loc, eliminar wrappers triviales |
| Mar 2025 | 6–7 | 3 | ~4h | Exports CSV/JSON, filtros FolderScanner, 22 optimizaciones, output/ |
| 10/03/2026 | 8 | 4 | ~1.5h | Diagnóstico paralelo (5 collectors, 13s→3-5s), BootMs type-safe fix |


### 🔴 PRIORIDAD INMEDIATA — Pruebas SFC/DISM

> **Fecha de adición:** 10/03/2026  
> **Razón:** Se detectó que SFC no ejecutaba correctamente ni mostraba progreso. Fix aplicado pero requiere validación en entorno real.

**Checklist de pruebas:**

| # | Test | Modo | Verificar |
|---|------|------|-----------|
| 1 | SFC DRY RUN | Análisis | Muestra "[DRY RUN] Se ejecutaría: sfc.exe /scannow" |
| 2 | SFC REAL | Ejecución | Barra muestra "SFC /SCANNOW: X%", consola en tiempo real |
| 3 | SFC UI | Visual | No se congela la interfaz durante 10-30 min |
| 4 | SFC CBS.log | Post-exec | Últimas 20 líneas del CBS.log mostradas |
| 5 | SFC exit codes | Post-exec | 0=OK, 1=Reparado, 2=Corrupto, 3=Error |
| 6 | DISM DRY RUN | Análisis | Muestra mensaje simulación |
| 7 | DISM 3 pasos | Ejecución | "Paso 1/3", "Paso 2/3", "Paso 3/3" visibles |
| 8 | DISM progreso | Visual | Porcentaje actualizado por paso |
| 9 | Diagnóstico paralelo | Ejecución | 5 collectors completan en <5s |
| 10 | Exports CSV/JSON | Ejecución | Archivos guardados en ./output/ |


## 🎯 Estrategia de Implementación (Fases 5–19)

### Prioridad Alta — v3.3.0-STABLE (Fases 5–9, ~8h)

Estas fases completan la versión estable. Se implementan en orden secuencial:

| Fase | Descripción | Tiempo | Dependencias | Archivos clave |
|------|-------------|--------|--------------|----------------|
| **5** | Toast Notifications | ~1h | Ninguna | SysOpt.ps1, Toast.dll |
| **6** | Sistema de Módulos | ~2h | Ninguna | ISysOptModule interface, module loader |
| **7** | Módulo Office | ~2h | Fase 6 | SysOpt.Module.Office.dll |
| **8** | Responsive UI | ~1h | Ninguna | MainWindow.xaml |
| **9** | Polish + Release | ~1.5h | Todas | Testing, docs, release |

**Estrategia**: Fases 5 y 8 son independientes (se pueden hacer en paralelo). Fase 7 requiere la infra de Fase 6. Fase 9 es el cierre final.

### Prioridad Media — v3.4.0 (Fases 10–14, ~5.5h)

Nuevas funcionalidades del sistema. Cada fase es independiente (excepto 11 que se beneficia de 10):

| Fase | Descripción | Tiempo | Nueva DLL | Complejidad |
|------|-------------|--------|-----------|-------------|
| **10** | Restore Points | ~1h | — | Baja |
| **11** | Limpieza Programada | ~1h | — | Media (Task Scheduler) |
| **12** | Game Mode | ~1.5h | GameMode.dll | Media |
| **13** | DNS Optimizer | ~1h | — | Baja |
| **14** | Battery Health | ~1h | — | Baja (solo laptops) |

**Estrategia**: Empezar por Fase 10 (cimiento para auto-restore antes de optimizar). Fase 12 es la más compleja (nueva DLL). Fases 13-14 son quick wins independientes.

### Prioridad Baja — v3.5.0 (Fases 15–19, ~11h)

Features avanzadas con DLLs nuevas. Orden recomendado por dependencias:

| Fase | Descripción | Tiempo | Nueva DLL | Nuevo XAML | Deps |
|------|-------------|--------|-----------|------------|------|
| **15** | Bloatware Manager | ~2h | Bloatware.dll | BloatwareWindow.xaml | Fase 10 (restore) |
| **16** | Privacy Scanner | ~2h | Privacy.dll | PrivacyWindow.xaml | — |
| **17** | Monitor Tiempo Real | ~2h | — | MonitorWidget.xaml | — |
| **18** | Temps + S.M.A.R.T. | ~2h | HwMonitor.dll | — | — |
| **19** | Historial Rendimiento | ~3h | MetricsStore.dll | — | Fase 17 + 11 |

**Estrategia**: Fases 15-18 son independientes y se pueden intercalar. Fase 19 es la más ambiciosa y requiere Fase 17 (monitor) como fuente de datos.

### Resumen de recursos necesarios:

| Versión | Fases | Horas est. | DLLs nuevas | XAMLs nuevos | Lang keys nuevas est. |
|---------|-------|------------|-------------|--------------|----------------------|
| v3.3.0-STABLE | 5–9 | ~8h | 0 | 0 | ~30 |
| v3.4.0 | 10–14 | ~5.5h | 1 (GameMode) | 0 | ~50 |
| v3.5.0 | 15–19 | ~11h | 4 (Bloatware, Privacy, HwMonitor, MetricsStore) | 3 (Bloatware, Privacy, Monitor) | ~120 |
| **Total** | **5–19** | **~24.5h** | **5** | **3** | **~200** |


## 📅 Cronograma Estimado

| Sesión | Fase | Duración est. | Entregable |
|--------|------|--------------|------------|
| 4 | FASE 1: Split Core.dll | 2h | ✅ 3 nuevas DLLs + lazy loading |
| 5 | FASE 1: Testing + FASE 2 | 1.5h | ✅ Loc deduplicada, wrappers limpiados |
| 6 | FASE 2: Refactoring + FASE 3 inicio | 2h | Feature A parcial |
| 7 | FASE 3: Feature A cierre | 2h | Snapshots, dedup, export |
| 8 | FASE 4: Rendimiento diag | 1.5h | 13s → 5s |
| 9 | FASE 5: Toast system | 1h | Toasts completos |
| 10 | FASE 6: Module system | 2h | ISysOptModule + discovery |
| 11 | FASE 7: Office module | 2h | Módulo Office funcional |
| 12 | FASE 8: Responsive UI | 1h | Layout adaptable |
| 13 | FASE 9: Polish + v3.3.0-STABLE | 1.5h | Testing final, docs |
| 14 | FASE 10: Restore Points | 1h | Puntos de restauración auto |
| 15 | FASE 11: Limpieza Programada | 1h | Scheduler + Task Scheduler |
| 16 | FASE 12: Game Mode | 1.5h | Perfil gaming + rollback |
| 17 | FASE 13: DNS Optimizer | 1h | Benchmark + auto-config DNS |
| 18 | FASE 14: Battery Health | 1h | Salud batería + perfiles energía |
| 19 | FASE 15: Gestor Bloatware | 2h | Scanner + desinstalador apps |
| 20 | FASE 16: Privacy Scanner | 2h | Telemetría + privacy score |
| 21 | FASE 17: Monitor Tiempo Real | 2h | Widget flotante + sparklines |
| 22 | FASE 18: Temperaturas + SMART | 2h | Temp CPU + salud disco |
| 23 | FASE 19: Historial Rendimiento | 3h | SQLite + gráficas tendencia |

---

## 🔮 Post v3.3.0 — Roadmap Enterprise

| Versión | Feature | Descripción |
|---------|---------|-------------|
| v3.4.0 | New Features Pack 1 | Fases 10-14: Restore Points, Limpieza Programada, Game Mode, DNS, Battery |
| v3.5.0 | New Features Pack 2 | Fases 15-19: Bloatware, Privacy, Monitor, Temperaturas, Historial |
| v3.6.0 | Agent Mode | Servicio Windows que recolecta métricas en background |
| v3.7.0 | Dashboard Web | Panel web para ver métricas de múltiples endpoints |
| v3.8.0 | Multi-Endpoint | Gestión remota de N equipos desde dashboard central |
| v4.0.0 | Enterprise Agent | Compliance policies, auto-remediation, RBAC |

---

## 📋 Archivos a Modificar por Fase

### FASE 1 — Split Core.dll ✅

| Archivo | Acción | Estado |
|---------|--------|--------|
| `libs/csproj/SysOpt.Core.cs` | Reducir a 8 clases (~624 lín) | ✅ |
| `libs/csproj/SysOpt.Collector.cs` | **NUEVO** — 17 clases (~863 lín) | ✅ |
| `libs/csproj/SysOpt.Cleanup.cs` | **NUEVO** — 2 clases (~820 lín) | ✅ |
| `assets/xaml/MainWindow.xaml` | Versión dinámica `{{APP_VERSION}}` | ✅ |
| `assets/xaml/AboutWindow.xaml` | Versión dinámica `$($script:AppVersion)` | ✅ |
| `SysOpt.ps1` L18 | `$script:AppVersion` como fuente única de versión | ✅ |
| `libs/csproj/SysOpt.Collector.cs` | **NUEVO** — 17 clases (~860 lín) |
| `libs/csproj/SysOpt.Cleanup.cs` | **NUEVO** — 2 clases (~795 lín) |
| `libs/csproj/SysOpt.Collector.csproj` | **NUEVO** |
| `libs/csproj/SysOpt.Cleanup.csproj` | **NUEVO** |
| `libs/csproj/compile-dlls.ps1` | Añadir 2 nuevos targets |
| `SysOpt.ps1` L155-210 | Nuevo load order (12 DLLs) |
| `SysOpt.ps1` ~L325 | Añadir `Ensure-Dll` function |
| `SysOpt.ps1` L7177 | Lazy-load Cleanup en $OptimizationScript |
| `libs/csproj/SysOpt.Optimizer.cs` | Actualizar referencia a Cleanup.dll |

### FASE 2 — Deduplicación

| Archivo | Acción |
|---------|--------|
| `libs/csproj/SysOpt.Diagnostics.cs` | Eliminar `Loc` local, referenciar Core |
| `libs/csproj/SysOpt.Optimizer.cs` | Eliminar `Loc` local, referenciar Core |
| `SysOpt.ps1` | Eliminar 3 wrappers triviales |
