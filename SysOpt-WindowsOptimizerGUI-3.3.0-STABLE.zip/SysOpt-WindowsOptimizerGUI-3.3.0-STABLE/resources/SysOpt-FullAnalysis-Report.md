﻿# SysOpt v3.3.0-DEV — Complete Program Analysis

> Generated: 2026-03-09 | Source: `/SysOpt-WindowsOptimizerGUI-3.3.0-DEV/`
> Main script: `SysOpt.ps1` — 8,045 lines | 12 DLLs | 11 XAML windows | 68 themes | 3 languages (888 keys each)

---

## 1. Project Structure

### 1.1 File Tree (all files with sizes)

| Path | Size | Description |
|------|------|-------------|
| `LICENSE` | 35,218 B | Project license |
| `README.MD` | 44,034 B | Project documentation |
| `SysOpt-v3.3.0-Roadmap.html` | 125,023 B | Development roadmap (HTML) |
| `SysOpt.info` | 10,159 B | PowerShell data file — changelog & metadata |
| `SysOpt.ps1` | ~415 KB | **Main script** — ~8,045 lines, full application |
| `SysOpt_Roadmap.html` | 73,954 B | Legacy roadmap |
| **assets/fonts/** | | |
| `matrix_code_nfi.ttf` | 50,384 B | Matrix Code NFI font (easter egg) |
| **assets/img/** | | |
| `SysOpt.ico` | 165,662 B | Application icon (multi-size ICO) |
| `sysopt.png` | 19,174 B | Logo PNG |
| `sysopt1.png` | 26,687 B | Alternate logo PNG |
| **assets/lang/** | | |
| `en-us.lang` | 54,113 B | English (US) — 888 translation keys |
| `es-es.lang` | 56,345 B | Spanish (Spain) — 888 translation keys |
| `pt-br.lang` | 57,199 B | Portuguese (Brazil) — 888 translation keys |
| **assets/templates/** | | |
| `analysisreport.html` | 23,018 B | HTML template for diagnostic reports |
| `diskreport.html` | 16,832 B | HTML template for disk usage reports |
| **assets/themes/** | | 68 theme files (`.theme` format) |
| *(68 files, ~6.7–6.9 KB each)* | ~464 KB total | See §7 for full list |
| **assets/xaml/** | | |
| `AboutWindow.xaml` | 19,326 B | About dialog |
| `BreakoutWindow.xaml` | 4,283 B | Breakout game window |
| `ChangelogWindow.xaml` | 6,523 B | Changelog viewer |
| `DedupWindow.xaml` | 9,808 B | Duplicate file finder |
| `DiagnosticWindow.xaml` | 65,169 B | System diagnostic window (CSV+JSON export buttons) |
| `FolderScannerWindow.xaml` | 27,117 B | Folder scanner (advanced filters panel) |
| `MainWindow.xaml` | 127,214 B | **Main application window** (JSON export button) |
| `OptionsWindow.xaml` | 26,457 B | Settings dialog |
| `SplashWindow.xaml` | 2,115 B | Splash screen |
| `StartupManagerWindow.xaml` | 10,179 B | Startup programs manager |
| `TasksWindow.xaml` | 21,362 B | Background tasks panel |
| **output/** | | Default export directory (CSV, JSON, HTML, TXT) |
| `.gitkeep` | 0 B | Placeholder to preserve empty dir |
| **libs/** | | Compiled DLLs |
| `SysOpt.Breakout.dll` | 11,776 B | Breakout game engine |
| `SysOpt.Collector.dll` | ~42 KB | Data collection + WMI snapshots (863 lines, 17 classes) |
| `SysOpt.Cleanup.dll` | ~35 KB | System cleanup engine (820 lines, 2 classes) — LAZY |
| `SysOpt.Core.dll` | ~8 KB | Core kernel (split: 624 lines, 8 classes) |
| `SysOpt.Diagnostics.dll` | 46,080 B | System diagnostics engine |
| `SysOpt.DiskEngine.dll` | 16,896 B | Disk scanning engine |
| `SysOpt.MemoryHelper.dll` | 3,584 B | Win32 memory P/Invoke |
| `SysOpt.Optimizer.dll` | 35,840 B | Optimization orchestrator |
| `SysOpt.StartupManager.dll` | 10,240 B | Startup program manager |
| `SysOpt.ThemeEngine.dll` | 11,264 B | Theme parser and applier |
| `SysOpt.Toast.dll` | 11,776 B | Toast notification system |
| `SysOpt.WseTrim.dll` | 4,096 B | Working-set trimmer |
| **libs/csproj/** | | C# source files |
| `DiskEngine.cs` | 17,514 B (427 lines) | Disk scanning models and scanner |
| `MemoryHelper.cs` | 1,042 B (29 lines) | Memory P/Invoke wrappers |
| `SysOpt.Breakout.cs` | 17,623 B (424 lines) | Breakout game engine |
| `SysOpt.Core.cs` | 102,706 B (2,265 lines) | Core classes — the largest C# file |
| `SysOpt.Diagnostics.cs` | 68,861 B (1,300 lines) | Diagnostic analysis engine |
| `SysOpt.Diagnostics.csproj` | 509 B | csproj for Diagnostics |
| `SysOpt.DiskEngine.csproj` | 498 B | csproj for DiskEngine |
| `SysOpt.MemoryHelper.csproj` | 646 B | csproj for MemoryHelper |
| `SysOpt.Optimizer.cs` | 51,407 B (1,193 lines) | Optimization orchestrator |
| `SysOpt.StartupManager.cs` | 15,098 B (398 lines) | Startup manager engine |
| `SysOpt.StartupManager.csproj` | 312 B | csproj for StartupManager |
| `SysOpt.ThemeEngine.cs` | 14,944 B (342 lines) | Theme engine |
| `SysOpt.Toast.cs` | 12,458 B (300 lines) | Toast notifications |
| `SysOpt.WseTrim.csproj` | 486 B | csproj for WseTrim |
| `WseTrim.cs` | 1,586 B (41 lines) | Working-set trim implementation |
| `compile-dlls.ps1` | 12,973 B | DLL compilation script |
| **resources/** | | |
| `SysOpt-SessionReport-2026-03-09.md` | 9,195 B | Session report |

**Totals:** 105 files • ~2.1 MB total (excluding themes ~464 KB)

---

## 2. Architecture Overview

### 2.1 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         SysOpt.ps1                              │
│  PowerShell 5.1+ orchestrator — WPF GUI host (~7,800 lines)    │
│                                                                 │
│  ┌──────────────┐  ┌──────────────┐  ┌───────────────────────┐  │
│  │ XAML Windows  │  │  .lang i18n  │  │  .theme Appearance    │  │
│  │ (11 files)    │  │ (3 languages)│  │  (68 themes)          │  │
│  └──────┬───────┘  └──────┬───────┘  └───────────┬───────────┘  │
│         │                 │                      │              │
│  ┌──────▼─────────────────▼──────────────────────▼───────────┐  │
│  │              PS1 Runtime Engine                            │  │
│  │  • Window creation & event binding                        │  │
│  │  • Background runspace management                         │  │
│  │  • Theme/Language application                             │  │
│  │  • Task management (register, complete, cancel)           │  │
│  └──────────────────────────┬────────────────────────────────┘  │
│                             │ calls                             │
│  ┌──────────────────────────▼────────────────────────────────┐  │
│  │              C# DLL Layer (12 DLLs)                       │  │
│  │                                                           │  │
│  │  Core.dll          ← Kernel: i18n, logging, formatter    │  │
│  │  Collector.dll     ← WMI snapshots, data collection       │  │
│  │  Cleanup.dll       ← System cleanup engine (LAZY)         │  │
│  │  DiskEngine.dll    ← Parallel disk scanner                │  │
│  │  Optimizer.dll     ← Optimization orchestrator            │  │
│  │  Diagnostics.dll   ← System health analysis              │  │
│  │  ThemeEngine.dll   ← Theme parser/applier                 │  │
│  │  Toast.dll         ← WPF toast notifications              │  │
│  │  StartupManager.dll← Startup programs CRUD                │  │
│  │  MemoryHelper.dll  ← Win32 EmptyWorkingSet                │  │
│  │  WseTrim.dll       ← Working-set trimmer                  │  │
│  │  Breakout.dll      ← Easter egg game                      │  │
│  └───────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 Data Flow

1. **PS1 → C# DLLs:** PS1 calls static C# methods for data collection (`SystemDataCollector`), optimization (`OptimizerEngine`), diagnostics (`DiagnosticsEngine`), etc.
2. **C# → PS1:** C# returns typed snapshot objects (CpuSnapshot, RamSnapshot, etc.) consumed by PS1 to populate UI.
3. **PS1 → XAML:** XAML loaded via `XamlLoader::Load()`, parsed via `XamlReader`, and controls bound via `FindName()`.
4. **PS1 → Lang:** `LangEngine::ParseLangFile()` parses `.lang` files into dictionaries; `T()` function resolves keys at runtime.
5. **PS1 → Theme:** `ThemeEngine::ParseThemeFile()` parses `.theme` files; `Get-TC` reads theme colors; `ThemeApplier` applies to WPF tree.
6. **Background Work:** Runspace pools (`Initialize-RunspacePool`) handle CPU-intensive operations (disk scan, optimization, export) without blocking the UI thread. `DispatcherTimer` bridges async results back to UI.

### 2.3 Singleton Instance

Application enforces single instance via `SysOptFallbacks::InitMutex("Global\OptimizadorSistemaGUI_v5")`. Second launches are rejected.

---

## 3. DLL Registry

| # | DLL File | Size | Source Lines | Guard Type | Load Phase | Classes | Hard? |
|---|----------|------|-------------|------------|------------|---------|-------|
| 1 | SysOpt.MemoryHelper.dll | 3,584 B | 29 | `MemoryHelper` | Startup (splash 10%) | 1 | ✅ Hard |
| 2 | SysOpt.DiskEngine.dll | 16,896 B | 427 | `DiskItem_v211` | Startup (splash 17%) | 6 | ✅ Hard |
| 3 | SysOpt.Core.dll | ~8 KB | 624 | `LangEngine` | Startup (splash 24%) | 8 | ✅ Hard |
| 4 | SysOpt.Collector.dll | ~42 KB | 863 | `SystemDataCollector` | Startup (splash 26%) | 17 | ✅ Hard |
| — | SysOpt.Cleanup.dll | ~35 KB | 820 | `CleanupEngine` | Lazy (on first clean) | 2 | ❌ Lazy |
| 5 | SysOpt.ThemeEngine.dll | 11,264 B | 364 | `ThemeEngine` | Startup (splash 31%) | 2 | ✅ Hard |
| 5 | SysOpt.WseTrim.dll | 4,096 B | 41 | `WseTrim` | Startup (splash 38%) | 1 | ❌ Soft |
| 6 | SysOpt.Optimizer.dll | 35,840 B | 1,193 | `SysOpt.Optimizer.OptimizerEngine` | Startup (splash 45%) | 8 | ❌ Soft |
| 7 | SysOpt.StartupManager.dll | 10,240 B | 398 | `SysOpt.StartupManager.StartupEngine` | Startup (splash 52%) | 3 | ❌ Soft |
| 8 | SysOpt.Diagnostics.dll | 46,080 B | 1,300 | `SysOpt.Diagnostics.DiagnosticsEngine` | Startup (splash 59%) | 6 | ❌ Soft |
| 9 | SysOpt.Toast.dll | 11,776 B | 300 | `SysOpt.Toast.ToastManager` | Startup (splash 62%) | 2 | ❌ Soft |
| 10 | SysOpt.Breakout.dll | 11,776 B | 424 | *(loaded on-demand)* | On-demand (Show-BreakoutGame) | 3 | N/A |
| — | *(inline)* DwmHelper | — | ~20 lines | `DwmHelper` | Post-XAML (line 840) | 1 | ❌ Soft |

**Total C# source:** ~6,755 lines across 12 `.cs` files (Core split into Core + Collector + Cleanup). Phase 2 eliminated duplicate Loc classes.

### 3.2 — Planned DLLs (Phases 10-19)

| # | DLL File | Version | Phase | Classes | Description |
|---|----------|---------|-------|---------|-------------|
| 13 | SysOpt.GameMode.dll | v3.4.0 | Phase 12 | `GameModeProfile`, `GameModeManager` | Gaming profiles with service kill/rollback |
| 14 | SysOpt.Bloatware.dll | v3.5.0 | Phase 15 | `BloatwareItem`, `BloatwareScanner`, `BloatwareRemover` | Detect + remove preinstalled apps |
| 15 | SysOpt.Privacy.dll | v3.5.0 | Phase 16 | `PrivacyItem`, `PrivacyScanner`, `PrivacyCleaner` | Windows telemetry + privacy score |
| 16 | SysOpt.HwMonitor.dll | v3.5.0 | Phase 18 | `SmartData`, `TempReader`, `HwMonitorEngine` | S.M.A.R.T. + CPU/GPU temperatures |
| 17 | SysOpt.MetricsStore.dll | v3.5.0 | Phase 19 | `MetricsDb`, `MetricEntry`, `TrendCalculator` | SQLite local + trend graphs |

**New XAML Windows:**
- `BloatwareWindow.xaml` — Bloatware scanner/remover UI (Phase 15)
- `PrivacyWindow.xaml` — Privacy scanner with score gauge (Phase 16)
- `MonitorWidget.xaml` — Floating mini widget CPU/RAM/Disk (Phase 17)



> **Phase 1 note:** Core.dll was split from 2,265 lines into Core (624) + Collector (863) + Cleanup (820).
> Cleanup.dll uses lazy loading — only loaded on first optimization run.

---

## 4. C# Class Reference

### 4.1 SysOpt.Core.dll — `SysOpt.Core.cs` (624 lines) — HARD load

#### 4.1.1 `public static class Loc` (L39–L52)
Localization bridge for Core DLL.
- `SetDict(Dictionary<string,string> d)` — Sets the localization dictionary
- `T(string key, string fallback)` — Translates a key with fallback
- **PS1 callers:** `Load-Language` (via `[Loc]::SetDict()`)

#### 4.1.2 `public static class LangEngine` (L54–L124)
Language file parser.
- `ParseLangFile(string path) → Dictionary<string,string>` — Parses `.lang` files (key=value format)
- `GetLangMeta(string path) → Dictionary<string,string>` — Extracts metadata (Name, Author, etc.)
- `ListLanguages(string langFolder) → string[]` — Lists available language codes
- **PS1 callers:** `Load-Language`, `Show-OptionsWindow`

#### 4.1.3 `public static class XamlLoader` (L126–L156)
External XAML file loader.
- `Load(string xamlFolder, string name) → string` — Loads XAML content by name
- `ListXaml(string xamlFolder) → string[]` — Lists available XAML files
- **PS1 callers:** MainWindow load (L416), `Show-OptionsWindow`, `Show-BreakoutGame`, `Show-TasksWindow`, `Show-StartupManager`, `Show-DiagnosticReport`, `Show-FolderScanner`, DedupWindow

#### 4.1.4 `public static class SettingsHelper` (L158–L189)
JSON settings file reader.
- `ReadKey(string jsonPath, string key) → string` — Reads a key from settings JSON
- **PS1 callers:** not directly called (utility)

#### 4.1.5 `public static class ScanTokenManager` (L191–L270)
Cancellation token management for scan operations.
- `RequestNew()` — Creates a new CancellationTokenSource
- `Cancel()` — Cancels current token → sets ScanCtl211.Stop = true
- `GetCtsWithTimeout(int timeoutMs) → CancellationTokenSource` — Token with timeout
- `Dispose()` — Disposes current CTS
- Properties: `Token`, `IsCancelled`
- **PS1 callers:** CTK initialization (L212–213), `Start-DiskScan`, scan cancel buttons, `Save-Settings`

#### 4.1.6 `public class CpuSnapshot` (L272–L286)
Data model for CPU state.
- Properties: `Name`, `Cores`, `LogicalProcessors`, `LoadPercent`, `ClockMhz`, `MaxClockMhz`, `TemperatureCelsius`, `CoreLoads[]`, `Timestamp`
- **PS1 callers:** `Update-SystemInfo`, `Update-PerformanceTab`

#### 4.1.7 `public class RamSnapshot` (L288–L301)
Data model for RAM state.
- Properties: `TotalBytes`, `UsedBytes`, `FreeBytes`, `UsedPercent`, `PageFileTotalBytes`, `PageFileUsedBytes`, `PageFileUsedPercent`, `Modules`, `Timestamp`
- **PS1 callers:** `Update-SystemInfo`, `Update-PerformanceTab`, `Show-FolderScanner`

#### 4.1.8 `public class RamModuleInfo` (L303–L313)
Data model for individual RAM module.
- Properties: `Slot`, `CapacityBytes`, `Type`, `SpeedMhz`, `Manufacturer`

#### 4.1.9 `public class DiskSnapshot` (L315–L329)
Data model for disk state.
- Properties: `Drives`, `Volumes`, `ReadBytesPerSec`, `WriteBytesPerSec`, `ActivityPercent`, `Timestamp`
- **PS1 callers:** `Update-SystemInfo`, `Update-PerformanceTab`

#### 4.1.10 `public class DiskDriveInfo` (L331–L342)
Physical disk drive details.
- Properties: `FriendlyName`, `MediaType`, `BusType`, `SizeBytes`, `HealthStatus`, `PowerOnHours`, `TemperatureCelsius`, `ReadErrorsTotal`, `WearPercent`

#### 4.1.11 `public class DiskVolumeInfo` (L344–L355)
Disk volume details.
- Properties: `DeviceId`, `Label`, `FileSystem`, `TotalBytes`, `FreeBytes`, `UsedPercent`

#### 4.1.12 `public class NetworkSnapshot` (L357–L363)
Network state snapshot.
- Properties: `Adapters`, `Timestamp`

#### 4.1.13 `public class NetworkAdapterInfo` (L365–L382)
Network adapter details.
- Properties: `Name`, `Description`, `Type`, `MacAddress`, `IpAddress`, `Gateway`, `IsUp`, `SpeedBps`, `RxBytesPerSec`, `TxBytesPerSec`, `TotalRxBytes`, `TotalTxBytes`

#### 4.1.14 `public class GpuSnapshot` (L384–L390)
GPU state snapshot.
- Properties: `Gpus`, `Timestamp`

#### 4.1.15 `public class GpuInfo` (L392–L403)
GPU details.
- Properties: `Name`, `DriverVersion`, `AdapterRamBytes`, `VideoModeDesc`, `Status`, `TemperatureCelsius`

#### 4.1.16 `public class PortSnapshot` (L405–L416)
Open port state snapshot.
- Properties: `TcpPorts`, `UdpPorts`, `Timestamp`

#### 4.1.17 `public class OpenPortInfo` (L418–L431)
Individual port details.
- Properties: `LocalPort`, `LocalAddress`, `RemotePort`, `RemoteAddress`, `State`, `Pid`, `ProcessName`

#### 4.1.18 `public class SystemSnapshot` (L433–L465)
Full system state aggregator.
- Properties: `MachineName`, `OsCaption`, `OsVersion`, `OsBuild`, `BootTime`, `Timestamp`, `Cpu`, `Ram`, `Disk`, `Network`, `Gpu`, `Ports`
- **PS1 callers:** auto-refresh timer, `AgentBus::EvaluateAndDispatch`

#### 4.1.19 `public static class SystemDataCollector` (L467–L1000)
**Core data access layer (DAL)** — replaces all direct WMI queries.
- `EnsureDiskCounters()` — (private) Initializes performance counters
- `GetCpuSnapshot() → CpuSnapshot` — CPU name, cores, load, clock, temperature
- `GetRamSnapshot() → RamSnapshot` — RAM total/used/free, modules
- `GetDiskSnapshot() → DiskSnapshot` — Drives, volumes, I/O counters
- `GetNetworkSnapshot() → NetworkSnapshot` — Adapters with speeds
- `GetGpuSnapshot() → GpuSnapshot` — GPUs via WMI
- `GetPortSnapshot() → PortSnapshot` — TCP/UDP open ports
- `GetFullSnapshot() → SystemSnapshot` — Aggregates all above
- Helper methods: `SafeStr`, `SafeInt`, `SafeLong`, `SafeDouble`
- **PS1 callers:** `Update-SystemInfo`, `Update-PerformanceTab`, auto-refresh timer, `Show-FolderScanner`

#### 4.1.20 `public class AgentThresholds` (L1002–L1025)
Threshold configuration for the agent bus.
- Properties: `CpuLoadPercent`, `RamUsedPercent`, `DiskActivityPercent`, `DiskUsedPercent`, `DiskTempCelsius`, `SnapshotIntervalSec`

#### 4.1.21 `public interface IAgentTransport` (L1027–L1044)
Plugin interface for external agent communication.

#### 4.1.22 `public static class AgentBus` (L1046–L1112)
Event-driven bus for monitoring agents.
- Properties: `IsAgentEnabled`, `Transport`, `Thresholds`
- `EvaluateAndDispatch(SystemSnapshot snapshot)` — Checks thresholds and dispatches alerts
- **PS1 callers:** auto-refresh timer (when agent enabled)

#### 4.1.23 `public static class LogEngine` (L1114–L1285)
File-based logging system.
- Properties: `DebugEnabled`
- `Initialize(string logDir)` — Initializes log directory and creates day file
- `Header(string appName, string version)` — Writes startup header
- `Write(string message, string level)` — Writes a log entry
- `Close()` — Flushes and closes
- Private: `EnsureDay()`, `CloseWriter()`, `WriteRaw()`
- **PS1 callers:** `Initialize-Logger`, `Write-Log`, `Show-OptionsWindow`, debug toggle

#### 4.1.24 `public static class SysOptFallbacks` (L1287–L1423)
Bootstrap and DLL loading management.
- `InitMutex(string mutexName)` — Creates singleton mutex
- `AcquireMutex() → bool` — Tries to acquire mutex
- `ReleaseMutex()` — Releases mutex
- `DisposeMutex()` — Disposes mutex
- `IsLoaded(string guardType) → bool` — Checks if a DLL is already loaded
- `RegisterLoaded(string guardType)` — Marks a DLL as loaded
- `LoadDll(string path, string guardType, bool hard)` — Safe DLL loader with guard
- Property: `RunspacePoolAvailable`
- **PS1 callers:** `Load-SysOptDll` (L121), window close (L7586), `Initialize-RunspacePool`

#### 4.1.25 `public static class Formatter` (L1425–L1469)
Human-readable formatters.
- `FormatBytes(long bytes) → string` — "1.23 GB"
- `FormatRate(double bps) → string` — "12.3 MB/s"
- `FormatLinkSpeed(ulong bps) → string` — "1 Gbps"
- `ParseLinkBps(string raw) → ulong` — Parses link speed strings
- **PS1 callers:** `Format-Bytes`, `Format-Rate`, `Get-LinkBps`, `Update-SystemInfo`, disk scan display, many UI formatters

#### 4.1.26 `public class CleanupResult` (L1471–L1489)
Result model for cleanup operations.
- Properties: `FreedMB`, `FilesProcessed`, `Errors`, `Success`, `Summary`, `Messages`

#### 4.1.27 `public static class CleanupEngine` (L1491–L2263)
**Comprehensive cleanup operations.**
- `CleanPaths(string[] paths, bool dryRun) → CleanupResult` — Deletes files in given paths
- `EmptyRecycleBin(bool dryRun) → CleanupResult` — Empties recycle bin
- `CleanBrowserCaches(bool dryRun) → CleanupResult` — Cleans Chrome/Edge/Firefox caches
- `CleanRegistryOrphans(bool dryRun) → CleanupResult` — Removes orphaned registry keys
- `CleanEventLogs(string[] logNames, bool dryRun) → CleanupResult` — Clears Windows event logs
- `FlushDns(bool dryRun) → CleanupResult` — Flushes DNS cache
- `BackupRegistry(string outputFolder, bool dryRun) → CleanupResult` — Exports registry backup
- `RunExternalTool(string fileName, string arguments, int timeoutMs) → CleanupResult` — Runs external tools
- `RunSfc(bool dryRun) → CleanupResult` — Runs System File Checker
- `RunDism(bool dryRun) → CleanupResult` — Runs DISM repair
- Private: `GetDirectorySize()`, `SafeEnumerateEntries()`
- **PS1 callers:** Called by OptimizerEngine methods (DoTempFiles, DoRecycleBin, etc.)

---


### 4.1b SysOpt.Collector.dll — `SysOpt.Collector.cs` (863 lines) — HARD load

> **New in v3.3.0 Phase 1:** Extracted from Core.dll. Contains 17 snapshot/data classes + SystemDataCollector.

> **New in v3.3.0 Phase 3:** Added CSV/JSON export for diagnostics, JSON export for disk (server sync ready).
> Advanced folder scanner filters (size, date, extension categories). 22 performance optimizations applied.
> All exports default to `./output/` directory. 888 lang keys per language (was 860).

| Class | Lines | Purpose |
|-------|-------|---------|
| `CpuSnapshot` | L34 | CPU data model |
| `RamSnapshot` | L50 | RAM data model |
| `RamModuleInfo` | L65 | RAM module details |
| `DiskSnapshot` | L77 | Disk data model |
| `DiskDriveInfo` | L93 | Physical disk info |
| `DiskVolumeInfo` | L106 | Volume/partition info |
| `NetworkSnapshot` | L119 | Network data model |
| `NetworkAdapterInfo` | L127 | Network adapter details |
| `GpuSnapshot` | L146 | GPU data model |
| `GpuInfo` | L154 | GPU details |
| `PortSnapshot` | L167 | Open ports model |
| `OpenPortInfo` | L180 | Port details |
| `SystemSnapshot` | L195 | Aggregate system snapshot |
| `SystemDataCollector` | L229 | WMI data collection engine (535 lines) |
| `AgentThresholds` | L764 | Alert threshold config |
| `IAgentTransport` | L789 | Agent transport interface |
| `AgentBus` | L808 | Agent event bus |

### 4.1c SysOpt.Cleanup.dll — `SysOpt.Cleanup.cs` (820 lines) — LAZY load

> **New in v3.3.0 Phase 1:** Extracted from Core.dll. Loaded on-demand when user runs optimization.

| Class | Lines | Purpose |
|-------|-------|---------|
| `CleanupResult` | L26 | Cleanup operation result DTO |
| `CleanupEngine` | L46 | Full cleanup engine (temp files, browser cache, WU cache, registry, etc.) |

### 4.2 SysOpt.DiskEngine.dll — `DiskEngine.cs` (427 lines)

#### 4.2.1 `public class DiskItem_v211` (L27–L59)
Data model for a scanned file/directory.
- Properties: `DisplayName`, `FullPath`, `ParentPath`, `SizeBytes`, `SizeStr`, `SizeColor`, `PctStr`, `FileCount`, `DirCount`, `IsDir`, `HasChildren`, `Icon`, `Indent`, `BarWidth`, `BarColor`, `TotalPct`, `Depth`, `ToggleVisibility`, `ToggleIcon`

#### 4.2.2 `public class DiskItemToggle_v230 : INotifyPropertyChanged` (L61–L107)
Observable wrapper for DiskItem with expand/collapse state.
- Property: `Item`
- Implements `INotifyPropertyChanged`

#### 4.2.3 `public static class ScanCtl211` (L109–L146)
Scan control (progress/cancellation state).
- Properties: `Done`, `Total`, `Current`, `Stop`
- `SetToken(CancellationToken token)` — Bridges CancellationToken to Stop flag
- `Reset()` — Resets counters
- **PS1 callers:** `Start-DiskScan`, scan cancel, scan progress polling

#### 4.2.4 `public static class PScanner211` (L148–L222)
Parallel directory scanner.
- `ScanDir(string root, int maxDepth, IList<DiskItem_v211> result, int maxItems, ...) → long` — Scans directory tree
- **PS1 callers:** `Start-DiskScan` (background runspace)

#### 4.2.5 `public class DiskResult` (L224–L242)
Result model for disk optimization.
- Properties: `FreedMB`, `FilesProcessed`, `Errors`, `Success`, `Summary`, `Messages`

#### 4.2.6 `public class VolumeInfo` (L244–L252)
Volume information model.
- Properties: `DriveLetter`, `SizeGB`, `FreeGB`, `MediaType`, `IsSSD`, `IsNVMe`

#### 4.2.7 `public static class DiskOptimizer` (L254–L427)
Disk optimization operations.
- `GetFixedVolumes() → VolumeInfo[]` — Lists fixed volumes
- `OptimizeVolume(string driveLetter, bool isSSD, bool dryRun) → DiskResult` — Optimizes a volume (defrag/trim)
- `ScheduleChkdsk(string drive, bool dryRun) → DiskResult` — Schedules CHKDSK
- **PS1 callers:** OptimizerEngine.DoOptimizeDisks, OptimizerEngine.DoChkdsk

---

### 4.3 SysOpt.Diagnostics.dll — `SysOpt.Diagnostics.cs` (1,285 lines)

> **Phase 2 note:** Local `Loc` class removed — now uses `Loc` from Core.dll (global namespace).

#### 4.3.1 `public class DiagInput` (L17–L115)
Input data model for diagnostic analysis — 30+ properties.
- Cleanup sizes: `TempFilesMB`, `UserTempMB`, `RecycleBinMB`, `WUCacheMB`, `BrowserCacheMB`, `DnsEntries`, `OrphanedKeys`, `EventLogsMB`
- System: `RamUsedPct`, `DiskCUsedPct`, `ComputerName`, `CpuModel`, `OsVersion`, `RamTotalGB`, `RamFreeGB`, `DiskTotalGB`, `DiskFreeGB`
- Counts: `TempFileCount`, `StartupCount`, `ServicesBloatCount`, `ServicesTotalCount`
- Runtime: `UptimeHours`
- Security: `AntivirusName`, `AntivirusEnabled`, `FirewallEnabled`, `FirewallName`, `UacLevel`, `WindowsUpdateOk`, `WindowsUpdateDetail`
- Health: `SfcStatus`, `SfcDetail`, `SmartOkC`, `SmartDetailC`, `BootTimeSeconds`, `CriticalSvcOk`, `CriticalSvcTotal`, `StoppedCriticalSvcNames`, `NetworkConnected`, `NetworkDetail`, `DnsResolutionOk`, `DnsLatencyMs`

#### 4.3.3 `public class DiagItem` (L117–L132)
Single diagnostic check result.
- Properties: `IsSection`, `SectionTitle`, `SectionIcon`, `Status`, `Label`, `Detail`, `Action`, `Deduction`, `ExportLine`

#### 4.3.4 `public class DiagResult` (L134–L148)
Complete diagnostic analysis result.
- Properties: `Items`, `Score` (0–100), `CritCount`, `WarnCount`, `OkCount`, `SkipCount`, `InfoCount`, `ScoreLabel`, `ScoreColor`, `ExportLines`

#### 4.3.5 `public class HtmlReportParams` (L150–L164)
Parameters for HTML report generation.
- Properties: `TemplateHtml`, `AppVersion`, `LogoBase64`, `AnalysisTime`

#### 4.3.6 `public static class DiagnosticsEngine` (L166–L1300)
**Core diagnostic analysis and reporting.**
- `Analyze(DiagInput report) → DiagResult` — Runs 30+ diagnostic checks, assigns 0–100 score
- `GenerateHtmlReport(DiagInput, DiagResult, HtmlReportParams) → string` — Generates full HTML report with SVG pie chart
- Private: `BuildSystemInfoItems()`, `AppendInfoItem()`, `BuildCheckRows()`, `BuildPieSlices()`, `BuildRecommendations()`, `GroupSections()`, `BuildFullCirclePath()`, `GetStatusBadge()`, `FormatGB()`, `Enc()`, `AddSection()`, `AddRow()`
- **PS1 callers:** `Show-DiagnosticReport`

---

### 4.4 SysOpt.Optimizer.dll — `SysOpt.Optimizer.cs` (1,180 lines)

> **Phase 2 note:** Local `Loc` class removed — now uses `Loc` from Core.dll (global namespace).

#### 4.4.1 `public class OptimizeOptions` (L40–L63)
Option flags for optimization.
- Properties: `DryRun`, `OptimizeDisks`, `RecycleBin`, `TempFiles`, `UserTemp`, `WUCache`, `Chkdsk`, `ClearMemory`, `CloseProcesses`, `DNSCache`, `BrowserCache`, `BackupRegistry`, `CleanRegistry`, `SFC`, `DISM`, `EventLogs`, `AutoRestart`

#### 4.4.3 `public class OptimizeProgress` (L87–L97)
Progress callback data.
- Properties: `TaskName`, `Percent`, `Message`, `Status`, `IsError`

#### 4.4.4 `public class TaskResult` (L99–L115)
Individual task result.
- Properties: `TaskName`, `Success`, `FreedMB`, `ItemsCount`, `Messages`, `Error`

#### 4.4.5 `public class DiagnosticData` (L117–L135)
Post-optimization diagnostic data.
- Properties: `TempFilesMB`, `UserTempMB`, `RecycleBinMB`, `WUCacheMB`, `BrowserCacheMB`, `DnsEntries`, `OrphanedKeys`, `EventLogsMB`, `RamUsedPct`, `DiskCUsedPct`, `StartupCount`, `ServicesBloatCount`, `ServicesTotalCount`, `UptimeHours`

#### 4.4.6 `public class OptimizeResult` (L137–L162)
Full optimization session result.
- Properties: `Cancelled`, `IsDryRun`, `Tasks`, `TotalFreedMB`, `TotalTasks`, `CompletedTasks`, `Duration`, `DiagData`, `Summary`

#### 4.4.7 `public static class WUCacheManager` (L164–L289)
Windows Update cache cleaner.
- `Clean(bool dryRun) → TaskResult`
- Private: `GetDirectorySizeMB()`, `StopService()`, `StartService()`

#### 4.4.8 `public static class ProcessManager` (L291–L460)
Process management for optimization.
- `ClearMemory(bool dryRun) → TaskResult` — Trims working sets of all processes
- `CloseNonCritical(bool dryRun) → TaskResult` — Closes non-critical processes
- Private: `GetParentPid()`, `CriticalProcesses` (HashSet)

#### 4.4.9 `public static class OptimizerEngine` (L462–L1193)
**Optimization orchestrator** — the main optimization workflow.
- `Run(OptimizeOptions opts, CancellationToken cancel, Action<OptimizeProgress> progressCallback) → OptimizeResult` — Runs selected optimization tasks in sequence
- Private task methods: `ExecuteTask()`, `DoOptimizeDisks()`, `DoRecycleBin()`, `DoTempFiles()`, `DoUserTemp()`, `DoChkdsk()`, `DoDnsCache()`, `DoBrowserCache()`, `DoBackupRegistry()`, `DoCleanRegistry()`, `DoSfc()`, `DoDism()`, `DoEventLogs()`
- Private helpers: `GetSelectedTasks()`, `Pct()`, `UpdateDiagData()`, `Msg()`, `Progress()`, `Status()`, `EmitSection()`, `EmitBox()`
- **PS1 callers:** `$OptimizationScript` scriptblock (L7233)

---

### 4.5 SysOpt.ThemeEngine.dll — `SysOpt.ThemeEngine.cs` (364 lines)

#### 4.5.1 `public static class ThemeEngine` (L23–L124)
Theme file parser.
- `ParseThemeFile(string path) → Dictionary<string,string>` — Parses `.theme` files
- `GetThemeMeta(string path) → Dictionary<string,string>` — Extracts theme metadata
- `ListThemes(string themesFolder) → string[]` — Lists available themes
- **PS1 callers:** `Apply-ThemeWithProgress`, `Show-OptionsWindow`

#### 4.5.2 `public static class ThemeApplier` (L126–L342)
WPF visual tree theme applier.
- `DarkenColor(string hex, double factor) → string` — Darkens a hex color
- `BuildStatusColors(Dictionary<string,string> tc) → Dictionary<string,string>` — Builds status color palette
- `ApplyComboBoxTheme(ComboBox cb, string bgHex, string borderHex, string fgHex, string hoverHex)` — Themes ComboBox controls
- `ReplaceGradientColors(DependencyObject root, Dictionary<string,Color> colorMap)` — Replaces gradient colors in visual tree
- `GetVisualChildren(DependencyObject parent) → List<DependencyObject>` — Enumerates visual children
- **PS1 callers:** `Apply-ThemeWithProgress`, `Apply-ComboBoxDarkTheme`, `Get-VisualChildren`

---

### 4.6 SysOpt.Toast.dll — `SysOpt.Toast.cs` (300 lines)

#### 4.6.1 `public enum ToastType` (L29)
Values: `Success`, `Info`, `Warning`, `Error`

#### 4.6.2 `public static class ToastManager` (L32–L300)
WPF toast notification system.
- Properties: `Enabled`, `Debug`, `ActiveCount`
- `SetTheme(Dictionary<string,string> theme)` — Sets toast color palette
- `Show(string title, string message, ToastType type, int durationMs)` — Shows a toast
- Private: `ShowCore()`, `DismissToast()`, `PositionToast()`, `RepositionAll()`, `TC()`, `AccentFor()`, `IconFor()`, `Brush()`, `Dur()`
- **PS1 callers:** `Show-Toast`, `Sync-ToastTheme`, options toggle, debug toggle

---

### 4.7 SysOpt.StartupManager.dll — `SysOpt.StartupManager.cs` (398 lines)

#### 4.7.1 `public class StartupEntry` (L27–L53)
Startup program entry model.
- Properties: `Enabled`, `Name`, `Command`, `Source`, `RegPath`, `OriginalName`, `Type`, `FilePath`

#### 4.7.2 `public class ApplyResult` (L55–L67)
Result of applying startup changes.
- Properties: `Disabled`, `Errors`, `ErrorDetails`

#### 4.7.3 `public static class StartupEngine` (L69–L398)
Startup program management.
- `GetEntries() → List<StartupEntry>` — Reads all startup entries from registry + startup folder
- `DisableEntry(StartupEntry entry) → bool`
- `EnableEntry(StartupEntry entry) → bool`
- `ApplyChanges(IEnumerable<StartupEntry> entries) → ApplyResult`
- `ExportJson(IEnumerable<StartupEntry> entries) → string`
- Private: `DisableRegistryEntry()`, `EnableRegistryEntry()`, `DisableStartupFolderEntry()`, `EnableStartupFolderEntry()`, `ParseRegPath()`, `GetHive()`, `EscapeJson()`
- **PS1 callers:** `Show-StartupManager`, `Show-DiagnosticReport` (startup count)

---

### 4.8 SysOpt.MemoryHelper.dll — `MemoryHelper.cs` (29 lines)

#### 4.8.1 `public class MemoryHelper` (L16–L29)
Win32 P/Invoke wrappers.
- `SetSystemFileCacheSize(IntPtr min, IntPtr max, uint flags) → bool` — [DllImport kernel32]
- `EmptyWorkingSet(IntPtr hProcess) → bool` — [DllImport psapi]
- `OpenProcess(uint access, bool inherit, int pid) → IntPtr` — [DllImport kernel32]
- `CloseHandle(IntPtr handle) → bool` — [DllImport kernel32]
- **PS1 callers:** `Invoke-AggressiveGC`

---

### 4.9 SysOpt.WseTrim.dll — `WseTrim.cs` (41 lines)

#### 4.9.1 `public class WseTrim` (L19–L41)
Working-set trimmer.
- `TrimCurrentProcess()` — Trims current process working set
- `TrimProcess(IntPtr hProcess)` — Trims specified process
- Private: `SetProcessWorkingSetSize` [DllImport kernel32]
- **PS1 callers:** `Show-FolderScanner` (L6097)

---

### 4.10 SysOpt.Breakout.dll — `SysOpt.Breakout.cs` (424 lines)

#### 4.10.1 `public class Brick` (L24–L33)
Brick data model for the game.

#### 4.10.2 `public class GameHost : FrameworkElement` (L34–L51)
WPF rendering host.
- `Open() → DrawingContext` — Opens a drawing context
- `GetVisualChild()` override

#### 4.10.3 `public class BreakoutEngine` (L53–L424)
Full Breakout game engine.
- `Init(Canvas gameCanvas, string cBg, string cBall, ...)` — Initializes game with theme colors
- `Stop()` — Stops the game loop
- Private: `Freeze()` and game loop logic
- **PS1 callers:** `Show-BreakoutGame` (loaded on-demand via Add-Type)

---

### 4.11 DwmHelper (Inline C# in SysOpt.ps1, L840–L865)

Compiled inline via `Add-Type -TypeDefinition`.
- `SetDarkMode(IntPtr hwnd, bool dark)` — DWMWA_USE_IMMERSIVE_DARK_MODE (Win10 1809+)
- `SetCaptionColor(IntPtr hwnd, byte r, byte g, byte b)` — DWMWA_CAPTION_COLOR (Win11 22000+)
- `SetTextColor(IntPtr hwnd, byte r, byte g, byte b)` — DWMWA_TEXT_COLOR (Win11 22000+)
- **PS1 callers:** `Apply-TitleBarTheme`

---

## 5. PowerShell Function Reference

### 5.1 Bootstrap & Core Functions

| # | Function | Lines | Purpose | C# Classes Used | DLL Dependencies |
|---|----------|-------|---------|-----------------|------------------|
| 1 | `T` | L46–L53 | Translation helper — looks up key in `$LangDict` with fallback | — | — |
| 2 | `Bootstrap-Language` | L55–L93 | Early language bootstrap before Core.dll loads — parses lang file manually | — | — |
| 3 | `Set-SplashProgress` | L95–L108 | Updates splash screen progress bar and text | — | — |
| 4 | `Load-SysOptDll` | L110–L150 | Loads a C# DLL with guard-type check to prevent double-loading | `SysOptFallbacks` | Core |
| 5 | `Get-TC` | L235–L243 | Gets theme color by key with default fallback | — | — |
| 6 | `Sync-ToastTheme` | L244–L255 | Syncs current theme colors to ToastManager | `ToastManager` | Toast |
| 7 | `Show-Toast` | L256–L283 | Shows a toast notification (wrapper around ToastManager.Show) | `ToastManager`, `ToastType` | Toast |
| 8 | `New-ThemedWindowResources` | L284–L297 | Creates WPF resource dictionary with theme colors | — | — |
| 9 | `Update-DynamicThemeValues` | L298–L324 | Updates dynamic theme values in running window | — | — |
| 10 | `Initialize-RunspacePool` | L325–L342 | Creates a shared runspace pool for background operations | `SysOptFallbacks` | Core |
| 11 | `New-PooledPS` | L343–L357 | Creates a PowerShell instance from the pool | — | — |
| 12 | `Dispose-PooledPS` | L358–L363 | Disposes a pooled PowerShell context | — | — |
| 13 | `Invoke-AggressiveGC` | L364–L382 | Forces aggressive garbage collection + working-set trim | `MemoryHelper` | MemoryHelper |
| 14 | `Test-Administrator` | L383–L399 | Checks if running as administrator | — | — |

### 5.2 UI Utility Functions

| # | Function | Lines | Purpose | C# Classes Used |
|---|----------|-------|---------|-----------------|
| 15 | `Set-OutputState` | L523–L569 | Sets output text and colors on status fields | — |
| 16 | `Show-ThemedDialog` | L570–L696 | Shows a themed modal dialog (info/warning/error/question, OK/YesNo) | — |
| 17 | `Show-ThemedInput` | L697–L892 | Shows a themed input dialog with text field | — |

### 5.3 Logging Functions

| # | Function | Lines | Purpose | C# Classes Used |
|---|----------|-------|---------|-----------------|
| 18 | `Initialize-Logger` | L893–L902 | Initializes LogEngine with log directory | `LogEngine` |
| 19 | `Write-Log` | L903–L923 | Writes a log message to file and optionally console | `LogEngine` |
| 20 | `Write-ConsoleMain` | L924–L1020 | Writes formatted output to the main console TextBox | — |

### 5.4 Task Management Functions

| # | Function | Lines | Purpose | C# Classes Used |
|---|----------|-------|---------|-----------------|
| 21 | `Register-Task` | L1021–L1048 | Registers a new background task in the tasks panel | — |
| 22 | `Complete-Task` | L1049–L1060 | Marks a task as completed (success or error) | — |
| 23 | `Update-Task` | L1061–L1089 | Updates task progress percentage | — |
| 24 | `Cancel-Task` | L4822–L4839 | Cancels a running task by ID | — |
| 25 | `Pause-Task` | L4840–L4850 | Pauses a running task | — |
| 26 | `Resume-Task` | L4851–L4861 | Resumes a paused task | — |
| 27 | `Refresh-TasksPanel` | L4862–L4964 | Refreshes the tasks panel UI | — |

### 5.5 System Information Functions

| # | Function | Lines | Purpose | C# Classes Used |
|---|----------|-------|---------|-----------------|
| 28 | `Update-SystemInfo` | L1187–L1253 | Refreshes the System Info tab — CPU, RAM, SMART, Network | `SystemDataCollector`, `Formatter` |
| 29 | `Draw-SparkLine` | L1090–L1186 | Draws a sparkline WPF graph for real-time metrics | — |
| 30 | `Get-VisualChildren` | L1254 | Wrapper for `ThemeApplier::GetVisualChildren` | `ThemeApplier` |
| 31 | `Apply-ComboBoxDarkTheme` | L1256–L1453 | Applies dark theme to ComboBox controls | `ThemeApplier` |

### 5.6 Formatter Wrappers

| # | Function | Lines | Purpose | C# Classes Used |
|---|----------|-------|---------|-----------------|
| 32 | `Format-Bytes` | L1454 | Wrapper for `Formatter::FormatBytes` | `Formatter` |
| 33 | `Format-Rate` | L1457 | Wrapper for `Formatter::FormatRate` | `Formatter` |
| 34 | ~~`Get-LinkBps`~~ | — | **Removed (Phase 2)** — 0 callers | — |
| 35 | ~~`Format-SnapshotSize`~~ | — | **Removed (Phase 2)** — calls replaced by `Format-Bytes` | — |

> **Phase 2 note:** `Get-VisualChildren` wrapper also removed — calls replaced by `[ThemeApplier]::GetVisualChildren()`

### 5.7 Performance & Auto-Refresh

| # | Function | Lines | Purpose | C# Classes Used |
|---|----------|-------|---------|-----------------|
| 36 | `Update-PerformanceTab` | L1461–L1725 | Updates the Performance tab — CPU cores, RAM, disk I/O, network, GPU, ports | `SystemDataCollector`, `Formatter` |
| 37 | `Start-AutoRefreshTimer` | L1726–L1790 | Starts a DispatcherTimer for auto-refresh of performance data | `SystemDataCollector` |

### 5.8 Disk Explorer Functions

| # | Function | Lines | Purpose | C# Classes Used |
|---|----------|-------|---------|-----------------|
| 38 | `Request-DiskViewRefresh` | L1791–L1815 | Requests a refresh of disk view (debounced) | — |
| 39 | `Refresh-DiskView` | L1816–L1897 | Refreshes the disk explorer data grid | — |
| 40 | `Invalidate-DiskViewCache` | L1898–L1901 | Invalidates the disk view cache | — |
| 41 | `Get-SizeColor` | L1902–L1912 | Returns color based on file size (red for large, green for small) | — |
| 42 | `Start-DiskScan` | L1913–L2376 | **Main disk scan operation** — launches background scan in runspace, polls via timer, builds tree | `ScanTokenManager`, `ScanCtl211`, `PScanner211`, `Formatter` |
| 43 | `Apply-DiskFilter` | L4965–L5748 | Applies search/filter to scanned disk items | — |

### 5.9 Settings & Configuration

| # | Function | Lines | Purpose | C# Classes Used |
|---|----------|-------|---------|-----------------|
| 44 | `Save-Settings` | L2377–L2401 | Saves app settings to JSON | `LogEngine`, `ToastManager` |
| 45 | `Load-Settings` | L2402–L2440 | Loads app settings from JSON | `LogEngine`, `ToastManager` |
| 46 | `Load-Language` | L2441–L2475 | Loads a language file and applies to UI + C# DLLs | `LangEngine`, `Loc` (Core/Diag/Optimizer) |

### 5.10 Theme & DWM Functions

| # | Function | Lines | Purpose | C# Classes Used |
|---|----------|-------|---------|-----------------|
| 47 | `Apply-TitleBarTheme` | L2476–L2505 | Applies theme to native title bar via DWM | `DwmHelper` (inline) |
| 48 | `Update-WindowTitle` | L2506–L2515 | Updates window title with optional [DEBUG MODE] badge | `LogEngine` |
| 49 | `Apply-LanguageToUI` | L2516–L2860 | Applies all translation keys to named UI elements | — |
| 50 | `Apply-ButtonTheme` | L2861–L2916 | Themes all buttons in a visual tree | — |
| 51 | `Apply-ThemeWithProgress` | L2917–L3136 | Applies a full theme with progress indicator — colors, gradients, buttons | `ThemeEngine`, `ThemeApplier` |

### 5.11 Window Functions

| # | Function | Lines | Purpose | C# Classes Used |
|---|----------|-------|---------|-----------------|
| 52 | `Show-BreakoutGame` | L3137–L3194 | Opens Breakout easter egg game (loads DLL on demand) | `BreakoutEngine` |
| 53 | `Show-OptionsWindow` | L3195–L3617 | Opens Settings window — theme/lang/debug/toast toggles, about page | `LangEngine`, `ThemeEngine`, `LogEngine`, `ToastManager`, `XamlLoader` |
| 54 | `Show-TasksWindow` | L4630–L4821 | Opens background tasks window | `XamlLoader` |
| 55 | `Show-FolderScanner` | L5902–L6248 | Opens Folder Scanner window — live file-system exploration | `XamlLoader`, `SystemDataCollector`, `WseTrim` |
| 56 | `Show-StartupManager` | L6249–L6314 | Opens Startup Manager window — enable/disable startup programs | `StartupEngine`, `XamlLoader` |
| 57 | `Show-DiagnosticReport` | L6394–L7175 | Opens Diagnostic window — 30+ checks, score, export to text/HTML | `DiagnosticsEngine`, `DiagInput`, `StartupEngine`, `XamlLoader` |
| 58 | `Show-AboutWindow` | L7720–L~7800 | Opens About window | — |

### 5.12 Snapshot & Export Functions

| # | Function | Lines | Purpose | C# Classes Used |
|---|----------|-------|---------|-----------------|
| 59 | `Update-SnapshotCheckState` | L3621–L3647 | Updates snapshot checkbox state for bulk operations | — |
| 60 | `Show-ExportProgressDialog` | L3648–L3808 | Creates and shows an export progress dialog | — |
| 61 | `Close-ProgressDialog` | L3809–L3813 | Closes a progress dialog | — |
| 62 | `Update-ProgressDialog` | L3814–L3830 | Updates progress dialog percentage and phase text | — |
| 63 | `Load-SnapshotList` | L3831–L4052 | Loads saved snapshots from the snapshot directory | — |
| 64 | `Get-SnapshotEntriesAsync` | L4053–L4629 | Loads snapshot entries asynchronously via FIFO streaming | — |

### 5.12b Export Multi-Format Functions (Phase 3)

| Function/Handler | Context | Format | Output |
|-----------------|---------|--------|--------|
| `btnExportCsv.Click` (Disk) | MainWindow | CSV | Disk scan results with headers |
| `btnExportJson.Click` (Disk) | MainWindow | JSON | Disk data with version/timestamp for server sync |
| `btnExportCsv.Click` (Diag) | DiagnosticWindow | CSV | Sections, status, labels, details, actions |
| `btnExportDiagJson.Click` | DiagnosticWindow | JSON | Score, counts, items array for server sync |
| `btnExportDiag.Click` | DiagnosticWindow | TXT | Human-readable diagnostic report |
| `btnExportDiagHtml.Click` | DiagnosticWindow | HTML | Styled report with charts |

All exports default to `$script:OutputDir` (`./output/`).

### 5.13 Diagnostic Helper

| # | Function | Lines | Purpose | C# Classes Used |
|---|----------|-------|---------|-----------------|
| 65 | `Add-DiagRow` | L6315–L6393 | Adds a diagnostic row to the UI panel | — |

### 5.14 Optimization

| # | Function | Lines | Purpose | C# Classes Used |
|---|----------|-------|---------|-----------------|
| 66 | `Start-Optimization` | L7296–L7719 | **Main optimization entry point** — validates options, creates runspace, runs OptimizerEngine | `OptimizerEngine`, `OptimizeOptions`, `OptimizeProgress` |
| — | `$OptimizationScript` (scriptblock) | L7177–L7295 | Background runspace script for optimization — calls OptimizerEngine.Run | `OptimizerEngine`, `Core`, `DiskEngine`, `MemoryHelper`, `Diagnostics` |

**Total functions: 66 named functions + 1 scriptblock**

---

## 6. XAML Window Reference

### 6.1 MainWindow.xaml (126,869 B)
- **Title:** `SysOpt - Windows Optimizer GUI v3.3.0`
- **Type:** Primary application window
- **Key named elements:** `bd`, `box`, `chk`, `el`, `lbiBd`, `tabBorder`, `thumb`, `track`, `PART_Indicator`, `PART_Track` (+ hundreds of unnamed template elements)
- **Tabs:** System Info, Performance, Disk Explorer, Optimizer, Console
- **Notable:** Largest XAML file; contains all tab panels, sidebar, and custom control templates

### 6.1b FolderScannerWindow.xaml — Advanced Filters (Phase 3)

New collapsible filter panel with:
- **Size filter**: Min/Max in MB (`txtFilterMinSize`, `txtFilterMaxSize`)
- **Date filter**: From/To (`txtFilterDateFrom`, `txtFilterDateTo`) with tolerant dd/MM/yyyy parsing
- **Extension filter**: 6 category checkboxes (Video 🎬, Audio 🎵, Image 🖼, Docs 📄, Archive 📦, Other 📎)
- **Toggle button**: `btnToggleFilters` with active filter count badge
- **Clear button**: `btnClearFilters` resets all filters
- All labels use `T()` function (30 new lang keys × 3 languages)
- All colors use `Get-TC` / `DynamicResource` (68 themes compatible)

### 6.2 DiagnosticWindow.xaml (63,819 B)
- **Title:** `$(T 'DiagWindowTitle' 'Diagnóstico del Sistema — SysOpt')`
- **Type:** System diagnostic dialog
- **Named elements (103):** `ScoreLabel`, `ScoreText`, `scoreRingFg`, `panelRecommendations`, `panelCategoryBars`, and 9 page panels (`pageResumen`, `pageSistema`, `pageLimpieza`, `pageDisco`, `pageSeguridad`, `pageInicio`, `pageServicios`, `pageRed`, `pageInfoSistema`) with corresponding nav buttons, badges, and dots
- **Style:** Windows Settings-like sidebar + content panel

### 6.3 OptionsWindow.xaml (26,457 B)
- **Title:** `$(T 'OptSettingsTitle' 'Configuración — SysOpt')`
- **Named elements (55):** `cmbTheme`, `cmbLang`, `tglDebugLog`, `tglToast`, 3 page panels (`pageInterface`, `pageBehavior`, `pageAbout`), nav buttons, about section elements
- **Pages:** Interface (theme/language), Behavior (debug/toast), About

### 6.4 TasksWindow.xaml (21,362 B)
- **Title:** `Tareas en Segundo Plano — SysOpt`
- **Named elements (5):** `bd`, `btnTitleCloseTasks`, `titleBarTasks`, `txtTitleBarTasks`
- **Purpose:** Shows background task queue with progress bars

### 6.5 FolderScannerWindow.xaml (20,274 B)
- **Title:** `Explorador de Carpeta`
- **Named elements (4):** `PART_Indicator`, `PART_Track`, `bd`, `lbi`
- **Purpose:** Live folder exploration with size analysis

### 6.6 AboutWindow.xaml (19,326 B)
- **Title:** `$(T 'AboutWindowTitle' 'Acerca de SysOpt')`
- **Named elements (3):** `bd`, `btnTitleCloseAbout`, `titleBarAbout`
- **Purpose:** Credits and version info

### 6.7 StartupManagerWindow.xaml (10,179 B)
- **Title:** `Gestor de Inicio`
- **Named elements (0 explicit):** Uses `FindName()` in PS1 — `StartupGrid`, `StartupStatus`, `btnApplyStartup`, `btnCloseStartup`, `titleBar`
- **Purpose:** Enable/disable startup programs

### 6.8 DedupWindow.xaml (9,808 B)
- **Title:** `Archivos Duplicados — SysOpt`
- **Named elements (2):** `btnTitleCloseDedup`, `titleBarDedup`
- **Purpose:** Duplicate file finder

### 6.9 ChangelogWindow.xaml (6,523 B)
- **Title:** `$(T 'AboutChangelogTitle' 'Registro de cambios')`
- **Named elements (5):** `bd`, `btnCLClose`, `btnTitleCloseCL`, `titleBarCL`, `txtCLContent`
- **Purpose:** Version changelog viewer

### 6.10 BreakoutWindow.xaml (4,283 B)
- **Title:** `SysOpt Breakout`
- **Named elements (3):** `btnTitleCloseBrk`, `gameCanvas`, `titleBarBrk`
- **Purpose:** Easter egg Breakout game

### 6.11 SplashWindow.xaml (2,115 B)
- **Title:** *(none — splash screen)*
- **Named elements (0):** Progress controlled by `Set-SplashProgress`
- **Purpose:** Startup splash screen with progress bar

---

## 7. Translation System

### 7.1 Language Files

| File | Language | Lines | Keys | Size |
|------|----------|-------|------|------|
| `en-us.lang` | English (US) | 1,012 | 860 | 54,113 B |
| `es-es.lang` | Spanish (Spain) | 1,010 | 860 | 56,345 B |
| `pt-br.lang` | Portuguese (Brazil) | 1,015 | 860 | 57,199 B |

**All 3 languages have identical key coverage (888 keys each) — 100% parity.**

### 7.2 Localization Pipeline

1. `.lang` files parsed by `LangEngine::ParseLangFile()` → `Dictionary<string,string>`
2. PS1 `$script:LangDict` stores active dictionary
3. `T(key, fallback)` resolves at runtime in PS1
4. C# DLLs receive dictionary via `Loc::SetDict()` — separate Loc class per DLL namespace
5. `Apply-LanguageToUI()` iterates known XAML controls and sets `.Text` / `.Content`
6. Background runspaces pre-resolve `T()` calls before launching (no cross-thread access)

---

## 8. DLL Dependency Matrix

### 8.1 Inter-DLL Dependencies

```
SysOpt.Core.dll (624 lines, HARD load)
  ├── depends on: System.Diagnostics, System.Threading, System.IO
  ├── classes: Loc, LangEngine, XamlLoader, SettingsHelper, ScanTokenManager, LogEngine, SysOptFallbacks, Formatter
  ├── used by: SysOpt.Collector.dll, SysOpt.Cleanup.dll, SysOpt.Optimizer.dll, SysOpt.Diagnostics.dll
  │            SysOpt.DiskEngine.dll (ScanTokenManager bridge)
  │            All PS1 functions

SysOpt.Collector.dll (863 lines, HARD load) — NEW in Phase 1
  ├── depends on: SysOpt.Core.dll (Loc, Formatter, LogEngine)
  ├── depends on: System.Management (WMI), System.Diagnostics, System.Threading
  ├── classes: 13 Snapshot DTOs + SystemDataCollector + AgentThresholds + IAgentTransport + AgentBus
  └── used by: SysOpt.Optimizer.dll, SysOpt.Diagnostics.dll, PS1 Update-SystemInfo

SysOpt.Cleanup.dll (820 lines, LAZY load) — NEW in Phase 1
  ├── depends on: SysOpt.Core.dll (Loc, LogEngine, Formatter)
  ├── classes: CleanupResult, CleanupEngine
  └── used by: SysOpt.Optimizer.dll (on first optimization run)

SysOpt.DiskEngine.dll
  ├── depends on: System.Threading, System.IO
  ├── used by: PS1 Start-DiskScan
  └── bridges: ScanTokenManager (Core) → ScanCtl211 (DiskEngine)

SysOpt.Optimizer.dll (1,180 lines)
  ├── depends on: SysOpt.Core.dll (Loc — global namespace, Formatter)
  ├── depends on: SysOpt.Collector.dll (SystemDataCollector, SystemSnapshot)
  ├── depends on: SysOpt.Cleanup.dll (CleanupEngine — lazy loaded)
  ├── depends on: SysOpt.DiskEngine.dll (DiskOptimizer)
  ├── depends on: SysOpt.MemoryHelper.dll
  └── used by: PS1 $OptimizationScript

SysOpt.Diagnostics.dll (1,285 lines)
  ├── depends on: SysOpt.Core.dll (Loc — global namespace, Phase 2)
  ├── depends on: SysOpt.Collector.dll (SystemSnapshot, DiagInput)
  ├── depends on: System.Text (HTML generation)
  └── used by: PS1 Show-DiagnosticReport

SysOpt.ThemeEngine.dll
  ├── depends on: PresentationFramework, PresentationCore (WPF)
  └── used by: PS1 Apply-ThemeWithProgress

SysOpt.Toast.dll
  ├── depends on: PresentationFramework (WPF Window)
  └── used by: PS1 Show-Toast

SysOpt.StartupManager.dll
  ├── depends on: Microsoft.Win32 (Registry)
  └── used by: PS1 Show-StartupManager, Show-DiagnosticReport

SysOpt.MemoryHelper.dll
  ├── depends on: kernel32.dll, psapi.dll (P/Invoke)
  └── used by: PS1 Invoke-AggressiveGC

SysOpt.WseTrim.dll
  ├── depends on: kernel32.dll (P/Invoke)
  └── used by: PS1 Show-FolderScanner

SysOpt.Breakout.dll
  ├── depends on: PresentationFramework, PresentationCore (WPF)
  └── loaded on-demand by Show-BreakoutGame
```

### 8.2 Dependency Direction Arrows

```
Collector ──→ Core (Loc, Formatter, LogEngine)
Cleanup ──→ Core (Loc, LogEngine)
Optimizer ──→ Core (Loc, Formatter)
Optimizer ──→ Collector (SystemSnapshot)
Optimizer ──→ Cleanup (CleanupEngine — lazy)
Optimizer ──→ DiskEngine (DiskOptimizer)
Optimizer ──→ MemoryHelper
DiskEngine ──→ Core (ScanTokenManager bridge)
Diagnostics ──→ Core (Loc — global namespace)
Diagnostics ──→ Collector (SystemSnapshot, DiagInput)
ThemeEngine ──→ (independent, WPF only)
Toast ──→ (independent, WPF only)
StartupManager ──→ (independent, Registry only)
MemoryHelper ──→ (independent, Win32 P/Invoke only)
WseTrim ──→ (independent, Win32 P/Invoke only)
Breakout ──→ (independent, WPF only)
```

---

## 9. PS1 Lifecycle Phases

### Phase 1: Early Bootstrap (Lines 1–100)
- **L1–L45:** Script header, `$ErrorActionPreference`, `Add-Type` for WPF assemblies, `$script:AppVersion`, `$script:AppDir`
- **L46–L53:** `T()` function definition (translation helper)
- **L55–L93:** `Bootstrap-Language` — early language loading before DLLs
- **L95–L108:** `Set-SplashProgress` — splash screen control
- Splash window created and shown

### Phase 2: DLL Loading (Lines 100–215)
- **L110–L150:** `Load-SysOptDll` function definition
- **L153–L205:** Sequential DLL loading (10 HARD DLLs at startup + 1 LAZY):
  1. MemoryHelper (10%) → 2. DiskEngine (17%) → 3. Core (24%) → 4. Collector (26%) → 5. ThemeEngine (31%) → 6. WseTrim (38%) → 7. Optimizer (45%) → 8. StartupManager (52%) → 9. Diagnostics (59%) → 10. Toast (62%)
  - Cleanup.dll: LAZY — loaded on-demand (first optimization run)
  - Breakout.dll: ON-DEMAND — loaded when user opens minigame
- **L208–L215:** CTK initialization (ScanTokenManager bridge)

### Phase 3: Variable Setup & Config (Lines 215–L400)
- **L217–L234:** `$script:XamlFolder`, `$script:CurrentLang`, `$script:CurrentTheme`, directory variables
- **L235–L399:** Helper functions — `Get-TC`, `Sync-ToastTheme`, `Show-Toast`, `New-ThemedWindowResources`, `Update-DynamicThemeValues`, `Initialize-RunspacePool`, `New-PooledPS`, `Dispose-PooledPS`, `Invoke-AggressiveGC`, `Test-Administrator`
- **L400–L401:** Mutex acquisition (`SysOptFallbacks::InitMutex` + `AcquireMutex`)

### Phase 4: XAML Window Creation (Lines 400–L900)
- **L416:** `$xaml = [XamlLoader]::Load($script:XamlFolder, "MainWindow")`
- XAML string expansion, XML parsing, `XamlReader::Load`
- `FindName()` for all named controls (hundreds of controls)
- **L830–L870:** DwmHelper inline C# compilation + icon loading
- **L893–L923:** Logger initialization

### Phase 5: Function Definitions (Lines 900–L7175)
- **L903–L1186:** Logging, task management, sparkline drawing
- **L1187–L1725:** `Update-SystemInfo`, `Update-PerformanceTab`
- **L1726–L2376:** Auto-refresh timer, disk view, disk scan
- **L2377–L3136:** Settings, language, theme functions
- **L3137–L3617:** Breakout game, Options window
- **L3618–L4964:** Snapshot/export system, tasks window
- **L4965–L6248:** Disk filter, dedup window, folder scanner
- **L6249–L7175:** Startup manager, diagnostic report

### Phase 6: Event Binding (Lines 7175–L7580)
- **L7177–L7295:** `$OptimizationScript` scriptblock definition
- **L7296–L7500:** Button click handlers (`$btnRefreshInfo`, `$btnSelectAll`, `Start-Optimization`)
- All `Add_Click`, `Add_Checked`, `Add_Unchecked` bindings

### Phase 7: Startup Sequence (Lines 7580–L7800)
- **L7580–L7590:** Window closing handler — `LogEngine::Close()`, `SysOptFallbacks::DisposeMutex()`
- **L7590–L7620:** Initial data load — `Load-Settings`, `Load-Language`, `Apply-ThemeWithProgress`
- **L7620–L7650:** `Update-SystemInfo` (first call), `Start-AutoRefreshTimer`
- **L7650–L7700:** Splash close, `Apply-TitleBarTheme`
- **L7720+:** `Show-AboutWindow` function, `$window.ShowDialog()` — **enters WPF event loop**

---

## 10. Cross-Reference Index

### Alphabetical Class/Function → Location & Usage

| Name | Type | Defined | Used By |
|------|------|---------|---------|
| `Add-DiagRow` | PS1 func | L6315 | `Show-DiagnosticReport` |
| `AgentBus` | C# class | Core.cs L1046 | Auto-refresh timer |
| `AgentThresholds` | C# class | Core.cs L1002 | `AgentBus` |
| `Apply-ButtonTheme` | PS1 func | L2861 | `Apply-ThemeWithProgress` |
| `Apply-ComboBoxDarkTheme` | PS1 func | L1256 | `Apply-ThemeWithProgress`, options window |
| `Apply-LanguageToUI` | PS1 func | L2516 | `Load-Language` |
| `Apply-TitleBarTheme` | PS1 func | L2476 | Startup, theme change, lang change |
| `Apply-ThemeWithProgress` | PS1 func | L2917 | Startup, options apply |
| `ApplyResult` | C# class | StartupManager.cs L55 | `StartupEngine::ApplyChanges` |
| `Bootstrap-Language` | PS1 func | L55 | Startup (Phase 1) |
| `BreakoutEngine` | C# class | Breakout.cs L53 | `Show-BreakoutGame` |
| `Brick` | C# class | Breakout.cs L24 | `BreakoutEngine` |
| `Cancel-Task` | PS1 func | L4822 | Tasks window |
| `CleanupEngine` | C# class | Core.cs L1491 | `OptimizerEngine` |
| `CleanupResult` | C# class | Core.cs L1471 | `CleanupEngine` methods |
| `Close-ProgressDialog` | PS1 func | L3809 | Snapshot/export operations |
| `Complete-Task` | PS1 func | L1049 | Various async operations |
| `CpuSnapshot` | C# class | Core.cs L272 | `SystemDataCollector` |
| `DiagInput` | C# class | Diagnostics.cs L38 | `Show-DiagnosticReport` |
| `DiagItem` | C# class | Diagnostics.cs L117 | `DiagnosticsEngine` |
| `DiagnosticData` | C# class | Optimizer.cs L117 | `OptimizerEngine` |
| `DiagnosticsEngine` | C# class | Diagnostics.cs L166 | `Show-DiagnosticReport` |
| `DiagResult` | C# class | Diagnostics.cs L134 | `DiagnosticsEngine::Analyze` |
| `DiskDriveInfo` | C# class | Core.cs L331 | `SystemDataCollector` |
| `DiskItem_v211` | C# class | DiskEngine.cs L27 | `PScanner211`, disk view |
| `DiskItemToggle_v230` | C# class | DiskEngine.cs L61 | Disk tree expand/collapse |
| `DiskOptimizer` | C# class | DiskEngine.cs L254 | `OptimizerEngine` |
| `DiskResult` | C# class | DiskEngine.cs L224 | `DiskOptimizer` |
| `DiskSnapshot` | C# class | Core.cs L315 | `SystemDataCollector` |
| `DiskVolumeInfo` | C# class | Core.cs L344 | `SystemDataCollector` |
| `Dispose-PooledPS` | PS1 func | L358 | Various async operations |
| `Draw-SparkLine` | PS1 func | L1090 | `Update-PerformanceTab` |
| `DwmHelper` | C# class (inline) | PS1 L840 | `Apply-TitleBarTheme` |
| `Format-Bytes` | PS1 func | L1454 | Various |
| `Format-Rate` | PS1 func | L1457 | Network display |
| `Format-SnapshotSize` | PS1 func | L3618 | Snapshot system |
| `Formatter` | C# class | Core.cs L1425 | `Format-Bytes`, `Format-Rate`, many UI functions |
| `GameHost` | C# class | Breakout.cs L34 | `BreakoutEngine` |
| `Get-LinkBps` | PS1 func | L1459 | Network display |
| `Get-SizeColor` | PS1 func | L1902 | Disk scan display |
| `Get-SnapshotEntriesAsync` | PS1 func | L4053 | Snapshot loading |
| `Get-TC` | PS1 func | L235 | **Everywhere** (theme colors) |
| `Get-VisualChildren` | PS1 func | L1254 | Theme application |
| `GpuInfo` | C# class | Core.cs L392 | `SystemDataCollector` |
| `GpuSnapshot` | C# class | Core.cs L384 | `SystemDataCollector` |
| `HtmlReportParams` | C# class | Diagnostics.cs L150 | `DiagnosticsEngine::GenerateHtmlReport` |
| `IAgentTransport` | C# interface | Core.cs L1027 | `AgentBus` |
| `Initialize-Logger` | PS1 func | L893 | Startup (Phase 4) |
| `Initialize-RunspacePool` | PS1 func | L325 | Startup |
| `Invalidate-DiskViewCache` | PS1 func | L1898 | Disk filter/refresh |
| `Invoke-AggressiveGC` | PS1 func | L364 | Post-export, post-scan |
| `LangEngine` | C# class | Core.cs L54 | `Load-Language`, `Show-OptionsWindow` |
| `Load-Language` | PS1 func | L2441 | Settings load, options apply |
| `Load-Settings` | PS1 func | L2402 | Startup (Phase 7) |
| `Load-SnapshotList` | PS1 func | L3831 | Snapshot panel |
| `Load-SysOptDll` | PS1 func | L110 | Startup (Phase 2) |
| `Loc` (Core) | C# class | Core.cs L39 | `Load-Language` |
| `Loc` (Diagnostics) | C# class | Diagnostics.cs L17 | `Load-Language` |
| `Loc` (Optimizer) | C# class | Optimizer.cs L38 | `Load-Language` |
| `LogEngine` | C# class | Core.cs L1114 | `Initialize-Logger`, `Write-Log`, many |
| `MemoryHelper` | C# class | MemoryHelper.cs L16 | `Invoke-AggressiveGC` |
| `NetworkAdapterInfo` | C# class | Core.cs L365 | `SystemDataCollector` |
| `NetworkSnapshot` | C# class | Core.cs L357 | `SystemDataCollector` |
| `New-PooledPS` | PS1 func | L343 | Various async operations |
| `New-ThemedWindowResources` | PS1 func | L284 | Window creation |
| `OpenPortInfo` | C# class | Core.cs L418 | `SystemDataCollector` |
| `OptimizerEngine` | C# class | Optimizer.cs L462 | `$OptimizationScript` |
| `OptimizeOptions` | C# class | Optimizer.cs L62 | `Start-Optimization` |
| `OptimizeProgress` | C# class | Optimizer.cs L87 | Progress callback |
| `OptimizeResult` | C# class | Optimizer.cs L137 | `OptimizerEngine::Run` |
| `Pause-Task` | PS1 func | L4840 | Tasks window |
| `PortSnapshot` | C# class | Core.cs L405 | `SystemDataCollector` |
| `ProcessManager` | C# class | Optimizer.cs L291 | `OptimizerEngine` |
| `PScanner211` | C# class | DiskEngine.cs L148 | `Start-DiskScan` background runspace |
| `RamModuleInfo` | C# class | Core.cs L303 | `SystemDataCollector` |
| `RamSnapshot` | C# class | Core.cs L288 | `SystemDataCollector` |
| `Refresh-DiskView` | PS1 func | L1816 | Disk scan, filter |
| `Refresh-TasksPanel` | PS1 func | L4862 | Tasks window |
| `Register-Task` | PS1 func | L1021 | Async operations |
| `Request-DiskViewRefresh` | PS1 func | L1791 | Disk view |
| `Resume-Task` | PS1 func | L4851 | Tasks window |
| `Save-Settings` | PS1 func | L2377 | Options apply, window close |
| `ScanCtl211` | C# class | DiskEngine.cs L109 | `Start-DiskScan`, scan cancel |
| `ScanTokenManager` | C# class | Core.cs L191 | CTK init, `Start-DiskScan`, cancel |
| `Set-OutputState` | PS1 func | L523 | Status display |
| `Set-SplashProgress` | PS1 func | L95 | Startup (Phase 1–2) |
| `SettingsHelper` | C# class | Core.cs L158 | Utility |
| `Show-AboutWindow` | PS1 func | L7720 | About button |
| `Show-BreakoutGame` | PS1 func | L3137 | Easter egg |
| `Show-DiagnosticReport` | PS1 func | L6394 | Diagnostics button |
| `Show-ExportProgressDialog` | PS1 func | L3648 | Export operations |
| `Show-FolderScanner` | PS1 func | L5902 | Folder scanner button |
| `Show-OptionsWindow` | PS1 func | L3195 | Settings button |
| `Show-StartupManager` | PS1 func | L6249 | Startup manager button |
| `Show-TasksWindow` | PS1 func | L4630 | Tasks button |
| `Show-ThemedDialog` | PS1 func | L570 | **Everywhere** (modal dialogs) |
| `Show-ThemedInput` | PS1 func | L697 | Snapshot naming |
| `Show-Toast` | PS1 func | L256 | Success/error notifications |
| `Start-AutoRefreshTimer` | PS1 func | L1726 | Startup (Phase 7) |
| `Start-DiskScan` | PS1 func | L1913 | Scan button |
| `Start-Optimization` | PS1 func | L7296 | Optimize button |
| `StartupEngine` | C# class | StartupManager.cs L69 | `Show-StartupManager`, `Show-DiagnosticReport` |
| `StartupEntry` | C# class | StartupManager.cs L27 | `StartupEngine` |
| `Sync-ToastTheme` | PS1 func | L244 | Theme change |
| `SysOptFallbacks` | C# class | Core.cs L1287 | `Load-SysOptDll`, mutex, runspace pool |
| `SystemDataCollector` | C# class | Core.cs L467 | `Update-SystemInfo`, `Update-PerformanceTab`, auto-refresh |
| `SystemSnapshot` | C# class | Core.cs L433 | `SystemDataCollector::GetFullSnapshot` |
| `T` | PS1 func | L46 | **Everywhere** (translation) |
| `TaskResult` | C# class | Optimizer.cs L99 | `OptimizerEngine` |
| `Test-Administrator` | PS1 func | L383 | Startup admin check |
| `ThemeApplier` | C# class | ThemeEngine.cs L126 | `Apply-ThemeWithProgress`, `Apply-ComboBoxDarkTheme` |
| `ThemeEngine` | C# class | ThemeEngine.cs L23 | `Apply-ThemeWithProgress`, `Show-OptionsWindow` |
| `ToastManager` | C# class | Toast.cs L32 | `Show-Toast`, `Sync-ToastTheme`, options |
| `ToastType` | C# enum | Toast.cs L29 | `Show-Toast` |
| `Update-DynamicThemeValues` | PS1 func | L298 | Theme change |
| `Update-PerformanceTab` | PS1 func | L1461 | Auto-refresh timer |
| `Update-ProgressDialog` | PS1 func | L3814 | Export operations |
| `Update-SnapshotCheckState` | PS1 func | L3621 | Snapshot panel |
| `Update-SystemInfo` | PS1 func | L1187 | Refresh button, startup |
| `Update-Task` | PS1 func | L1061 | Async operations |
| `Update-WindowTitle` | PS1 func | L2506 | Debug toggle |
| `VolumeInfo` | C# class | DiskEngine.cs L244 | `DiskOptimizer` |
| `WseTrim` | C# class | WseTrim.cs L19 | `Show-FolderScanner` |
| `WUCacheManager` | C# class | Optimizer.cs L164 | `OptimizerEngine` |
| `XamlLoader` | C# class | Core.cs L126 | All window functions |

---

## 11. Theme Files (68 themes)

apple, assassins-creed, aws, azure, bioshock, bloodborne, bloomberg, counter-strike, crash-bandicoot, cyberpunk, dark-souls, default, default-light, diablo, doom, dracula, elden-ring, fallout-wasteland, figma, final-fantasy, github-dark, god-of-war, gta-vice-city, halo, hollow-knight, iceblue, icecream, kiss, league-of-legends, manga-japan, mass-effect, matrix, metal-gear, metroid, minecraft, monokai, mortal-kombat, notion, office, overwatch, pac-man, pipboy, portal, prince-of-persia, ps5, red-dead-redemption, resident-evil, sekiro, simpsons, slack, solarized-dark, sonic, spyro, starcraft, starwars, street-fighter, symphony of the night, tekken, the-witcher, tomb-raider, ubuntu, votorantim, votorantim2, wallstreet, windows, windows-light, xbox, zelda

---

## 12. Summary Statistics

| Metric | Value |
|--------|-------|
| Total files | 105 |
| SysOpt.ps1 lines | ~7,793 |
| C# source lines (all .cs) | ~6,772 |
| XAML files | 11 |
| XAML total size | 310 KB |
| DLLs | 12 (10 HARD at startup + 1 LAZY + 1 on-demand) |
| DLL total size | ~293 KB (projected after recompile) |
| PS1 functions | 63 + 1 scriptblock |
| C# classes/structs/enums | 55 |
| C# static classes | 17 |
| C# data model classes | 27 |
| C# interfaces | 1 |
| C# enums | 1 |
| Theme files | 68 |
| Languages | 3 (888 keys each) |
| Translation keys | 860 |
| HTML templates | 2 |
