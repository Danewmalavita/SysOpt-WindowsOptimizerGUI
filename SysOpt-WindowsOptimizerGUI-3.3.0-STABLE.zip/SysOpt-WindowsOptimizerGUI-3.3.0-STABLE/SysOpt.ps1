﻿# SysOpt - Software de optimización del sistema
# Copyright (C) 2026 Danew Malavita
#
# Este programa es software libre bajo los términos de la GPL v3+.
# Consulta el archivo LICENSE o visita <https://www.gnu.org/licenses/>.

#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Optimizador de Sistema Windows con Interfaz Gráfica
.DESCRIPTION
    Script completo de optimización con GUI, limpieza avanzada, verificación de sistema y registro.
#>

# -----------------------------------------------------------------------------
# Metadatos de versión -- cargados desde SysOpt.info (About en Opciones)
# -----------------------------------------------------------------------------
$script:AppVersion = "3.3.0"
# -- Metadatos de versión -- cargados desde SysOpt.info --
$script:AppNotes = $null
$_infoPath = Join-Path $PSScriptRoot "SysOpt.info"
if (Test-Path $_infoPath) {
    try {
        $script:AppNotes = & ([scriptblock]::Create((Get-Content $_infoPath -Raw -Encoding UTF8)))
    } catch {
        Write-Warning "Error cargando SysOpt.info: $_"
    }
}

# -- Alias de acceso rápido para el resto del script
$script:AppDir = $PSScriptRoot

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
# [DEFERRED] System.Windows.Forms carga diferida al timer post-boot (solo se usa en diálogos)
# [REMOVED] Microsoft.VisualBasic -- no se usa en el programa
Add-Type -AssemblyName WindowsBase


# -- Early i18n bootstrap (before DLLs) ------------------------------
# LangEngine lives in Core.dll which isn't loaded yet.  We parse the
# .lang file with pure PowerShell so splash strings are translated.
$script:LangDict       = @{}           # Diccionario clave->texto actual
$script:LangDir        = Join-Path $PSScriptRoot "assets\lang"
$script:_langCachePath   = [System.IO.Path]::Combine($env:TEMP, "SysOpt", "lang-cache.json")
$script:_langCacheApplied = $false
$script:_langCacheMsg     = ""
$script:SafeMode        = $false
$global:_sysoptSafeMode  = $false
$script:LoadedModules   = @{}
$script:ModulesDir      = ""
$script:ModulesJsonPath = ""
$script:ModulesRegistryNative = $null
$script:_modCachePath   = ""
$script:_modCacheData   = $null

function global:T([string]$Key, [string]$Fallback = "") {
    if ($script:LangDict -and $script:LangDict.Count -gt 0 -and $script:LangDict.ContainsKey($Key)) {
        return $script:LangDict[$Key]
    }
    if ($Fallback) { return $Fallback }
    return $Key
}

# Quick .lang parser (key = value) -- replaced later by LangEngine
# [PERF] Si existe caché JSON válida en %TEMP%\SysOpt\lang-cache.json, la usa
#        en lugar de parsear ~1100 líneas del .lang -- ahorra ~50ms en el boot.
function script:Bootstrap-Language {
    $code = "es-es"   # default; will be overridden by Load-Settings later
    $settingsPath = Join-Path $PSScriptRoot "config.json"
    if (Test-Path $settingsPath) {
        try {
            $cfg = Get-Content $settingsPath -Raw | ConvertFrom-Json
            if ($cfg.Language) { $code = $cfg.Language }
        } catch {}
    }
    $langPath = Join-Path $script:LangDir "$code.lang"
    if (-not (Test-Path $langPath)) { return }

    # -- [PERF] Intentar cargar desde caché JSON ----------------------
    $cacheHit = $false
    if (Test-Path $script:_langCachePath) {
        try {
            $rawJson = [System.IO.File]::ReadAllText($script:_langCachePath, [System.Text.Encoding]::UTF8)
            $cache   = $rawJson | ConvertFrom-Json
            $langHash = (Get-FileHash $langPath -Algorithm MD5).Hash
            if ($cache.LangCode -eq $code -and
                $cache.LangHash -eq $langHash -and
                $cache.Version  -eq $script:AppVersion) {
                # ¡Caché válida! Restaurar diccionario directamente
                $dict = @{}
                foreach ($prop in $cache.Dict.PSObject.Properties) {
                    $dict[$prop.Name] = $prop.Value
                }
                $script:LangDict    = $dict
                $script:CurrentLang = $code
                $script:_langCacheApplied = $true
                $script:_langCacheMsg = "[PERF] Lang cache hit: $code ($($dict.Count) keys)"
                $cacheHit = $true
            }
        } catch {}
    }

    if (-not $cacheHit) {
        # -- Parseo clásico línea a línea -----------------------------
        $dict = @{}
        foreach ($line in [System.IO.File]::ReadAllLines($langPath)) {
            $line = $line.Trim()
            if ($line -eq '' -or $line.StartsWith('#') -or $line.StartsWith('[')) { continue }
            $idx = $line.IndexOf('=')
            if ($idx -gt 0) {
                $k = $line.Substring(0, $idx).Trim()
                $v = $line.Substring($idx + 1).Trim()
                # Remove surrounding quotes if present
                if ($v.Length -ge 2 -and $v[0] -eq '"' -and $v[-1] -eq '"') {
                    $v = $v.Substring(1, $v.Length - 2)
                }
                $dict[$k] = $v
            }
        }
        $script:LangDict    = $dict
        $script:CurrentLang = $code

        # -- Guardar caché para próximo arranque ----------------------
        try {
            $dir = [System.IO.Path]::GetDirectoryName($script:_langCachePath)
            if (-not (Test-Path $dir)) { [System.IO.Directory]::CreateDirectory($dir) | Out-Null }
            $langHash = (Get-FileHash $langPath -Algorithm MD5).Hash
            $cacheObj = @{
                LangCode = $code
                LangHash = $langHash
                Version  = $script:AppVersion
                Dict     = $dict
            }
            $json = $cacheObj | ConvertTo-Json -Depth 3 -Compress
            $tmp  = $script:_langCachePath + ".tmp"
            [System.IO.File]::WriteAllText($tmp, $json, [System.Text.Encoding]::UTF8)
            [System.IO.File]::Copy($tmp, $script:_langCachePath, $true)
            try { [System.IO.File]::Delete($tmp) } catch {}
        } catch {}
    }
}
Bootstrap-Language

# -- [OPT-2] BAML -- Inicializar Application para soporte pack:// URI --------------
# Application.Current es necesario para cargar BAML pre-compilado via pack URI.
# ShutdownMode explícito evita que Application cierre la app al cerrar ventanas.
try {
    if (-not [System.Windows.Application]::Current) {
        $null = [System.Windows.Application]::new()
        [System.Windows.Application]::Current.ShutdownMode = [System.Windows.ShutdownMode]::OnExplicitShutdown
    }
} catch { } # No-op: BAML es opcional, sin Application se usa XAML raw


# -----------------------------------------------------------------------------
$splashXaml = [System.IO.File]::ReadAllText((Join-Path $PSScriptRoot "assets\xaml\SplashWindow.xaml"))
$splashReader = [System.Xml.XmlNodeReader]::new([xml]$splashXaml)
$splashWin    = [Windows.Markup.XamlReader]::Load($splashReader)
$splashMsg    = $splashWin.FindName("SplashMsg")
$splashBar    = $splashWin.FindName("SplashBar")
$splashWin.Show()
[System.Windows.Threading.Dispatcher]::CurrentDispatcher.Invoke([Action]{}, [System.Windows.Threading.DispatcherPriority]::Background)  # pump WPF nativo (sin Forms)

function global:Set-SplashProgress([int]$Pct, [string]$Msg = "") {
    if ($Msg) { $splashMsg.Text = $Msg }
    # Marquee mode: bar animates automatically, we just update text
    [System.Windows.Threading.Dispatcher]::CurrentDispatcher.Invoke([Action]{}, [System.Windows.Threading.DispatcherPriority]::Background)
}
Set-SplashProgress 10 ((T "SplashLoadingAssemblies"))

# =============================================================================
# CARGA DE DLL EXTERNAS  --  todas en .\libs\  relativas a PSScriptRoot
# Orden HARD: MemoryHelper -> DiskEngine -> Core -> Collector -> ThemeEngine    [Soft = post-splash, Cleanup = LAZY]
# compile-dlls.ps1 en .\libs\ recompila todas si modificas los .cs
# =============================================================================

function script:Load-SysOptDll {
    param(
        [string]$DllPath,
        [string]$GuardType,    # tipo C# que confirma que el DLL ya está cargado
        [string]$Label,
        [switch]$Hard          # si presente, falla con throw en lugar de warn
    )

    # -- Ruta 1: SysOptFallbacks disponible -> delegar completamente ---------------
    if (([System.Management.Automation.PSTypeName]"SysOptFallbacks").Type) {
        try {
            [SysOptFallbacks]::LoadDll($DllPath, $GuardType, [bool]$Hard) | Out-Null
            Write-Verbose "SysOpt: DLL cargada: $Label"
            # Write-Log no existe aun en bootstrap; se registra en el log completo mas adelante
            if (Get-Command Write-Log -ErrorAction SilentlyContinue) {
                Write-Log "DLL cargada: $Label" -Level DBG
            }
        } catch {
            $errMsg = "Error cargando $Label -- $($_.Exception.Message)"
            Write-Warning $errMsg
            if (Get-Command Write-Log -ErrorAction SilentlyContinue) {
                Write-Log $errMsg -Level ERR
            }
            if ($Hard) { throw }
        }
        return
    }

    # -- Ruta 2: bootstrap (antes de que Core.dll esté disponible) ------------
    if (([System.Management.Automation.PSTypeName]$GuardType).Type) {
        Write-Verbose "SysOpt: $Label ya cargado en esta sesion"
        return
    }
    if (-not (Test-Path $DllPath)) {
        $msg = "SysOpt: $DllPath no encontrado. Ejecuta compile-dlls.ps1 en .\libs\"
        if ($Hard) { throw $msg } else { Write-Warning $msg; return }
    }
    # v3.3.0-OPT-6: Assembly.Load(bytes) -- carga directa sin validación de firma
    try   {
        $bytes = [System.IO.File]::ReadAllBytes($DllPath)
        [System.Reflection.Assembly]::Load($bytes) | Out-Null
    }
    catch { Write-Verbose "SysOpt: $Label -- Load(bytes): $($_.Exception.Message)" }
}

# -- Ensure-Dll -- lazy loader para DLLs bajo demanda -------------------------
function script:Ensure-Dll {
    param([string]$Name, [string]$Guard)
    if (-not ([System.Management.Automation.PSTypeName]$Guard).Type) {
        Load-SysOptDll -DllPath (Join-Path $script:_libsDir "SysOpt.$Name.dll") `
                       -GuardType $Guard -Label $Name -Hard
    }
}

$script:_libsDir = Join-Path $PSScriptRoot "libs"


# -- [OPT] FindName Cache -- evita recorrido del árbol visual en cada llamada ---
# v3.3.0-OPT: ~200 llamadas FindName/sesión -> caché O(1) tras primera búsqueda
$script:_fnCache = @{}
function script:CFN {
    <#
    .SYNOPSIS  Cached FindName -- busca un control WPF por x:Name con caché O(1).
    .PARAMETER Root   Raíz XAML (ventana, UserControl, etc.)
    .PARAMETER Name   El x:Name del control
    #>
    param([System.Windows.FrameworkElement]$Root, [string]$Name)
    $key = "$($Root.GetHashCode())_$Name"
    if ($script:_fnCache.ContainsKey($key)) { return $script:_fnCache[$key] }
    $ctrl = $Root.FindName($Name)
    if ($null -ne $ctrl) { $script:_fnCache[$key] = $ctrl }
    return $ctrl
}
# -- [DLL 1/11] MemoryHelper -- Win32 P/Invoke para EmptyWorkingSet -------------
Set-SplashProgress 10 ((T "SplashLoadingMemHelper"))
Load-SysOptDll -DllPath (Join-Path $script:_libsDir "SysOpt.MemoryHelper.dll") `
               -GuardType "MemoryHelper" -Label "MemoryHelper" -Hard

# -- [DLL 2/11] Core -- LangEngine + XamlLoader + LogEngine + SysOptFallbacks + Formatter --
# v3.3.0: kernel reducido -- Data Models y AgentBus movidos a Collector.dll
# Core se carga PRIMERO porque SysOptFallbacks.RegisterLoaded() es necesario para la carga paralela
Set-SplashProgress 22 ((T "SplashLoadingCore"))
Load-SysOptDll -DllPath (Join-Path $script:_libsDir "SysOpt.Core.dll") `
               -GuardType "LangEngine" -Label "Core" -Hard

# -- [DLL 3-5/11] Carga paralela: DiskEngine + Collector + ThemeEngine ---------
# v3.3.0-FIX: Usa [SysOptFallbacks]::LoadDllsParallel() (C# puro).
# El método anterior usaba Task.Run con scriptblocks PS -- INCOMPATIBLE con PS5
# porque los scriptblocks requieren un Runspace que no existe en hilos ThreadPool.
# Además, las closures PS capturan variables por referencia (no por valor),
# causando que las 3 tareas cargasen la misma DLL (la última del foreach).
# La nueva implementación C# usa closures correctas y I/O paralelo + Load secuencial.
Set-SplashProgress 36 ((T "SplashLoadingParallel" "Componentes paralelos..."))
$_parDlls = @(
    @{ Dll = 'SysOpt.DiskEngine.dll';  Guard = 'DiskItem_v211';       Label = 'DiskEngine' },
    @{ Dll = 'SysOpt.Collector.dll';   Guard = 'SystemDataCollector'; Label = 'Collector'  },
    @{ Dll = 'SysOpt.ThemeEngine.dll'; Guard = 'ThemeEngine';         Label = 'ThemeEngine' }
)
try {
    $_parPaths  = @(); $_parGuards = @()
    foreach ($pd in $_parDlls) {
        $_parPaths  += Join-Path $script:_libsDir $pd.Dll
        $_parGuards += $pd.Guard
    }
    [SysOptFallbacks]::LoadDllsParallel($_parPaths, $_parGuards, 5000) | Out-Null
    foreach ($pd in $_parDlls) {
        if (([System.Management.Automation.PSTypeName]$pd.Guard).Type) {
            [SysOptFallbacks]::RegisterLoaded($pd.Guard)
            if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log "[BOOT] $($pd.Label) cargado (paralelo C#)" -Level DBG }
        } else {
            if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log "[BOOT] $($pd.Label) NO disponible tras carga paralela" -Level WARN }
        }
    }
    Set-SplashProgress 58 ((T "SplashLoadingParallelDone" "Componentes cargados."))
} catch {
    if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log "[BOOT] Carga paralela (C#) falló: $($_.Exception.Message) -- fallback secuencial" -Level WARN }
    foreach ($pd in $_parDlls) {
        Load-SysOptDll -DllPath (Join-Path $script:_libsDir $pd.Dll) `
                       -GuardType $pd.Guard -Label $pd.Label -Hard
    }
    Set-SplashProgress 58 ((T "SplashLoadingThemeEngine"))
}

# -- [DLL 5/12] LazyLoader -- índice estático de funciones del bundle ----------
# Carga inmediata: necesario para que los stubs on-demand funcionen sin
# dot-sourcear el bundle completo (4944 -> 238 líneas BOOT).
Set-SplashProgress 62 ((T "SplashLoadingLazy" "Cargando índice..."))
Load-SysOptDll -DllPath (Join-Path $script:_libsDir "SysOpt.LazyLoader.dll") `
               -GuardType "SysOpt.LazyLoader" -Label "LazyLoader" -Hard
if (([System.Management.Automation.PSTypeName]"SysOpt.LazyLoader").Type) {
    [SysOpt.LazyLoader]::Initialize($PSScriptRoot)
}

# -- [OPT-2] Cargar BAML resources DLL si existe (generada por compile-xaml.ps1) -
$script:_bamlAvailable = $false
$_bamlDll = Join-Path $script:_libsDir "SysOpt.XamlResources.dll"
if (Test-Path $_bamlDll) {
    try {
        [System.Reflection.Assembly]::LoadFrom($_bamlDll) | Out-Null
        $script:_bamlAvailable = $true
        if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log "[PERF] BAML resources DLL cargada" -Level DBG }
    } catch {
        if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log "[BAML] No se pudo cargar BAML DLL: $($_.Exception.Message)" -Level WARN }
    }
}

# -- [DEFERRED] DLLs Soft -- se cargan post-splash para acelerar el arranque ----
# Estas DLLs no son necesarias durante el boot visual. Se cargan en Window_Loaded
# después de cerrar el splash, reduciendo el tiempo de splash en ~2-3 segundos.
# El usuario ve la ventana principal mientras estas DLLs cargan.
$script:_deferredDlls = @(
    @{ Name = "WseTrim";        GuardType = "WseTrim";                              Label = "WseTrim" },
    @{ Name = "Optimizer";      GuardType = "SysOpt.Optimizer.OptimizerEngine";     Label = "Optimizer" },
    @{ Name = "StartupManager"; GuardType = "SysOpt.StartupManager.StartupEngine";  Label = "StartupManager" },
    @{ Name = "Diagnostics";    GuardType = "SysOpt.Diagnostics.DiagnosticsEngine"; Label = "Diagnostics" },
    @{ Name = "Wizard";         GuardType = "SysOpt.Wizard.WizardEngine";           Label = "Wizard" },
    @{ Name = "Toast";          GuardType = "SysOpt.Toast.ToastManager";            Label = "Toast" },
    @{ Name = "Modules";       GuardType = "ModuleEngine";                         Label = "Modules" },
    @{ Name = "Snapshot";      GuardType = "SysOpt.Snapshot.SnapshotReader";       Label = "Snapshot" }
)
# Nota: SysOpt.Breakout.dll es fire-and-forget -- se carga en proceso aislado
# desde Show-BreakoutGame, no necesita Load-SysOptDll aquí.

# -- Inicializar CTK global ----------------------------------------------------
# ScanTokenManager reemplaza el flag booleano ScanCtl211.Stop para cancelacion
# limpia de runspaces. El token se crea aqui; cada operacion llama RequestNew().
if (([System.Management.Automation.PSTypeName]'ScanTokenManager').Type) {
    [ScanTokenManager]::RequestNew()
    [ScanCtl211]::SetToken([ScanTokenManager]::Token)   # [CTK] bridge token -> ScanCtl211.Stop
    Write-Verbose "SysOpt: ScanTokenManager inicializado -- bridge CTK activo"
} else {
    Write-Warning "SysOpt: ScanTokenManager no disponible -- CTK desactivado (Core.dll v3.1?)"
}

# Ruta centralizada a los XAML externos estáticos
$script:XamlFolder = Join-Path $PSScriptRoot "assets\xaml"

Set-SplashProgress 70 (T "SplashBasicModules" "Módulos base cargados.")

# -----------------------------------------------------------------------------
# [I18N] Variables globales de idioma y tema
# -----------------------------------------------------------------------------
# [MOVED] LangDict -- see early bootstrap above
$script:CurrentLang    = "es-es"       # Código del idioma activo
$script:CurrentTheme   = "default"     # Nombre del tema activo (sin extensión)
$script:ThemesDir      = Join-Path $PSScriptRoot "assets\themes"
$script:_fnBundlePath  = Join-Path $PSScriptRoot "libs\SysOpt.Functions.bundle.ps1"

    # -- Auto-unblock: el usuario solo necesita desbloquear SysOpt.ps1 --
    if (Test-Path $script:_fnBundlePath) {
        Unblock-File -Path $script:_fnBundlePath -ErrorAction SilentlyContinue
    }
# [PERF] Theme cache + settings path -- definidas temprano para pre-apply antes del mega-block
$script:SettingsPath = [System.IO.Path]::Combine(
    [Environment]::GetFolderPath("ApplicationData"), "SysOpt", "settings.json")
$script:_themeCachePath = [System.IO.Path]::Combine($env:TEMP, "SysOpt", "theme-cache.json")
$script:_themeCacheApplied = $false
$script:_themeCacheData = $null
# [MOVED] _langCachePath, _langCacheApplied, LangDir -- see early bootstrap above

# [MOVED] function T -- see early bootstrap above

function global:Get-TC {
    param([string]$Key, [string]$Default = "#FFFFFF")
    if ($script:CurrentThemeColors -and $script:CurrentThemeColors.ContainsKey($Key)) {
        return $script:CurrentThemeColors[$Key]
    }
    return $Default
}

# -- [TOAST] Sincronizar tema del motor de toast y wrapper de envío ------------
function global:Sync-ToastTheme {
    if (([System.Management.Automation.PSTypeName]"SysOpt.Toast.ToastManager").Type) {
        $dict = New-Object 'System.Collections.Generic.Dictionary[string,string]'
        if ($script:CurrentThemeColors) {
            foreach ($kv in $script:CurrentThemeColors.GetEnumerator()) {
                $dict[$kv.Key] = $kv.Value
            }
        }
        [SysOpt.Toast.ToastManager]::SetTheme($dict)
    }
}

function global:Show-Toast {
    param(
        [string]$Title,
        [string]$Message = "",
        [string]$Type = "Info",
        [int]$DurationMs = 4000
    )
    if (-not ([System.Management.Automation.PSTypeName]"SysOpt.Toast.ToastManager").Type) { return }
    if (-not [SysOpt.Toast.ToastManager]::Enabled) { return }
    try {
        $toastType = [SysOpt.Toast.ToastType]::$Type
        [SysOpt.Toast.ToastManager]::Show($Title, $Message, $toastType, $DurationMs)
        if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log "[TOAST] $Type -> $Title" -Level "DBG" -NoUI }
    } catch {
        if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log "[TOAST] Error: $($_.Exception.Message)" -Level "WARN" -NoUI }
    }
}

# -- Registro de ventanas flotantes que deben recibir el tema -----------------
# Cualquier ventana flotante (Tasks, DedupWindow...) se añade aquí al abrirse y
# se elimina al cerrarse. Apply-ThemeWithProgress itera la lista para
# propagar los TB_* brushes a sus ResourceDictionary igual que al MainWindow.
$script:ThemedWindows = [System.Collections.Generic.List[System.Windows.Window]]::new()

# -- New-ThemedWindowResources -------------------------------------------------
# Genera un ResourceDictionary con todos los TB_* SolidColorBrushes del tema
# actual clonados desde $window.Resources, listo para asignarse a una ventana
# flotante y recibir actualizaciones posteriores de Apply-ThemeWithProgress.
function global:New-ThemedWindowResources {
    $rd = [System.Windows.ResourceDictionary]::new()
    foreach ($key in $window.Resources.Keys) {
        $keyStr = "$key"
        if ($keyStr -like 'TB_*') {
            $brush = $window.Resources[$key]
            if ($brush -is [System.Windows.Media.SolidColorBrush]) {
                $rd[$keyStr] = [System.Windows.Media.SolidColorBrush]::new($brush.Color)
            }
        }
    }
    return $rd
}

function global:Update-DynamicThemeValues {
    $tc = $script:CurrentThemeColors
    if (-not $tc -or $tc.Count -eq 0) { return }

    # Compute status colors via C# ThemeApplier
    # BuildStatusColors expects Dictionary<string,string> -- convert Hashtable
    $tcDict = [System.Collections.Generic.Dictionary[string, string]]::new()
    foreach ($k in $tc.Keys) { $tcDict[$k] = [string]$tc[$k] }
    $statusColors = [ThemeApplier]::BuildStatusColors($tcDict)
    foreach ($kv in $statusColors.GetEnumerator()) { $tc[$kv.Key] = $kv.Value }

    # Update TaskStatusMap with themed colors
    $script:TaskStatusMap = @{
        running   = @{ Text = T 'StatusRunning' (T 'TaskInProgress' 'En curso');   Bg = $tc["StatusRunningBg"]; Fg = $tc["StatusRunningFg"] }
        paused    = @{ Text = T 'StatusPaused'  'Pausada';    Bg = $tc["StatusCancelBg"];  Fg = $tc["StatusCancelFg"] }
        done      = @{ Text = T 'StatusDone' 'Completada';    Bg = $tc["StatusDoneBg"];    Fg = $tc["StatusDoneFg"] }
        error     = @{ Text = T 'StatusError' 'Error';        Bg = $tc["StatusErrorBg"];   Fg = $tc["StatusErrorFg"] }
        cancelled = @{ Text = T 'StatusCancel' 'Cancelada';   Bg = $tc["StatusCancelBg"];  Fg = $tc["StatusCancelFg"] }
    }
}

# -----------------------------------------------------------------------------
# Reutiliza runspaces entre operaciones async (exportar, cargar entries, top-files)
# eliminando el overhead de arranque (~2-5 MB por runspace) y la carga de módulos.
# Pool de 1 mín / 5 máx runspaces. Se abre una sola vez al inicio.
# -----------------------------------------------------------------------------
$script:RunspacePool = $null
function global:Initialize-RunspacePool {
    if ($null -ne $script:RunspacePool -and $script:RunspacePool.RunspacePoolStateInfo.State -eq 'Opened') { return }
    try {
        $iss  = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault2()
        # [OPT] Pool de 5 runspaces (era 3) -- permite más tareas concurrentes
        # Nota: ISS preload de DLLs removido -- PS 5.1 no resuelve rutas custom en SessionStateAssemblyEntry
        $pool = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspacePool(1, 5, $iss, $Host)
        $pool.ApartmentState = [System.Threading.ApartmentState]::MTA
        $pool.Open()
        $script:RunspacePool = $pool
        [SysOptFallbacks]::RunspacePoolAvailable = $true
        if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log "RunspacePool abierto (1-5 runspaces)" -Level DBG }
    } catch {
        Write-Verbose "SysOpt: RunspacePool init failed -- will fallback to individual runspaces. $_"
        $script:RunspacePool = $null
        [SysOptFallbacks]::RunspacePoolAvailable = $false
    }
}

# Helper para crear PowerShell asignado al pool (o runspace individual como fallback)
function global:New-PooledPS {
    Initialize-RunspacePool
    $ps = [System.Management.Automation.PowerShell]::Create()
    if ([SysOptFallbacks]::RunspacePoolAvailable -and $null -ne $script:RunspacePool) {
        $ps.RunspacePool = $script:RunspacePool
        return @{ PS = $ps; RS = $null }
    } else {
        $rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
        $rs.ApartmentState = "MTA"; $rs.Open()
        $ps.Runspace = $rs
        return @{ PS = $ps; RS = $rs }
    }
}

# Helper para dispose limpio de PS+RS (RS puede ser $null si usó pool)
function global:Dispose-PooledPS($ctx) {
    try { $ctx.PS.Dispose() } catch {}
    if ($null -ne $ctx.RS) { try { $ctx.RS.Close(); $ctx.RS.Dispose() } catch {} }
}

# -----------------------------------------------------------------------------
function global:Invoke-AggressiveGC {
    try {
        [Runtime.GCSettings]::LargeObjectHeapCompactionMode = `
            [Runtime.GCLargeObjectHeapCompactionMode]::CompactOnce
        [GC]::Collect(2, [GCCollectionMode]::Forced, $true, $true)
        [GC]::WaitForPendingFinalizers()
        [GC]::Collect(2, [GCCollectionMode]::Forced, $true, $true)
        # EmptyWorkingSet en el proceso actual
        $h = [MemoryHelper]::OpenProcess(0x1F0FFF, $false, [Diagnostics.Process]::GetCurrentProcess().Id)
        if ($h -ne [IntPtr]::Zero) {
            [MemoryHelper]::EmptyWorkingSet($h) | Out-Null
            [MemoryHelper]::CloseHandle($h) | Out-Null
        }
    } catch {}
}

# -----------------------------------------------------------------------------
# Verificar permisos de administrador
# -----------------------------------------------------------------------------
function global:Test-Administrator {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal   = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-Administrator)) {
    [System.Windows.MessageBox]::Show(
        (T "ErrAdminRequired" "Este programa requiere permisos de administrador.`n`nPor favor, ejecuta PowerShell como administrador y vuelve a intentarlo."),
        (T "ErrAdminTitle" "Permisos Insuficientes"),
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Error
    )
    exit 1
}

# -----------------------------------------------------------------------------
[SysOptFallbacks]::InitMutex("Global\OptimizadorSistemaGUI_v5")
if (-not [SysOptFallbacks]::AcquireMutex()) {
    [System.Windows.MessageBox]::Show(
        (T "ErrAlreadyRunning" "Ya hay una instancia del Optimizador en ejecución.`n`nCierra la ventana existente antes de abrir una nueva."),
        (T "ErrAlreadyRunningTitle" "Ya en ejecución"),
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Warning
    )
    exit
}

Set-SplashProgress 74 (T "SplashAnalyzingPerms" "Analizando permisos...")

# -----------------------------------------------------------------------------
# XAML -- Interfaz Gráfica v1.0
# -----------------------------------------------------------------------------
# v3.3.0-OPT-2: Intentar BAML primero (3-5x más rápido que parsing XAML raw)
$window = $null
if ($script:_bamlAvailable) {
    try {
        $window = [XamlLoader]::LoadBaml($script:_libsDir, "MainWindow")
        if ($window) { Write-Log "[PERF] MainWindow cargada desde BAML" -Level DBG }
    } catch {
        if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log "[BAML] Fallback MainWindow a XAML: $($_.Exception.Message)" -Level WARN }
        $window = $null
    }
}
if (-not $window) {
    # Fallback: parsing XAML raw (original)
    $xaml = [XamlLoader]::Load($script:XamlFolder, "MainWindow")
    $xaml = $xaml -replace '\{\{APP_VERSION\}\}', "v$($script:AppVersion)"
    Set-SplashProgress 82 (T "SplashBuildingUI" "Construyendo interfaz gráfica...")
    $reader = [System.Xml.XmlNodeReader]::new([xml]$xaml)
    $window = [Windows.Markup.XamlReader]::Load($reader)
}

# [FIX-LANG-SYNC] Exponer $window como variable global para que los callbacks
# OnLanguageChanged_<modId> (funciones global:) puedan acceder a la ventana.
# Las funciones global: solo ven: scope local -> scope global, NO el scope del script.
$global:_sysoptMainWindow = $window

# -- [PERF] Theme cache pre-apply -- DynamicResource brushes ANTES del primer render --
# Lee settings.json rápidamente para obtener el nombre del tema, luego comprueba
# la caché en %TEMP%. Si es válida, inyecta los brushes en window.Resources AHORA,
# de modo que el mega-block y ShowDialog renderizan con colores correctos desde el inicio.
# Esto elimina el flash del tema default -> tema custom.
try {
    if (Test-Path $script:SettingsPath) {
        $rawSettingsJson = [System.IO.File]::ReadAllText($script:SettingsPath, [System.Text.Encoding]::UTF8)
        $settingsQuick = $rawSettingsJson | ConvertFrom-Json
        if ($settingsQuick.Theme -and $settingsQuick.Theme -ne "default") {
            $qThemePath = [System.IO.Path]::Combine($script:ThemesDir, "$($settingsQuick.Theme).theme")
            if ((Test-Path $qThemePath) -and (Test-Path $script:_themeCachePath)) {
                $rawCacheJson = [System.IO.File]::ReadAllText($script:_themeCachePath, [System.Text.Encoding]::UTF8)
                $cache = $rawCacheJson | ConvertFrom-Json
                $themeHash = (Get-FileHash $qThemePath -Algorithm MD5).Hash
                if ($cache.ThemeName -eq $settingsQuick.Theme -and
                    $cache.ThemeHash  -eq $themeHash -and
                    $cache.Version    -eq $script:AppVersion) {
                    # ¡Caché válida! Inyectar brushes pre-computados
                    foreach ($prop in $cache.Brushes.PSObject.Properties) {
                        try {
                            $brush = [System.Windows.Media.SolidColorBrush]::new(
                                [System.Windows.Media.ColorConverter]::ConvertFromString($prop.Value))
                            $window.Resources["TB_$($prop.Name)"] = $brush
                        } catch {}
                    }
                    $script:_themeCacheApplied = $true
                    $script:_themeCacheData = $cache
                    $script:CurrentTheme = $settingsQuick.Theme
                    # Write-Log aún no existe aquí; guardar mensaje para log posterior
                    $script:_themeCacheMsg = "[PERF] Theme cache pre-applied: $($settingsQuick.Theme) ($(($cache.Brushes.PSObject.Properties | Measure-Object).Count) brushes)"
                }
            }
        }
    }
} catch {
    # Write-Log no disponible aún -- ignorar silenciosamente
}

Set-SplashProgress 90 (T "SplashBindingControls" "Enlazando controles...")
# [PERF] RunspacePool init movido a Window_Loaded -- abre 5 runspaces y es lento

# -- [PERF] Parallel DLL loading -- cargar DLLs diferidas en background --------
# Add-Type carga assemblies al AppDomain compartido, disponible en todos los hilos.
# Mientras el hilo UI procesa FindName/handlers (~4500 líneas, lazy dot-source), el background
# carga las 6 DLLs diferidas. Para cuando Window_Loaded se ejecuta, ya están listas.
$script:_bgDllRS = $null
$script:_bgDllPS = $null
$script:_bgDllHandle = $null
try {
    $script:_bgDllRS = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
    $script:_bgDllRS.Open()
    $script:_bgDllPS = [PowerShell]::Create()
    $script:_bgDllPS.Runspace = $script:_bgDllRS
    $script:_bgDllPS.AddScript({
        param($libsDir, $dllNames)
        foreach ($name in $dllNames) {
            $p = [System.IO.Path]::Combine($libsDir, "SysOpt.$name.dll")
            if ([System.IO.File]::Exists($p)) {
                try { [System.Reflection.Assembly]::LoadFrom($p) | Out-Null } catch {}
            }
        }
    }).AddArgument($script:_libsDir).AddArgument(
        @($script:_deferredDlls | ForEach-Object { $_.Name })
    ) | Out-Null
    $script:_bgDllHandle = $script:_bgDllPS.BeginInvoke()
} catch {
    # Fallback: will load synchronously in Window_Loaded
    $script:_bgDllHandle = $null
}

# -----------------------------------------------------------------------------
# [ERR] Error boundary global -- captura excepciones no controladas de runspaces
# y del hilo UI. Loguea el error y muestra un diálogo amigable en lugar de
# que el proceso muera silenciosamente o con un crash report crudo de PowerShell.
# -----------------------------------------------------------------------------

# Handler para excepciones no controladas en cualquier hilo/runspace
$script:UnhandledExHandler = [System.UnhandledExceptionEventHandler]{
    param($sender, $e)
    $ex  = $e.ExceptionObject
    $msg = if ($ex -is [Exception]) { $ex.Message } else { $ex.ToString() }
    $stack = if ($ex -is [Exception] -and $ex.StackTrace) { "`n$($ex.StackTrace)" } else { "" }
    try { Write-Log "[ERR-GLOBAL] $msg$stack" -Level "CRIT" -NoUI } catch {}
    # Intentar mostrar diálogo si el Dispatcher sigue vivo
    try {
        $window.Dispatcher.Invoke([action]{
            $body = "$((T "BgErrorMsg"))`n`n$msg"
            Show-ThemedDialog -Title (T "ErrUnexpectedTitle" "Error inesperado") -Message $body -Type "error"
        })
    } catch {}
}
[System.AppDomain]::CurrentDomain.add_UnhandledException($script:UnhandledExHandler)

# Handler para excepciones no controladas en el hilo del Dispatcher de WPF
$script:DispatcherExHandler = [System.Windows.Threading.DispatcherUnhandledExceptionEventHandler]{
    param($sender, $e)
    $msg   = $e.Exception.Message
    $stack = if ($e.Exception.StackTrace) { "`n$($e.Exception.StackTrace)" } else { "" }
    try { Write-Log "[ERR-DISPATCHER] $msg$stack" -Level "CRIT" } catch {}
    try {
        Show-ThemedDialog -Title (T "ErrUITitle" "Error de interfaz") `
            -Message ((T "ErrUnexpectedUI" "Error inesperado en la interfaz gráfica.") + "`n`n$msg`n`n" + (T "ErrCheckLog" "La aplicación intentará continuar. Revisa el log en .\logs\")) `
            -Type "error"
    } catch {}
    $e.Handled = $true   # evitar que WPF cierre la ventana
}
$window.Dispatcher.add_UnhandledException($script:DispatcherExHandler)

$StatusText    = (CFN $window "StatusText")
$ConsoleOutput = (CFN $window "ConsoleOutput")
$ProgressBar   = (CFN $window "ProgressBar")
$ProgressText  = (CFN $window "ProgressText")
$TaskText      = (CFN $window "TaskText")

# Info panel
$InfoCPU       = (CFN $window "InfoCPU")
$InfoRAM       = (CFN $window "InfoRAM")
$InfoDisk      = (CFN $window "InfoDisk")
$btnRefreshInfo= (CFN $window "btnRefreshInfo")
$CpuPctText    = (CFN $window "CpuPctText")
$RamPctText    = (CFN $window "RamPctText")
$DiskPctText   = (CFN $window "DiskPctText")
$CpuChart      = (CFN $window "CpuChart")
$RamChart      = (CFN $window "RamChart")
$DiskChart     = (CFN $window "DiskChart")

# Checkboxes
$chkDryRun          = (CFN $window "chkDryRun")
$chkOptimizeDisks   = (CFN $window "chkOptimizeDisks")
$chkRecycleBin      = (CFN $window "chkRecycleBin")
$chkTempFiles       = (CFN $window "chkTempFiles")
$chkUserTemp        = (CFN $window "chkUserTemp")
$chkWUCache         = (CFN $window "chkWUCache")
$chkChkdsk          = (CFN $window "chkChkdsk")
$chkClearMemory     = (CFN $window "chkClearMemory")
$chkCloseProcesses  = (CFN $window "chkCloseProcesses")
$chkDNSCache        = (CFN $window "chkDNSCache")
$chkBrowserCache    = (CFN $window "chkBrowserCache")
$chkBackupRegistry  = (CFN $window "chkBackupRegistry")
$chkCleanRegistry   = (CFN $window "chkCleanRegistry")
$chkSFC             = (CFN $window "chkSFC")
$chkDISM            = (CFN $window "chkDISM")
$chkEventLogs       = (CFN $window "chkEventLogs")
$chkShowStartup     = (CFN $window "chkShowStartup")
$chkAutoRestart     = (CFN $window "chkAutoRestart")

# Botones
$btnSelectAll  = (CFN $window "btnSelectAll")
$btnDryRun     = (CFN $window "btnDryRun")
$btnStart      = (CFN $window "btnStart")
$btnCancel     = (CFN $window "btnCancel")
$btnSaveLog    = (CFN $window "btnSaveLog")
$btnWizard     = (CFN $window "btnWizard")
$ctxOutputClear    = (CFN $window "ctxOutputClear")
$ctxOutputSaveLog  = (CFN $window "ctxOutputSaveLog")
$ctxOutputOpenLogs = (CFN $window "ctxOutputOpenLogs")
$ctxOutputReadLast = (CFN $window "ctxOutputReadLast")
$btnExit       = (CFN $window "btnExit")
$btnOptions    = (CFN $window "btnOptions")

# Output panel controls
$OutputPanel         = (CFN $window "OutputPanel")
$gridOutputSplitter  = (CFN $window "gridOutputSplitter")
$btnOutputClose      = (CFN $window "btnOutputClose")
$btnOutputMinimize   = (CFN $window "btnOutputMinimize")
$btnOutputExpand     = (CFN $window "btnOutputExpand")
$btnShowOutput       = (CFN $window "btnShowOutput")

# -- Estado del panel Output --------------------------------------------------
$script:OutputState   = "normal"   # "normal" | "minimized" | "hidden" | "expanded"
$script:OutputNormalH = 200        # altura normal en píxeles
$script:OutputDefaultCollapsed = $false  # [NEW] setting: iniciar con panel contraído
$global:_sysoptOutputDefaultCollapsed = $false

function global:Set-OutputState {
    param([string]$State)
    # Obtener el RowDefinition del Grid padre por índice 3
    $mainGrid = $OutputPanel.Parent
    $outputRowDef = $mainGrid.RowDefinitions[3]

    switch ($State) {
        "hidden" {
            $OutputPanel.Visibility = [System.Windows.Visibility]::Collapsed
            if ($gridOutputSplitter) { $gridOutputSplitter.Visibility = [System.Windows.Visibility]::Collapsed }
            $outputRowDef.MinHeight = 0        # [FIX] Resetear MinHeight para liberar espacio
            $outputRowDef.Height = [System.Windows.GridLength]::new(0)
            $btnShowOutput.Visibility = [System.Windows.Visibility]::Visible
            $script:OutputState = "hidden"
        }
        "minimized" {
            $OutputPanel.Visibility = [System.Windows.Visibility]::Visible
            if ($gridOutputSplitter) { $gridOutputSplitter.Visibility = [System.Windows.Visibility]::Visible }
            $outputRowDef.MinHeight = 36
            $outputRowDef.Height = [System.Windows.GridLength]::new(36)
            $btnShowOutput.Visibility = [System.Windows.Visibility]::Collapsed
            $script:OutputState = "minimized"
        }
        "expanded" {
            $OutputPanel.Visibility = [System.Windows.Visibility]::Visible
            if ($gridOutputSplitter) { $gridOutputSplitter.Visibility = [System.Windows.Visibility]::Visible }
            $outputRowDef.MinHeight = 120      # restaurar MinHeight
            $outputRowDef.Height = [System.Windows.GridLength]::new(1, [System.Windows.GridUnitType]::Star)
            $btnShowOutput.Visibility = [System.Windows.Visibility]::Collapsed
            $script:OutputState = "expanded"
        }
        default {   # "normal"
            $OutputPanel.Visibility = [System.Windows.Visibility]::Visible
            if ($gridOutputSplitter) { $gridOutputSplitter.Visibility = [System.Windows.Visibility]::Visible }
            $outputRowDef.MinHeight = 120      # restaurar MinHeight
            $outputRowDef.Height = [System.Windows.GridLength]::new($script:OutputNormalH)
            $btnShowOutput.Visibility = [System.Windows.Visibility]::Collapsed
            $script:OutputState = "normal"
        }
    }
}

$btnOutputClose.Add_Click({ Set-OutputState "hidden" })
$btnOutputMinimize.Add_Click({
    if ($script:OutputState -eq "minimized") { Set-OutputState "normal" } else { Set-OutputState "minimized" }
})
$btnOutputExpand.Add_Click({
    if ($script:OutputState -eq "expanded") { Set-OutputState "normal" } else { Set-OutputState "expanded" }
})
$btnShowOutput.Add_Click({ Set-OutputState "normal" })

Set-SplashProgress 91 (T "SplashLoading91" "Controles de salida...")
# -----------------------------------------------------------------------------
# DIÁLOGOS TEMÁTICOS -- reemplazan MessageBox y InputBox del sistema
# Tipos: "info" | "warning" | "error" | "success" | "question"
# -----------------------------------------------------------------------------
# -- [LAZY] Helper: extrae una función del bundle via LazyLoader --------------
# Si LazyLoader no está disponible, fallback a dot-source completo del bundle.
function script:Lazy-Load {
    param([string]$FnName)
    if (([System.Management.Automation.PSTypeName]"SysOpt.LazyLoader").Type) {
        $code = [SysOpt.LazyLoader]::ExtractFunction($FnName)
        if ($code) {
            if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log "[LAZY] Extracted: $FnName via LazyLoader" -Level DBG -NoUI }
            Invoke-Expression $code; return
        }
        if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log "[LAZY] ExtractFunction returned null for: $FnName -- fallback to bundle" -Level WARN -NoUI }
    } else {
        if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log "[LAZY] LazyLoader type not available -- fallback to bundle for: $FnName" -Level WARN -NoUI }
    }
    . $script:_fnBundlePath   # fallback
}

function global:Show-ThemedDialog {
    param(
            [string]$Title,
            [string]$Message,
            [ValidateSet("info","warning","error","success","question")]
            [string]$Type = "info",
            [ValidateSet("OK","YesNo")]
            [string]$Buttons = "OK"
        )
    Lazy-Load "Show-ThemedDialog"
    Show-ThemedDialog @PSBoundParameters
}

function global:Show-ThemedInput {
    param(
            [string]$Title,
            [string]$Prompt,
            [string]$Default = ""
        )
    Lazy-Load "Show-ThemedInput"
    Show-ThemedInput @PSBoundParameters
}

# -----------------------------------------------------------------------------
# Directorio raíz de la aplicación -- ruta canónica usada en todo el script
# -----------------------------------------------------------------------------
$script:AppDir = if ($PSScriptRoot -and $PSScriptRoot -ne '') {
    $PSScriptRoot
} elseif ($MyInvocation.MyCommand.Path) {
    Split-Path -Parent $MyInvocation.MyCommand.Path
} else {
    (Get-Location).Path
}

# -----------------------------------------------------------------------------
# Cargar logo desde .\assets\img\sysopt.png e icono de ventana desde .\assets\img\SysOpt.ico
# -----------------------------------------------------------------------------
$imgLogo = (CFN $window "imgLogo")
try {
    $logoPath = Join-Path $script:AppDir "assets\img\sysopt.png"
    if (Test-Path $logoPath) {
        $logoBitmap = New-Object System.Windows.Media.Imaging.BitmapImage
        $logoBitmap.BeginInit()
        $logoBitmap.UriSource   = [Uri]::new($logoPath, [UriKind]::Absolute)
        $logoBitmap.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
        $logoBitmap.EndInit()
        $imgLogo.Source = $logoBitmap
    }
} catch {
    Write-Verbose "SysOpt: No se pudo cargar el logo -- $($_.Exception.Message)"
}

# -----------------------------------------------------------------------------
# [DWM] Helper para barra de título temática -- Windows 10 (dark mode) / 11 (colores)
# Usa DwmSetWindowAttribute para pintar la barra de título nativa con los
# colores del tema activo.  Fallback silencioso en OS anteriores a 1809.
# -----------------------------------------------------------------------------
try {
    # [OPT] Intentar cargar DLL pre-compilada (instantáneo ~5ms)
    # Fallback: compilar C# en runtime (~500ms) si la DLL no existe o está bloqueada
    $dwmDll = Join-Path $script:_libsDir "SysOpt.DwmHelper.dll"
    $dwmLoaded = $false
    if (Test-Path $dwmDll) {
        try {
            [System.Reflection.Assembly]::LoadFrom($dwmDll) | Out-Null
            $dwmLoaded = $null -ne ([System.Management.Automation.PSTypeName]'DwmHelper').Type
        } catch {
            # DLL bloqueada por Zone.Identifier u otro error -> fallback a Add-Type
        }
    }
    if (-not $dwmLoaded) {
        Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class DwmHelper {
    [DllImport("dwmapi.dll", PreserveSig = true)]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int val, int size);
    public static void SetDarkMode(IntPtr hwnd, bool dark) {
        int v = dark ? 1 : 0;
        // DWMWA_USE_IMMERSIVE_DARK_MODE = 20 (Win10 1809+)
        DwmSetWindowAttribute(hwnd, 20, ref v, 4);
    }
    public static void SetCaptionColor(IntPtr hwnd, byte r, byte g, byte b) {
        // DWMWA_CAPTION_COLOR = 35 (Win11 22000+)
        int c = (int)r | ((int)g << 8) | ((int)b << 16);
        DwmSetWindowAttribute(hwnd, 35, ref c, 4);
    }
    public static void SetTextColor(IntPtr hwnd, byte r, byte g, byte b) {
        // DWMWA_TEXT_COLOR = 36 (Win11 22000+)
        int c = (int)r | ((int)g << 8) | ((int)b << 16);
        DwmSetWindowAttribute(hwnd, 36, ref c, 4);
    }
}
"@ -ErrorAction SilentlyContinue
    }
} catch {}

# Icono de la ventana principal (barra de tareas y Alt+Tab)
try {
    $icoPath = Join-Path $script:AppDir "assets\img\SysOpt.ico"
    if (Test-Path $icoPath) {
        $window.Icon = [System.Windows.Media.Imaging.BitmapFrame]::Create(
            [Uri]::new($icoPath, [UriKind]::Absolute))
    }
} catch {
    Write-Verbose "SysOpt: No se pudo cargar el icono -- $($_.Exception.Message)"
}

# Estado de cancelación
$script:CancelSource = $null
$script:WasCancelled = $false

# -----------------------------------------------------------------------------
# [LOG] Logging estructurado -- archivo rotante diario + consola UI
# Ruta: .\logs\SysOpt_YYYY-MM-DD.log  (relativo al script)
# Niveles: INFO (por defecto), WARN, ERROR
# Thread-safe: StreamWriter con mutex de nombre para acceso concurrente
# -----------------------------------------------------------------------------
# -- [LOG] Logger delegado a LogEngine (SysOpt.Core.dll) ---------------------
# LogEngine es thread-safe, soporta rotación diaria y mutex con nombre.
# Write-Log e Initialize-Logger mantienen la misma firma pública para que
# el resto del script no necesite cambios.
# -----------------------------------------------------------------------------

function global:Initialize-Logger {
    try {
        $logsDir = Join-Path $script:AppDir "logs"
        [LogEngine]::Initialize($logsDir)
        [LogEngine]::Header("SysOpt", $script:AppVersion)
    } catch {
        # LogEngine no disponible aún (carga inicial antes de DLLs) -- silencioso
    }
}

function global:Write-Log {
    param(
        [string]$Message,
        [ValidateSet("DBG","INFO","WARN","ERR","CRIT","UI")][string]$Level = "INFO",
        [switch]$NoUI    # si $true, solo va al archivo (llamadas desde runspaces)
    )
    $timestamp = Get-Date -Format "HH:mm:ss"

    # -- Escribir al archivo vía LogEngine -----------------------------------
    try { [LogEngine]::Write($Message, $Level) } catch {}

    # -- Consola UI (solo hilo principal) ------------------------------------
    if ($Level -eq "UI" -and $null -ne $ConsoleOutput) {
        try { $ConsoleOutput.AppendText("$Message`n"); $ConsoleOutput.ScrollToEnd() } catch {}
    } elseif (-not $NoUI -and $null -ne $ConsoleOutput) {
        try { $ConsoleOutput.AppendText("[$timestamp] $Message`n"); $ConsoleOutput.ScrollToEnd() } catch {}
    }
}

# Write-ConsoleMain -- mensajes puramente visuales: van a la consola de pantalla pero NO
# al archivo de log. Usa nivel "UI" para separar instrucciones decorativas de eventos reales.
function global:Write-ConsoleMain {
    param([string]$Message)
    Write-Log -Message $Message -Level "UI"
}

# Inicializar el logger en cuanto AppDir esté disponible
Initialize-Logger

# [MOVED] Auditoría de DLL diferida al timer post-boot (ver _bootPerfTimer)


# -----------------------------------------------------------------------------
# [TASKPOOL] Registro centralizado de tareas async -- alimenta la pestaña ? Tareas
# Cada operación async (escaneo, export, snapshot, dedup...) se registra aquí.
# La pestaña la lee cada segundo desde un DispatcherTimer.
# -----------------------------------------------------------------------------
$script:TaskPool = [System.Collections.Concurrent.ConcurrentDictionary[string,object]]::new()
$script:TaskIdSeq = 0

function global:Register-Task {
    param(
        [string]$Id,        # clave única (p.ej. "scan", "csv", "dedup")
        [string]$Name,      # nombre visible
        [string]$Icon = "$([char]0x23F3)",
        [string]$IconBg = (Get-TC 'BgInput' '#1A2040')
    )
    $task = [System.Collections.Hashtable]::Synchronized(@{
        Id         = $Id
        Name       = $Name
        Icon       = $Icon
        IconBg     = $IconBg
        Status     = "running"   # running | done | error | cancelled | paused
        Pct        = 0
        Detail     = ""
        StartTime  = [datetime]::Now
        EndTime    = $null
        # -- Hooks de control (poblados por quien lanza la tarea) -------------
        CancelFn   = $null       # ScriptBlock: cancela la tarea
        PauseFn    = $null       # ScriptBlock: pausa  (solo diskscan)
        ResumeFn   = $null       # ScriptBlock: reanuda (solo diskscan)
        Paused     = $false
    })
    $script:TaskPool[$Id] = $task
    Write-Log "[TASK] Iniciada: $Name" -Level "DBG" -NoUI
    return $task
}

function global:Complete-Task {
    param([string]$Id, [switch]$IsError, [string]$Detail = "")
    if ($script:TaskPool.ContainsKey($Id)) {
        $t = $script:TaskPool[$Id]
        $t.Status  = if ($IsError) { "error" } else { "done" }
        $t.Pct     = if ($IsError) { $t.Pct } else { 100 }
        $t.Detail  = if ($Detail) { $Detail } else { $t.Detail }
        $t.EndTime = [datetime]::Now
        Write-Log "[TASK] Completada ($($t.Status)): $($t.Name)" -Level $(if($IsError){"WARN"}else{"DBG"}) -NoUI
    }
}

function global:Update-Task {
    param([string]$Id, [int]$Pct = -1, [string]$Detail = "")
    if ($script:TaskPool.ContainsKey($Id)) {
        $t = $script:TaskPool[$Id]
        if ($Pct -ge 0)  { $t.Pct    = [math]::Min(99, $Pct) }
        if ($Detail)     { $t.Detail = $Detail }
    }
}
# [DAL] WMI queries migradas a C# SystemDataCollector en SysOpt.Collector.dll
# Las funciones Get-SharedCimSession e Invoke-CimQuery fueron eliminadas en v3.2.1
# Todas las consultas WMI ahora pasan por [SystemDataCollector]::Get*Snapshot()

# -----------------------------------------------------------------------------
# Chart history buffers (60 samples each)
# -----------------------------------------------------------------------------
$script:CpuHistory  = [System.Collections.Generic.List[double]]::new()
$script:RamHistory  = [System.Collections.Generic.List[double]]::new()
$script:DiskHistory = [System.Collections.Generic.List[double]]::new()
$script:DiskCounter = $null
# v3.3.0-OPT: PerformanceCounter diferido a primera apertura de tab Rendimiento
# New-Object PerformanceCounter tarda ~100-200ms (lectura registro WMI) -> no bloquear boot
function script:Ensure-DiskCounter {
    if ($null -ne $script:DiskCounter) { return }
    try {
        $script:DiskCounter = New-Object System.Diagnostics.PerformanceCounter(
            "PhysicalDisk", "% Disk Time", "_Total", $false)
        $null = $script:DiskCounter.NextValue()   # first call always 0, warm up
        Write-Log "[PERF] PerformanceCounter inicializado (lazy)" -Level DBG
    } catch {
        $script:DiskCounter = $null
        Write-Log "[PERF] PerformanceCounter no disponible: $_" -Level WARN
    }
}

# -----------------------------------------------------------------------------
# Helper: Draw sparkline chart on a WPF Canvas
Set-SplashProgress 92 (T "SplashLoading92" "Sistema de tareas...")
# -----------------------------------------------------------------------------
function global:Draw-SparkLine {
    param(
        [System.Windows.Controls.Canvas]$Canvas,
        [System.Collections.Generic.List[double]]$Data,
        [string]$LineColor,
        [string]$FillColor
    )

    $Canvas.Children.Clear()
    $w = $Canvas.ActualWidth
    $h = $Canvas.ActualHeight
    if ($w -le 0 -or $h -le 0) { $w = 300; $h = 52 }

    $maxPoints = 60
    $pts = $Data.ToArray()
    if ($pts.Count -eq 0) { return }

    $step = if ($pts.Count -gt 1) { $w / ($maxPoints - 1) } else { $w }
    $startIdx = [Math]::Max(0, $pts.Count - $maxPoints)
    $visible = $pts[$startIdx..($pts.Count - 1)]

    # Grid lines at 25%, 50%, 75%
    foreach ($gridPct in @(25, 50, 75)) {
        $gy = $h - ($gridPct / 100.0 * $h)
        $line = New-Object System.Windows.Shapes.Line
        $line.X1 = 0; $line.X2 = $w
        $line.Y1 = $gy; $line.Y2 = $gy
        $line.Stroke = [System.Windows.Media.Brushes]::White
        $line.Opacity = 0.06
        $line.StrokeDashArray = [System.Windows.Media.DoubleCollection]::new()
        $line.StrokeDashArray.Add(4); $line.StrokeDashArray.Add(4)
        [void]$Canvas.Children.Add($line)
    }

    # Build polyline points
    $polyPts = New-Object System.Windows.Media.PointCollection
    for ($i = 0; $i -lt $visible.Count; $i++) {
        $xOffset = $maxPoints - $visible.Count
        $x = ($i + $xOffset) * $step
        $y = $h - ($visible[$i] / 100.0 * $h)
        $polyPts.Add([System.Windows.Point]::new($x, $y))
    }

    # Fill polygon (area under line)
    if ($polyPts.Count -ge 2) {
        $fillPts = New-Object System.Windows.Media.PointCollection
        foreach ($p in $polyPts) { $fillPts.Add($p) }
        $fillPts.Add([System.Windows.Point]::new($polyPts[$polyPts.Count-1].X, $h))
        $fillPts.Add([System.Windows.Point]::new($polyPts[0].X, $h))

        $poly = New-Object System.Windows.Shapes.Polygon
        $poly.Points = $fillPts
        $gradBrush = New-Object System.Windows.Media.LinearGradientBrush
        $gradBrush.StartPoint = [System.Windows.Point]::new(0, 0)
        $gradBrush.EndPoint   = [System.Windows.Point]::new(0, 1)
        $gs1 = New-Object System.Windows.Media.GradientStop
        $gs1.Color  = [System.Windows.Media.ColorConverter]::ConvertFromString($FillColor)
        $gs1.Offset = 0
        $gs2 = New-Object System.Windows.Media.GradientStop
        $gs2.Color  = [System.Windows.Media.ColorConverter]::ConvertFromString($FillColor)
        $gs2.Offset = 1
        $gs2.Color = [System.Windows.Media.Color]::FromArgb(5, $gs2.Color.R, $gs2.Color.G, $gs2.Color.B)
        $gradBrush.GradientStops.Add($gs1)
        $gradBrush.GradientStops.Add($gs2)
        $poly.Fill    = $gradBrush
        $poly.Opacity = 0.35
        [void]$Canvas.Children.Add($poly)
    }

    # Draw the line
    if ($polyPts.Count -ge 2) {
        $pline = New-Object System.Windows.Shapes.Polyline
        $pline.Points = $polyPts
        $pline.Stroke = New-Object System.Windows.Media.SolidColorBrush(
            [System.Windows.Media.ColorConverter]::ConvertFromString($LineColor))
        $pline.StrokeThickness = 1.8
        [void]$Canvas.Children.Add($pline)
    }

    # Current value dot
    if ($polyPts.Count -ge 1) {
        $lastPt = $polyPts[$polyPts.Count - 1]
        $dot = New-Object System.Windows.Shapes.Ellipse
        $dot.Width  = 6; $dot.Height = 6
        $dot.Fill   = New-Object System.Windows.Media.SolidColorBrush(
            [System.Windows.Media.ColorConverter]::ConvertFromString($LineColor))
        [System.Windows.Controls.Canvas]::SetLeft($dot, $lastPt.X - 3)
        [System.Windows.Controls.Canvas]::SetTop($dot,  $lastPt.Y - 3)
        [void]$Canvas.Children.Add($dot)
    }
}

# -----------------------------------------------------------------------------
# [N1] Actualizar panel superior (CPU, RAM, Disco C:) + gráficas sparkline
#      Síncrono en el UI thread -- igual que el original. Los CimInstance rápidos
#      (<150 ms) no congelan la UI en un tick de 2 segundos.
# -----------------------------------------------------------------------------
function global:Update-SystemInfo {
    try {
        # SystemDataCollector snapshots -- consolidates CIM queries
        $ramSnap  = [SystemDataCollector]::GetRamSnapshot()
        $cpuSnap  = [SystemDataCollector]::GetCpuSnapshot()
        $diskSnap = [SystemDataCollector]::GetDiskSnapshot()

        $totalGB = [math]::Round($ramSnap.TotalBytes / 1GB, 1)
        $freeGB  = [math]::Round($ramSnap.FreeBytes  / 1GB, 1)
        $usedPct = [math]::Round($ramSnap.UsedPercent)

        $diskVol     = $diskSnap.Volumes | Where-Object { $_.DeviceId -eq 'C:' } | Select-Object -First 1
        $diskTotalGB = if ($diskVol) { [math]::Round($diskVol.TotalBytes / 1GB, 1) } else { 0 }
        $diskFreeGB  = if ($diskVol) { [math]::Round($diskVol.FreeBytes  / 1GB, 1) } else { 0 }
        $diskUsedPct = if ($diskVol) { [math]::Round($diskVol.UsedPercent) } else { 0 }

        $cpuLoad = [math]::Min(100, [math]::Max(0, $cpuSnap.LoadPercent))
        $cpuName = ($cpuSnap.Name -replace '\s+', ' ')
        if ($cpuName.Length -gt 35) { $cpuName = $cpuName.Substring(0, 35) + [char]0x2026 }

        # Actividad de disco via PerformanceCounter
        $diskActivity = 0.0
        if ($null -ne $script:DiskCounter) {
            try { $diskActivity = [math]::Min(100, [math]::Max(0, $script:DiskCounter.NextValue())) } catch {}
        }

        # Actualizar buffers de historial
        $script:CpuHistory.Add($cpuLoad)
        $script:RamHistory.Add([double]$usedPct)
        $script:DiskHistory.Add($diskActivity)
        if ($script:CpuHistory.Count  -gt 60) { $script:CpuHistory.RemoveAt(0) }
        if ($script:RamHistory.Count  -gt 60) { $script:RamHistory.RemoveAt(0) }
        if ($script:DiskHistory.Count -gt 60) { $script:DiskHistory.RemoveAt(0) }

        # Actualizar etiquetas del panel superior
        $InfoCPU.Text  = $cpuName
        $InfoRAM.Text  = "$freeGB $(T 'GbFree' (T 'PerfGBFree' 'GB libre')) / $totalGB GB"
        $InfoDisk.Text = "$diskFreeGB $(T 'GbFree' (T 'PerfGBFree' 'GB libre')) / $diskTotalGB GB"

        $CpuPctText.Text  = "  $([int]$cpuLoad)%"
        $RamPctText.Text  = "  $usedPct%"
        $DiskPctText.Text = "  $diskUsedPct% $(T 'PctUsed' 'usado')"

        # Dibujar gráficas sparkline
        Draw-SparkLine -Canvas $CpuChart  -Data $script:CpuHistory  -LineColor (Get-TC 'AccentBlue' '#5BA3FF') -FillColor (Get-TC 'AccentBlue' '#5BA3FF')
        Draw-SparkLine -Canvas $RamChart  -Data $script:RamHistory  -LineColor (Get-TC 'AccentGreen' '#4AE896') -FillColor (Get-TC 'AccentGreen' '#4AE896')
        Draw-SparkLine -Canvas $DiskChart -Data $script:DiskHistory -LineColor (Get-TC 'AccentAmber' '#FFB547') -FillColor (Get-TC 'AccentAmber' '#FFB547')

    } catch {
        $InfoCPU.Text  = (T "NotAvailable" "No disponible")
        $InfoRAM.Text  = (T "NotAvailable" "No disponible")
        $InfoDisk.Text = (T "NotAvailable" "No disponible")
    }
}

# Timer de actualización del panel superior -- cada 2 segundos (igual que el original)
$chartTimer = New-Object System.Windows.Threading.DispatcherTimer
$chartTimer.Interval = [TimeSpan]::FromSeconds(2)
$chartTimer.Add_Tick({ Update-SystemInfo })

# Arrancar todo una vez que la ventana esté completamente cargada
# (garantiza que los Canvas tienen ActualWidth/Height reales para las gráficas)
# -----------------------------------------------------------------------------
# [U1] Forzar tema oscuro en los ComboBox recorriendo su visual tree
#      WPF ignora Background en el ToggleButton interno a menos que se recorra
#      explícitamente el árbol visual después de que el control está cargado.
# -----------------------------------------------------------------------------
# Get-VisualChildren removed -- use [ThemeApplier]::GetVisualChildren() directly

function global:Apply-ComboBoxDarkTheme {
    param([System.Windows.Controls.ComboBox]$ComboBox)
    [ThemeApplier]::ApplyComboBoxTheme(
        $ComboBox,
        (Get-TC 'BgInput' '#1A1E2F'),
        (Get-TC 'BorderSubtle' '#3A4468'),
        (Get-TC 'TextPrimary' '#E8ECF4'),
        (Get-TC 'ComboHover' '#1E3A5C')
    )
}

# [DWM] Aplicar tema a la barra de título cuando el HWND esté listo
$window.Add_SourceInitialized({
    Apply-TitleBarTheme
    Write-Log "[DWM] Barra de título temática aplicada" -Level "INFO" -NoUI

    # -- [OPT] Cargar Forms aquí (diferido del boot, necesario para Screen) --
    if (-not ('System.Windows.Forms.Screen' -as [type])) {
        Add-Type -AssemblyName System.Windows.Forms
    }

    # -- [RESPONSIVE] Adaptar ventana al monitor actual ----------------------
    try {
        $w = $this                    # $this = Window (sender)
        $hwnd   = (New-Object System.Windows.Interop.WindowInteropHelper($w)).Handle
        $screen = [System.Windows.Forms.Screen]::FromHandle($hwnd)
        $wa     = $screen.WorkingArea # working area en píxeles

        # Factor DPI -> convertir píxeles a DIPs (unidades WPF)
        $src = [System.Windows.PresentationSource]::FromVisual($w)
        $dX  = if ($src) { $src.CompositionTarget.TransformToDevice.M11 } else { 1.0 }
        $dY  = if ($src) { $src.CompositionTarget.TransformToDevice.M22 } else { 1.0 }

        $waW = $wa.Width  / $dX
        $waH = $wa.Height / $dY
        $margin  = 10
        $resized = $false

        if ($w.Width  -gt ($waW - $margin)) {
            $w.Width  = [math]::Max($w.MinWidth,  $waW - $margin)
            $resized  = $true
        }
        if ($w.Height -gt ($waH - $margin)) {
            $w.Height = [math]::Max($w.MinHeight, $waH - $margin)
            $resized  = $true
        }

        if ($resized) {
            # Re-centrar en el monitor real (no en el primario)
            $w.WindowStartupLocation = "Manual"
            $w.Left = ($wa.Left / $dX) + (($waW - $w.Width)  / 2)
            $w.Top  = ($wa.Top  / $dY) + (($waH - $w.Height) / 2)
            Write-Log "[UI] Ventana adaptada al monitor: $([int]$w.Width)x$([int]$w.Height) ($($screen.DeviceName))" -Level "INFO" -NoUI
        }
    } catch {
        Write-Log "[UI] Error adaptando ventana al monitor: $($_.Exception.Message)" -Level "WARN" -NoUI
    }
})

$window.Add_Loaded({
    try {
    # [MOVED] splash close moved to before ShowDialog
    } catch {}

    # -- [DEFERRED-LOAD] Recoger DLLs del background (ya cargadas en paralelo) --
    if ($script:_bgDllHandle) {
        try {
            if (-not $script:_bgDllHandle.IsCompleted) {
                $script:_bgDllPS.EndInvoke($script:_bgDllHandle) | Out-Null
            }
            Write-Log "DLLs diferidas cargadas via background thread" -Level DBG -NoUI
        } catch {
            Write-Log "Background DLL load error: $($_.Exception.Message)" -Level WARN -NoUI
        } finally {
            try { $script:_bgDllPS.Dispose() } catch {}
            try { $script:_bgDllRS.Close(); $script:_bgDllRS.Dispose() } catch {}
            $script:_bgDllHandle = $null
            $script:_bgDllPS = $null
            $script:_bgDllRS = $null
        }
    }
    # Fallback: si background falló, cargar síncronamente
    foreach ($dll in $script:_deferredDlls) {
        if (-not ([System.Management.Automation.PSTypeName]$dll.GuardType).Type) {
            Load-SysOptDll -DllPath (Join-Path $script:_libsDir "SysOpt.$($dll.Name).dll") `
                           -GuardType $dll.GuardType -Label $dll.Label
        }
    }
    Write-Log "DLLs diferidas verificadas post-splash" -Level DBG -NoUI

    # -- [LAZY] Pre-cargar fase BOOT del bundle (Show-ThemedDialog + Show-ThemedInput) --
    if (([System.Management.Automation.PSTypeName]"SysOpt.LazyLoader").Type) {
        try {
            Invoke-Expression ([SysOpt.LazyLoader]::ExtractPhase("BOOT"))
            [SysOpt.LazyLoader]::MarkPhaseLoaded("BOOT")
            Write-Log "[PERF] LazyLoader BOOT phase loaded (238 lines vs 4944 total)" -Level DBG -NoUI
        } catch {
            Write-Log "[WARN] BOOT phase error: $_ -- stubs mantienen fallback" -Level WARN -NoUI
        }
    }

    # [C3-APP] Ensure Application.Current exists for DynamicResource in popups
    # PowerShell WPF apps don't always create an Application object automatically.
    # Without it, DynamicResource lookups in popup ContextMenus fail silently.
    if ($null -eq [System.Windows.Application]::Current) {
        try {
            $app = [System.Windows.Application]::new()
            $app.ShutdownMode = [System.Windows.ShutdownMode]::OnExplicitShutdown
        } catch {}
    }

    # [C3-PRE] Copiar TB_* del Window al Application.Current.Resources
    # Los ContextMenu en Popups heredan Application.Resources pero NO Window.Resources.
    # Esto garantiza que cualquier CM (incluyendo DataTemplate) resuelva los brushes.
    try {
        foreach ($rk in @($window.Resources.Keys)) {
            if ([string]$rk -like "TB_*") {
                [System.Windows.Application]::Current.Resources[[string]$rk] = $window.Resources[$rk]
            }
        }
    } catch {}

    # [C3] Restaurar configuracion guardada (tema, idioma, preferencias)
    Load-Settings

    # -- [NEW] Aplicar estado por defecto del panel de salida --
    # [FIX] Diferir con DispatcherTimer para que el layout este completo
    Write-Log ("[CFG] OutputDefaultCollapsed after Load-Settings: {0}" -f $script:OutputDefaultCollapsed) -Level "DBG" -NoUI
    if ($script:OutputDefaultCollapsed -eq $true) {
        $script:_deferOutputTimer = New-Object System.Windows.Threading.DispatcherTimer
        $script:_deferOutputTimer.Interval = [System.TimeSpan]::FromMilliseconds(150)
        $script:_deferOutputTimer.Add_Tick({
            $script:_deferOutputTimer.Stop()
            Set-OutputState "hidden"
        })
        $script:_deferOutputTimer.Start()
    }

    try {
        Load-Language $script:CurrentLang
    } catch {}

    if ($script:CurrentTheme -ne "default") {
        if ($script:_themeCacheApplied -and $script:_themeCacheData) {
            # -- [PERF] Caché pre-aplicada: solo gradientes + estado (sin progress window) --
            try {
                # Propagar brushes a Application.Resources (para Popups/ContextMenu)
                foreach ($prop in $script:_themeCacheData.Brushes.PSObject.Properties) {
                    try {
                        $brush = $window.Resources["TB_$($prop.Name)"]
                        if ($brush) {
                            [System.Windows.Application]::Current.Resources["TB_$($prop.Name)"] = $brush
                        }
                    } catch {}
                }
                # Aplicar gradient map desde caché
                $gradMap = [System.Collections.Generic.Dictionary[string, [System.Windows.Media.Color]]]::new()
                foreach ($prop in $script:_themeCacheData.GradientMap.PSObject.Properties) {
                    try {
                        $gradMap[$prop.Name] = [System.Windows.Media.ColorConverter]::ConvertFromString($prop.Value)
                    } catch {}
                }
                if ($gradMap.Count -gt 0) {
                    [ThemeApplier]::ReplaceGradientColors($window, $gradMap)
                }
                # Restaurar estado del tema
                $script:CurrentThemeColors = @{}
                foreach ($prop in $script:_themeCacheData.ThemeColors.PSObject.Properties) {
                    $script:CurrentThemeColors[$prop.Name] = $prop.Value
                }
                Update-DynamicThemeValues
                Write-Log "[PERF] Theme restored from cache (no progress window)" -Level DBG -NoUI
                if ($script:_langCacheApplied) { Write-Log $script:_langCacheMsg -Level DBG -NoUI }
            } catch {
                Write-Log "[WARN] Theme cache restore error: $_ -- falling back to full apply" -Level WARN -NoUI
                Apply-ThemeWithProgress -ThemeName $script:CurrentTheme
                Update-DynamicThemeValues
            }
            $script:_themeCacheData = $null  # Liberar memoria
        } else {
            try {
                Apply-ThemeWithProgress -ThemeName $script:CurrentTheme
                Update-DynamicThemeValues
            } catch {}
        }
    }
    # [PERF] Log de lang cache (cuando no hubo theme cache)
    if ($script:_langCacheApplied -and -not $script:_themeCacheApplied) {
        Write-Log $script:_langCacheMsg -Level DBG -NoUI
    }

    # Aplicar tema oscuro a todos los ComboBox de la ventana
    try {
        $allCombos = [ThemeApplier]::GetVisualChildren($window) | Where-Object { $_ -is [System.Windows.Controls.ComboBox] }
        foreach ($cb in $allCombos) { Apply-ComboBoxDarkTheme $cb }
    } catch {}

    # Aplicar colores de tema a los botones nombrados
    try { Apply-ButtonTheme } catch {}

    # [TOAST] Inicializar motor de notificaciones con tema y estado
    try {
        if (([System.Management.Automation.PSTypeName]"SysOpt.Toast.ToastManager").Type) {
            Sync-ToastTheme
            [SysOpt.Toast.ToastManager]::Debug = [LogEngine]::DebugEnabled
        }
    } catch {}

    $chartTimer.Start()
    # [OPT] Update-SystemInfo se difiere 50ms -- las WMI queries (CPU, RAM, Disco)
    # bloqueaban el UI thread 5-15s ANTES de que el módulo loading pudiera arrancar.
    # Ahora se ejecuta en paralelo: módulos cargan mientras SystemInfo se recopila.
    $script:_sysInfoBootTimer = [System.Windows.Threading.DispatcherTimer]::new()
    $script:_sysInfoBootTimer.Interval = [TimeSpan]::FromMilliseconds(50)
    $script:_sysInfoBootTimer.Add_Tick({
        $script:_sysInfoBootTimer.Stop()
        $script:_sysInfoBootTimer = $null
        Update-SystemInfo
    })
    $script:_sysInfoBootTimer.Start()

    # -- [F6+] Carga PARALELA de módulos ----------------------------------------
    # Ventana visible al instante. Runspace BG pre-lee DLLs de módulos
    # mientras el UI thread dot-sourcea el bundle -> ahorro ~1-3s.
    $script:_borderModuleLoading = (CFN $window "borderModuleLoading")
    $script:_txtModuleLoading    = (CFN $window "txtModuleLoading")
    if ($script:_borderModuleLoading) { $script:_borderModuleLoading.Visibility = "Visible" }
    if ($script:_txtModuleLoading) { $script:_txtModuleLoading.Text = (T "ModLoadPreparing" "Preparando módulos...") }

    # -- Mini-spinner para lazy loading de pestañas ---------------------------
    $script:_borderTabSpinner = (CFN $window "borderTabSpinner")
    $script:_txtTabSpinner    = (CFN $window "txtTabSpinner")

    # -- Runspace BG: Pre-leer DLL bytes en background (I/O paralelo) ------
    $script:_modBgPS     = $null
    $script:_modBgHandle = $null
    $script:_modPreRead  = $null
    try {
        $bgW = New-PooledPS
        $script:_modBgPS = $bgW.PS
        [void]$script:_modBgPS.AddScript({
            param($ModulesDir, $BundlePath)
            $result = @{ DllBytes = @{} }
            # Warm bundle into OS file-cache (dot-source will be faster)
            try { [void][System.IO.File]::ReadAllBytes($BundlePath) } catch {}
            # Pre-read all module DLL bytes
            if (Test-Path $ModulesDir) {
                Get-ChildItem $ModulesDir -Directory | ForEach-Object {
                    $ld = Join-Path $_.FullName 'libs'
                    if (Test-Path $ld) {
                        Get-ChildItem $ld -Filter '*.dll' | ForEach-Object {
                            try { $result.DllBytes[$_.FullName] = [System.IO.File]::ReadAllBytes($_.FullName) } catch {}
                        }
                    }
                }
            }
            return $result
        }).AddArgument((Join-Path $script:AppDir "modules")).AddArgument($script:_fnBundlePath)
        $script:_modBgHandle = $script:_modBgPS.BeginInvoke()
        Write-Log "[BOOT] BG DLL pre-read lanzado" -Level DBG -NoUI
    } catch {
        Write-Log "[BOOT] BG pre-read no disponible, usará I/O síncrono: $_" -Level WARN -NoUI
    }

    # -- DispatcherTimer: pasos en UI thread (BG corre en paralelo) --------
    $script:_modLoadStep  = 0
    $script:_modLoadTimer = [System.Windows.Threading.DispatcherTimer]::new()
    $script:_modLoadTimer.Interval = [TimeSpan]::FromMilliseconds(30)
    $script:_modLoadTimer.Add_Tick({
        $script:_modLoadStep++
        switch ($script:_modLoadStep) {
            1 {
                # UI pintó la barra -> siguiente tick hace dot-source
                if ($script:_txtModuleLoading) { $script:_txtModuleLoading.Text = (T "ModLoadFunctions" "Cargando funciones...") }
            }
            2 {
                # [LAZY] Cargar solo TAB_MODULOS del bundle (349 líneas vs 4944 total)
                try {
                    if (([System.Management.Automation.PSTypeName]"SysOpt.LazyLoader").Type) {
                        Invoke-Expression ([SysOpt.LazyLoader]::ExtractPhase("TAB_MODULOS"))
                        [SysOpt.LazyLoader]::MarkPhaseLoaded("TAB_MODULOS")
                        Write-Log "[PERF] TAB_MODULOS loaded via LazyLoader (349 lines)" -Level DBG -NoUI
                    } else {
                        . $script:_fnBundlePath   # fallback
                    }
                } catch {
                    Write-Log "[MOD] Error cargando funciones de módulos: $_" -Level WARN -NoUI
                }
                if ($script:_txtModuleLoading) { $script:_txtModuleLoading.Text = (T "ModLoadInit" "Inicializando módulos...") }
            }
            3 {
                # Recoger bytes del BG (si aún corre, reintentar en siguiente tick)
                if ($script:_modBgHandle -and -not $script:_modBgHandle.IsCompleted) {
                    $script:_modLoadStep--
                    return
                }
                if ($script:_modBgHandle) {
                    try {
                        $raw = $script:_modBgPS.EndInvoke($script:_modBgHandle)
                        $script:_modPreRead = if ($raw -is [System.Collections.ObjectModel.Collection[psobject]]) { $raw[0] } else { $raw }
                    } catch { Write-Log "[BOOT] BG EndInvoke error: $_" -Level WARN -NoUI }
                    try { $script:_modBgPS.Dispose() } catch {}
                    $script:_modBgPS = $null; $script:_modBgHandle = $null
                }
                # Initialize-ModuleSystem con DLLs pre-leídas
                if (-not $script:SafeMode) {
                    try {
                        $preReadDlls = if ($script:_modPreRead) { $script:_modPreRead.DllBytes } else { $null }
                        Initialize-ModuleSystem -PreReadDlls $preReadDlls
                    } catch {
                        Write-Log "[MOD] Error inicializando sistema de módulos: $_" -Level WARN -NoUI
                    }
                } else {
                    Write-Log "[MOD] Modo Seguro activo -- módulos no cargados" -Level WARN -NoUI
                }
                if ($script:_txtModuleLoading) { $script:_txtModuleLoading.Text = (T "ModLoadUI" "Montando interfaces...") }
            }
            4 {
                # Mount tabs + cerrar overlay
                try { Mount-ModuleTabs } catch {
                    Write-Log "[MOD] Error montando tabs de módulos: $_" -Level WARN -NoUI
                }
                $script:_modLoadTimer.Stop()
                if ($script:_borderModuleLoading) { $script:_borderModuleLoading.Visibility = "Collapsed" }
                $script:_borderModuleLoading  = $null
                $script:_txtModuleLoading     = $null
                $script:_modLoadTimer         = $null
                $script:_modPreRead           = $null
                Write-Log "[BOOT] Módulos cargados (parallel) OK" -Level DBG -NoUI
                # [LAZY] Liberar caché de lectura del bundle (ya no se necesita en RAM)
                try { [SysOpt.LazyLoader]::FlushFileCache() } catch {}
            }
        }
    })
    $script:_modLoadTimer.Start()
    # [OPT] Update-PerformanceTab se carga via _bootPerfTimer (independiente del bundle)
    # Los datos de Rendimiento se cargan 300ms después sin bloquear el render
    $script:_bootPerfTimer = [System.Windows.Threading.DispatcherTimer]::new()
    $script:_bootPerfTimer.Interval = [TimeSpan]::FromMilliseconds(300)
    $script:_bootPerfTimer.Add_Tick({
        $script:_bootPerfTimer.Stop()
        Update-PerformanceTab

        # -- [DEFERRED] Auditoría de DLL + carga diferida de Forms --
        # -----------------------------------------------------------------------------
        # [BOOT] Auditoría de DLL -- registra en el log qué ensamblados están cargados,
        # desde qué ruta física y su versión. Detecta si alguna DLL esperada falta o
        # fue cargada desde una ruta distinta a .\libs\ (p.ej. GAC o sesión anterior).
        # -----------------------------------------------------------------------------
        try {
            $expectedDlls = @(
                @{ Guard = 'MemoryHelper';       Dll = 'SysOpt.MemoryHelper.dll'  },
                @{ Guard = 'DiskItem_v211';      Dll = 'SysOpt.DiskEngine.dll'    },
                @{ Guard = 'LangEngine';         Dll = 'SysOpt.Core.dll'          },
                @{ Guard = 'ScanTokenManager';   Dll = 'SysOpt.Core.dll'          },
                @{ Guard = 'SystemDataCollector';Dll = 'SysOpt.Collector.dll'     },
                @{ Guard = 'ThemeEngine';        Dll = 'SysOpt.ThemeEngine.dll'   },
                @{ Guard = 'DwmHelper';          Dll = 'SysOpt.DwmHelper.dll'    },
            @{ Guard = 'SysOpt.LazyLoader';  Dll = 'SysOpt.LazyLoader.dll'   }
                # Soft DLLs (WseTrim, Optimizer, StartupManager, Diagnostics, Wizard, Toast) -> diferidas post-splash
            )

            Write-Log "-- Auditoría de ensamblados ------------------------------" -Level "DBG" -NoUI
            $seen = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)

            foreach ($entry in $expectedDlls) {
                $type = ([System.Management.Automation.PSTypeName]$entry.Guard).Type
                if ($null -ne $type) {
                    $asm      = $type.Assembly
                    $location = $asm.Location
                    $version  = $asm.GetName().Version.ToString()

                    # Verificar que la ruta coincide con .\libs\ esperado
                    # NOTA: Assembly.Load(byte[]) produce Location="" -- es correcto (in-memory load)
                    $expectedPath = Join-Path $script:_libsDir $entry.Dll
                    if ([string]::IsNullOrEmpty($location)) {
                        $srcNote = "MEM"    # Cargada vía Load(bytes) -- sin ubicación física
                    } elseif ([System.IO.Path]::GetFullPath($location) -eq [System.IO.Path]::GetFullPath($expectedPath)) {
                        $srcNote = "OK"
                    } elseif ($asm.GlobalAssemblyCache) {
                        $srcNote = "GAC"
                    } else {
                        $srcNote = "RUTA DISTINTA"
                    }
                    $fromExpected = ($srcNote -eq "OK" -or $srcNote -eq "MEM")

                    # Solo loggear cada DLL física una vez (Core.dll tiene 3 tipos guard)
                    $seenKey = if ([string]::IsNullOrEmpty($location)) { $entry.Dll } else { $location }
                    if ($seen.Add($seenKey)) {
                        $locDisplay = if ([string]::IsNullOrEmpty($location)) { "(in-memory)" } else { $location }
                        Write-Log ("[DLL] {0,-28} v{1}  [{2}]  {3}" -f $entry.Dll, $version, $srcNote, $locDisplay) -Level "DBG" -NoUI
                    }
                } else {
                    Write-Log ("[DLL] {0,-28} NO CARGADA -- tipo '{1}' no encontrado" -f $entry.Dll, $entry.Guard) -Level "WARN" -NoUI
                }
            }

            # -- Cleanup.dll -- LAZY: solo se carga cuando el usuario ejecuta optimización --
            # No se carga en boot. Se verifica que el archivo exista en disco.
            $cleanupPath = Join-Path $script:_libsDir "SysOpt.Cleanup.dll"
            if (Test-Path $cleanupPath) {
                Write-Log "[DLL] SysOpt.Cleanup.dll            (lazy -- verificado en disco)" -Level "DBG" -NoUI
            } else {
                Write-Log "[DLL] SysOpt.Cleanup.dll            NO encontrado -- optimización no disponible" -Level "WARN" -NoUI
            }

            # -- Breakout.dll -- fire-and-forget (se lanza en proceso aislado desde Options) --
            # No se carga en boot, solo se verifica que el archivo exista en disco.
            $brkPath = Join-Path $script:_libsDir "SysOpt.Breakout.dll"
            if (Test-Path $brkPath) {
                Write-Log "[DLL] SysOpt.Breakout.dll          (fire-and-forget -- verificado en disco)" -Level "DBG" -NoUI
            } else {
                Write-Log "[DLL] SysOpt.Breakout.dll          NO encontrado -- easter egg no disponible" -Level "WARN" -NoUI
            }

            # -- XamlResources.dll -- BAML precompilado (no tiene tipo guard público) --
            # Se carga vía XamlLoader.LoadBaml con Assembly.LoadFrom -- verificar en AppDomain
            $xamlResAsm = [System.AppDomain]::CurrentDomain.GetAssemblies() |
                Where-Object { $_.GetName().Name -eq 'SysOpt.XamlResources' } | Select-Object -First 1
            if ($xamlResAsm) {
                $xrVer = $xamlResAsm.GetName().Version.ToString()
                $xrLoc = if ([string]::IsNullOrEmpty($xamlResAsm.Location)) { "(in-memory)" } else { $xamlResAsm.Location }
                Write-Log ("[DLL] {0,-28} v{1}  [OK]  {2}" -f "SysOpt.XamlResources.dll", $xrVer, $xrLoc) -Level "DBG" -NoUI
                if ($xamlResAsm.Location) { [void]$seen.Add($xamlResAsm.Location) }
            } else {
                $xamlResPath = Join-Path $script:_libsDir "SysOpt.XamlResources.dll"
                if (Test-Path $xamlResPath) {
                    Write-Log "[DLL] SysOpt.XamlResources.dll  NO CARGADA en AppDomain (BAML)" -Level "WARN" -NoUI
                }
            }

            # Extra: detectar DLLs SysOpt.*.dll en AppDomain que no estén en la lista esperada
            $allAsm = [System.AppDomain]::CurrentDomain.GetAssemblies() |
                Where-Object { $_.GetName().Name -like 'SysOpt.*' }
            # Excluir DLLs diferidas (se cargan post-splash, pueden existir de sesión previa)
            $deferredNames = $script:_deferredDlls | ForEach-Object { "SysOpt.$($_.Name)" }
            foreach ($asm in $allAsm) {
                $loc = $asm.Location
                if ($loc -and -not $seen.Contains($loc) -and $asm.GetName().Name -notin $deferredNames) {
                    Write-Log ("[DLL] {0,-28} v{1}  [EXTRA]  {2}" -f $asm.GetName().Name, $asm.GetName().Version, $loc) -Level "WARN" -NoUI
                }
            }

            # Auto-detección: escanear libs/ en busca de SysOpt.*.dll que existan en disco
            # pero NO estén cargadas en el AppDomain -- captura DLLs nuevas no registradas
            $expectedFileNames = ($expectedDlls | ForEach-Object { $_.Dll }) + ($script:_deferredDlls | ForEach-Object { "SysOpt.$($_.Name).dll" }) | Sort-Object -Unique
            # DLLs lazy/fire-and-forget: se verifican por separado (no se cargan en boot)
            $fireAndForget = @('SysOpt.Breakout.dll', 'SysOpt.Cleanup.dll', 'SysOpt.XamlResources.dll')
            $diskDlls = Get-ChildItem -Path $script:_libsDir -Filter "SysOpt.*.dll" -File -ErrorAction SilentlyContinue
            foreach ($diskDll in $diskDlls) {
                if ($diskDll.Name -notin $expectedFileNames -and $diskDll.Name -notin $fireAndForget -and -not $seen.Contains($diskDll.FullName)) {
                    Write-Log ("[DLL] {0,-28} [EN DISCO NO CARGADA] {1}" -f $diskDll.Name, $diskDll.FullName) -Level "WARN" -NoUI
                    Write-Log "      ? Añade esta DLL a la sección de carga y a `$expectedDlls en la auditoría" -Level "WARN" -NoUI
                }
            }

            Write-Log "-- Fin auditoría -----------------------------------------" -Level "DBG" -NoUI
        } catch {
            Write-Log "[DLL] Error en auditoría de ensamblados: $($_.Exception.Message)" -Level "WARN" -NoUI
        }


    })
    $script:_bootPerfTimer.Start()

    # -- [BOOT] Contexto de arranque -- log detallado de configuracion y entorno --
    # Se ejecuta DESPUES de Load-Settings/Load-Language/Apply-Theme para reflejar
    # el estado real con el que arranca la sesion. Solo va al archivo (-NoUI).
    try {
        # -- Aplicacion --------------------------------------------------------
        Write-Log "-- Configuracion de arranque -----------------------------" -Level "INFO" -NoUI
        Write-Log ("[APP] Version        : v{0}" -f $script:AppVersion)                                         -Level "INFO" -NoUI
        Write-Log ("[APP] Tema activo     : {0}" -f $script:CurrentTheme)                                       -Level "INFO" -NoUI
        Write-Log ("[APP] Idioma activo   : {0}" -f $script:CurrentLang)                                        -Level "INFO" -NoUI
        Write-Log ("[APP] Settings path   : {0}" -f $script:SettingsPath)                                       -Level "INFO" -NoUI
        $settingsExist = Test-Path $script:SettingsPath
        Write-Log ("[APP] Settings existe : {0}" -f $(if ($settingsExist) {"SI"} else {"NO -- usando defaults"})) -Level "INFO" -NoUI

        # Ruta de escaneo y auto-refresh desde los controles ya restaurados
        try {
            $scanPath    = if ($txtDiskScanPath -and $txtDiskScanPath.Text) { $txtDiskScanPath.Text } else { (T "SmartNotDefined" "(no definida)") }
            $autoRefresh = if ($chkAutoRefresh -and $chkAutoRefresh.IsChecked) { "ON" } else { "OFF" }
            $refreshSecs = if ($cmbRefreshInterval -and $cmbRefreshInterval.SelectedItem) { "$($cmbRefreshInterval.SelectedItem.Tag) s" } else { "(default)" }
            Write-Log ("[APP] Disco scan path : {0}" -f $scanPath)    -Level "INFO" -NoUI
            Write-Log ("[APP] Auto-refresh    : {0}  intervalo={1}" -f $autoRefresh, $refreshSecs) -Level "INFO" -NoUI
        } catch {}

        # -- Entorno de ejecucion ----------------------------------------------
        Write-Log ("[ENV] PowerShell      : v{0}  ({1}-bit)" -f $PSVersionTable.PSVersion, $(if ([Environment]::Is64BitProcess) {"64"} else {"32"})) -Level "INFO" -NoUI
        Write-Log ("[ENV] Admin           : {0}" -f $(if (([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {"SI"} else {"NO -- funciones limitadas"})) -Level "INFO" -NoUI
        Write-Log ("[ENV] PID             : {0}" -f $PID)                                               -Level "INFO" -NoUI
        Write-Log ("[ENV] Script root     : {0}" -f $PSScriptRoot)                                      -Level "INFO" -NoUI
        Write-Log ("[ENV] Working dir     : {0}" -f (Get-Location).Path)                                -Level "INFO" -NoUI

        # -- [DAL] Sistema -- snapshot completo via C# (reemplaza 5 queries WMI) -
        try {
            $snap = [SystemDataCollector]::GetFullSnapshot()

            # OS
            Write-Log ("[SYS] OS              : {0}  (Build {1})" -f $snap.OsCaption.Trim(), $snap.OsBuild) -Level "INFO" -NoUI

            # RAM (from DAL)
            $totalRamGB = [math]::Round($snap.Ram.TotalBytes / 1GB, 1)
            $freeRamGB  = [math]::Round($snap.Ram.FreeBytes  / 1GB, 1)
            $usedRamPct = [math]::Round($snap.Ram.UsedPercent)
            Write-Log ("[SYS] RAM             : {0} GB total  |  {1} GB libre  |  {2}% usado" -f $totalRamGB, $freeRamGB, $usedRamPct) -Level "INFO" -NoUI

            # Boot time (from DAL)
            if ($snap.BootTime -ne [datetime]::MinValue) {
                Write-Log ("[SYS] Ultimo boot     : {0}" -f $snap.BootTime) -Level "INFO" -NoUI
            }

            # CPU (from DAL)
            Write-Log ("[SYS] CPU             : {0}  ({1} cores / {2} hilos)" -f $snap.Cpu.Name.Trim(), $snap.Cpu.Cores, $snap.Cpu.LogicalProcessors) -Level "INFO" -NoUI
            Write-Log ("[SYS] CPU carga       : {0}%  @{1} MHz" -f [int]$snap.Cpu.LoadPercent, [int]$snap.Cpu.ClockMhz) -Level "INFO" -NoUI

            # Disco C: (from DAL)
            $diskC = $snap.Disk.Volumes | Where-Object { $_.DeviceId -eq 'C:' } | Select-Object -First 1
            if ($diskC) {
                $dTotalGB = [math]::Round($diskC.TotalBytes / 1GB, 1)
                $dFreeGB  = [math]::Round($diskC.FreeBytes  / 1GB, 1)
                $dUsedPct = [math]::Round($diskC.UsedPercent)
                Write-Log ("[SYS] Disco C:        : {0} GB total  |  {1} GB libre  |  {2}% usado" -f $dTotalGB, $dFreeGB, $dUsedPct) -Level "INFO" -NoUI
            }

            # -- Advertencias (reutiliza datos DAL -- 0 queries adicionales) ----
            $freeMB = [math]::Round($snap.Ram.FreeBytes / 1MB)
            if ($freeMB -lt 512) {
                Write-Log ("[WARN] RAM libre muy baja al arrancar: ${freeMB} MB -- rendimiento puede verse afectado") -Level "WARN" -NoUI
            }
            if ($diskC) {
                $freeGBw = [math]::Round($diskC.FreeBytes / 1GB, 1)
                if ($freeGBw -lt 5) {
                    Write-Log ("[WARN] Disco C: con menos de 5 GB libres (${freeGBw} GB) -- algunas operaciones pueden fallar") -Level "WARN" -NoUI
                }
            }
        } catch {}
        try {
            # Tema no encontrado (se cargó settings.json pero el .theme ya no existe)
            if ($script:CurrentTheme -ne "default") {
                $themePath = Join-Path $script:ThemesDir "$($script:CurrentTheme).theme"
                if (-not (Test-Path $themePath)) {
                    Write-Log ("[WARN] Tema guardado '$($script:CurrentTheme)' no encontrado en assets	hemes\ -- usando default") -Level "WARN" -NoUI
                }
            }
            # Idioma no encontrado
            $langPath = Join-Path $script:LangDir "$($script:CurrentLang).lang"
            if (-not (Test-Path $langPath)) {
                Write-Log ("[WARN] Idioma guardado '$($script:CurrentLang)' no encontrado en assets\lang\ -- sin traducciones") -Level "WARN" -NoUI
            }
        } catch {}

        # -- Módulos --
        Write-Log ("[APP] Módulos cargados : {0}" -f $(if ($script:LoadedModules) { $script:LoadedModules.Count } else { 0 })) -Level "INFO" -NoUI
        Write-Log ("[APP] Modo seguro      : {0}" -f $(if ($script:SafeMode) { "ON" } else { "OFF" })) -Level "INFO" -NoUI

        Write-Log "-- Fin contexto de arranque ------------------------------" -Level "INFO" -NoUI
    } catch {
        Write-Log "[BOOT] Error al registrar contexto de arranque: $($_.Exception.Message)" -Level "WARN" -NoUI
    }
})

# -----------------------------------------------------------------------------
# TAB 2: RENDIMIENTO -- controles y lógica
# -----------------------------------------------------------------------------
$btnRefreshPerf   = (CFN $window "btnRefreshPerf")
$txtPerfStatus    = (CFN $window "txtPerfStatus")
# [A3] Auto-refresco controles
$chkAutoRefresh      = (CFN $window "chkAutoRefresh")
$cmbRefreshInterval  = (CFN $window "cmbRefreshInterval")
$script:AutoRefreshTimer = $null
$script:AppClosing       = $false
$script:WizardMode       = $false
# Aplicar tema oscuro al ComboBox también en su evento Loaded individual
if ($null -ne $cmbRefreshInterval) {
    $cmbRefreshInterval.Add_Loaded({ Apply-ComboBoxDarkTheme $cmbRefreshInterval })
}
$txtCpuName       = (CFN $window "txtCpuName")
$icCpuCores       = (CFN $window "icCpuCores")
$txtRamTotal      = (CFN $window "txtRamTotal")
$txtRamUsed       = (CFN $window "txtRamUsed")
$txtRamFree       = (CFN $window "txtRamFree")
$txtRamPct        = (CFN $window "txtRamPct")
$pbRam            = (CFN $window "pbRam")
$icRamModules     = (CFN $window "icRamModules")
$icSmartDisks     = (CFN $window "icSmartDisks")
$icNetAdapters    = (CFN $window "icNetAdapters")

function global:Format-Bytes { param([long]$Bytes); return [Formatter]::FormatBytes($Bytes) }

Set-SplashProgress 93 (T "SplashLoading93" "Panel de rendimiento...")
# causando fallo de resolución de nombre "OUL" al invocarse desde el dispatcher WPF)
function global:Format-Rate { param([double]$bps); return [Formatter]::FormatRate($bps) }


function global:Update-PerformanceTab {
    if ($script:AppClosing) { return }
    $txtPerfStatus.Text = (T "PerfCollectingData" "Recopilando datos...")

    # [OPT] Solo importar módulos una vez -- Import-Module es costoso (~1s por módulo)
    if (-not $script:_perfModulesLoaded) {
        try { Import-Module Storage    -ErrorAction SilentlyContinue } catch {}
        try { Import-Module NetAdapter -ErrorAction SilentlyContinue } catch {}
        try { Import-Module NetTCPIP   -ErrorAction SilentlyContinue } catch {}
        $script:_perfModulesLoaded = $true
    }

    # -- CPU Cores -- [DAL] GetCpuSnapshot reemplaza 2 queries WMI ---
    try {
        $cpuSnap = [SystemDataCollector]::GetCpuSnapshot()
        $txtCpuName.Text = "$($cpuSnap.Name)  |  $($cpuSnap.Cores) $((T "CpuCoresLabel"))  /  $($cpuSnap.LogicalProcessors) $((T "CpuLogicalLabel"))"

        $coreItems = [System.Collections.Generic.List[object]]::new()
        try {
            $cpuPerf = $cpuSnap.CoreLoads
            if ($cpuPerf -and $cpuPerf.Count -gt 0) {
                for ($ci = 0; $ci -lt $cpuPerf.Count; $ci++) {
                    $val = [math]::Round($cpuPerf[$ci], 1)
                    $coreItems.Add([PSCustomObject]@{
                        CoreLabel = "Core $ci"
                        Usage     = "$val%"
                        UsageNum  = $val
                        Freq      = "$([math]::Round($cpuObj.CurrentClockSpeed / 1000.0, 2)) GHz"
                    })
                }
            } else {
                $val = [double]$cpuObj.LoadPercentage
                $coreItems.Add([PSCustomObject]@{
                    CoreLabel = (T "CpuTotal" "CPU Total"); Usage = "$val%"; UsageNum = $val
                    Freq      = "$([math]::Round($cpuObj.CurrentClockSpeed / 1000.0, 2)) GHz"
                })
            }
        } catch {
            $coreItems.Add([PSCustomObject]@{
                CoreLabel = (T "CpuTotal" "CPU Total"); Usage = "$([int]$cpuSnap.LoadPercent)%"
                UsageNum  = $cpuSnap.LoadPercent
                Freq      = "$([math]::Round($cpuSnap.ClockMhz / 1000.0, 2)) GHz"
            })
        }
        $icCpuCores.ItemsSource = $coreItems
    } catch { $txtCpuName.Text = (T "NotAvailable" "No disponible") }

    # -- RAM Detallada -- [DAL] GetRamSnapshot reemplaza 2 queries WMI --
    try {
        $ramSnap = [SystemDataCollector]::GetRamSnapshot()
        $totalB  = $ramSnap.TotalBytes
        $freeB   = $ramSnap.FreeBytes
        $usedB   = $ramSnap.UsedBytes
        $pct     = [math]::Round($ramSnap.UsedPercent)

        $fmt = { param($b) return [Formatter]::FormatBytes([long]$b) }

        $txtRamTotal.Text = & $fmt $totalB
        $txtRamUsed.Text  = & $fmt $usedB
        $txtRamFree.Text  = & $fmt $freeB
        $txtRamPct.Text   = "$pct%"
        $pbRam.Value      = $pct

        $modItems = [System.Collections.Generic.List[object]]::new()
        foreach ($mod in $ramSnap.Modules) {
            $modItems.Add([PSCustomObject]@{
                Slot = if ($mod.Slot) { $mod.Slot } else { "Ranura" }
                Info = "$($mod.Type)  *  $(if($mod.SpeedMhz){"$($mod.SpeedMhz) MHz"}else{"--"})  *  Mfg: $(if($mod.Manufacturer){$mod.Manufacturer}else{"N/A"})"
                Size = & $fmt ([long]$mod.CapacityBytes)
            })
        }
        $icRamModules.ItemsSource = $modItems
    } catch { $txtRamTotal.Text = "N/A" }

    # -- SMART del Disco ----------------------------------------
    try {
        $smartItems = [System.Collections.Generic.List[object]]::new()
        foreach ($disk in (Get-PhysicalDisk -ErrorAction Stop)) {
            $rel = $null
            try { $rel = Get-StorageReliabilityCounter -PhysicalDisk $disk -ErrorAction Stop } catch {}

            $health = $disk.HealthStatus
            $bg = switch ($health) {
                "Healthy" { Get-TC 'BgStatusOk'   '#182A1E' }
                "Warning" { Get-TC 'BgStatusWarn'  '#2A2010' }
                default   { Get-TC 'BgStatusErr'   '#2A1018' }
            }
            $fg = switch ($health) {
                "Healthy" { Get-TC 'FgStatusOk'   '#4AE896' }
                "Warning" { Get-TC 'FgStatusWarn'  '#FFB547' }
                default   { Get-TC 'FgStatusErr'   '#FF6B84' }
            }

            $attrs = [System.Collections.Generic.List[object]]::new()
            $sz = if ($disk.Size -ge 1GB) { "{0:N1} GB" -f ($disk.Size / 1GB) } else { "{0:N0} MB" -f ($disk.Size / 1MB) }
            $attrs.Add([PSCustomObject]@{ Name=(T "SmartType" "Tipo");    Value=$disk.MediaType; ValueColor=(Get-TC 'TextSecondary' '#B0BACC') })
            $attrs.Add([PSCustomObject]@{ Name=(T "SmartSize" "Tamaño");  Value=$sz;             ValueColor=(Get-TC 'AccentBlue'    '#5BA3FF') })
            $attrs.Add([PSCustomObject]@{ Name="Bus";     Value=$disk.BusType;   ValueColor=(Get-TC 'TextSecondary' '#B0BACC') })
            if ($rel) {
                if ($null -ne $rel.PowerOnHours) {
                    $attrs.Add([PSCustomObject]@{ Name=(T "SmartPowerOnHours" "Horas enc."); Value="$($rel.PowerOnHours) h"; ValueColor=(Get-TC 'AccentAmber' '#FFB547') })
                }
                if ($null -ne $rel.Temperature) {
                    $tc = $rel.Temperature
                    $tc2 = if ($tc -ge 55) { Get-TC 'FgStatusErr' '#FF6B84' } elseif ($tc -ge 45) { Get-TC 'FgStatusWarn' '#FFB547' } else { Get-TC 'FgStatusOk' '#4AE896' }
                    $attrs.Add([PSCustomObject]@{ Name=(T "SmartTemp" "Temperatura"); Value="${tc}$([char]0x00B0)C"; ValueColor=$tc2 })
                }
                if ($null -ne $rel.ReadErrorsTotal) {
                    $attrs.Add([PSCustomObject]@{ Name=(T "SmartReadErr" "Errores lect."); Value=$rel.ReadErrorsTotal
                        ValueColor=if($rel.ReadErrorsTotal -gt 0){ Get-TC 'FgStatusErr' '#FF6B84' }else{ Get-TC 'FgStatusOk' '#4AE896' } })
                }
                if ($null -ne $rel.Wear) {
                    $wc = if ($rel.Wear -ge 80) { Get-TC 'FgStatusErr' '#FF6B84' } elseif ($rel.Wear -ge 50) { Get-TC 'FgStatusWarn' '#FFB547' } else { Get-TC 'FgStatusOk' '#4AE896' }
                    $attrs.Add([PSCustomObject]@{ Name=(T "SmartWear" "Desgaste"); Value="$($rel.Wear)%"; ValueColor=$wc })
                }
            }
            $smartItems.Add([PSCustomObject]@{
                DiskName=$disk.FriendlyName; Status=$health; StatusBg=$bg; StatusFg=$fg; Attributes=$attrs
            })
        }
        $icSmartDisks.ItemsSource = $smartItems
    } catch {
        $icSmartDisks.ItemsSource = @([PSCustomObject]@{
            DiskName=((T "SmartReadErrorMsg")); Status="N/A"; StatusBg=(Get-TC 'BgStatusErr' '#2A1018'); StatusFg=(Get-TC 'FgStatusErr' '#FF6B84'); Attributes=@()
        })
    }

    # -- Tarjetas de Red ----------------------------------------
    try {
        # [DAL] Tabla de velocidades via GetNetworkSnapshot (reemplaza query WMI directa)
        $netSnap = [SystemDataCollector]::GetNetworkSnapshot()
        $wmiTable = @{}
        foreach ($adapter in $netSnap.Adapters) {
            $norm = ($adapter.Name -replace '\s*#\d+$','' -replace '_',' ').ToLower().Trim()
            $wmiTable[$norm] = $adapter
        }

        # Funciones de formato inline (sin scriptblock para evitar problemas de scope)
        function global:Format-NetRate  { param([double]$b); return [Formatter]::FormatRate($b) }
        function global:Format-NetBytes { param([double]$b); return [Formatter]::FormatBytes([long]$b) }
        function global:Format-LinkBps  { param([uint64]$bps); return [Formatter]::FormatLinkSpeed($bps) }

        $netItems = [System.Collections.Generic.List[object]]::new()

        # -- Intentar con Get-NetAdapter (módulo NetAdapter) --------------
        $gotNetAdapter = $false
        try {
            $adapters = Get-NetAdapter -ErrorAction Stop
            $gotNetAdapter = $true

            foreach ($a in $adapters) {
                # IP
                $ip = ((T "NetNoIP"))
                try {
                    $ipObj = Get-NetIPAddress -InterfaceIndex $a.InterfaceIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue | Select-Object -First 1
                    if ($ipObj -and $ipObj.IPAddress) { $ip = $ipObj.IPAddress }
                } catch {}

                # Tipo de adaptador
                $desc = "$($a.InterfaceDescription)"
                $adType = "$([char]::ConvertFromUtf32(0x1F50C)) Ethernet"
                if (($desc -match 'Wi.?Fi|Wireless|WLAN|802\.11') -or ("$($a.PhysicalMediaType)" -match '802\.11|Wireless|NativeWifi')) {
                    $adType = "$([char]::ConvertFromUtf32(0x1F4F6)) WiFi"
                } elseif ($desc -match 'Loopback|Pseudo|Miniport|Hyper-V|VMware|VirtualBox|TAP|TUN|VPN') {
                    $adType = "$([char]::ConvertFromUtf32(0x1F5A5)) Virtual"
                }

                # Velocidad de enlace
                $linkBps = [uint64]0
                $lsStr = "$($a.LinkSpeed)"
                $lsParsed = [uint64]0
                if ([uint64]::TryParse($lsStr, [ref]$lsParsed)) {
                    $linkBps = $lsParsed
                } elseif ($lsStr -match '([\d\.]+)\s*(G|M|K)?bps') {
                    $lv = [double]$Matches[1]; $lu = "$($Matches[2])"
                    $lm = 1
                    if ($lu -eq 'G') { $lm = 1000000000 } elseif ($lu -eq 'M') { $lm = 1000000 } elseif ($lu -eq 'K') { $lm = 1000 }
                    $linkBps = [uint64]($lv * $lm)
                }
                $speedStr = Format-LinkBps $linkBps

                # Velocidad rx/tx desde WMI
                $descNorm = ($desc -replace '\s*#\d+$','').ToLower().Trim()
                $wmiRow = $wmiTable[$descNorm]
                if (-not $wmiRow) {
                    foreach ($k in $wmiTable.Keys) {
                        if ($descNorm -like "*$k*" -or $k -like "*$($a.Name.ToLower().Trim())*") { $wmiRow = $wmiTable[$k]; break }
                    }
                }
                $rxBps = 0.0; $txBps = 0.0
                if ($null -ne $wmiRow) { $rxBps = [double]$wmiRow.RxBytesPerSec; $txBps = [double]$wmiRow.TxBytesPerSec }

                # Bytes totales
                $ioStr = ""
                try {
                    $stats = Get-NetAdapterStatistics -Name $a.Name -ErrorAction SilentlyContinue
                    if ($stats) { $ioStr = "$(T 'NetTotal' 'Total') v $(Format-NetBytes $stats.ReceivedBytes)  ^ $(Format-NetBytes $stats.SentBytes)" }
                } catch {}

                # Color de estado
                $stColor = Get-TC 'TextSecondary' '#9BA4C0'
                if ($a.Status -eq "Up") { $stColor = Get-TC 'AccentGreen' '#4AE896' }

                $netItems.Add([PSCustomObject]@{
                    Name        = "$adType  $($a.Name)"
                    IP          = "IP: $ip  |  MAC: $($a.MacAddress)"
                    MAC         = $desc
                    Speed       = $speedStr
                    Status      = "$($a.Status)   v $(Format-NetRate $rxBps)   ^ $(Format-NetRate $txBps)"
                    StatusColor = $stColor
                    BytesIO     = $ioStr
                })
            }
        } catch {}

        # -- [DAL] Fallback via GetNetworkSnapshot (reemplaza 2 queries WMI) --
        if (-not $gotNetAdapter -or $netItems.Count -eq 0) {
            try {
                foreach ($ad in $netSnap.Adapters) {
                    if (-not $ad.IsUp) { continue }
                    $adType = switch ($ad.Type) {
                        "WiFi"    { "$([char]::ConvertFromUtf32(0x1F4F6)) WiFi" }
                        "Virtual" { "$([char]::ConvertFromUtf32(0x1F5A5)) Virtual" }
                        default   { "$([char]::ConvertFromUtf32(0x1F50C)) Ethernet" }
                    }
                    $netItems.Add([PSCustomObject]@{
                        Name        = "$adType  $($ad.Name)"
                        IP          = "IP: $(if($ad.IpAddress){$ad.IpAddress}else{(T "NetNoIP")})  |  MAC: $(if($ad.MacAddress){$ad.MacAddress}else{'--'})"
                        MAC         = $ad.Description
                        Speed       = Format-LinkBps ([uint64]$ad.SpeedBps)
                        Status      = "$(T 'NicActive' 'Activa')  v $(Format-NetRate $ad.RxBytesPerSec)  ^ $(Format-NetRate $ad.TxBytesPerSec)  |  GW: $(if($ad.Gateway){$ad.Gateway}else{T 'NicNoGW' 'Sin GW'})"
                        StatusColor = (Get-TC 'AccentGreen' '#4AE896')
                        BytesIO     = "v $(Format-NetBytes $ad.TotalRxBytes)  ^ $(Format-NetBytes $ad.TotalTxBytes)"
                    })
                }
            } catch {
                $netItems.Add([PSCustomObject]@{
                    Name="[!] Error DAL al leer red"; IP=$_.Exception.Message
                    MAC=""; Speed=""; Status="Error"; StatusColor=(Get-TC 'AccentRed' '#FF6B84'); BytesIO=""
                })
            }
        }

        if ($netItems.Count -eq 0) {
            $netItems.Add([PSCustomObject]@{
                Name="[i] $(T 'NicNoAdapters' 'Sin adaptadores activos')"; IP=(T "NicNoAdaptersDesc" "No se detectaron tarjetas de red activas")
                MAC=""; Speed=""; Status="--"; StatusColor=(Get-TC 'TextMuted' '#7880A0'); BytesIO=""
            })
        }

        $icNetAdapters.ItemsSource = $netItems

    } catch {
        $icNetAdapters.ItemsSource = @([PSCustomObject]@{
            Name="[!] $((T "NetErrorAdapters"))"
            IP="[$($_.Exception.GetType().Name)] $($_.Exception.Message)"
            MAC=""; Speed=""; Status="Error"; StatusColor=(Get-TC 'AccentRed' '#FF6B84'); BytesIO=""
        })
    }

    $txtPerfStatus.Text = "$(T 'PerfUpdated' 'Actualizado'): $(Get-Date -Format 'HH:mm:ss')"
}

$btnRefreshPerf.Add_Click({ Update-PerformanceTab })

# [A3] Auto-refresco de Rendimiento -------------------------------------------
# Handler único compartido -- evita Add_Tick duplicado si se recrea el timer
$script:AutoRefreshTick = { Update-PerformanceTab }.GetNewClosure()

function global:Start-AutoRefreshTimer {
    $secs = 5
    $sel  = $cmbRefreshInterval.SelectedItem
    if ($sel -and $sel.Tag) { $secs = [int]$sel.Tag }
    $script:AutoRefreshTimer          = New-Object System.Windows.Threading.DispatcherTimer
    $script:AutoRefreshTimer.Interval = [TimeSpan]::FromSeconds($secs)
    $script:AutoRefreshTimer.Add_Tick($script:AutoRefreshTick)
    $script:AutoRefreshTimer.Start()
    $txtPerfStatus.Text = "  $(T 'PerfAutoRefresh' 'Auto-refresco cada') $secs s $(T 'PerfAutoRefreshActive' 'activo')"
}

$chkAutoRefresh.Add_Checked({ Start-AutoRefreshTimer })
$chkAutoRefresh.Add_Unchecked({
    if ($null -ne $script:AutoRefreshTimer) { $script:AutoRefreshTimer.Stop(); $script:AutoRefreshTimer = $null }
    $txtPerfStatus.Text = "  $((T "AutoRefreshDisabled"))"
})
$cmbRefreshInterval.Add_SelectionChanged({
    if ($chkAutoRefresh.IsChecked -eq $true) {
        if ($null -ne $script:AutoRefreshTimer) { $script:AutoRefreshTimer.Stop(); $script:AutoRefreshTimer = $null }
        Start-AutoRefreshTimer
    }
})

# -----------------------------------------------------------------------------
# TAB 3: EXPLORADOR DE DISCO -- controles y lógica
# -----------------------------------------------------------------------------
$txtDiskScanPath    = (CFN $window "txtDiskScanPath")
$btnDiskBrowse      = (CFN $window "btnDiskBrowse")
$btnDiskScan        = (CFN $window "btnDiskScan")
$btnDiskStop        = (CFN $window "btnDiskStop")
$lbDiskTree         = (CFN $window "lbDiskTree")
$txtDiskScanStatus  = (CFN $window "txtDiskScanStatus")
$pbDiskScan         = (CFN $window "pbDiskScan")
$txtDiskDetailName  = (CFN $window "txtDiskDetailName")
$txtDiskDetailSize  = (CFN $window "txtDiskDetailSize")
$txtDiskDetailFiles = (CFN $window "txtDiskDetailFiles")
$txtDiskDetailDirs  = (CFN $window "txtDiskDetailDirs")
$txtDiskDetailPct   = (CFN $window "txtDiskDetailPct")
$icTopFiles         = (CFN $window "icTopFiles")
$txtDiskFilter      = (CFN $window "txtDiskFilter")
$btnDiskFilterClear = (CFN $window "btnDiskFilterClear")
$btnExportCsv       = (CFN $window "btnExportCsv")
$btnExportJson      = (CFN $window "btnExportJson")
$btnDiskReport      = (CFN $window "btnDiskReport")
$btnDedup           = (CFN $window "btnDedup")
$ctxMenu        = $lbDiskTree.ContextMenu
$ctxOpen        = $ctxMenu.Items | Where-Object { $_.Name -eq "ctxOpen"      }
$ctxCopy        = $ctxMenu.Items | Where-Object { $_.Name -eq "ctxCopy"      }
$ctxScanFolder  = $ctxMenu.Items | Where-Object { $_.Name -eq "ctxScanFolder" }
$ctxDelete      = $ctxMenu.Items | Where-Object { $_.Name -eq "ctxDelete"    }

$script:DiskScanRunspace = $null
$script:DiskScanResults  = $null
# Rutas colapsadas por el usuario (toggle ?/?)
$script:CollapsedPaths   = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
# Todos los items escaneados (sin filtrar) -- base para rebuilds de vista
$script:AllScannedItems  = [System.Collections.Generic.List[object]]::new(4096)  # [NEW-03] capacity hint
# Índice posición en LiveList para actualizaciones O(1)
$script:LiveIndexMap     = [System.Collections.Generic.Dictionary[string,int]]::new([System.StringComparer]::OrdinalIgnoreCase)

# -----------------------------------------------------------------------------
# Reconstruye la lista visible aplicando el filtro de colapso
# -----------------------------------------------------------------------------
# [NEW-01] Debounce timer: evita rebuilds múltiples en ráfagas del scanner
$script:_diskViewDebounce = $null
function global:Request-DiskViewRefresh {
    param([switch]$RebuildMap)
    # Si viene con RebuildMap o no hay timer activo, disparar inmediatamente
    # (los colapsos manuales necesitan respuesta inmediata)
    if ($RebuildMap) {
        if ($null -ne $script:_diskViewDebounce) {
            try { $script:_diskViewDebounce.Stop() } catch {}
            $script:_diskViewDebounce = $null
        }
        Refresh-DiskView -RebuildMap
        return
    }
    # Para actualizaciones de datos (ráfaga del scanner), debounce 80ms
    if ($null -ne $script:_diskViewDebounce) { return }  # ya pendiente
    $dt = New-Object System.Windows.Threading.DispatcherTimer
    $dt.Interval = [TimeSpan]::FromMilliseconds(80)
    $dt.Add_Tick({
        $script:_diskViewDebounce.Stop()
        $script:_diskViewDebounce = $null
        Refresh-DiskView
    })
    $script:_diskViewDebounce = $dt
    $dt.Start()
}

function global:Refresh-DiskView {
    param([switch]$RebuildMap)
    if ($null -eq $script:LiveList) { return }

    # -- Fase 1: construir y ordenar el childMap (cacheado) ----------------------
    # Al colapsar/expandir los datos NO cambian -> reutilizamos el mapa ya ordenado.
    # Solo se reconstruye cuando llegan datos nuevos del escáner (-RebuildMap).
    if ($RebuildMap -or $null -eq $script:CachedChildMap) {
        $script:CachedChildMap = [System.Collections.Generic.Dictionary[string,
                      System.Collections.Generic.List[object]]]::new(
                        [System.StringComparer]::OrdinalIgnoreCase)

        foreach ($item in $script:AllScannedItems) {
            $pk = if ($null -ne $item.ParentPath -and $item.ParentPath -ne '') { $item.ParentPath } else { '::ROOT::' }
            if (-not $script:CachedChildMap.ContainsKey($pk)) {
                $script:CachedChildMap[$pk] = [System.Collections.Generic.List[object]]::new()
            }
            $script:CachedChildMap[$pk].Add($item)
        }

        # Ordenar cada grupo con Array.Sort (sin pipeline) -- mayor tamaño primero
        foreach ($pk in @($script:CachedChildMap.Keys)) {
            $lst = $script:CachedChildMap[$pk]
            if ($lst.Count -lt 2) { continue }
            # Sort-Object solo se ejecuta al construir el mapa (no en cada colapso)
            # PowerShell no acepta scriptblock como IComparer en [Array]::Sort
            $sorted = $lst | Sort-Object -Property @{Expression={ if ($_.SizeBytes -ge 0) { $_.SizeBytes } else { 0L } }} -Descending
            $lst.Clear()
            foreach ($x in $sorted) { $lst.Add($x) }
        }
    }

    # -- Fase 2: DFS con pila de índices (orden garantizado) --------------------
    # Mantenemos una pila de (parentKey, índiceActual) para recorrer el árbol
    # en profundidad respetando el orden ya establecido en CachedChildMap.
    # Esto evita la recursión y el problema del Stack LIFO que mezcla el orden.
    $script:LiveList.Clear()

    # Cada entrada en la pila: [string parentKey, int currentIndex]
    $dfsStack = [System.Collections.Generic.Stack[object[]]]::new()
    if ($script:CachedChildMap.ContainsKey('::ROOT::')) {
        $dfsStack.Push(@('::ROOT::', 0))
    }

    while ($dfsStack.Count -gt 0) {
        $frame   = $dfsStack.Peek()
        $pk      = [string]$frame[0]
        $idx     = [int]$frame[1]
        $children = $script:CachedChildMap[$pk]

        if ($idx -ge $children.Count) {
            # Agotamos todos los hijos de este padre -> subimos
            [void]$dfsStack.Pop()
            continue
        }

        # Avanzar índice para la próxima vuelta de este frame
        $frame[1] = $idx + 1

        $item = $children[$idx]

        # Sincronizar ícono
        if ($item.IsDir -and $item.HasChildren) {
            $item.ToggleIcon = if ($script:CollapsedPaths.Contains($item.FullPath)) {
                [string][char]0x25B6
            } else {
                [string][char]0x25BC
            }
        }

        $script:LiveList.Add($item)

        # Si el directorio está expandido, bajar a sus hijos
        if ($item.IsDir -and $item.HasChildren -and
            -not $script:CollapsedPaths.Contains($item.FullPath) -and
            $script:CachedChildMap.ContainsKey($item.FullPath)) {
            $dfsStack.Push(@($item.FullPath, 0))
        }
    }
}

# Invalida el childMap cacheado; llamar cuando el escáner emita nuevos datos
function global:Invalidate-DiskViewCache {
    $script:CachedChildMap = $null
}

function global:Get-SizeColor {
    param([long]$Bytes)
    if ($Bytes -ge 10GB) { return (Get-TC 'AccentRed' '#FF6B84') }
    if ($Bytes -ge 1GB)  { return (Get-TC 'AccentAmber' '#FFB547') }
    if ($Bytes -ge 100MB){ return (Get-TC 'AccentBlue' '#5BA3FF') }
    return (Get-TC 'TextSecondary' '#B0BACC')
}

# Get-SizeColorFromStr es alias de Get-SizeColor (eliminado duplicado)
Set-Alias -Name Get-SizeColorFromStr -Value Get-SizeColor -Scope Script

function global:Start-DiskScan {
    param([string]$RootPath)
    Lazy-Load "Start-DiskScan"
    Start-DiskScan @PSBoundParameters
}

$btnDiskBrowse.Add_Click({
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    try {
        $dlg.Description  = (T "ScanSelectFolder")
        $dlg.RootFolder   = "MyComputer"
        $dlg.SelectedPath = $txtDiskScanPath.Text
        if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            $txtDiskScanPath.Text = $dlg.SelectedPath
        }
    } finally { $dlg.Dispose() }
})

$btnDiskScan.Add_Click({
    Save-Settings  # [C3]
    Start-DiskScan -RootPath $txtDiskScanPath.Text.Trim()
})

$btnDiskStop.Add_Click({
    [ScanTokenManager]::Cancel()   # [CTK] bridge -> ScanCtl211.Stop = true automático
    $btnDiskStop.IsEnabled = $false
    $txtDiskScanStatus.Text = "$([char]0x23F3) $((T "ScanCancelling"))"
})

# -----------------------------------------------------------------------------
# [C3] PERSISTENCIA DE CONFIGURACIÓN -- %APPDATA%\SysOpt\settings.json
# -----------------------------------------------------------------------------
# NOTA: $script:SettingsPath y $script:_themeCachePath definidos al inicio (L228-233)

function global:Save-ThemeCache {
    param([string]$ThemeName, [string]$ThemePath, [hashtable]$NewColors, $GradientMap)
    try {
        $dir = [System.IO.Path]::GetDirectoryName($script:_themeCachePath)
        if (-not (Test-Path $dir)) { [System.IO.Directory]::CreateDirectory($dir) | Out-Null }
        $themeHash = (Get-FileHash $ThemePath -Algorithm MD5).Hash
        # Serialize computed brush colors from window Resources
        $brushCache = @{}
        foreach ($hex in $script:ThemeColorMap.Keys) {
            $res = $window.Resources["TB_$hex"]
            if ($res -is [System.Windows.Media.SolidColorBrush]) {
                $c = $res.Color
                $brushCache[$hex] = "#{0:X2}{1:X2}{2:X2}" -f $c.R, $c.G, $c.B
            }
        }
        # Serialize gradient map
        $gradCache = @{}
        if ($GradientMap) {
            foreach ($kv in $GradientMap.GetEnumerator()) {
                $gradCache[$kv.Key] = "#{0:X2}{1:X2}{2:X2}" -f $kv.Value.R, $kv.Value.G, $kv.Value.B
            }
        }
        $cacheObj = @{
            ThemeName   = $ThemeName
            ThemeHash   = $themeHash
            Version     = $script:AppVersion
            Brushes     = $brushCache
            GradientMap = $gradCache
            ThemeColors = $NewColors
        }
        $json = $cacheObj | ConvertTo-Json -Depth 5
        $tmp = $script:_themeCachePath + ".tmp"
        [System.IO.File]::WriteAllText($tmp, $json, [System.Text.Encoding]::UTF8)
        [System.IO.File]::Copy($tmp, $script:_themeCachePath, $true)
        try { [System.IO.File]::Delete($tmp) } catch {}
        Write-Log "[PERF] Theme cache saved for '$ThemeName'" -Level DBG -NoUI
    } catch {
        Write-Log "[WARN] Theme cache save error: $_" -Level WARN -NoUI
    }
}


# -----------------------------------------------------------------------------
# [PERF] Save-LangCache -- Serializa $script:LangDict a JSON en %TEMP%\SysOpt
# Se invoca después de Load-Language o cambio de idioma. Patrón idéntico a
# Save-ThemeCache.  Hash MD5 del .lang + AppVersion validan la caché.
# -----------------------------------------------------------------------------
function global:Save-LangCache {
    param([string]$LangCode)
    try {
        $dir = [System.IO.Path]::GetDirectoryName($script:_langCachePath)
        if (-not (Test-Path $dir)) { [System.IO.Directory]::CreateDirectory($dir) | Out-Null }
        $langPath = Join-Path $script:LangDir "$LangCode.lang"
        if (-not (Test-Path $langPath)) { return }
        $langHash = (Get-FileHash $langPath -Algorithm MD5).Hash
        $cacheObj = @{
            LangCode = $LangCode
            LangHash = $langHash
            Version  = $script:AppVersion
            Dict     = $script:LangDict
        }
        $json = $cacheObj | ConvertTo-Json -Depth 3 -Compress
        $tmp  = $script:_langCachePath + ".tmp"
        [System.IO.File]::WriteAllText($tmp, $json, [System.Text.Encoding]::UTF8)
        [System.IO.File]::Copy($tmp, $script:_langCachePath, $true)
        try { [System.IO.File]::Delete($tmp) } catch {}
        Write-Log "[PERF] Lang cache saved for '$LangCode' ($($script:LangDict.Count) keys)" -Level DBG -NoUI
    } catch {
        Write-Log "[WARN] Lang cache save error: $_" -Level WARN -NoUI
    }
}

function global:Save-Settings {
    try {
        $dir = [System.IO.Path]::GetDirectoryName($script:SettingsPath)
        if (-not (Test-Path $dir)) { [System.IO.Directory]::CreateDirectory($dir) | Out-Null }
        $cfg = @{
            DiskScanPath       = $txtDiskScanPath.Text
            AutoRefresh        = ($chkAutoRefresh.IsChecked -eq $true)
            RefreshIntervalSec = if ($cmbRefreshInterval.SelectedItem) { $cmbRefreshInterval.SelectedItem.Tag } else { "5" }
            DiskFilterText     = $txtDiskFilter.Text
            Theme              = $script:CurrentTheme
            Language           = $script:CurrentLang
            DebugLog           = [LogEngine]::DebugEnabled
            ToastEnabled       = if (([System.Management.Automation.PSTypeName]"SysOpt.Toast.ToastManager").Type) { [SysOpt.Toast.ToastManager]::Enabled } else { $true }
            ToastDurationMs    = if (([System.Management.Automation.PSTypeName]"SysOpt.Toast.ToastManager").Type) { [SysOpt.Toast.ToastManager]::DefaultDurationMs } else { 4000 }
            ToastCorner        = if (([System.Management.Automation.PSTypeName]"SysOpt.Toast.ToastManager").Type) { [SysOpt.Toast.ToastManager]::Corner.ToString() } else { "BottomRight" }
            SafeMode           = $(if ($null -ne $global:_sysoptSafeMode) { $global:_sysoptSafeMode } else { $script:SafeMode })
            OutputDefaultCollapsed = $(if ($null -ne $global:_sysoptOutputDefaultCollapsed) { $global:_sysoptOutputDefaultCollapsed } else { ($script:OutputDefaultCollapsed -eq $true) })
        }
        $json = $cfg | ConvertTo-Json
        # Escritura atómica: temp -> Move evita file-lock conflicts
        $tmp = $script:SettingsPath + ".tmp"
        [System.IO.File]::WriteAllText($tmp, $json, [System.Text.Encoding]::UTF8)
        [System.IO.File]::Copy($tmp, $script:SettingsPath, $true)
        try { [System.IO.File]::Delete($tmp) } catch {}
    } catch {
        Write-Log "[WARN] No se pudo guardar settings.json: $_" -Level "WARN" -NoUI
    }
}

function global:Load-Settings {
    try {
        if (Test-Path $script:SettingsPath) {
            $cfg = Get-Content -Path $script:SettingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
            # Output panel default state (prioridad: leer ANTES de accesos a UI que pueden fallar)
            if ($cfg.PSObject.Properties['OutputDefaultCollapsed'] -and $cfg.OutputDefaultCollapsed -eq $true) {
                $script:OutputDefaultCollapsed = $true
                $global:_sysoptOutputDefaultCollapsed = $true
            }
            if ($cfg.DiskScanPath)   { $txtDiskScanPath.Text = $cfg.DiskScanPath }
            if ($cfg.DiskFilterText) { $txtDiskFilter.Text   = $cfg.DiskFilterText }
            # Auto-refresh interval
            if ($cfg.RefreshIntervalSec) {
                foreach ($item in $cmbRefreshInterval.Items) {
                    if ($item.Tag -eq "$($cfg.RefreshIntervalSec)") {
                        $cmbRefreshInterval.SelectedItem = $item; break
                    }
                }
            }
            # Auto-refresh on/off (set last so timer uses correct interval)
            if ($cfg.AutoRefresh -eq $true) { $chkAutoRefresh.IsChecked = $true }
            if ($cfg.Theme -and (Test-Path (Join-Path $script:ThemesDir "$($cfg.Theme).theme"))) {
                $script:CurrentTheme = $cfg.Theme
            }
            if ($cfg.Language -and (Test-Path (Join-Path $script:LangDir "$($cfg.Language).lang"))) {
                $script:CurrentLang = $cfg.Language
Set-SplashProgress 94 (T "SplashLoading94" "Configuración del sistema...")
            }
            # Debug logging toggle
            if ($cfg.PSObject.Properties['DebugLog'] -and $cfg.DebugLog -eq $true) {
                [LogEngine]::DebugEnabled = $true
            }
            # Toast notifications toggle
            if ($cfg.PSObject.Properties['ToastEnabled']) {
                if (([System.Management.Automation.PSTypeName]"SysOpt.Toast.ToastManager").Type) {
                    [SysOpt.Toast.ToastManager]::Enabled = ($cfg.ToastEnabled -ne $false)
                }
            }
            # Toast duration
            if ($cfg.PSObject.Properties['ToastDurationMs'] -and $cfg.ToastDurationMs -gt 0) {
                if (([System.Management.Automation.PSTypeName]"SysOpt.Toast.ToastManager").Type) {
                    [SysOpt.Toast.ToastManager]::DefaultDurationMs = [int]$cfg.ToastDurationMs
                }
            }
            # Toast corner
            if ($cfg.PSObject.Properties['ToastCorner'] -and $cfg.ToastCorner) {
                if (([System.Management.Automation.PSTypeName]"SysOpt.Toast.ToastManager").Type) {
                    try {
                        $tc = [SysOpt.Toast.ToastCorner]::$($cfg.ToastCorner)
                        [SysOpt.Toast.ToastManager]::Corner = $tc
                    } catch {}
                }
            }
            # Safe Mode
            if ($cfg.PSObject.Properties['SafeMode'] -and $cfg.SafeMode -eq $true) {
                $script:SafeMode = $true
                $global:_sysoptSafeMode = $true
                Write-Log "[APP] Modo Seguro activado -- módulos no se cargarán" -Level WARN -NoUI
            }

        }
    } catch {}
}

# -----------------------------------------------------------------------------
# [I18N] Cargar idioma y aplicar a toda la UI
# -----------------------------------------------------------------------------
function global:Load-Language {
    param([string]$LangCode)
    $langPath = Join-Path $script:LangDir "$LangCode.lang"
    if (-not (Test-Path $langPath)) {
        Write-Log "[LANG] Archivo de idioma no encontrado: $LangCode  (path: $langPath)" -Level "WARN" -NoUI
        return
    }
    Write-Log "[LANG] Cargando idioma: $LangCode" -Level "INFO" -NoUI

    try {
        $script:LangDict    = [LangEngine]::ParseLangFile($langPath)
        $script:CurrentLang  = $LangCode
    } catch {
        Write-Verbose "SysOpt: Error al cargar idioma $LangCode : $($_.Exception.Message)"
        return
    }

    # [PERF] Actualizar caché de idioma en %TEMP%
    try { Save-LangCache -LangCode $LangCode } catch {}

    # Aplicar textos a controles conocidos
    Apply-LanguageToUI

    # -- Sync localization to C# DLLs ---------------------------------
    try {
        $dictGeneric = New-Object 'System.Collections.Generic.Dictionary[string,string]'([System.StringComparer]::OrdinalIgnoreCase)
        foreach ($k in $script:LangDict.Keys) { $dictGeneric[$k] = $script:LangDict[$k] }
        [Loc]::SetDict($dictGeneric)  # Single source -- Diagnostics/Optimizer use SysOpt.Core.Loc via assembly reference
    } catch { Write-Log "WARN" "Loc.SetDict failed: $_" }

    # -- Recargar lang de módulos activos al cambiar idioma ------------
    if ($script:LoadedModules -and $script:LoadedModules.Count -gt 0 -and $script:ModulesDir) {
        foreach ($modId in $script:LoadedModules.Keys) {
            $modLangDir = Join-Path (Join-Path $script:ModulesDir $modId) "lang"
            if (-not (Test-Path $modLangDir)) { continue }
            $modLangFile = Join-Path $modLangDir "$LangCode.lang"
            if (-not (Test-Path $modLangFile)) {
                $modLangFile = Join-Path $modLangDir "en-us.lang"
            }
            if (Test-Path $modLangFile) {
                try {
                    $modDict = [LangEngine]::ParseLangFile($modLangFile)
                    foreach ($k in $modDict.Keys) { $script:LangDict[$k] = $modDict[$k] }
                    Write-Log "[LANG] Módulo '$modId' lang recargado ($LangCode)" -Level DBG -NoUI
                } catch {
                    Write-Log "[LANG] Error recargando lang del módulo '$modId': $_" -Level WARN -NoUI
                }
            }
        }
        # Re-sync Loc tras merge de módulos
        try {
            $dictGeneric2 = New-Object 'System.Collections.Generic.Dictionary[string,string]'([System.StringComparer]::OrdinalIgnoreCase)
            foreach ($k in $script:LangDict.Keys) { $dictGeneric2[$k] = $script:LangDict[$k] }
            [Loc]::SetDict($dictGeneric2)
        } catch {}

        # -- [FIX-LANG-SYNC] Invocar callbacks OnLanguageChanged de módulos --
        # Cada módulo puede declarar una función global OnLanguageChanged_<modId>
        # que actualiza los controles de su UI con los nuevos textos del idioma.
        foreach ($modId in $script:LoadedModules.Keys) {
            $callbackName = "OnLanguageChanged_$modId"
            if (Get-Command $callbackName -ErrorAction SilentlyContinue) {
                try {
                    & $callbackName -LangCode $LangCode
                    Write-Log "[LANG] Callback '$callbackName' ejecutado" -Level DBG -NoUI
                } catch {
                    Write-Log "[LANG] Error en callback '$callbackName': $_" -Level WARN -NoUI
                }
            }
        }
    }
}

# -----------------------------------------------------------------------------
# [DWM] Apply-TitleBarTheme -- pinta la barra de título nativa con colores
# del tema activo.  En Win11 -> fondo + texto custom.  En Win10 -> dark mode.
# Se invoca al iniciar, al cambiar tema y al cambiar idioma.
# -----------------------------------------------------------------------------
function global:Apply-TitleBarTheme {
    try {
        $hwnd = [System.Windows.Interop.WindowInteropHelper]::new($window).Handle
        if ($hwnd -eq [IntPtr]::Zero) { return }
        # Dark mode (Win10 1809+)
        [DwmHelper]::SetDarkMode($hwnd, $true)
        # Caption background = BgDeep (Win11 22000+)
        $bg = Get-TC 'BgDeep' '#0D0F1A'
        if ($bg -and $bg.Length -ge 7) {
            [DwmHelper]::SetCaptionColor($hwnd,
                [Convert]::ToByte($bg.Substring(1,2), 16),
                [Convert]::ToByte($bg.Substring(3,2), 16),
                [Convert]::ToByte($bg.Substring(5,2), 16))
        }
        # Caption text = TextPrimary (Win11 22000+)
        $fg = Get-TC 'TextPrimary' '#E8ECF4'
        if ($fg -and $fg.Length -ge 7) {
            [DwmHelper]::SetTextColor($hwnd,
                [Convert]::ToByte($fg.Substring(1,2), 16),
                [Convert]::ToByte($fg.Substring(3,2), 16),
                [Convert]::ToByte($fg.Substring(5,2), 16))
        }
    } catch {
        Write-Log "[DWM] Error aplicando tema a title bar: $_" -Level "DBG" -NoUI
    }
}

# -----------------------------------------------------------------------------
# [TITLE] Update-WindowTitle -- título dinámico con badge [DEBUG MODE]
# -----------------------------------------------------------------------------
function global:Update-WindowTitle {
    $title = "SysOpt -- $(T 'AppSubtitle' 'Windows Optimizer GUI') v$($script:AppVersion)"
    try {
        if ([LogEngine]::DebugEnabled) {
            $title += "  [DEBUG MODE]"
        }
    } catch {}
    $window.Title = $title
}

function global:Apply-LanguageToUI {
    $d = $script:LangDict
    if ($d.Count -eq 0) { return }

    # -- Window title ------------------------------------------------------
    Update-WindowTitle
    Apply-TitleBarTheme

    # -- Status bar --------------------------------------------------------
    if ($null -ne $StatusText -and $StatusText.Text -match 'Listo|Ready|Pronto') {
        $StatusText.Text = T 'StatusReady' 'Listo para optimizar'
    }

    # -- Top bar tooltips --------------------------------------------------
    if ($null -ne $btnShowTasks)  { $btnShowTasks.ToolTip  = T 'TooltipTasks'       'Tareas en segundo plano' }
    if ($null -ne $btnOptions)    { $btnOptions.ToolTip    = T 'TooltipOptions'     'Opciones -- Tema e Idioma' }
    if ($null -ne $btnRefreshInfo){ $btnRefreshInfo.ToolTip= T 'TooltipRefreshInfo' 'Actualizar información del sistema' }

    # -- DryRun label ------------------------------------------------------
    if ($null -ne $chkDryRun -and $null -ne $chkDryRun.Content) {
        try { $chkDryRun.Content.Text = T 'DryRunLabel' 'MODO ANÁLISIS  (sin cambios)' } catch {}
    }

    # -- Tab headers -------------------------------------------------------
    $tabs = (CFN $window "tabMain")
    if ($null -ne $tabs -and $tabs.Items.Count -ge 4) {
        $tabs.Items[0].Header = T 'TabOptimization' '?  Optimización'
        $tabs.Items[1].Header = T 'TabPerformance'  '?  Rendimiento'
        $tabs.Items[2].Header = T 'TabDisk'         '?  Explorador de Disco'
        $tabs.Items[3].Header = T 'TabHistory'      '?  Historial'
    }

    # -- Checkboxes de optimización ----------------------------------------
    $chkMap = @{
        chkOptimizeDisks  = 'ChkOptimizeDisks'
        chkRecycleBin     = 'ChkRecycleBin'
        chkTempFiles      = 'ChkTempFiles'
        chkUserTemp       = 'ChkUserTemp'
        chkWUCache        = 'ChkWUCache'
        chkChkdsk         = 'ChkChkdsk'
        chkClearMemory    = 'ChkClearMemory'
        chkCloseProcesses = 'ChkCloseProcesses'
        chkDNSCache       = 'ChkDNSCache'
        chkBrowserCache   = 'ChkBrowserCache'
        chkBackupRegistry = 'ChkBackupRegistry'
        chkCleanRegistry  = 'ChkCleanRegistry'
        chkSFC            = 'ChkSFC'
        chkDISM           = 'ChkDISM'
        chkEventLogs      = 'ChkEventLogs'
        chkShowStartup    = 'ChkShowStartup'
    }
    foreach ($entry in $chkMap.GetEnumerator()) {
        $ctrl = (CFN $window $entry.Key)
        if ($null -ne $ctrl -and $d.ContainsKey($entry.Value)) {
            $ctrl.Content = $d[$entry.Value]
        }
    }

    # -- Bottom buttons ----------------------------------------------------
    if ($null -ne $btnStart)     { $btnStart.Content     = T 'BtnStart'     '?  Iniciar optimización' }
    if ($null -ne $btnDryRun)    { $btnDryRun.Content    = T 'BtnDryRun'    'Analizar' }
    if ($null -ne $btnWizard)    { $btnWizard.Content    = "$([char]0x2728) " + (T 'BtnWizard'    'Wizard') }
    if ($null -ne $btnSelectAll) { $btnSelectAll.Content  = T 'BtnSelectAll' 'Seleccionar todo' }
    if ($null -ne $btnCancel -and $btnCancel.IsEnabled -eq $false) {
        $btnCancel.Content = T 'BtnCancel' 'Cancelar'
    }
    if ($null -ne $btnExit)      { $btnExit.Content      = T 'BtnExit'     'Salir' }

    # -- CheckBox reiniciar ------------------------------------------------
    if ($null -ne $chkAutoRestart) {
        try { $chkAutoRestart.Content.Text = T 'ChkAutoRestart' 'Reiniciar al finalizar' } catch {
            $chkAutoRestart.Content = T 'ChkAutoRestart' 'Reiniciar al finalizar'
        }
    }

    # -- Section headers (Optimization tab) --------------------------------
    $hdrMap = @{
        txtHdrDisks      = 'HdrDisksFiles'
        txtHdrMemProc    = 'HdrMemoryProc'
        txtHdrNetBrowser = 'HdrNetBrowsers'
        txtHdrRegistry   = 'HdrRegistry'
        txtHdrSysVerify  = 'HdrSysVerify'
        txtHdrEventLogs  = 'HdrEventLogs'
        txtHdrStartup    = 'HdrStartupPrograms'
    }
    foreach ($entry in $hdrMap.GetEnumerator()) {
        $ctrl = (CFN $window $entry.Key)
        if ($null -ne $ctrl -and $d.ContainsKey($entry.Value)) { $ctrl.Text = $d[$entry.Value] }
    }

    # -- Optimization notes ------------------------------------------------
    $noteMap = @{
        txtSecurityNote = 'NoteSecurityLog'
        txtStartupNote  = 'NoteStartupManage'
    }
    foreach ($entry in $noteMap.GetEnumerator()) {
        $ctrl = (CFN $window $entry.Key)
        if ($null -ne $ctrl -and $d.ContainsKey($entry.Value)) { $ctrl.Text = $d[$entry.Value] }
    }

    # -- Section headers (Performance tab) ---------------------------------
    $perfHdrMap = @{
        txtHdrCpuCores = 'HdrCpuCores'
        txtHdrRam      = 'HdrMemoryRam'
        txtHdrSmart    = 'HdrSmartDisk'
        txtHdrNic      = 'HdrNetCards'
        txtHdrDiskC    = 'HdrDiskC'
        txtHdrDetail   = 'HdrDetail'
        txtHdrOutput   = 'HdrOutput'
    }
    foreach ($entry in $perfHdrMap.GetEnumerator()) {
        $ctrl = (CFN $window $entry.Key)
        if ($null -ne $ctrl -and $d.ContainsKey($entry.Value)) { $ctrl.Text = $d[$entry.Value] }
    }

    # -- RAM sub-labels ----------------------------------------------------
    $ramMap = @{
        txtRamLblTotal = 'RamLblTotal'
        txtRamLblUsed  = 'RamLblUsed'
        txtRamLblFree  = 'RamLblFree'
        txtRamLblPct   = 'RamLblUsePct'
    }
    foreach ($entry in $ramMap.GetEnumerator()) {
        $ctrl = (CFN $window $entry.Key)
        if ($null -ne $ctrl -and $d.ContainsKey($entry.Value)) { $ctrl.Text = $d[$entry.Value] }
    }

    # -- Performance controls ----------------------------------------------
    $btnRP = (CFN $window 'btnRefreshPerf')
    if ($null -ne $btnRP) { $btnRP.Content = "$([char]::ConvertFromUtf32(0x1F504))  " + (T 'PerfBtnRefresh' 'Actualizar') }

    $txtARL = (CFN $window 'txtAutoRefreshLabel')
    if ($null -ne $txtARL) { $txtARL.Text = T 'PerfAutoRefresh' 'Auto-refresco' }

    if ($null -ne $txtPerfStatus -and $txtPerfStatus.Text -match 'Haz clic|Click|Clique') {
        $txtPerfStatus.Text = "  " + (T 'PerfClickRefresh' 'Haz clic en Actualizar para cargar datos')
    }

    # -- Console panel tooltips --------------------------------------------
    if ($null -ne $btnOutputClose)    { $btnOutputClose.ToolTip    = T 'TipOutputClose'    'Ocultar output' }
    if ($null -ne $btnOutputMinimize) { $btnOutputMinimize.ToolTip = T 'TipOutputMinimize' 'Minimizar output' }
    if ($null -ne $btnOutputExpand)   { $btnOutputExpand.ToolTip   = T 'TipOutputExpand'   'Expandir output' }

    # -- Disk Explorer -- labels --------------------------------------------
    $diskLblMap = @{
        txtLblPath        = 'DiskLblPath'
        txtLblFilter      = 'DiskLblFilter'
        txtColName        = 'DiskColName'
        txtColSize        = 'DiskColSize'
        txtColFiles       = 'DiskColFiles'
        txtLblDetailSize  = 'DiskDetailSize'
        txtLblDetailFiles = 'DiskDetailFiles'
        txtLblDetailDirs  = 'DiskDetailDirs'
        txtLblDetailPct   = 'DiskDetailPctParent'
        txtHdrTop10       = 'DiskHdrTop10'
    }
    foreach ($entry in $diskLblMap.GetEnumerator()) {
        $ctrl = (CFN $window $entry.Key)
        if ($null -ne $ctrl -and $d.ContainsKey($entry.Value)) { $ctrl.Text = $d[$entry.Value] }
    }

    # -- Disk Explorer -- buttons -------------------------------------------
    $btnScan = (CFN $window 'btnDiskScan')
    if ($null -ne $btnScan) { $btnScan.Content = "$([char]::ConvertFromUtf32(0x1F50D))  " + (T 'DiskBtnScan' 'Escanear') }
    $btnStop = (CFN $window 'btnDiskStop')
    if ($null -ne $btnStop -and $btnStop.IsEnabled -eq $false) { $btnStop.Content = "$([char]0x23F9)  " + (T 'DiskBtnStop' 'Detener') }
    $btnBrowse = (CFN $window 'btnDiskBrowse')
    if ($null -ne $btnBrowse) { $btnBrowse.ToolTip = T 'DiskBrowseTip' 'Seleccionar carpeta' }
    $btnFltClr = (CFN $window 'btnDiskFilterClear')
    if ($null -ne $btnFltClr) { $btnFltClr.ToolTip = T 'DiskFilterClearTip' 'Limpiar filtro' }

    # Disk bottom buttons
    $btnDed = (CFN $window 'btnDedup')
    if ($null -ne $btnDed) {
        $btnDed.Content = "$([char]::ConvertFromUtf32(0x1F50D))  " + (T 'DiskBtnDedup' 'Duplicados')
        $btnDed.ToolTip = T 'DiskDedupTip' 'Busca archivos duplicados por SHA256 (>10 MB) en el escaneo actual'
    }
    $btnExpCSV = (CFN $window 'btnExportCsv')
    if ($null -ne $btnExpCSV) {
        $btnExpCSV.Content = "$([char]::ConvertFromUtf32(0x1F4C4))  " + (T 'DiskBtnExportCsv' 'Exportar CSV')
        $btnExpCSV.ToolTip = T 'DiskExportCsvTip' 'Exportar resultados a CSV'
    }
    $btnHtmlR = (CFN $window 'btnDiskReport')
    if ($null -ne $btnHtmlR) {
        $btnHtmlR.Content = "$([char]::ConvertFromUtf32(0x1F4CA))  " + (T 'DiskBtnHtmlReport' 'Informe HTML')
        $btnHtmlR.ToolTip = T 'DiskHtmlReportTip' 'Genera informe HTML visual del escaneo'
    }

    # Disk scan status
    $txtDSS = (CFN $window 'txtDiskScanStatus')
    if ($null -ne $txtDSS -and $txtDSS.Text -match 'Listo|Ready|Pronto') {
        $txtDSS.Text = T 'DiskStatusReady' 'Listo'
    }

    # -- Disk Explorer -- context menu --------------------------------------
    $ctxMap = @{
        ctxOpen       = @("$([char]::ConvertFromUtf32(0x1F4C1))  ", 'CtxOpenExplorer',  'Abrir en Explorador')
        ctxCopy       = @("$([char]::ConvertFromUtf32(0x1F4CB))  ", 'CtxCopyPath',      'Copiar ruta')
        ctxScanFolder = @("$([char]::ConvertFromUtf32(0x1F50D))  ", 'CtxScanFolder',    'Escanear carpeta')
        ctxDelete     = @("$([char]::ConvertFromUtf32(0x1F5D1))  ", 'CtxDeleteFolder',  'Eliminar carpeta...')
    }
    foreach ($entry in $ctxMap.GetEnumerator()) {
        $ctrl = (CFN $window $entry.Key)
        if ($null -ne $ctrl) {
            $icon = $entry.Value[0]
            $key  = $entry.Value[1]
            $fb   = $entry.Value[2]
            $ctrl.Header = $icon + (T $key $fb)
        }
    }

    # -- Output console -- context menu -----------------------------------
    # Icons are already included in the lang file values, so no prefix needed
    $ctxOutMap = @{
        ctxOutputClear    = @('CtxOutputClear',    "$([char]::ConvertFromUtf32(0x1F9F9)) Limpiar Output")
        ctxOutputSaveLog  = @('CtxOutputSaveLog',  "$([char]::ConvertFromUtf32(0x1F4BE)) Guardar Log")
        ctxOutputOpenLogs = @('CtxOutputOpenLogs', "$([char]::ConvertFromUtf32(0x1F4C1)) Abrir carpeta de logs")
        ctxOutputReadLast = @('CtxOutputReadLast', "$([char]::ConvertFromUtf32(0x1F4C4)) Leer último log")
    }
    foreach ($entry in $ctxOutMap.GetEnumerator()) {
        $ctrl = (CFN $window $entry.Key)
        if ($null -ne $ctrl) {
            $ctrl.Header = T $entry.Value[0] $entry.Value[1]
        }
    }

    # Filter tooltip
    $txtFilter = (CFN $window 'txtDiskFilter')
    if ($null -ne $txtFilter) { $txtFilter.ToolTip = T 'DiskFilterTip' 'Filtra carpetas por nombre en tiempo real' }

    # -- History tab -------------------------------------------------------
    $txtSNL = (CFN $window 'txtSnapNameLabel')
    if ($null -ne $txtSNL) { $txtSNL.Text = T 'SnapLblName' 'Nombre:' }

    $btnSnapSave = (CFN $window 'btnSnapshotSave')
    if ($null -ne $btnSnapSave) { $btnSnapSave.Content = "$([char]::ConvertFromUtf32(0x1F4BE))  " + (T 'SnapBtnSave' 'Guardar') }

    $chkSnapAll = (CFN $window 'chkSnapshotSelectAll')
    if ($null -ne $chkSnapAll) { $chkSnapAll.Content = T 'SnapChkAll' 'Todo' }

    $txtSnapSel = (CFN $window 'txtSnapshotSelCount')
    if ($null -ne $txtSnapSel -and $txtSnapSel.Text -match 'guardados|saved|salvos') {
        $txtSnapSel.Text = T 'SnapSavedStatus' 'Snapshots guardados'
    }

    $btnSnapCmp = (CFN $window 'btnSnapshotCompare')
    if ($null -ne $btnSnapCmp) {
        $btnSnapCmp.Content = "$([char]::ConvertFromUtf32(0x1F50D))  " + (T 'SnapBtnCompare' 'Comparar')
        $btnSnapCmp.ToolTip = T 'SnapCompareTip' 'Compara los snapshots marcados entre sí o contra el escaneo actual'
    }

    $btnSnapDel = (CFN $window 'btnSnapshotDelete')
    if ($null -ne $btnSnapDel) {
        $btnSnapDel.Content = "$([char]::ConvertFromUtf32(0x1F5D1))  " + (T 'SnapBtnDelete' 'Eliminar')
        $btnSnapDel.ToolTip = T 'SnapDeleteTip' 'Elimina todos los snapshots marcados'
    }

    $txtSnapDT = (CFN $window 'txtSnapshotDetailTitle')
    if ($null -ne $txtSnapDT -and $txtSnapDT.Text -match 'Selecciona|Select|Selecione') {
        $txtSnapDT.Text = T 'SnapSelectPrompt' 'Selecciona un snapshot'
    }

    $txtSnapSt = (CFN $window 'txtSnapshotStatus')
    if ($null -ne $txtSnapSt -and $txtSnapSt.Text -match 'Sin snapshots|No snapshots|Sem snapshots') {
        $txtSnapSt.Text = T 'SnapNoSnapshots' 'Sin snapshots guardados.'
    }
}



# -----------------------------------------------------------------------------
# [THEME] Aplicar tema con barra de progreso + subproceso para parsing
# -----------------------------------------------------------------------------
# Theme color mapping: XAML hex -> (ThemeKey, OffsetR, OffsetG, OffsetB)

$script:ThemeColorMap = @{
    "00D4B4" = @("AccentCyan", -74, -20, 30)
    "080A14" = @("ConsoleBg", 0, 0, 0)
    "0D0F1A" = @("BgDeep", 0, 0, 0)
    "0E2E2A" = @("BtnCyanBg", 1, 0, 6)
    "131625" = @("BgCardDark", 0, 0, 0)
    "132040" = @("BgInput", -11, -2, 11)
    "161925" = @("BgCard", 0, 0, 0)
    "163530" = @("DryRunBg", 9, 13, 0)
    "181D2E" = @("PurpleBlobBg", -2, 9, -2)
    "182A1E" = @("BgStatusOk", 0, 0, 0)
    "1A1E2A" = @("BgCard", 4, 5, 5)
    "1A1E2F" = @("BgInput", -4, -4, -6)
    "1A2035" = @("BgInput", -4, -2, 0)
    "1A2040" = @("BgInput", -4, -2, 11)
    "1A2540" = @("CtxHover", -4, -5, -8)
    "1A2F4A" = @("BgStatusInfo", 0, 0, 0)
    "1A3A5C" = @("BgStatusInfo", 0, 11, 18)
    "1A4A35" = @("BgStatusOk", 2, 32, 23)
    "1A6B3E" = @("BgStatusInfo", 0, 60, -12)
    "1E2235" = @("BgInput", 0, 0, 0)
    "1E3058" = @("ComboSelected", 0, 0, -8)
    "1E3A5C" = @("ComboSelected", 0, 10, -4)
    "252A38" = @("BgInput", 7, 8, 3)
    "252B3B" = @("BgInput", 7, 9, 6)
    "252B40" = @("BorderSubtle", -5, -4, -8)
    "253060" = @("ComboSelected", 7, 0, 0)
    "28C874" = @("AccentCyan", -34, -32, -34)
    "2A1018" = @("BgStatusErr", 0, 0, 0)
    "2A1A4A" = @("PurpleBlobBg", 18, -3, 28)
    "2A2010" = @("BgStatusWarn", 0, 0, 0)
    "2A2F48" = @("BorderSubtle", 0, 0, 0)
    "2A3048" = @("BorderSubtle", 0, 1, 0)
    "2A3448" = @("BorderSubtle", 0, 5, 0)
    "2A3A5A" = @("ComboSelected", 12, 10, -6)
    "2E0E14" = @("BtnDangerBg", 0, -2, -4)
    "2E1E08" = @("BtnAmberBg", 0, -2, -8)
    "2E3650" = @("BorderSubtle", 4, 7, 8)
    "2EDFBF" = @("AccentCyan", -28, -9, 41)
    "2FD980" = @("AccentCyan", -27, -15, -22)
    "3A2010" = @("BgStatusWarn", 16, 0, 0)
    "3A4060" = @("BorderHover", 0, 0, 0)
    "3A4468" = @("BorderHover", 0, 4, 8)
    "3D5080" = @("BorderHover", 3, 16, 32)
    "3D8EFF" = @("BorderActive", -30, -21, 0)
    "4A3010" = @("BtnAmberBg", 28, 16, 0)
    "4AE896" = @("AccentCyan", 0, 0, 0)
    "5AE88A" = @("AccentCyan", 16, 0, -12)
    "5BA3FF" = @("BorderActive", 0, 0, 0)
    "6ABDA0" = @("AccentCyan", 32, -43, 10)
    "6B7A9E" = @("TextMuted", 0, 6, 10)
    "7880A0" = @("TextMuted", 13, 12, 12)
    "7BA8E0" = @("BorderActive", 32, 5, -31)
    "8B96B8" = @("TextSecondary", -16, -14, -8)
    "9B7EFF" = @("AccentPurple", -9, 2, 0)
    "9BA4C0" = @("TextSecondary", 0, 0, 0)
    "A47CFF" = @("AccentPurple", 0, 0, 0)
    "B0BACC" = @("TextSecondary", 21, 22, 12)
    "C07AFF" = @("AccentPurple", 28, -2, 0)
    "C0933A" = @("AccentAmber", -63, -34, -13)
    "CC2244" = @("AccentRed", -51, -73, -64)
    "D0D8F0" = @("TextPrimary", -24, -18, -6)
    "D4850A" = @("AccentAmber", -43, -48, -61)
    "D4D9E8" = @("TextPrimary", -20, -17, -14)
    "E0E8F4" = @("TextPrimary", -8, -2, -2)
    "E8ECF4" = @("TextPrimary", 0, 2, -2)
    "F0F3FA" = @("TextPrimary", 8, 9, 4)
    "F5A623" = @("AccentAmber", -10, -15, -36)
    "FF4D6A" = @("AccentRed", 0, -30, -26)
    "FF6B84" = @("AccentRed", 0, 0, 0)
    "FFB547" = @("AccentAmber", 0, 0, 0)
    "FFFFFF" = @("BtnPrimaryFg", 0, 0, 0)
    "1A4A8A" = @("BtnPrimaryBg", 0, 0, 0)
    "0D2E24" = @("BtnCyanBg", 0, 0, 0)
    "2E2010" = @("BtnAmberBg", 0, 0, 0)
    "2E1018" = @("BtnDangerBg", 0, 0, 0)
    "6B7494" = @("TextMuted", 0, 0, 0)
}

# -----------------------------------------------------------------------------
# Apply-ButtonTheme -- pinta programáticamente los botones nombrados de la
# ventana principal usando las claves del tema activo. Complementa el sistema
# TB_RRGGBB (DynamicResource) para botones con colores asignados directamente.
# -----------------------------------------------------------------------------
function global:Apply-ButtonTheme {
    $bc = [System.Windows.Media.BrushConverter]::new()

    # Helper: clave de tema -> SolidColorBrush
    function global:Local:Brush([string]$key, [string]$fallback) {
        $bc.ConvertFromString((Get-TC $key $fallback))
    }

    # -- Paleta por tipo de botón ----------------------------------------------
    $palette = @{
        "Primary"   = @{ Bg = (Brush 'BtnPrimaryBg'   '#1A4A8A'); Fg = (Brush 'BtnPrimaryFg'   '#FFFFFF'); Border = (Brush 'BtnPrimaryBorder' '#5BA3FF') }
        "Cyan"      = @{ Bg = (Brush 'BtnCyanBg'      '#0D2E24'); Fg = (Brush 'BtnCyanFg'      '#4AE896'); Border = (Brush 'AccentCyan'       '#4AE896') }
        "Amber"     = @{ Bg = (Brush 'BtnAmberBg'     '#2E2010'); Fg = (Brush 'BtnAmberFg'     '#FFB547'); Border = (Brush 'AccentAmber'      '#FFB547') }
        "Danger"    = @{ Bg = (Brush 'BtnDangerBg'    '#2E1018'); Fg = (Brush 'BtnDangerFg'    '#FF6B84'); Border = (Brush 'AccentRed'        '#FF6B84') }
        "Secondary" = @{ Bg = (Brush 'BtnSecondaryBg' '#1E2235'); Fg = (Brush 'BtnSecondaryFg' '#9BA4C0'); Border = (Brush 'BorderSubtle'     '#2A2F48') }
        "Ghost"     = @{ Bg = (Brush 'BtnGhostBg'     '#1E2235'); Fg = (Brush 'BtnGhostFg'     '#6B7494'); Border = (Brush 'BtnGhostBorder'   '#2A2F48') }
    }

    # -- Mapa: nombre exacto del control -> tipo -------------------------------
    $btnMap = @{
        # -- Footer (barra inferior) -------------------------------------------
        "btnStart"           = "Primary"    # ? Iniciar optimización
        "btnDryRun"          = "Cyan"       # [SEARCH] Analizar
        "btnWizard"          = "Cyan"       # ? Wizard
        "btnCancel"          = "Amber"      # Cancelar
        "btnSelectAll"       = "Secondary"  # Seleccionar todo
        "btnExit"            = "Danger"     # Salir
        # -- Header (barra superior) -------------------------------------------
        "btnShowTasks"       = "Ghost"      # ? Tareas
        "btnOptions"         = "Ghost"      # ? Opciones
        "btnRefreshInfo"     = "Ghost"      # ? Actualizar info del sistema
        # -- Tab Rendimiento ---------------------------------------------------
        "btnRefreshPerf"     = "Cyan"       # ? Actualizar
        # -- Tab Explorador de Disco -------------------------------------------
        "btnDiskScan"        = "Cyan"       # [SEARCH] Escanear
        "btnDiskStop"        = "Amber"      # ? Detener
        "btnDiskBrowse"      = "Ghost"      # ? Browse (carpeta)
        "btnDiskFilterClear" = "Ghost"      # ? Limpiar filtro
        # -- Tab Historial / Snapshots -----------------------------------------
        "btnSnapshotSave"    = "Secondary"  # ? Guardar
        "btnSnapshotCompare" = "Cyan"       # ? Comparar
        "btnSnapshotDelete"  = "Danger"     # ? Eliminar
    }

    foreach ($name in $btnMap.Keys) {
        try {
            $ctrl = (CFN $window $name)
            if ($null -eq $ctrl) { continue }
            $p = $palette[$btnMap[$name]]
            $ctrl.Background  = $p.Bg
            $ctrl.Foreground  = $p.Fg
            $ctrl.BorderBrush = $p.Border
        } catch {}
    }
}

function global:Apply-ThemeWithProgress {
    param([string]$ThemeName)

    $themePath = Join-Path $script:ThemesDir "$ThemeName.theme"
    if (-not (Test-Path $themePath)) {
        Show-ThemedDialog -Title (T 'DlgError' 'Error') `
            -Message "Tema no encontrado: $ThemeName" -Type "error"
        return
    }

    # -- Progress window (uses current theme colors) --
    $progWin = New-Object System.Windows.Window
    $progWin.Title                 = ""
    $progWin.Width                 = 440
    $progWin.Height                = 120
    $progWin.WindowStartupLocation = "CenterOwner"
    $progWin.ResizeMode            = "NoResize"
    $progWin.WindowStyle           = "None"
    $progWin.AllowsTransparency    = $true
    $progWin.Background            = [System.Windows.Media.Brushes]::Transparent
    $progWin.Topmost               = $true
    try { $progWin.Owner = $window } catch {}

    $bc = [System.Windows.Media.BrushConverter]::new()

    $rootBorder = New-Object System.Windows.Controls.Border
    $rootBorder.CornerRadius    = [System.Windows.CornerRadius]::new(12)
    $rootBorder.BorderBrush     = $bc.ConvertFromString((Get-TC 'AccentBlue' '#5BA3FF'))
    $rootBorder.BorderThickness = [System.Windows.Thickness]::new(1)
    $rootBorder.Background      = $bc.ConvertFromString((Get-TC 'BgCardDark' '#131625'))

    $shadow = New-Object System.Windows.Media.Effects.DropShadowEffect
    $shadow.BlurRadius = 24; $shadow.ShadowDepth = 0; $shadow.Opacity = 0.5
    $shadow.Color = [System.Windows.Media.Colors]::Black
    $rootBorder.Effect = $shadow

    $sp = New-Object System.Windows.Controls.StackPanel
    $sp.Margin = [System.Windows.Thickness]::new(24,16,24,16)

    $lbl = New-Object System.Windows.Controls.TextBlock
    $lbl.FontFamily = [System.Windows.Media.FontFamily]::new("Segoe UI")
    $lbl.FontSize   = 12
    $lbl.FontWeight = [System.Windows.FontWeights]::SemiBold
    $lbl.Foreground = $bc.ConvertFromString((Get-TC 'TextPrimary' '#E8ECF4'))
    $lbl.Margin     = [System.Windows.Thickness]::new(0,0,0,8)
    $lbl.Text       = T 'SplashApplyingTheme' 'Aplicando tema...'

    $barBg = New-Object System.Windows.Controls.Border
    $barBg.Height          = 6
    $barBg.CornerRadius    = [System.Windows.CornerRadius]::new(3)
    $barBg.Background      = $bc.ConvertFromString((Get-TC 'BgInput' '#1A1E2F'))

    $barFill = New-Object System.Windows.Controls.Border
    $barFill.HorizontalAlignment = "Left"
    $barFill.Width        = 0
    $barFill.Height       = 6
    $barFill.CornerRadius = [System.Windows.CornerRadius]::new(3)
    $grad = New-Object System.Windows.Media.LinearGradientBrush
    $grad.StartPoint = [System.Windows.Point]::new(0,0)
    $grad.EndPoint   = [System.Windows.Point]::new(1,0)
    $grad.GradientStops.Add([System.Windows.Media.GradientStop]::new(
        [System.Windows.Media.ColorConverter]::ConvertFromString((Get-TC 'ProgressStart' '#5BA3FF')), 0))
    $grad.GradientStops.Add([System.Windows.Media.GradientStop]::new(
        [System.Windows.Media.ColorConverter]::ConvertFromString((Get-TC 'ProgressEnd' '#2EDFBF')), 1))
    $barFill.Background = $grad

    $barBg.Child = $barFill
    [void]$sp.Children.Add($lbl)
    [void]$sp.Children.Add($barBg)
    $rootBorder.Child = $sp
    $progWin.Content  = $rootBorder

    $progWin.Show()
    $progWin.Dispatcher.Invoke([action]{}, [System.Windows.Threading.DispatcherPriority]::Render)

    # ThemeEngine::ParseThemeFile lee un fichero INI pequeño -- operación síncrona <50ms.
    # No se necesita runspace de fondo ni animación de espera.
    $lbl.Text = T 'SplashLoadingTheme' 'Cargando tema...'
    $barFill.Width = [math]::Round(392 * 20 / 100)
    $progWin.Dispatcher.Invoke([action]{}, [System.Windows.Threading.DispatcherPriority]::Render)

    $newColors = @{}
    try {
        $colors = [ThemeEngine]::ParseThemeFile($themePath)
        foreach ($k in $colors.Keys) { $newColors[$k] = $colors[$k] }
    } catch {
        $progWin.Close()
        Show-ThemedDialog -Title (T 'DlgError' 'Error') `
            -Message "$((T "ThemeLoadError")): $($_.Exception.Message)" -Type "error"
        return
    }
    if ($newColors.Count -eq 0) { $progWin.Close(); return }

    # -- PASS 1: Update TB_ DynamicResource brushes (auto-propagates to main XAML) --
    $lbl.Text = T 'SplashApplyingTheme' 'Aplicando colores...'
    $barFill.Width = [math]::Round(392 * 35 / 100)
    $progWin.Dispatcher.Invoke([action]{}, [System.Windows.Threading.DispatcherPriority]::Render)

    # [OPT] Gradient map se construye aquí mismo -- elimina iteración duplicada en PASS 2
    $gradientMap = [System.Collections.Generic.Dictionary[string, [System.Windows.Media.Color]]]::new()
    $mapKeys = $script:ThemeColorMap.Keys
    $totalKeys = @($mapKeys).Count
    $idx = 0
    foreach ($hex in $mapKeys) {
        $info = $script:ThemeColorMap[$hex]
        $themeKey = $info[0]
        $dr = [int]$info[1]; $dg = [int]$info[2]; $db = [int]$info[3]

        if ($newColors.ContainsKey($themeKey)) {
            try {
                $baseColor = [System.Windows.Media.ColorConverter]::ConvertFromString($newColors[$themeKey])
                $newR = [math]::Max(0, [math]::Min(255, [int]$baseColor.R + $dr))
                $newG = [math]::Max(0, [math]::Min(255, [int]$baseColor.G + $dg))
                $newB = [math]::Max(0, [math]::Min(255, [int]$baseColor.B + $db))
                $finalColor = [System.Windows.Media.Color]::FromRgb($newR, $newG, $newB)
                $brush = [System.Windows.Media.SolidColorBrush]::new($finalColor)
                $window.Resources["TB_$hex"] = $brush
                # Propagar a Application.Current.Resources para que
                # cualquier Popup/ContextMenu del proceso lo resuelva
                try { [System.Windows.Application]::Current.Resources["TB_$hex"] = $brush } catch {}
                # Propagar a ventanas flotantes registradas (Tasks, Dedup, etc.)
                foreach ($fw in @($script:ThemedWindows)) {
                    try {
                        if ($null -ne $fw -and $fw.IsLoaded) {
                            $fw.Resources["TB_$hex"] = $brush
                        }
                    } catch {}
                }
                # [OPT] Build gradient map simultaneously -- reutiliza finalColor
                $gradientMap[("#{0:X2}{1:X2}{2:X2}" -f [int]("0x" + $hex.Substring(0,2)), [int]("0x" + $hex.Substring(2,2)), [int]("0x" + $hex.Substring(4,2)))] = $finalColor
            } catch {}
        }

        $idx++
        # [OPT] Dispatcher.Invoke cada 50 keys (era 20) -- reduce overhead de pump UI
        if ($idx % 50 -eq 0) {
            $pct = 35 + [math]::Round(($idx / $totalKeys) * 50)
            $barFill.Width = [math]::Round(392 * $pct / 100)
            $progWin.Dispatcher.Invoke([action]{}, [System.Windows.Threading.DispatcherPriority]::Render)
        }
    }

    # -- PASS 2: Apply gradient map pre-construido (loop eliminado -- computado en PASS 1) --
    $lbl.Text = T 'SplashApplyingTheme' 'Actualizando gradientes...'
    $barFill.Width = [math]::Round(392 * 88 / 100)
    $progWin.Dispatcher.Invoke([action]{}, [System.Windows.Threading.DispatcherPriority]::Render)
    [ThemeApplier]::ReplaceGradientColors($window, $gradientMap)

    $barFill.Width = [math]::Round(392 * 95 / 100)

    # -- PASS 3: Update script-level state --
    $barFill.Width = [math]::Round(392 * 95 / 100)
    $lbl.Text = T 'SplashApplyingTheme' 'Finalizando...'
    $progWin.Dispatcher.Invoke([action]{}, [System.Windows.Threading.DispatcherPriority]::Render)

    $script:CurrentTheme = $ThemeName
    $script:CurrentThemeColors = @{}
    foreach ($kv in $newColors.GetEnumerator()) {
        $script:CurrentThemeColors[$kv.Key] = $kv.Value
    }

    # Compute derived colors (status, etc.)
    Update-DynamicThemeValues

    # [TOAST] Sincronizar colores del tema con el motor de toast
    try { Sync-ToastTheme } catch {}

    # Update ComboBox themes
    try {
        $allCombos = [ThemeApplier]::GetVisualChildren($window) | Where-Object { $_ -is [System.Windows.Controls.ComboBox] }
        foreach ($cb in $allCombos) {
            try { Apply-ComboBoxDarkTheme -ComboBox $cb } catch {}
        }
    } catch {}

    # -- PASS 4: Repaint named buttons that use direct colors (not DynamicResource) --
    try { Apply-ButtonTheme } catch {}
    Apply-TitleBarTheme

    # -- PASS 5: Refresh tasks panel so IconBg/StatusBg recalculate with new theme --
    try { Refresh-TasksPanel } catch {}

    # -- PASS 6: Re-build system info (SMART badges) with new theme colors --
    try { Update-SystemInfo } catch {}

    # Save settings
    try { Save-Settings } catch {}

    # -- [PERF] Guardar caché de tema para arranques futuros --
    try { Save-ThemeCache -ThemeName $ThemeName -ThemePath $themePath -NewColors $newColors -GradientMap $gradientMap } catch {}

    $barFill.Width = 392
    $lbl.Text = T 'SplashThemeApplied' 'Tema aplicado!'
    # DispatcherTimer de un solo disparo -- evita Sleep en UI thread
    $closeTimer = New-Object System.Windows.Threading.DispatcherTimer
    $closeTimer.Interval = [TimeSpan]::FromMilliseconds(400)
    $capturedWin = $progWin
    $closeTimer.Add_Tick({
        $closeTimer.Stop()
        $capturedWin.Close()
    }.GetNewClosure())
    $closeTimer.Start()
}

# -----------------------------------------------------------------------------
# [OPTIONS] Ventana de Configuración -- Win11 Settings style
# -----------------------------------------------------------------------------

# =======================================================
# ?  Easter Egg: Atari Breakout
# =======================================================
function global:Show-BreakoutGame {
    Lazy-Load "Show-BreakoutGame"
    Show-BreakoutGame @args
}

function global:Show-OptionsWindow {
    param([string]$StartPage = "interface")
    Lazy-Load "Show-OptionsWindow"
    Show-OptionsWindow @PSBoundParameters
}


$script:SnapshotDir = Join-Path $script:AppDir "snapshots"
$script:LogsDir     = Join-Path $script:AppDir "logs"
$script:OutputDir   = Join-Path $script:AppDir "output"
if (-not (Test-Path $script:OutputDir)) { [System.IO.Directory]::CreateDirectory($script:OutputDir) | Out-Null }

# Referencias UI
$lbSnapshots            = (CFN $window "lbSnapshots")
$lbSnapshotDetail       = (CFN $window "lbSnapshotDetail")
$btnSnapshotSave        = (CFN $window "btnSnapshotSave")
$btnSnapshotCompare     = (CFN $window "btnSnapshotCompare")
$btnSnapshotDelete      = (CFN $window "btnSnapshotDelete")
$chkSnapshotSelectAll   = (CFN $window "chkSnapshotSelectAll")
$txtSnapshotSelCount    = (CFN $window "txtSnapshotSelCount")
$txtSnapshotName        = (CFN $window "txtSnapshotName")
$txtSnapshotDetailTitle = (CFN $window "txtSnapshotDetailTitle")
$txtSnapshotDetailMeta  = (CFN $window "txtSnapshotDetailMeta")
$txtSnapshotStatus      = (CFN $window "txtSnapshotStatus")

# -- Helpers de formato -------------------------------------------------------
# Format-Bytes removed -- use Format-Bytes directly

# -- Actualizar contador y estado de botones según checks ---------------------
function global:Update-SnapshotCheckState {
    $all     = @($lbSnapshots.ItemsSource)
    $checked = @($all | Where-Object { $_.IsChecked })
    $n       = $checked.Count
    $total   = $all.Count

    $txtSnapshotSelCount.Text = if ($n -eq 0) {
        if ($total -eq 0) { T "SnapNoSnapshots" "Sin snapshots guardados." } else { "$total $(T 'SnapAvailable' 'snapshot(s) disponibles.')" }
    } else {
        "$n $(T 'Of' 'de') $total $(T 'SnapSelected' 'seleccionados')"
    }

    $btnSnapshotDelete.IsEnabled  = ($n -gt 0)
    $hasCurrentScan = ($null -ne $script:AllScannedItems -and $script:AllScannedItems.Count -gt 0)
    $btnSnapshotCompare.IsEnabled = ($n -eq 2) -or ($n -eq 1 -and $hasCurrentScan)
    $btnSnapshotCompare.Content   = if ($n -eq 2) {
        ([char]::ConvertFromUtf32(0x1F4CA) + "  " + (T "BtnCompare" "Comparar") + " 2")
    } else {
        ([char]::ConvertFromUtf32(0x1F4CA) + "  " + (T "BtnCompare" "Comparar"))
    }
}

# -- Ventana de progreso con botón "Segundo plano" ----------------------------
# Usada por: Load-SnapshotList, Get-SnapshotEntriesAsync, guardar snapshot,
#            exportar CSV, exportar HTML.
# El botón "Poner en segundo plano" oculta la ventana pero NO detiene el proceso
# ni el DispatcherTimer -- al completarse se cierra sola igual.
function global:Show-ExportProgressDialog {
    param([string]$OperationTitle = (T "Processing" "Procesando..."))
    Lazy-Load "Show-ExportProgressDialog"
    Show-ExportProgressDialog @PSBoundParameters
}

# Helper interno: cierra la ventana de progreso (visible u oculta en 2do plano)
function global:Close-ProgressDialog($prog) {
    try { $prog.Window.Close() } catch {}
}

# Helper: actualiza el diálogo de progreso de forma null-safe
function global:Update-ProgressDialog($prog, [int]$pct, [string]$phase, [string]$count) {
    if ($null -eq $prog) { return }
    try {
        if ($null -ne $prog.Phase)   { $prog.Phase.Text    = $phase }
        if ($null -ne $prog.Pct)     { $prog.Pct.Text      = "$pct%" }
        if ($null -ne $prog.BarFill) { $prog.BarFill.Width = [math]::Round(408 * $pct / 100, 0) }
        if ($null -ne $prog.Count -and $count -ne '') { $prog.Count.Text = $count }
    } catch {}
}

# -- Estado compartido thread-safe (único, reutilizado por todos los runspaces) -
$script:ExportState = [hashtable]::Synchronized(@{
    Phase = ""; Progress = 0; ItemsDone = 0; ItemsTotal = 0
    Done = $false; Error = ""; Result = $null
})

# -- Cargar lista de snapshots en background ----------------------------------
function global:Load-SnapshotList {
    Lazy-Load "Load-SnapshotList"
    Load-SnapshotList @args
}

# -- Leer entries de un snapshot en background --------------------------------
# $OnComplete: scriptblock { param($entries) ... }   entries = List[hashtable]
# $OnError:   scriptblock { param($msg) ... }
function global:Get-SnapshotEntriesAsync {
    param(
            [string]$FilePath,
            [string]$OperationTitle = "",
            [scriptblock]$OnComplete,
            [scriptblock]$OnError
        )
    if ([string]::IsNullOrEmpty($OperationTitle)) { $OperationTitle = (T "SnapLoadingMsg") }
    Lazy-Load "Get-SnapshotEntriesAsync"
    Get-SnapshotEntriesAsync @PSBoundParameters
}

# -- Guardar snapshot del escaneo actual -------------------------------------
$btnSnapshotSave.Add_Click({
    if ($null -eq $script:AllScannedItems -or $script:AllScannedItems.Count -eq 0) { return }
    $label = $txtSnapshotName.Text.Trim()
    if ($label -eq '') { $label = "$(T 'SnapScanLabel' 'Escaneo') $(Get-Date -Format 'dd/MM/yyyy HH:mm')" }

    $btnSnapshotSave.IsEnabled = $false
    $txtSnapshotStatus.Text    = "$([char]0x23F3) $((T "SnapSavingMsg"))"
    Register-Task -Id "snap-save" -Name "$(T 'SnapSaving' 'Guardando snapshot'): $label" -Icon "$([char]::ConvertFromUtf32(0x1F4BE))" -IconBg (Get-TC 'BgStatusOk' '#1A2A1E') | Out-Null

    $script:ExportState.Phase     = (T "PhasePreparingShort" "Preparando..."); $script:ExportState.Progress = 0
    $script:ExportState.ItemsDone = 0; $script:ExportState.ItemsTotal = $script:AllScannedItems.Count
    $script:ExportState.Done      = $false; $script:ExportState.Error = ""; $script:ExportState.Result = $null

    # -- [FIFO-01] FIFO streaming save via ConcurrentQueue --------------------
    $saveState = [hashtable]::Synchronized(@{
        Queue    = [System.Collections.Concurrent.ConcurrentQueue[object]]::new()
        FeedDone = $false          # UI señaliza que terminó de encolar
        Total    = $script:AllScannedItems.Count
    })

    $saveLabel = $label
    $saveRoot  = $txtDiskScanPath.Text
    $saveDir   = $script:SnapshotDir

Set-SplashProgress 96 (T "SplashLoading96" "Gestión de snapshots...")

    # Script background: drena Queue con StreamWriter JSON manual -- sin dependencia Newtonsoft
    # [i18n] Pre-resolve T() for bgSave background runspace
    $_bgS = @{
        PreparingDir   = (T 'PhasePreparingDir' 'Preparando directorio...')
        WritingEntries = (T 'PhaseWritingEntries' 'Escribiendo entradas...')
        Writing        = (T 'PhaseWriting' 'Escribiendo...')
        Completed      = (T 'PhaseCompleted' 'Completado')
    }

    $bgSave = {
        param($State, $ExportState, $Label, $RootPath, $SnapshotDir, $_bgS)
        $fs = $null; $sw = $null
        try {
            $ExportState.Phase = $_bgS.PreparingDir; $ExportState.Progress = 5
            if (-not (Test-Path $SnapshotDir)) {
                [System.IO.Directory]::CreateDirectory($SnapshotDir) | Out-Null
            }
            $fp = [System.IO.Path]::Combine($SnapshotDir, "snapshot_$(Get-Date -Format 'yyyyMMdd_HHmmss').json")

            # [FIFO] Abrir StreamWriter con buffer 64KB -- escribe JSON manualmente token a token
            $fs = [System.IO.File]::Open($fp, [System.IO.FileMode]::Create,
                  [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
            $sw = [System.IO.StreamWriter]::new($fs, [System.Text.Encoding]::UTF8, 65536)

            # Helper inline: escapa solo los caracteres JSON obligatorios en strings de rutas
            # Rutas Windows raramente tienen \n/\r/\t pero sí pueden tener comillas y backslashes.
            # El backslash ya está duplicado en FullPath (ej. C:\\Users\\...) dentro del JSON.

            # Cabecera del objeto raíz
            $date = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
            $lbl  = $Label   -replace '\\',  '\\\\' -replace '"', '\"'
            $root = $RootPath -replace '\\', '\\\\' -replace '"', '\"'
            $sw.WriteLine('{')
            $sw.WriteLine("  `"Label`": `"$lbl`",")
            $sw.WriteLine("  `"Date`": `"$date`",")
            $sw.WriteLine("  `"RootPath`": `"$root`",")
            $sw.WriteLine('  "Entries": [')

            $ExportState.Phase = $_bgS.WritingEntries; $ExportState.Progress = 10
            $total   = $State.Total
            $written = 0
            $item    = $null
            $first   = $true

            # [FIFO] Drenar queue FIFO hasta que el productor señalice FeedDone y la queue quede vacía
            while (-not ($State.FeedDone -and $State.Queue.IsEmpty)) {
                while ($State.Queue.TryDequeue([ref]$item)) {
                    # Separador entre objetos JSON (coma antes de cada entry excepto el primero)
                    if (-not $first) { $sw.Write(',') } else { $first = $false }

                    # Escapar strings -- comillas dobles y backslashes para JSON válido
                    $fp2 = ([string]$item.FP) -replace '\\', '\\\\' -replace '"', '\"'
                    $nm  = ([string]$item.N)  -replace '\\', '\\\\' -replace '"', '\"'
                    $fc  = ([string]$item.FC) -replace '\\', '\\\\' -replace '"', '\"'
                    $sz  = [long]$item.SZ
                    $d   = [int]$item.D

                    # Escribir objeto entry directamente al stream -- una sola llamada Write por entry
                    $sw.WriteLine("{`"FullPath`":`"$fp2`",`"Name`":`"$nm`",`"SizeBytes`":$sz,`"FileCount`":`"$fc`",`"Depth`":$d}")
                    $item = $null   # liberar referencia inmediatamente -- FIFO consume y descarta
                    $written++
                    if ($written % 500 -eq 0) {
                        $sw.Flush()   # flush periódico al disco -- evita buffers grandes
                        $ExportState.ItemsDone = $written
                        $ExportState.Progress  = if ($total -gt 0) { [int](10 + ($written / $total) * 85) } else { 50 }
                        $ExportState.Phase     = "$($_bgS.Writing) ($written / $total)"
                    }
                }
                if (-not $State.FeedDone) { [System.Threading.Thread]::Sleep(5) }
            }

            # Cerrar array y objeto raíz
            $sw.WriteLine('  ]')
            $sw.WriteLine('}')
            $sw.Flush()

            $ExportState.Result = $Label; $ExportState.Progress = 100
            $ExportState.Phase  = $_bgS.Completed; $ExportState.ItemsDone = $written
            $ExportState.Done   = $true
        } catch {
            $ExportState.Error = $_.Exception.Message; $ExportState.Done = $true
        } finally {
            # [FIFO] Liberar recursos en orden -- sin importar si hubo error
            if ($null -ne $sw) { try { $sw.Close() } catch {} }
            if ($null -ne $fs) { try { $fs.Close(); $fs.Dispose() } catch {} }
        }
    }

    # [FIFO] Lanzar background ANTES de encolar -- así drena en paralelo
    $rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
    $rs.ApartmentState = "MTA"; $rs.Open()
    $ps = [System.Management.Automation.PowerShell]::Create(); $ps.Runspace = $rs
    [void]$ps.AddScript($bgSave)
    [void]$ps.AddParameter("State",       $saveState)
    [void]$ps.AddParameter("ExportState", $script:ExportState)
    [void]$ps.AddParameter("Label",       $saveLabel)
    [void]$ps.AddParameter("RootPath",    $saveRoot)
    [void]$ps.AddParameter("SnapshotDir", $saveDir)
    [void]$ps.AddParameter("_bgS",        $_bgS)
    $async = $ps.BeginInvoke()

    # [FIFO] Producir: encolar AllScannedItems item a item sin construir lista intermedia
    # El background ya está corriendo y drenando en paralelo -> RAM pico ? lote en tránsito
    foreach ($item in $script:AllScannedItems) {
        if ($item.SizeBytes -ge 0) {
            $saveState.Queue.Enqueue(@{
                FP = $item.FullPath; N = $item.DisplayName
                SZ = $item.SizeBytes; FC = $item.FileCount; D = $item.Depth
            })
        }
    }
    $saveState.FeedDone = $true   # señalizar al background que no hay más items

    $prog = Show-ExportProgressDialog
    if ($null -ne $prog.Title) { $prog.Title.Text = (T "SnapSavingMsg") }
    $prog.Window.Show()

    if ($null -ne $script:_saveTimer) { try { $script:_saveTimer.Stop() } catch {} }
    $t = New-Object System.Windows.Threading.DispatcherTimer
    $t.Interval = [TimeSpan]::FromMilliseconds(200)
    $script:_saveTimer = $t; $script:_saveProg  = $prog
    $script:_savePs    = $ps; $script:_saveRs   = $rs; $script:_saveAsync = $async

    $t.Add_Tick({
        $st  = $script:ExportState; $pg = $script:_saveProg; $pct = [int]$st.Progress
        $cntStr = if ($st.ItemsTotal -gt 0) { "$($st.ItemsDone) / $($st.ItemsTotal) $(T 'SnapEntries' 'entradas')" } else { "" }
        Update-ProgressDialog $pg $pct $st.Phase $cntStr
        Update-Task -Id "snap-save" -Pct $pct -Detail $cntStr
        if ($st.Done) {
            $script:_saveTimer.Stop()
            Close-ProgressDialog $script:_saveProg
            try { $script:_savePs.EndInvoke($script:_saveAsync) | Out-Null } catch {}
            # [FIFO] Liberar runspace y forzar GC -- el proceso termina limpio
            try { $script:_savePs.Dispose(); $script:_saveRs.Close(); $script:_saveRs.Dispose() } catch {}
            [System.GC]::Collect(2, [System.GCCollectionMode]::Forced, $true, $true)
            [System.GC]::WaitForPendingFinalizers()
            try {
                [System.Runtime.GCSettings]::LargeObjectHeapCompactionMode = `
                    [System.Runtime.GCLargeObjectHeapCompactionMode]::CompactOnce
                [System.GC]::Collect()
            } catch {}
            $btnSnapshotSave.IsEnabled = $true
            if ($st.Error -ne "") {
                $txtSnapshotStatus.Text = "$((T "SnapSaveError")): $($st.Error)"
                Complete-Task -Id "snap-save" -IsError -Detail $st.Error
            } else {
                $snapFile = if ($st.Result) { [string]$st.Result } else { "" }
                $snapLeaf = if ($snapFile) { Split-Path $snapFile -Leaf } else { "snapshot" }
                $txtSnapshotStatus.Text = "$([char]0x2705) $((T "SnapSavedMsg")): $snapLeaf"
                Complete-Task -Id "snap-save" -Detail $snapLeaf
                Show-Toast -Title (T "ToastSnapSavedTitle") -Message "$((T 'ToastSnapSavedMsg')) $snapLeaf" -Type "Success"
                Load-SnapshotList
            }
        }
    })
    $t.Start()
})

# -- CheckBox "Seleccionar todo" -----------------------------------------------
$chkSnapshotSelectAll.Add_Checked({
    foreach ($item in @($lbSnapshots.ItemsSource)) { $item.IsChecked = $true }
    $lbSnapshots.Items.Refresh(); Update-SnapshotCheckState
})
$chkSnapshotSelectAll.Add_Unchecked({
    foreach ($item in @($lbSnapshots.ItemsSource)) { $item.IsChecked = $false }
    $lbSnapshots.Items.Refresh(); Update-SnapshotCheckState
})

# -- Evento burbuja CheckBox dentro del ListBox -------------------------------
[System.Windows.RoutedEventHandler]$script:snapCheckHandler = { param($s,$e); Update-SnapshotCheckState }
$lbSnapshots.AddHandler([System.Windows.Controls.CheckBox]::CheckedEvent,   $script:snapCheckHandler)
$lbSnapshots.AddHandler([System.Windows.Controls.CheckBox]::UncheckedEvent, $script:snapCheckHandler)

# -- Selección de snapshot -> cargar entries en background ---------------------
$lbSnapshots.Add_SelectionChanged({
    $sel = $lbSnapshots.SelectedItem
    if ($null -eq $sel) { Update-SnapshotCheckState; return }

    $txtSnapshotDetailTitle.Text = $sel.Label
    $txtSnapshotDetailMeta.Text  = "$($sel.DateStr)  *  $($sel.RootPath)"
    $txtSnapshotStatus.Text      = "$([char]0x23F3) $((T "SnapLoadingEntries"))"
    $lbSnapshotDetail.ItemsSource = $null

    $selLabel = $sel.Label

    Get-SnapshotEntriesAsync -FilePath $sel.FilePath `
        -OperationTitle "$(T 'SnapLoading' 'Cargando snapshot') -- $($sel.Label)" `
        -OnComplete {
            param($entries)
            $detailItems = [System.Collections.Generic.List[object]]::new()
            foreach ($e in ($entries | Sort-Object { [long]$_.SizeBytes } -Descending)) {
                $sz = [long]$e.SizeBytes
                $detailItems.Add([PSCustomObject]@{
                    FolderName = $e.Name;    FullPath = $e.FullPath
                    SizeStr    = Format-Bytes $sz
                    SizeColor  = if ($sz -ge 10GB) { "#FF6B84" } elseif ($sz -ge 1GB) { "#FFB547" } `
                                 elseif ($sz -ge 100MB) { "#5BA3FF" } else { "#B0BACC" }
                    DeltaStr   = ""; DeltaColor = "#7880A0"
                })
            }
            $lbSnapshotDetail.ItemsSource = $detailItems
            $txtSnapshotStatus.Text       = "$($detailItems.Count) $((T "SnapEntriesInSnapshot"))"
            Update-SnapshotCheckState
        } `
        -OnError {
            param($msg)
            $txtSnapshotStatus.Text = "$((T "SnapLoadError")): $msg"
            Update-SnapshotCheckState
        }
})

# -- Comparar snapshots en background -----------------------------------------
# Patrón: cargar los JSON necesarios con Get-SnapshotEntriesAsync en cadena,
# luego realizar el cruce de datos en el callback (ya en el hilo UI, rápido).
$btnSnapshotCompare.Add_Click({
    $checked = @($lbSnapshots.ItemsSource | Where-Object { $_.IsChecked })

    if ($checked.Count -eq 2) {
        # -- Modo A vs B -------------------------------------------------------
        $snapA = $checked[0]; $snapB = $checked[1]
        $txtSnapshotStatus.Text      = "$([char]0x23F3) $((T "SnapLoadingAMsg"))"
        $txtSnapshotDetailTitle.Text = "$((T "SnapComparing")): $($snapA.Label)  vs  $($snapB.Label)"
        $txtSnapshotDetailMeta.Text  = "$($snapA.DateStr)  vs  $($snapB.DateStr)"
        $lbSnapshotDetail.ItemsSource = $null

        $script:_cmpSnapA = $snapA; $script:_cmpSnapB = $snapB

        # Primero cargamos A; en su callback cargamos B; en el de B cruzamos datos
        Get-SnapshotEntriesAsync -FilePath $snapA.FilePath `
            -OperationTitle "$(T 'BtnCompare' 'Comparar') -- $(T 'SnapLoadingShort' 'cargando') $($snapA.Label)" `
            -OnComplete {
                param($entriesA)
                $script:_cmpEntriesA = $entriesA
                $txtSnapshotStatus.Text = "$([char]0x23F3) $((T "SnapLoadingBMsg"))"

                Get-SnapshotEntriesAsync -FilePath $script:_cmpSnapB.FilePath `
                    -OperationTitle "$(T 'BtnCompare' 'Comparar') -- $(T 'SnapLoadingShort' 'cargando') $($script:_cmpSnapB.Label)" `
                    -OnComplete {
                        param($entriesB)
                        # Cruce de datos (rápido, en hilo UI)
                        $eA = $script:_cmpEntriesA
                        $mapB = [System.Collections.Generic.Dictionary[string,long]]::new(
                            [System.StringComparer]::OrdinalIgnoreCase)
                        foreach ($e in $entriesB) { $mapB[$e.FullPath] = [long]$e.SizeBytes }
                        $setA = [System.Collections.Generic.HashSet[string]]::new(
                            [System.StringComparer]::OrdinalIgnoreCase)
                        foreach ($e in $eA) { [void]$setA.Add($e.FullPath) }

                        $detailItems = [System.Collections.Generic.List[object]]::new()
                        foreach ($e in ($eA | Sort-Object { [long]$_.SizeBytes } -Descending)) {
                            $old = [long]$e.SizeBytes
                            $new = if ($mapB.ContainsKey($e.FullPath)) { $mapB[$e.FullPath] } else { -1L }
                            $d   = if ($new -ge 0) { $new - $old } else { $null }
                            $ds  = if ($null -eq $d) { T "SnapDeleted" "eliminada" } elseif ($d -eq 0) { T "SnapNoChange" "sin cambio" } `
                                   elseif ($d -gt 0) { "+$(Format-Bytes $d)" } else { "-$(Format-Bytes ([Math]::Abs($d)))" }
                            $dc  = if ($null -eq $d -or $d -eq 0) { "#7880A0" } elseif ($d -gt 0) { "#FF6B84" } else { "#4AE896" }
                            $sz  = if ($new -ge 0) { $new } else { $old }
                            $detailItems.Add([PSCustomObject]@{
                                FolderName = $e.Name; FullPath = $e.FullPath
                                SizeStr    = Format-Bytes $sz
                                SizeColor  = if ($sz -ge 10GB) { "#FF6B84" } elseif ($sz -ge 1GB) { "#FFB547" } `
                                             elseif ($sz -ge 100MB) { "#5BA3FF" } else { "#B0BACC" }
                                DeltaStr   = $ds; DeltaColor = $dc
                            })
                        }
                        foreach ($e in $entriesB) {
                            if (-not $setA.Contains($e.FullPath)) {
                                $detailItems.Add([PSCustomObject]@{
                                    FolderName = $e.Name; FullPath = $e.FullPath
                                    SizeStr    = Format-Bytes ([long]$e.SizeBytes)
                                    SizeColor  = "#4AE896"; DeltaStr = "nueva en B"; DeltaColor = "#4AE896"
                                })
                            }
                        }
                        $lbSnapshotDetail.ItemsSource = $detailItems
                        $txtSnapshotStatus.Text = "$((T "SnapCompDone")) -- $($detailItems.Count) $((T "DiskFolders"))."
                    } `
                    -OnError { param($msg); $txtSnapshotStatus.Text = "$((T "SnapLoadError")) B: $msg" }
            } `
            -OnError { param($msg); $txtSnapshotStatus.Text = "$((T "SnapLoadError")) A: $msg" }

    } elseif ($checked.Count -eq 1 -and $null -ne $script:AllScannedItems -and $script:AllScannedItems.Count -gt 0) {
        # -- Modo snapshot vs escaneo actual -----------------------------------
        $sel = $checked[0]
        $txtSnapshotStatus.Text      = "$([char]0x23F3) $((T "SnapLoadingCompareMsg"))"
        $txtSnapshotDetailTitle.Text = "$((T "SnapComparing")): $($sel.Label)  ->  $((T "SnapCompareVsCurrent"))"
        $txtSnapshotDetailMeta.Text  = "$($sel.DateStr)  vs  $(Get-Date -Format 'dd/MM/yyyy HH:mm')"
        $lbSnapshotDetail.ItemsSource = $null

        Get-SnapshotEntriesAsync -FilePath $sel.FilePath `
            -OperationTitle "$(T 'BtnCompare' 'Comparar') -- $(T 'SnapLoadingShort' 'cargando') $($sel.Label)" `
            -OnComplete {
                param($snapEntries)
                $currentMap = [System.Collections.Generic.Dictionary[string,long]]::new(
                    [System.StringComparer]::OrdinalIgnoreCase)
                foreach ($item in $script:AllScannedItems) {
                    if ($item.SizeBytes -ge 0) { $currentMap[$item.FullPath] = [long]$item.SizeBytes }
                }
                $snapSet = [System.Collections.Generic.HashSet[string]]::new(
                    [System.StringComparer]::OrdinalIgnoreCase)
                foreach ($e in $snapEntries) { [void]$snapSet.Add($e.FullPath) }

                $detailItems = [System.Collections.Generic.List[object]]::new()
                foreach ($e in ($snapEntries | Sort-Object { [long]$_.SizeBytes } -Descending)) {
                    $old = [long]$e.SizeBytes
                    $new = if ($currentMap.ContainsKey($e.FullPath)) { $currentMap[$e.FullPath] } else { -1L }
                    $d   = if ($new -ge 0) { $new - $old } else { $null }
                    $ds  = if ($null -eq $d) { T "SnapDeleted" "eliminada" } elseif ($d -eq 0) { T "SnapNoChange" "sin cambio" } `
                           elseif ($d -gt 0) { "+$(Format-Bytes $d)" } else { "-$(Format-Bytes ([Math]::Abs($d)))" }
                    $dc  = if ($null -eq $d -or $d -eq 0) { "#7880A0" } elseif ($d -gt 0) { "#FF6B84" } else { "#4AE896" }
                    $sz  = if ($new -ge 0) { $new } else { $old }
                    $detailItems.Add([PSCustomObject]@{
                        FolderName = $e.Name; FullPath = $e.FullPath
                        SizeStr    = Format-Bytes $sz
                        SizeColor  = if ($sz -ge 10GB) { "#FF6B84" } elseif ($sz -ge 1GB) { "#FFB547" } `
                                     elseif ($sz -ge 100MB) { "#5BA3FF" } else { "#B0BACC" }
                        DeltaStr   = $ds; DeltaColor = $dc
                    })
                }
                foreach ($item in $script:AllScannedItems) {
                    if ($item.SizeBytes -lt 0) { continue }
                    if (-not $snapSet.Contains($item.FullPath)) {
                        $detailItems.Add([PSCustomObject]@{
                            FolderName = $item.DisplayName; FullPath = $item.FullPath
                            SizeStr    = Format-Bytes $item.SizeBytes
                            SizeColor  = "#4AE896"; DeltaStr = "nueva"; DeltaColor = "#4AE896"
                        })
                    }
                }
                $lbSnapshotDetail.ItemsSource = $detailItems
                $txtSnapshotStatus.Text = "$((T "SnapCompDone")) -- $($detailItems.Count) $((T "DiskFolders"))."
            } `
            -OnError { param($msg); $txtSnapshotStatus.Text = "$((T "SnapCompareError")): $msg" }
    }
})

# -- Eliminar snapshots marcados (en lote) ------------------------------------
$btnSnapshotDelete.Add_Click({
    $checked = @($lbSnapshots.ItemsSource | Where-Object { $_.IsChecked })
    if ($checked.Count -eq 0) { return }
    $nombres = ($checked | ForEach-Object { $_.Label }) -join "`n  - "
    $msg = if ($checked.Count -eq 1) { "$(T 'SnapDeleteOne' 'Eliminar el snapshot'):`n  - $nombres" } `
           else { "$(T 'SnapDeleteMulti' 'Eliminar') $($checked.Count) snapshots:`n  - $nombres" }
    $confirm = Show-ThemedDialog -Title ((T "DlgConfirmDeleteTitle")) -Message $msg -Type "warning" -Buttons "YesNo"
    if ($confirm) {
        $errors = 0
        foreach ($snap in $checked) {
            try { Remove-Item -Path $snap.FilePath -Force -ErrorAction Stop } catch { $errors++ }
        }
        Load-SnapshotList
        if ($errors -gt 0) { $txtSnapshotStatus.Text = "$((T "SnapDeletedWithErrors")) $errors" }
    }
})

# -- Cargar lista la primera vez que se activa la pestaña Historial (run-once) --
$script:tabMain = (CFN $window "tabMain")
$tabHistorial    = (CFN $window "tabHistorial")
$tabDiskExplorer = (CFN $window "tabDiskExplorer")
$script:SnapshotListLoaded = $false

# -- [LAZY] Flags de carga de tabs + handler lazy ------------------------------
$script:_lazyTabLoaded = @{}

$script:tabMain.Add_SelectionChanged({
    param($s, $e)
    # Solo reaccionar al propio TabControl principal, no a controles hijos
    if ($e.Source -ne $script:tabMain) { return }

    $selectedTab = $script:tabMain.SelectedItem

    # -- TAB_HISTORIAL: cargar funciones de snapshot/diagnóstico bajo demanda --
    if ($selectedTab -eq $tabHistorial) {
        if (-not $script:_lazyTabLoaded["HISTORIAL"]) {
            $script:_lazyTabLoaded["HISTORIAL"] = $true
            if (([System.Management.Automation.PSTypeName]"SysOpt.LazyLoader").Type -and
                -not [SysOpt.LazyLoader]::IsPhaseLoaded("TAB_HISTORIAL")) {
                # Mini-spinner
                if ($script:_borderTabSpinner) {
                    $script:_txtTabSpinner.Text = (T "LazyLoadingTab" "Cargando pestaña...")
                    $script:_borderTabSpinner.Visibility = "Visible"
                }
                try {
                    Invoke-Expression ([SysOpt.LazyLoader]::ExtractPhase("TAB_HISTORIAL"))
                    [SysOpt.LazyLoader]::MarkPhaseLoaded("TAB_HISTORIAL")
                    Write-Log "[LAZY] TAB_HISTORIAL loaded (1352 lines on-demand)" -Level DBG -NoUI
                } catch {
                    Write-Log "[LAZY] TAB_HISTORIAL error: $_" -Level WARN -NoUI
                }
                if ($script:_borderTabSpinner) { $script:_borderTabSpinner.Visibility = "Collapsed" }
            }
            if (-not $script:SnapshotListLoaded) {
                $script:SnapshotListLoaded = $true
                Load-SnapshotList
            }
        }
    }

    # -- TAB_DISCO: cargar funciones de FolderScanner y DiskScan bajo demanda --
    if ($selectedTab -eq $tabDiskExplorer) {
        if (-not $script:_lazyTabLoaded["DISCO"]) {
            $script:_lazyTabLoaded["DISCO"] = $true
            if (([System.Management.Automation.PSTypeName]"SysOpt.LazyLoader").Type -and
                -not [SysOpt.LazyLoader]::IsPhaseLoaded("TAB_DISCO")) {
                if ($script:_borderTabSpinner) {
                    $script:_txtTabSpinner.Text = (T "LazyLoadingTab" "Cargando pestaña...")
                    $script:_borderTabSpinner.Visibility = "Visible"
                }
                try {
                    Invoke-Expression ([SysOpt.LazyLoader]::ExtractPhase("TAB_DISCO"))
                    [SysOpt.LazyLoader]::MarkPhaseLoaded("TAB_DISCO")
                    Write-Log "[LAZY] TAB_DISCO loaded (910 lines on-demand)" -Level DBG -NoUI
                } catch {
                    Write-Log "[LAZY] TAB_DISCO error: $_" -Level WARN -NoUI
                }
                if ($script:_borderTabSpinner) { $script:_borderTabSpinner.Visibility = "Collapsed" }
            }
        }
    }

    $e.Handled = $true
})

# -- Ventana flotante de Tareas (estilo emergente, como About) ----------------
$script:TasksWin       = $null   # referencia a la ventana si está abierta
$lbTasks             = $null    # se asignan al abrir la ventana
$txtTasksSubtitle    = $null
$txtTasksStatus      = $null
$btnTasksClearDone   = $null

function global:Show-TasksWindow {
    Lazy-Load "Show-TasksWindow"
    Show-TasksWindow @args
}

# Mapas de presentación por estado
$script:TaskStatusMap = @{
    running   = @{ Text = T 'StatusRunning' (T 'TaskInProgress' 'En curso');   Bg = (Get-TC 'BgStatusInfo' '#1A2F4A'); Fg = (Get-TC 'FgStatusInfo' '#5BA3FF') }
    paused    = @{ Text = T 'StatusPaused'  'Pausada';    Bg = (Get-TC 'BgStatusWarn' '#2A2010');  Fg = (Get-TC 'FgStatusWarn' '#FFB547') }
    done      = @{ Text = T 'StatusDone' 'Completada';    Bg = (Get-TC 'BgStatusOk' '#182A1E');    Fg = (Get-TC 'FgStatusOk' '#4AE896') }
    error     = @{ Text = T 'StatusError' 'Error';        Bg = (Get-TC 'BgStatusErr' '#2A1018');   Fg = (Get-TC 'FgStatusErr' '#FF6B84') }
    cancelled = @{ Text = T 'StatusCancel' 'Cancelada';   Bg = (Get-TC 'BgStatusWarn' '#2A2010');  Fg = (Get-TC 'FgStatusWarn' '#FFB547') }
}
$script:TaskIconMap = @{
    running   = "$([char]0x23F3)"
    paused    = "$([char]0x23F8)"
    done      = "$([char]0x2705)"
    error     = "$([char]0x274C)"
    cancelled = "$([char]0x26D4)"
}

# -- Helpers de control de tareas invocados desde el menú contextual -----------
function global:Cancel-Task([string]$Id) {
    $t = $null
    if (-not $script:TaskPool.TryGetValue($Id, [ref]$t) -or $null -eq $t) { return }
    if ($t.Status -notin @("running","paused")) { return }
    # Si estaba pausada, reanudar antes de cancelar (evita runspace colgado)
    if ($t.Paused -and $null -ne $t.ResumeFn) {
        try { & $t.ResumeFn } catch {}
        $t.Paused = $false
    }
    if ($null -ne $t.CancelFn) {
        try { & $t.CancelFn } catch {}
    }
    $t.Status  = "cancelled"
    $t.EndTime = [datetime]::Now
    Write-Log "[TASK] Cancelada por el usuario: $($t.Name)" -Level "WARN" -NoUI
    Refresh-TasksPanel
}

function global:Pause-Task([string]$Id) {
    $t = $null
    if (-not $script:TaskPool.TryGetValue($Id, [ref]$t) -or $null -eq $t) { return }
    if ($t.Status -ne "running" -or $null -eq $t.PauseFn) { return }
    try { & $t.PauseFn } catch {}
    $t.Paused = $true
    $t.Status = "paused"
    Write-Log "[TASK] Pausada por el usuario: $($t.Name)" -Level "INFO" -NoUI
    Refresh-TasksPanel
}

function global:Resume-Task([string]$Id) {
    $t = $null
    if (-not $script:TaskPool.TryGetValue($Id, [ref]$t) -or $null -eq $t) { return }
    if ($t.Status -ne "paused" -or $null -eq $t.ResumeFn) { return }
    try { & $t.ResumeFn } catch {}
    $t.Paused = $false
    $t.Status = "running"
    Write-Log "[TASK] Reanudada por el usuario: $($t.Name)" -Level "INFO" -NoUI
    Refresh-TasksPanel
}

function global:Refresh-TasksPanel {
    $bc_ = [System.Windows.Media.BrushConverter]::new()
    $lbTasks          = $script:lbTasksWin
    $txtTasksSubtitle = $script:txtTasksSubtitleWin
    $txtTasksStatus   = $script:txtTasksStatusWin
    if ($null -eq $lbTasks) { return }

    $tasks  = @($script:TaskPool.Values | Where-Object { $null -ne $_ } | Sort-Object { $_.StartTime } -Descending)
    $active = @($tasks | Where-Object { $_.Status -eq "running" })
    $done   = @($tasks | Where-Object { $_.Status -ne "running" })

    # Calcular ancho real de la barra (dinámico: se adapta al tamaño de ventana)
    $barMaxPx = 280   # fallback seguro
    try {
        $aw = $lbTasks.ActualWidth
        if ($aw -gt 100) {
            # Restar: icono(46) + badge(110) + scrollbar(17) + padding(28) = ~201px
            $barMaxPx = [math]::Max(100, $aw - 201)
        }
    } catch {}

    $items = [System.Collections.Generic.List[object]]::new()
    foreach ($t in $tasks) {
        $sm      = $script:TaskStatusMap[$t.Status]
        $elapsed = if ($t.EndTime) {
            $d = $t.EndTime - $t.StartTime
            if ($d.TotalHours -ge 1)   { $d.ToString("h\:mm\:ss") }
            elseif ($d.TotalMinutes -ge 1) { $d.ToString("m\:ss") + " min" }
            else { "$([int]$d.TotalSeconds) s" }
        } else {
            $d = [datetime]::Now - $t.StartTime
            if ($d.TotalHours -ge 1)   { $d.ToString("h\:mm\:ss") }
            elseif ($d.TotalMinutes -ge 1) { $d.ToString("m\:ss") + " min" }  # [FIX-BUG6] igual que EndTime
            else { "$([int]$d.TotalSeconds) s" }
        }

        $pct      = [math]::Min(100, [math]::Max(0, [int]$t.Pct))
        $pctColorHex = switch ($t.Status) {
            "done"      { Get-TC 'AccentGreen' '#4AE896' }
            "error"     { Get-TC 'AccentRed' '#FF6B84' }
            "cancelled" { Get-TC 'AccentAmber' '#FFB547' }
            default     { Get-TC 'AccentBlue' '#5BA3FF' }
        }
        $pctColor = try { $bc_.ConvertFromString($pctColorHex) } catch { $bc_.ConvertFromString((Get-TC 'AccentBlue' '#5BA3FF')) }
        $barColor = $pctColor
        $iconBgHex = switch ($t.Status) {
            "done"      { Get-TC 'BgStatusOk' '#182A1E' }
            "error"     { Get-TC 'BgStatusErr' '#2A1018' }
            "cancelled" { Get-TC 'BgStatusWarn' '#2A2010' }
            default     { $t.IconBg }
        }
        $iconBg = try { $bc_.ConvertFromString($iconBgHex) } catch { $bc_.ConvertFromString((Get-TC 'BgInput' '#1A2040')) }
        $icon = if ($t.Status -eq "running") { $t.Icon } else { $script:TaskIconMap[$t.Status] }

        $barFill  = [math]::Max(1, $pct)   # mínimo 1* para evitar columna cero
        $barEmpty = [math]::Max(1, 100 - $pct)
        # BarPx: ancho en px proporcional al porcentaje (dinámico según ancho real)
        $barPx = [double]($pct / 100.0 * $barMaxPx)

        $statusBg = try { $bc_.ConvertFromString($sm.Bg) } catch { $bc_.ConvertFromString((Get-TC 'BgStatusInfo' '#152F4A')) }
        $statusFg = try { $bc_.ConvertFromString($sm.Fg) } catch { $bc_.ConvertFromString((Get-TC 'AccentBlue' '#5BA3FF')) }
        $items.Add([PSCustomObject]@{
            Id          = $t.Id
            Name        = $t.Name
            Icon        = $icon
            IconBg      = $iconBg
            StatusText  = $sm.Text
            StatusBg    = $statusBg
            StatusFg    = $statusFg
            Pct         = $pct
            PctStr      = if ($t.Status -eq "running") { "$pct%" } elseif ($t.Status -eq "done") { "100%" } else { "" }
            PctColor    = $pctColor
            BarStarFill  = "$barFill*"
            BarStarEmpty = "$barEmpty*"
            BarPx       = $barPx
            BarColor    = $barColor
            Detail      = [string]$t.Detail
            Elapsed     = $elapsed
            # -- Capacidades para el menú contextual --------------------------
            CanCancel   = ($t.Status -in @("running","paused")) -and ($null -ne $t.CancelFn)
            CanPause    = ($t.Status -eq "running")             -and ($null -ne $t.PauseFn)
            CanResume   = ($t.Status -eq "paused")              -and ($null -ne $t.ResumeFn)
        })
    }

    $lbTasks.ItemsSource = $items
    $nActive = $active.Count
    $nDone   = $done.Count

    if ($null -ne $txtTasksSubtitle) {
        $txtTasksSubtitle.Text = if ($nActive -eq 0) {
            if ($nDone -eq 0) { T "TaskNone" "Sin tareas" } else { "$nDone $(T 'TaskCompleted' 'tarea(s) completada(s)')" }
        } else {
            "$nActive $(T 'TaskInProgress' 'tarea(s) en curso') * $nDone $(T 'TaskCompletedShort' 'completada(s)')"
        }
    }
    if ($null -ne $txtTasksStatus) {
        $txtTasksStatus.Text = "Pool: $nActive $((T "TaskActiveSummary")) * $nDone $((T "TaskDoneSummary"))"
    }
}

# Timer de refresco cada 1 s (solo actualiza si la ventana está abierta)
$script:TaskTimer = New-Object System.Windows.Threading.DispatcherTimer
$script:TaskTimer.Interval = [TimeSpan]::FromSeconds(1)
$script:TaskTimer.Add_Tick({
    if ($script:AppClosing) { $script:TaskTimer.Stop(); return }
    Refresh-TasksPanel
})
$script:TaskTimer.Start()

# -----------------------------------------------------------------------------
$script:FilterText = ""

function global:Apply-DiskFilter {
    param([string]$Filter)
    $script:FilterText = $Filter.Trim()
    if ($null -eq $script:AllScannedItems -or $script:AllScannedItems.Count -eq 0) { return }
    if ($null -eq $script:LiveList) { return }

    # la gestiona exclusivamente. Guardar el texto y aplicar solo cuando termine.
    if ($null -ne $script:DiskScanAsync) { return }

    if ([string]::IsNullOrWhiteSpace($script:FilterText)) {
        # Sin filtro: vista normal jerárquica
        Refresh-DiskView
    } else {
        # Con filtro: lista plana de items cuyo nombre contiene el texto
        $script:LiveList.Clear()
        foreach ($item in $script:AllScannedItems) {
            if ($item.SizeBytes -ge 0 -and $item.DisplayName -like "*$script:FilterText*") {
                $script:LiveList.Add($item)
            }
        }
    }
}

$txtDiskFilter.Add_TextChanged({
    Apply-DiskFilter $txtDiskFilter.Text
    Save-Settings
})

$btnDiskFilterClear.Add_Click({
    $txtDiskFilter.Text = ""
    Apply-DiskFilter ""
})

# -----------------------------------------------------------------------------
$ctxMenu.Add_Opened({
    $sel = $lbDiskTree.SelectedItem
    $hasItem = $null -ne $sel
    $ctxOpen.IsEnabled       = $hasItem -and $sel.IsDir -and (Test-Path $sel.FullPath)
    $ctxCopy.IsEnabled       = $hasItem
    $ctxScanFolder.IsEnabled = $hasItem -and $sel.IsDir -and (Test-Path $sel.FullPath)
    $ctxDelete.IsEnabled     = $hasItem -and $sel.IsDir -and (Test-Path $sel.FullPath)
})

$ctxOpen.Add_Click({
    $sel = $lbDiskTree.SelectedItem
    if ($null -ne $sel -and (Test-Path $sel.FullPath)) {
        Start-Process "explorer.exe" $sel.FullPath
    }
})

$ctxCopy.Add_Click({
    $sel = $lbDiskTree.SelectedItem
    if ($null -ne $sel) {
        [System.Windows.Clipboard]::SetText($sel.FullPath)
        $txtDiskScanStatus.Text = "$([char]0x2705) $(T 'DiskPathCopied' 'Ruta copiada'): $($sel.FullPath)"
    }
})

$ctxDelete.Add_Click({
    $sel = $lbDiskTree.SelectedItem
    if ($null -eq $sel -or -not $sel.IsDir) { return }
    $confirm = Show-ThemedDialog -Title ((T "DlgConfirmDeleteTitle")) `
        -Message "$((T "DlgConfirmDeleteFolderMsg"))`n`n$($sel.FullPath)`n`n$((T "DlgSize")): $($sel.SizeStr)`n`n$((T "DlgCannotUndo"))" `
        -Type "warning" -Buttons "YesNo"
    if ($confirm) {
        try {
            Remove-Item -Path $sel.FullPath -Recurse -Force -ErrorAction Stop
            # Quitar de AllScannedItems y refrescar vista
            $toRemove = $script:AllScannedItems | Where-Object {
                $_.FullPath -eq $sel.FullPath -or $_.FullPath.StartsWith($sel.FullPath + "\")
            }
            foreach ($r in @($toRemove)) { $script:AllScannedItems.Remove($r) | Out-Null }
            Refresh-DiskView -RebuildMap
            $txtDiskScanStatus.Text = "$([char]::ConvertFromUtf32(0x1F5D1)) $(T 'Deleted' 'Eliminado'): $($sel.FullPath)"
        } catch {
            Show-ThemedDialog -Title ((T "DlgDeleteError")) `
                -Message "$((T "DlgDeleteError")):`n$($_.Exception.Message)" -Type "error"
        }
    }
})


# -----------------------------------------------------------------------------
# [N9] Escanear carpeta -- ventana emergente con árbol de archivos y operaciones
# -----------------------------------------------------------------------------
$ctxScanFolder.Add_Click({
    $sel = $lbDiskTree.SelectedItem
    if ($null -eq $sel -or -not $sel.IsDir -or -not (Test-Path $sel.FullPath)) { return }
    Show-FolderScanner -FolderPath $sel.FullPath
})

# -----------------------------------------------------------------------------
$btnExportCsv.Add_Click({
    if ($null -eq $script:AllScannedItems -or $script:AllScannedItems.Count -eq 0) {
        Show-ThemedDialog -Title "Sin datos" `
            -Message (T "DiskNoScanData" "No hay datos de escaneo. Realiza un escaneo primero.") -Type "info"
        return
    }
    $dlgFile = New-Object System.Windows.Forms.SaveFileDialog
    try {
        $dlgFile.Title      = (T "DlgExportExplorerTitle")
        $dlgFile.Filter     = "CSV (*.csv)|*.csv|$((T "DlgAllFilesFilter"))|*.*"
        $dlgFile.DefaultExt = "csv"
        $dlgFile.FileName   = "SysOpt_Disco_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
        $dlgFile.InitialDirectory = $script:OutputDir
        if ($dlgFile.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return }
        $csvPath = $dlgFile.FileName
    } finally { $dlgFile.Dispose() }

    $btnExportCsv.IsEnabled  = $false
    $txtDiskScanStatus.Text  = "$([char]0x23F3) $(T 'DiskExportingCSV' 'Exportando CSV en segundo plano...')"
    Register-Task -Id "csv" -Name "$(T 'DiskExportCSV' 'Exportar CSV'): $([System.IO.Path]::GetFileName($csvPath))" -Icon "$([char]::ConvertFromUtf32(0x1F4C4))" -IconBg (Get-TC 'BgStatusOk' '#1A2A1E') | Out-Null

    $script:ExportState.Phase     = (T "PhasePreparingData" "Preparando datos...")
    $script:ExportState.Progress  = 0
    $script:ExportState.ItemsDone = 0
    $script:ExportState.ItemsTotal= $script:AllScannedItems.Count
    $script:ExportState.Done      = $false
    $script:ExportState.Error     = ""
    $script:ExportState.Result    = ""

    # [RAM-03] Pasar AllScannedItems por referencia -- sin clonar $csvData
    $script:ExportState.DataRef  = $script:AllScannedItems
    $script:ExportState.CsvPath2 = $csvPath

    # [i18n] Pre-resolve T() for bgCsvScript background runspace
    $_bgC = @{
        SortingData = (T 'PhaseSortingData' 'Ordenando datos...')
        WritingCsv  = (T 'PhaseWritingCsv' 'Escribiendo CSV...')
        CsvPath     = (T 'CsvPath' 'Ruta')
        CsvSize     = (T 'CsvSize' 'Tamaño')
        CsvFiles    = (T 'CsvFiles' 'Archivos')
        CsvFolders  = (T 'CsvFolders' 'Carpetas')
        CsvPctTotal = (T 'CsvPctTotal' '% del total')
        CsvType     = (T 'CsvType' 'Tipo')
        TypeFolder  = (T 'TypeFolder' 'Carpeta')
        TypeFile    = (T 'TypeFile' 'Archivo')
        WritingRow  = (T 'PhaseWritingRow' 'Escribiendo fila')
        Of          = (T 'Of' 'de')
        Completed   = (T 'PhaseCompleted' 'Completado')
    }

    $bgCsvScript = {
        param($State, $CsvPath, $_bgC)
        try {
            $Items = $State.DataRef
            $State.Phase    = $_bgC.SortingData
            $State.Progress = 5
            # Ordenar in-place sin crear lista nueva -- usar Array.Sort con comparer
            $sorted = [System.Linq.Enumerable]::OrderByDescending(
                [System.Collections.Generic.IEnumerable[object]]$Items,
                [Func[object,long]]{ param($x) if ($x.SizeBytes -ge 0) { $x.SizeBytes } else { 0L } }
            )
            $State.Phase    = $_bgC.WritingCsv
            $State.Progress = 10
            $total = $Items.Count
            $State.ItemsTotal = $total
            $sw = [System.IO.StreamWriter]::new($CsvPath, $false, [System.Text.Encoding]::UTF8, 65536)
            try {
                $sw.WriteLine('"' + $_bgC.CsvPath + '","' + $_bgC.CsvSize + '","Bytes","' + $_bgC.CsvFiles + '","' + $_bgC.CsvFolders + '","' + $_bgC.CsvPctTotal + '","' + $_bgC.CsvType + '"')
                $i = 0
                foreach ($r in $sorted) {
                    if ($r.SizeBytes -lt 0) { $i++; continue }
                    $ruta  = [string]$r.FullPath  -replace '"','""'
                    $tam   = [string]$r.SizeStr   -replace '"','""'
                    $arch  = [string]$r.FileCount -replace '"','""'
                    $pct   = [string]$r.PctStr    -replace '"','""'
                    $tipo  = if ($r.IsDir) { $_bgC.TypeFolder } else { $_bgC.TypeFile }
                    $sw.WriteLine('"' + $ruta + '","' + $tam + '",' + $r.SizeBytes + ',"' + $arch + '",' + $r.DirCount + ',"' + $pct + '","' + $tipo + '"')
                    $i++
                    if ($i % 1000 -eq 0) {
                        $sw.Flush()
                        $State.ItemsDone = $i
                        $State.Progress  = [int](10 + ($i / [math]::Max(1,$total)) * 85)
                        $State.Phase     = "$($_bgC.WritingRow) $i $($_bgC.Of) $total..."
                    }
                }
                $sw.Flush()
            } finally { $sw.Close(); $sw.Dispose() }
            $State.Result    = $CsvPath
            $State.Progress  = 100
            $State.Phase     = $_bgC.Completed
            $State.ItemsDone = $total
            $State.Done      = $true
        } catch {
            $State.Error = $_.Exception.Message
            $State.Done  = $true
        }
    }

    $ctxCsv = New-PooledPS
    $ps4 = $ctxCsv.PS
    [void]$ps4.AddScript($bgCsvScript)
    [void]$ps4.AddParameter("State",   $script:ExportState)
    [void]$ps4.AddParameter("CsvPath", $csvPath)
    [void]$ps4.AddParameter("_bgC",    $_bgC)
    $asyncCsv = $ps4.BeginInvoke()

    $progCsv = Show-ExportProgressDialog
    if ($null -ne $progCsv.Title) { $progCsv.Title.Text = (T "CsvExporting" "Exportando CSV") }
    $progCsv.Window.Show()

    $csvTimer = New-Object System.Windows.Threading.DispatcherTimer
    $csvTimer.Interval = [TimeSpan]::FromMilliseconds(200)
    $script:_csvProg  = $progCsv
    $script:_csvTimer = $csvTimer
    $script:_csvPs    = $ps4
    $script:_csvCtx   = $ctxCsv
    $script:_csvAsync = $asyncCsv

    # CancelFn para el menú contextual de tareas
    $csvTask = $null
    if ($script:TaskPool.TryGetValue("csv", [ref]$csvTask) -and $null -ne $csvTask) {
        $csvTask.CancelFn = {
            $script:ExportState.Done  = $true
            $script:ExportState.Error = (T "CancelledByUser" "Cancelado por el usuario")
            if ($null -ne $script:_csvTimer) { try { $script:_csvTimer.Stop() } catch {} }
            try { $script:_csvPs.Stop() } catch {}
            Dispose-PooledPS $script:_csvCtx
            if ($null -ne $script:_csvProg) { try { $script:_csvProg.Window.Close() } catch {} }
            try { $btnExportCsv.IsEnabled = $true } catch {}
        }
    }

    $csvTimer.Add_Tick({
        $st   = $script:ExportState
        $prog = $script:_csvProg
        $pct  = [int]$st.Progress
        $cntStr = if ($st.ItemsTotal -gt 0) { "$($st.ItemsDone) / $($st.ItemsTotal) $(T 'Rows' 'filas')" } else { "" }
        Update-ProgressDialog $prog $pct $st.Phase $cntStr
        Update-Task -Id "csv" -Pct $pct -Detail "$($st.Phase) $cntStr"
        if ($st.Done) {
            $script:_csvTimer.Stop()
            $prog.Window.Close()
            try { $script:_csvPs.EndInvoke($script:_csvAsync) | Out-Null } catch {}
            Dispose-PooledPS $script:_csvCtx
            $btnExportCsv.IsEnabled = $true
            if ($st.Error -ne "") {
                Complete-Task -Id "csv" -IsError -Detail $st.Error
                Show-ThemedDialog -Title ((T "DlgExportError")) -Message "$((T "DlgExportError")):`n$($st.Error)" -Type "error"
            } else {
                $f     = if ($st.Result) { [string]$st.Result } else { "" }
                $fLeaf = if ($f) { Split-Path $f -Leaf } else { "export.csv" }
                Complete-Task -Id "csv" -Detail $fLeaf
                $txtDiskScanStatus.Text = "$([char]0x2705) $((T "CsvExportedMsg")): $fLeaf"
                $n = $script:AllScannedItems.Count
                Show-ThemedDialog -Title ((T "DlgExportDoneTitle")) `
                    -Message "$((T "DlgCsvSavedFmt")) $f`n`n$n $((T "DlgElements"))." -Type "success"
                Show-Toast -Title (T "ToastExportDoneTitle") -Message (T "ToastExportDoneMsg") -Type "Success"
                Invoke-AggressiveGC
            }
        }
    })
    $csvTimer.Start()
})


# -- [B3b] Exportar JSON de disco (server sync) ------------------------------
# Estructura JSON preparada para sincronización con servidor futuro (Agent Mode)
# -----------------------------------------------------------------------------
$btnExportJson.Add_Click({
    if ($null -eq $script:AllScannedItems -or $script:AllScannedItems.Count -eq 0) {
        Show-ThemedDialog -Title "Sin datos" `
            -Message (T "DiskNoScanData" "No hay datos de escaneo. Realiza un escaneo primero.") -Type "info"
        return
    }
    $dlgFile = New-Object System.Windows.Forms.SaveFileDialog
    try {
        $dlgFile.Title      = (T "DiskExportJsonTitle")
        $dlgFile.Filter     = "JSON (*.json)|*.json"
        $dlgFile.DefaultExt = "json"
        $dlgFile.FileName   = "SysOpt_DiskSync_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
        $dlgFile.InitialDirectory = $script:OutputDir
        if ($dlgFile.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return }
        $jsonPath = $dlgFile.FileName
    } finally { $dlgFile.Dispose() }

    $btnExportJson.IsEnabled = $false
    $txtDiskScanStatus.Text  = [string]([char]0x23F3) + " " + (T 'DiskExportingJson')
    try {
        $syncData = @{
            version      = $script:AppVersion
            timestamp    = (Get-Date -Format 'o')
            computerName = $env:COMPUTERNAME
            scanPath     = $txtDiskScanPath.Text
            totalItems   = $script:AllScannedItems.Count
            items        = @(foreach ($r in $script:AllScannedItems) {
                @{
                    path      = $r.FullPath
                    sizeBytes = $r.SizeBytes
                    sizeStr   = $r.SizeStr
                    files     = $r.FileCount
                    dirs      = $r.DirCount
                    pct       = $r.PctStr
                    isDir     = [bool]$r.IsDir
                }
            })
        }
        $json = $syncData | ConvertTo-Json -Depth 4 -Compress
        [System.IO.File]::WriteAllText($jsonPath, $json, [System.Text.Encoding]::UTF8)
        $fLeaf = Split-Path $jsonPath -Leaf
        $txtDiskScanStatus.Text = [string]([char]0x2705) + " " + (T 'DiskExportJsonDone') + ": $fLeaf"
        Show-ThemedDialog -Title ((T "DlgExportDoneTitle")) `
            -Message "$((T 'DiskExportJsonDone')):`n$jsonPath" -Type "success"
        Show-Toast -Title (T "ToastExportDoneTitle") -Message (T "JsonSyncReady") -Type "Success"
    } catch {
        Show-ThemedDialog -Title "Error" -Message "Error: $($_.Exception.Message)" -Type "error"
        $txtDiskScanStatus.Text = [string]([char]0x274C) + " Error exportando JSON"
    } finally {
        $btnExportJson.IsEnabled = $true
    }
})

# -- [B3] Generar informe HTML desde el explorador de disco -------------------
# La exportación ocurre en un Runspace separado para no bloquear la UI.
# -----------------------------------------------------------------------------

$btnDiskReport.Add_Click({
    if ($null -eq $script:AllScannedItems -or $script:AllScannedItems.Count -eq 0) {
        Show-ThemedDialog -Title "Sin datos" `
            -Message (T "DiskNoScanData" "No hay datos de escaneo. Realiza un escaneo primero.") -Type "info"
        return
    }
    $templatePath = Join-Path $script:AppDir "assets\templates\diskreport.html"
    if (-not (Test-Path $templatePath)) {
Set-SplashProgress 97 (T "SplashLoading97" "Módulos de exportación...")
        Show-ThemedDialog -Title "Template no encontrado" `
            -Message "$((T "HtmlTemplateNotFound")):`n$templatePath" -Type "error"
        return
    }

    $btnDiskReport.IsEnabled = $false
    $txtDiskScanStatus.Text  = "$([char]0x23F3) $((T "HtmlGeneratingBg"))"
    Register-Task -Id "html" -Name "$(T 'DiskHtmlReport' 'Informe HTML'): $($txtDiskScanPath.Text)" -Icon "$([char]::ConvertFromUtf32(0x1F4CA))" -IconBg (Get-TC 'BgInput' '#1A2030') | Out-Null

    $script:ExportState.Phase     = (T "PhasePreparingData" "Preparando datos...")
    $script:ExportState.Progress  = 0
    $script:ExportState.ItemsDone = 0
    $script:ExportState.ItemsTotal= $script:AllScannedItems.Count
    $script:ExportState.Done      = $false
    $script:ExportState.Error     = ""
    $script:ExportState.Result    = ""

    # [RAM-03] Pasar AllScannedItems por referencia -- sin clonar en $dataSnapshot
    # El runspace recibe la referencia directa al list; no hay copia de RAM en pico
    $script:ExportState.DataRef = $script:AllScannedItems

    $exportParams = @{
        State        = $script:ExportState
        TemplatePath = $templatePath
        ScanPath     = $txtDiskScanPath.Text
        AppDir       = $script:AppDir
    }

    # [i18n] Pre-resolve T() for bgExportScript background runspace
    $_bgH = @{
        ReadingTemplate = (T 'PhaseReadingTemplate' 'Leyendo plantilla...')
        LoadingLogo     = (T 'HtmlLoadingLogo' 'Cargando logo...')
        CalcStats       = (T 'PhaseCalcStats' 'Calculando estadísticas...')
        GenPieChart     = (T 'PhaseGenPieChart' 'Generando gráfico de sectores...')
        DiskTotalDrive  = (T 'DiskTotalDrive' 'Total unidad')
        FreeSpace       = (T 'DiskFreeSpace' 'Espacio libre')
        DiskUsage       = (T 'DiskUsage' 'Uso de disco')
        OtherFolders    = (T 'OtherFolders' 'Otras carpetas')
        GenFolderTable  = (T 'PhaseGenFolderTable' 'Generando tabla de carpetas...')
        GenHtmlRows     = (T 'PhaseGenHtmlRows' 'Generando filas HTML...')
        AssemblingHtml  = (T 'PhaseAssemblingHtml' 'Ensamblando HTML...')
        WritingFile     = (T 'PhaseWritingFile' 'Escribiendo archivo...')
        Completed       = (T 'PhaseCompleted' 'Completado')
    }

    $bgExportScript = {
        param($State, $TemplatePath, $ScanPath, $AppDir, $_bgH)

        function global:SafeHtml([string]$s) {
            $s -replace '&','&amp;' -replace '<','&lt;' -replace '>','&gt;' `
               -replace '"','&quot;' -replace "'","&#39;"
        }
        function global:FmtSize([long]$bytes) {
            if ($bytes -ge 1GB) { "{0:N2} GB" -f ($bytes/1GB) }
            elseif ($bytes -ge 1MB) { "{0:N1} MB" -f ($bytes/1MB) }
            elseif ($bytes -ge 1KB) { "{0:N0} KB" -f ($bytes/1KB) }
            else { "$bytes B" }
        }

        $DataSnapshot = $State.DataRef

        try {
            $State.Phase = $_bgH.ReadingTemplate; $State.Progress = 2
            $tpl = [System.IO.File]::ReadAllText($TemplatePath, [System.Text.Encoding]::UTF8)

            $State.Phase = $_bgH.LoadingLogo; $State.Progress = 5
            $logoB64 = ""
            $logoPath = Join-Path $AppDir "assets\img\sysopt.png"
            if (Test-Path $logoPath) {
                try { $logoB64 = [Convert]::ToBase64String([System.IO.File]::ReadAllBytes($logoPath)) } catch {}
            }
            $logoTag = if ($logoB64) {
                "<img src='data:image/png;base64,$logoB64' alt='SysOpt' class='logo-img'/>"
            } else { "<div class='logo-fallback'>&#9881;</div>" }

            $State.Phase = $_bgH.CalcStats; $State.Progress = 10
            $now        = Get-Date
            $reportDate = $now.ToString('yyyyMMddHHmm')
            $dateLong   = $now.ToString('dd/MM/yyyy HH:mm:ss')

            $validItems = @($DataSnapshot)
            $rootItems  = @($validItems | Where-Object { $_.Depth -eq 0 } | Sort-Object SizeBytes -Descending)
            $totalBytes = ($rootItems | Measure-Object -Property SizeBytes -Sum).Sum
            if ($totalBytes -le 0) { $totalBytes = 1 }
            $totalStr     = FmtSize $totalBytes
            $totalFolders = $validItems.Count
            $totalFiles   = ($validItems | ForEach-Object {
                $fc = $_.FileCount
                if ($fc -match '^(\d+)\s') { [int]$Matches[1] } else { 0 }
            } | Measure-Object -Sum).Sum

            $diskStatsExtra = ""; $diskUsageBar = ""
            try {
                $drive = [System.IO.Path]::GetPathRoot($ScanPath)
                if ($drive -match '^[A-Za-z]:\\$') {
                    $di   = [System.IO.DriveInfo]::new($drive)
                    $dTot = $di.TotalSize; $dFree = $di.AvailableFreeSpace
                    $dUsed= $dTot - $dFree
                    $dPct = [math]::Round($dUsed / $dTot * 100, 1)
                    $diskStatsExtra = "<div class=`"stat-box`"><div class=`"stat-lbl`">$($_bgH.DiskTotalDrive) $drive</div><div class=`"stat-val c-cyan`">$(FmtSize $dTot)</div></div><div class=`"stat-box`"><div class=`"stat-lbl`">$($_bgH.FreeSpace)</div><div class=`"stat-val c-green`">$(FmtSize $dFree)</div></div><div class=`"stat-box`"><div class=`"stat-lbl`">$($_bgH.DiskUsage)</div><div class=`"stat-val c-red`">$dPct%</div></div>"
                    $diskUsageBar   = "<div class=`"disk-bar-wrap`"><div class=`"disk-bar-fill`" style=`"width:$dPct%`"></div></div><div class=`"disk-bar-label`">$dPct% utilizado &mdash; $(FmtSize $dUsed) de $(FmtSize $dTot)</div>"
                }
            } catch {}

            $State.Phase = $_bgH.GenPieChart; $State.Progress = 18
            $pal = @('#5BA3FF','#4AE896','#FFB547','#FF6B84','#9B7EFF','#2EDFBF',
                     '#FF9F43','#54A0FF','#5F27CD','#01CBC6','#FFC312','#C4E538',
                     '#12CBC4','#FDA7DF','#ED4C67','#F79F1F','#A29BFE','#74B9FF')
            $slicesSvg = ""; $legendHtml = ""
            $cx = 160; $cy = 160; $r = 148; $startAngle = -90.0
            $topN = [math]::Min($rootItems.Count, 16)
            $otherBytes = $totalBytes
            for ($i = 0; $i -lt $topN; $i++) { $otherBytes -= [long]$rootItems[$i].SizeBytes }
            $hasOther = ($rootItems.Count -gt $topN) -and ($otherBytes -gt 0)
            for ($i = 0; $i -lt $topN; $i++) {
                $item = $rootItems[$i]; $pct  = [long]$item.SizeBytes / $totalBytes
                $angle= $pct * 360.0; $endA = $startAngle + $angle
                $large= if ($angle -gt 180) { 1 } else { 0 }; $col = $pal[$i % $pal.Count]
                $pctLbl = [math]::Round($pct * 100, 1); $szStr = FmtSize ([long]$item.SizeBytes)
                $nameEsc = SafeHtml $item.DisplayName
                if ($angle -ge 359.9) {
                    $slicesSvg += "<circle cx='$cx' cy='$cy' r='$r' fill='$col' class='slice' data-name='$nameEsc' data-size='$szStr' data-pct='$pctLbl%'/>`n"
                } else {
                    $x1=[math]::Round($cx+$r*[math]::Cos($startAngle*[math]::PI/180),3)
                    $y1=[math]::Round($cy+$r*[math]::Sin($startAngle*[math]::PI/180),3)
                    $x2=[math]::Round($cx+$r*[math]::Cos($endA*[math]::PI/180),3)
                    $y2=[math]::Round($cy+$r*[math]::Sin($endA*[math]::PI/180),3)
                    $slicesSvg += "<path d='M$cx,$cy L$x1,$y1 A$r,$r 0 $large,1 $x2,$y2 Z' fill='$col' opacity='0.92' class='slice' data-name='$nameEsc' data-size='$szStr' data-pct='$pctLbl%'/>`n"
                }
                $legendHtml += "<div class='legend-item'><span class='legend-dot' style='background:$col'></span><span class='legend-name' title='$nameEsc'>$nameEsc</span><span class='legend-size'>$szStr</span><span class='legend-pct'>$pctLbl%</span></div>`n"
                $startAngle = $endA
            }
            if ($hasOther) {
                $angle=[math]::Round($otherBytes/$totalBytes*360,2); $endA=$startAngle+$angle
                $large=if($angle-gt 180){1}else{0}; $col='#3A4468'
                $szStr=FmtSize $otherBytes; $pctLbl=[math]::Round($otherBytes/$totalBytes*100,1)
                $x1=[math]::Round($cx+$r*[math]::Cos($startAngle*[math]::PI/180),3)
                $y1=[math]::Round($cy+$r*[math]::Sin($startAngle*[math]::PI/180),3)
                $x2=[math]::Round($cx+$r*[math]::Cos($endA*[math]::PI/180),3)
                $y2=[math]::Round($cy+$r*[math]::Sin($endA*[math]::PI/180),3)
                $slicesSvg += "<path d='M$cx,$cy L$x1,$y1 A$r,$r 0 $large,1 $x2,$y2 Z' fill='$col' opacity='0.7' class='slice' data-name='$($_bgH.OtherFolders)' data-size='$szStr' data-pct='$pctLbl%'/>`n"
                $legendHtml += "<div class='legend-item'><span class='legend-dot' style='background:$col'></span><span class='legend-name'>$($_bgH.OtherFolders)</span><span class='legend-size'>$szStr</span><span class='legend-pct'>$pctLbl%</span></div>`n"
            }

            $State.Phase = $_bgH.GenFolderTable; $State.Progress = 25
            $State.ItemsTotal = $validItems.Count
            # El StringBuilder ya no crece ilimitado en memoria
            $tmpRowsFile = [System.IO.Path]::GetTempFileName()
            $swRows = [System.IO.StreamWriter]::new($tmpRowsFile, $false, [System.Text.Encoding]::UTF8, 65536)
            $allSorted = @($validItems | Sort-Object SizeBytes -Descending)
            $total_items = $allSorted.Count
            $idx = 0; $startTime = [DateTime]::UtcNow
            try {
                for ($r2 = 0; $r2 -lt $total_items; $r2++) {
                    $item   = $allSorted[$r2]
                    $col2   = $pal[$idx % $pal.Count]
                    $pct2   = [math]::Round([long]$item.SizeBytes / $totalBytes * 100, 2)
                    $bar    = [math]::Min(100, $pct2)
                    $szStr2 = FmtSize ([long]$item.SizeBytes)
                    $nmEsc  = SafeHtml $item.DisplayName
                    $ptEsc  = SafeHtml $item.FullPath
                    $depth  = [int]$item.Depth
                    $dClass = switch ($depth) { 0 {"depth-0"} 1 {"depth-1"} 2 {"depth-2"} 3 {"depth-3"} default {"depth-4p"} }
                    $files  = if ($item.FileCount -match '^(\d+)\s' -and [int]$Matches[1] -gt 0) { $item.FileCount } else { "" }
                    $dotCol = if ($depth -eq 0) { $pal[$idx % $pal.Count] } else { "#3A4468" }
                    $swRows.WriteLine("<tr><td class=`"td-dot`"><span class=`"dot`" style=`"background:$dotCol`"></span></td><td class=`"$dClass`" title=`"$ptEsc`">$nmEsc</td><td class=`"td-path`" title=`"$ptEsc`">$ptEsc</td><td class=`"td-size`">$szStr2</td><td class=`"td-pct`">$pct2%</td><td class=`"td-files`">$files</td><td class=`"td-bar`"><div class=`"bar-wrap`"><div class=`"bar-fill`" style=`"width:$bar%;background:$dotCol`"></div></div></td></tr>")
                    if ($depth -eq 0) { $idx++ }
                    if ($r2 % 500 -eq 0) {
                        $swRows.Flush()
                        $State.ItemsDone = $r2
                        $elapsed = ([DateTime]::UtcNow - $startTime).TotalSeconds
                        $pctTable = if ($total_items -gt 0) { $r2 / $total_items } else { 1 }
                        $State.Progress = [int](25 + $pctTable * 55)
                        if ($elapsed -gt 0.5 -and $pctTable -gt 0.01) {
                            $eta = [int](($elapsed / $pctTable) * (1 - $pctTable))
                            $State.Phase = "$($_bgH.GenHtmlRows) (ETA: ${eta}s)"
                        }
                    }
                }
                $swRows.Flush()
            } finally { $swRows.Close(); $swRows.Dispose() }
            $State.ItemsDone = $total_items; $State.Progress = 82

            $State.Phase = $_bgH.AssemblingHtml; $State.Progress = 85
            $scanPathEsc = SafeHtml $ScanPath
            # Leer las filas del archivo temporal
            $tableRowsStr = [System.IO.File]::ReadAllText($tmpRowsFile, [System.Text.Encoding]::UTF8)
            try { [System.IO.File]::Delete($tmpRowsFile) } catch {}
            $html = $tpl `
                -replace '{{LOGO_TAG}}',         $logoTag `
                -replace '{{SCAN_PATH}}',         $scanPathEsc `
                -replace '{{REPORT_DATE}}',       $reportDate `
                -replace '{{REPORT_DATE_LONG}}',  $dateLong `
                -replace '{{SCAN_TIME}}',         $dateLong `
                -replace '{{APP_VERSION}}',       "v$($script:AppVersion)" `
                -replace '{{TOTAL_SIZE}}',        $totalStr `
                -replace '{{TOTAL_FOLDERS}}',     $totalFolders `
                -replace '{{TOTAL_FILES}}',       $totalFiles `
                -replace '{{DISK_STATS_EXTRA}}',  $diskStatsExtra `
                -replace '{{DISK_USAGE_BAR}}',    $diskUsageBar `
                -replace '{{PIE_SLICES}}',        $slicesSvg `
                -replace '{{PIE_LEGEND}}',        $legendHtml `
                -replace '{{TABLE_ROWS}}',        $tableRowsStr
            $tableRowsStr = $null  # liberar ref

            $State.Phase = $_bgH.WritingFile; $State.Progress = 95
            $outDir = Join-Path $AppDir "output"
            if (-not (Test-Path $outDir)) { [System.IO.Directory]::CreateDirectory($outDir) | Out-Null }
            $outFile = Join-Path $outDir "diskreport_$reportDate.html"
            [System.IO.File]::WriteAllText($outFile, $html, [System.Text.Encoding]::UTF8)

            $State.Result = $outFile; $State.Progress = 100
            $State.Phase  = $_bgH.Completed; $State.Done = $true
        } catch {
            $State.Error = $_.Exception.Message; $State.Done = $true
        }
    }

    $ctxHtml = New-PooledPS
    $ps2 = $ctxHtml.PS
    [void]$ps2.AddScript($bgExportScript)
    [void]$ps2.AddParameter("State",        $exportParams.State)
    [void]$ps2.AddParameter("TemplatePath", $exportParams.TemplatePath)
    [void]$ps2.AddParameter("ScanPath",     $exportParams.ScanPath)
    [void]$ps2.AddParameter("AppDir",       $exportParams.AppDir)
    [void]$ps2.AddParameter("_bgH",         $_bgH)
    $asyncHtml = $ps2.BeginInvoke()

    $progHtml = Show-ExportProgressDialog
    if ($null -ne $progHtml.Title) { $progHtml.Title.Text = (T "HtmlGeneratingBg") }
    $progHtml.Window.Show()

    $htmlTimer = New-Object System.Windows.Threading.DispatcherTimer
    $htmlTimer.Interval = [TimeSpan]::FromMilliseconds(200)
    $script:_htmlProg  = $progHtml
    $script:_htmlTimer = $htmlTimer
    $script:_htmlPs    = $ps2
    $script:_htmlCtx   = $ctxHtml
    $script:_htmlAsync = $asyncHtml

    # CancelFn para el menú contextual de tareas
    $htmlTask = $null
    if ($script:TaskPool.TryGetValue("html", [ref]$htmlTask) -and $null -ne $htmlTask) {
        $htmlTask.CancelFn = {
            $script:ExportState.Done  = $true
            $script:ExportState.Error = (T "CancelledByUser" "Cancelado por el usuario")
            if ($null -ne $script:_htmlTimer) { try { $script:_htmlTimer.Stop() } catch {} }
            try { $script:_htmlPs.Stop() } catch {}
            Dispose-PooledPS $script:_htmlCtx
            if ($null -ne $script:_htmlProg) { try { $script:_htmlProg.Window.Close() } catch {} }
        }
    }

    $htmlTimer.Add_Tick({
        $st   = $script:ExportState
        $prog = $script:_htmlProg
        $pct  = [int]$st.Progress
        $cntStr = if ($st.ItemsTotal -gt 0) { "$($st.ItemsDone) / $($st.ItemsTotal) $(T 'Items' 'elementos')" } else { "" }
        Update-ProgressDialog $prog $pct $st.Phase $cntStr
        Update-Task -Id "html" -Pct $pct -Detail "$($st.Phase) $cntStr"
        if ($st.Done) {
            $script:_htmlTimer.Stop()
            $prog.Window.Close()
            try { $script:_htmlPs.EndInvoke($script:_htmlAsync) | Out-Null } catch {}
            Dispose-PooledPS $script:_htmlCtx
            $btnDiskReport.IsEnabled = $true
            if ($st.Error -ne "") {
                Complete-Task -Id "html" -IsError -Detail $st.Error
                $txtDiskScanStatus.Text = (T "HtmlReportError")
                Show-ThemedDialog -Title ((T "HtmlReportError")) -Message $st.Error -Type "error"
            } else {
                $outFile2 = if ($st.Result) { [string]$st.Result } else { "" }
                $outLeaf  = if ($outFile2) { Split-Path $outFile2 -Leaf } else { "informe.html" }
                Complete-Task -Id "html" -Detail $outLeaf
                $txtDiskScanStatus.Text = "$([char]0x2705) $(T 'DiskReportGenerated' 'Informe generado'): $outLeaf"
                $open = Show-ThemedDialog -Title (T "DiskReportGenerated" "Informe generado") `
                    -Message "$((T "HtmlReportSavedOpenBrowser"))`n$outFile2" `
                    -Type "success" -Buttons "YesNo"
                if ($open -and $outFile2) { Start-Process $outFile2 }
                Invoke-AggressiveGC
            }
        }
    })
    $htmlTimer.Start()
})

# -----------------------------------------------------------------------------
# El hash se calcula en un runspace background para no bloquear la UI.
# Los resultados se muestran en una ventana dedicada con grupos por hash.
# -----------------------------------------------------------------------------
$btnDedup.Add_Click({
    if ($null -eq $script:AllScannedItems -or $script:AllScannedItems.Count -eq 0) {
        Show-ThemedDialog -Title "Sin datos" `
            -Message (T "DiskNoScanData" "No hay datos de escaneo. Realiza un escaneo primero.") -Type "info"
        return
    }

    $btnDedup.IsEnabled     = $false
    $txtDiskScanStatus.Text = "$([char]0x23F3) $((T "DedupCalculatingHashes"))"

    # [FIX-BUG1] Definir $rootPath ANTES de Register-Task (que lo usa en el nombre)
    $rootPath = $txtDiskScanPath.Text
    Register-Task -Id "dedup" -Name "Deduplicación SHA256: $rootPath" -Icon "$([char]::ConvertFromUtf32(0x1F50D))" -IconBg (Get-TC 'PurpleBlobBg' '#1A1A2F') | Out-Null

    # Estado compartido entre runspace y UI
    $script:DedupState = [hashtable]::Synchronized(@{
        Done       = $false
        Stop       = $false
        Paused     = $false
        Error      = ""
        Groups     = $null     # List de grupos de duplicados
        TotalFiles = 0
        TotalWaste = 0L        # bytes recuperables
    })
    $dedupParams = @{
        State    = $script:DedupState
        RootPath = $rootPath
    }

    $bgDedupScript = {
        param($State, $RootPath)
        try {
            $minBytes  = 10MB
            $sha256    = [System.Security.Cryptography.SHA256]::Create()
            $hashMap   = [System.Collections.Generic.Dictionary[string, System.Collections.Generic.List[string]]]::new()

            # [FIX-DEDUP-ACCESS] Enumerar archivos con cola manual para saltar directorios
            # inaccesibles (p.ej. C:\Documents and Settings -- junction point protegido de
            # Windows Vista+) en lugar de EnumerateFiles(..., AllDirectories) que lanza
            # UnauthorizedAccessException en el primer directorio denegado y aborta todo.
            $queue = [System.Collections.Generic.Queue[string]]::new()
            $queue.Enqueue($RootPath)
            $count = 0

            # [FIX-DEDUP-SYSTEM] Rutas del sistema excluidas: archivos de Windows son
            # idénticos por diseño (dlls, drivers) y marcarlos como "duplicados" es
            # peligroso y confuso. Se excluyen también junctions conocidos.
            $systemExclusions = [System.Collections.Generic.HashSet[string]]::new(
                [System.StringComparer]::OrdinalIgnoreCase)
            foreach ($excl in @(
                [System.IO.Path]::Combine($RootPath, "Windows"),
                [System.IO.Path]::Combine($RootPath, "Windows.old"),
                [System.IO.Path]::Combine($RootPath, "Documents and Settings"),
                [System.IO.Path]::Combine($RootPath, "System Volume Information"),
                [System.IO.Path]::Combine($RootPath, "Recovery"),
                [System.IO.Path]::Combine($RootPath, "$Recycle.Bin"),
                [System.IO.Path]::Combine($RootPath, "ProgramData\Microsoft"),
                [System.IO.Path]::Combine([System.Environment]::GetFolderPath("Windows"), "")
            )) { [void]$systemExclusions.Add($excl.TrimEnd('\')) }

            while ($queue.Count -gt 0) {
                $dir = $queue.Dequeue()

                # [CANCEL] Comprobar flag de cancelación en cada iteración
                if ($State.Stop) { break }

                # [PAUSE] Spinwait si la UI ha solicitado pausa
                while ($State.Paused -and -not $State.Stop) {
                    [System.Threading.Thread]::Sleep(100)
                }
                if ($State.Stop) { break }

                # [FIX-DEDUP-SYSTEM] Saltar rutas del sistema
                $dirNorm = $dir.TrimEnd('\')
                $skipDir = $false
                foreach ($excl in $systemExclusions) {
                    if ($dirNorm -eq $excl -or $dirNorm.StartsWith($excl + '\', [System.StringComparison]::OrdinalIgnoreCase)) {
                        $skipDir = $true; break
                    }
                }
                if ($skipDir) { continue }

                # Saltar junction points / symlinks -- evita bucles y accesos denegados
                try {
                    $dirInfo = [System.IO.DirectoryInfo]::new($dir)
                    $isJunction = ($dirInfo.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0
                    if ($isJunction) { continue }
                } catch { continue }

                # Encolar subdirectorios (silenciar error de acceso por directorio)
                try {
                    foreach ($sub in [System.IO.Directory]::GetDirectories($dir)) {
                        $queue.Enqueue($sub)
                    }
                } catch { <# sin permisos -- continuar con el resto #> }

                # Procesar archivos del directorio actual
                try {
                    foreach ($f in [System.IO.Directory]::GetFiles($dir)) {
                        try {
                            $fi = [System.IO.FileInfo]::new($f)
                            if ($fi.Length -lt $minBytes) { continue }
                            $stream    = [System.IO.File]::OpenRead($f)
                            $hashBytes = $sha256.ComputeHash($stream)
                            $stream.Close(); $stream.Dispose()
                            $hex = [System.BitConverter]::ToString($hashBytes) -replace '-',''
                            if (-not $hashMap.ContainsKey($hex)) {
                                $hashMap[$hex] = [System.Collections.Generic.List[string]]::new()
                            }
                            $hashMap[$hex].Add($f)
                            $count++
                        } catch { continue }
                    }
                } catch { continue }
            }
            $sha256.Dispose()

            # Filtrar solo grupos con 2+ archivos (duplicados reales)
            $groups = [System.Collections.Generic.List[object]]::new()
            $totalWaste = 0L
            foreach ($kvp in $hashMap.GetEnumerator()) {
                if ($kvp.Value.Count -lt 2) { continue }
                $sampleSize = ([System.IO.FileInfo]::new($kvp.Value[0])).Length
                $waste = $sampleSize * ($kvp.Value.Count - 1)
                $totalWaste += $waste

                $fmtSize = if ($sampleSize -ge 1GB) { "{0:N2} GB" -f ($sampleSize/1GB) }
                           elseif ($sampleSize -ge 1MB) { "{0:N1} MB" -f ($sampleSize/1MB) }
                           else { "{0:N0} KB" -f ($sampleSize/1KB) }
                $fmtWaste = if ($waste -ge 1GB) { "{0:N2} GB" -f ($waste/1GB) }
                            elseif ($waste -ge 1MB) { "{0:N1} MB" -f ($waste/1MB) }
                            else { "{0:N0} KB" -f ($waste/1KB) }

                $groups.Add([PSCustomObject]@{
                    Hash       = $kvp.Key.Substring(0, 16) + "..."
                    FullHash   = $kvp.Key
                    Count      = $kvp.Value.Count
                    SizeStr    = $fmtSize
                    SizeBytes  = $sampleSize
                    WasteStr   = $fmtWaste
                    WasteBytes = $waste
                    Files      = $kvp.Value -join "`n"
                    FilesList  = $kvp.Value
                })
            }

            # Ordenar por espacio desperdiciado descendente
            $sorted = $groups | Sort-Object WasteBytes -Descending
            $State.Groups     = [System.Collections.Generic.List[object]]::new()
            foreach ($g in $sorted) { $State.Groups.Add($g) }
            $State.TotalFiles = $count
            $State.TotalWaste = $totalWaste
        } catch {
            $State.Error = $_.Exception.Message
        } finally {
            $State.Done = $true
        }
    }

    $ctx = New-PooledPS
    $ctx.PS.AddScript($bgDedupScript).AddParameter("State", $script:DedupState).AddParameter("RootPath", $rootPath) | Out-Null
    $dedupAsync = $ctx.PS.BeginInvoke()

    $dedupTimer = New-Object System.Windows.Threading.DispatcherTimer
    $script:_dedupTimer = $dedupTimer

    # Registrar hooks de control para el menú contextual de tareas
    $dedupTask = $null
    if ($script:TaskPool.TryGetValue("dedup", [ref]$dedupTask) -and $null -ne $dedupTask) {
        $dedupTask.CancelFn = {
            $script:DedupState.Paused = $false  # desbloquear spinwait antes de cancelar
            $script:DedupState.Stop   = $true
            $script:DedupState.Done   = $true   # desbloquea el timer tick para limpieza
        }
        $dedupTask.PauseFn = {
            $script:DedupState.Paused = $true
        }
        $dedupTask.ResumeFn = {
            $script:DedupState.Paused = $false
        }
    }
    $dedupTimer.Interval = [TimeSpan]::FromMilliseconds(400)
    $dedupTimer.Add_Tick({
        if (-not $script:DedupState.Done) { return }
        # [FIX] Usar $script:_dedupTimer en vez de $dedupTimer -- en PS5.1 el closure
        # del Add_Tick no captura variables locales del scope padre; $dedupTimer sería
        # $null aquí y lanzaría "You cannot call a method on a null-valued expression".
        $script:_dedupTimer.Stop()
        $script:_dedupTimer = $null
        Dispose-PooledPS $ctx

        $btnDedup.IsEnabled = $true

        if ($script:DedupState.Error) {
            Complete-Task -Id "dedup" -IsError -Detail $script:DedupState.Error
            $txtDiskScanStatus.Text = "Error en deduplicación."
            Write-Log "[B5] Error SHA256: $($script:DedupState.Error)" -Level "ERR"
            Show-ThemedDialog -Title "Error de deduplicación" `
                -Message "$((T "DedupHashError")):`n$($script:DedupState.Error)" -Type "error"
            return
        }

        $groups = $script:DedupState.Groups
        $waste  = $script:DedupState.TotalWaste
        $fmtW   = if ($waste -ge 1GB) { "{0:N2} GB" -f ($waste/1GB) }
                  elseif ($waste -ge 1MB) { "{0:N1} MB" -f ($waste/1MB) }
                  else { "{0:N0} KB" -f ($waste/1KB) }

        if ($null -eq $groups -or $groups.Count -eq 0) {
            Complete-Task -Id "dedup" -Detail (T "DedupNoDuplicates" "Sin duplicados")
            $txtDiskScanStatus.Text = "$([char]0x2705) $((T "DedupNoDuplicates"))"
            Write-Log "[B5] Deduplicación completada: sin duplicados." -Level "INFO"
            Show-ThemedDialog -Title ((T "DedupNoDuplicatesTitle")) `
                -Message ((T "DedupNoDuplicatesMsg")) -Type "info"
            return
        }

        Complete-Task -Id "dedup" -Detail "$($groups.Count) $(T 'DedupGroups' 'grupos') * $fmtW $(T 'DedupRecoverable' 'recuperables')"
        $txtDiskScanStatus.Text = "$([char]0x2705) $($groups.Count) $((T "DedupGroupsFmt")) -- $fmtW $((T "DedupRecoverable"))"
        Write-Log "[B5] Deduplicación: $($groups.Count) grupos, $fmtW recuperables." -Level "INFO"

        # -- Ventana de resultados de deduplicación --------------------------
        $dedupXaml = [XamlLoader]::Load($script:XamlFolder, "DedupWindow")
    $dedupXaml = $ExecutionContext.InvokeCommand.ExpandString($dedupXaml)
        try {
            $dr   = [System.Xml.XmlNodeReader]::new([xml]$dedupXaml)
            $dWin = [Windows.Markup.XamlReader]::Load($dr)
            $dWin.Owner = $window

            # -- Custom title bar: DragMove + close --
            $dedupTitleBar = $dWin.FindName("titleBarDedup")
            if ($null -ne $dedupTitleBar) { $dedupTitleBar.Add_MouseLeftButtonDown({ $dWin.DragMove() }.GetNewClosure()) }
            $btnTitleCloseDedup = $dWin.FindName("btnTitleCloseDedup")
            if ($null -ne $btnTitleCloseDedup) { $btnTitleCloseDedup.Add_Click({ $dWin.Close() }.GetNewClosure()) }
            $dWin.Add_Closed({ try { $window.Activate() } catch {} })

            # -- Inyectar TB_* brushes del tema actual y registrar para futuros cambios
            $themedRd = New-ThemedWindowResources
            foreach ($k in @($themedRd.Keys)) { $dWin.Resources[$k] = $themedRd[$k] }
            $script:ThemedWindows.Add($dWin)
            $dWin.Add_Closed({ try { $script:ThemedWindows.Remove($dWin) | Out-Null } catch {} })

            $lbGroups       = $dWin.FindName("lbDedupGroups")
            $txtDedupSum    = $dWin.FindName("txtDedupSummary")
            $txtDedupSt     = $dWin.FindName("txtDedupStatus")
            $btnDedupClose  = $dWin.FindName("btnDedupClose")

            $txtDedupSum.Text = "$($groups.Count) $(T 'DedupGroups' 'grupos') * $($script:DedupState.TotalFiles) $(T 'DedupFilesAnalyzed' 'archivos analizados') * $fmtW $(T 'DedupRecoverableDelCopies' 'recuperables eliminando copias')"
            $lbGroups.ItemsSource = $groups

            # Botón eliminar copias de un grupo (conserva el primer archivo)
            $lbGroups.AddHandler(
                [System.Windows.Controls.Button]::ClickEvent,
                [System.Windows.RoutedEventHandler]{
                    param($s2, $e2)
                    $srcBtn = $e2.OriginalSource
                    if (-not ($srcBtn -is [System.Windows.Controls.Button]) -or $srcBtn.Name -ne "btnDedupDelete") { return }
                    $fullHash = [string]$srcBtn.Tag
                    $grp = $groups | Where-Object { $_.FullHash -eq $fullHash } | Select-Object -First 1
                    if ($null -eq $grp) { return }

                    $copies = $grp.FilesList | Select-Object -Skip 1
                    $confirmMsg = "$(T 'DedupConfirmDelete' 'Se eliminarán') $($copies.Count) $(T 'DedupCopiesOfGroup' 'copia(s) del grupo'):`n($(T 'DedupKeep' 'se conserva'): $($grp.FilesList[0]))`n`n$(T 'DedupContinue' '¿Continuar?')"
                    $ok = Show-ThemedDialog -Title ((T "DlgConfirmDeleteTitle")) -Message $confirmMsg -Type "confirm"
                    if (-not $ok) { return }

                    $deleted = 0; $errors = 0
                    foreach ($f in $copies) {
                        try { Remove-Item -Path $f -Force -ErrorAction Stop; $deleted++ }
                        catch { $errors++; Write-Log "[B5] Error eliminando $f : $($_.Exception.Message)" -Level "WARN" }
                    }
                    Write-Log "[B5] Eliminadas $deleted copias del hash $($grp.Hash). Errores: $errors." -Level "INFO"
                    $txtDedupSt.Text = "$([char]0x2705) $deleted $((T "DedupDeletedResult"))$(if($errors -gt 0){" * $errors $((T "DedupErrors"))"})"

                    # Refrescar lista quitando el grupo procesado
                    $groups.Remove($grp) | Out-Null
                    $lbGroups.Items.Refresh()
                }
            )

            $btnDedupClose.Add_Click({ $dWin.Close() })
            $dWin.ShowDialog() | Out-Null
        } catch {
            Write-Log "[B5] Error abriendo ventana de duplicados: $($_.Exception.Message)" -Level "ERR"
            Show-ThemedDialog -Title ((T "DlgError")) -Message "$((T "DedupWindowError")):`n$($_.Exception.Message)" -Type "error"
        }
    })
    $dedupTimer.Start()
})
$lbDiskTree.AddHandler(
    [System.Windows.Controls.Button]::ClickEvent,
    [System.Windows.RoutedEventHandler]{
        param($s, $e)
        $btn = $e.OriginalSource
        if ($btn -is [System.Windows.Controls.Button] -and $null -ne $btn.Tag -and "$($btn.Tag)" -ne "") {
            $path = [string]$btn.Tag
            if ($script:CollapsedPaths.Contains($path)) {
                # Expandir: quitar de colapsados, actualizar icono
                $script:CollapsedPaths.Remove($path) | Out-Null
                if ($null -ne $script:LiveItems -and $script:LiveItems.ContainsKey($path) -and $null -ne $script:AllScannedItems) {
                    $script:AllScannedItems[$script:LiveItems[$path]].ToggleIcon = [string][char]0x25BC   # ?
                }
            } else {
                # Colapsar: añadir a colapsados, actualizar icono
                $script:CollapsedPaths.Add($path) | Out-Null
                if ($null -ne $script:LiveItems -and $script:LiveItems.ContainsKey($path) -and $null -ne $script:AllScannedItems) {
                    $script:AllScannedItems[$script:LiveItems[$path]].ToggleIcon = [string][char]0x25B6   # ?
                }
            }
            # Refresh reconstruye qué items son visibles (muestra/oculta hijos).
            # Items.Refresh() es obligatorio: LiveList es List<T>, no ObservableCollection --
            # WPF no detecta Clear()/Add() sin notificación explícita al ItemsControl.
            Refresh-DiskView
            $lbDiskTree.Items.Refresh()
            $e.Handled = $true
        }
    }
)

# Selección en la lista -> actualizar panel de detalle
$lbDiskTree.Add_SelectionChanged({
    $sel = $lbDiskTree.SelectedItem
    if ($null -eq $sel) { return }

    $txtDiskDetailName.Text  = $sel.DisplayName
    $txtDiskDetailSize.Text  = $sel.SizeStr
    $txtDiskDetailFiles.Text = if ($sel.IsDir) { $sel.FileCount } else { ((T "DedupOneFile")) }
    $txtDiskDetailDirs.Text  = if ($sel.IsDir) { "$($sel.DirCount) $((T "DiskFolders"))" } else { "--" }
    $txtDiskDetailPct.Text   = "$($sel.TotalPct)%"

    # Top 10 archivos más grandes -- ejecutado en runspace para no bloquear la UI
    $icTopFiles.ItemsSource = @([PSCustomObject]@{ FileName = (T "DiskSearchingLargeFiles" "Buscando archivos grandes..."); FileSize = "" })
    $selPath = $sel.FullPath
    if ($sel.IsDir -and (Test-Path $selPath)) {
        $topBg = {
            param([string]$p)
            try {
                [System.IO.Directory]::GetFiles($p, "*", [System.IO.SearchOption]::AllDirectories) |
                    ForEach-Object {
                        try { [PSCustomObject]@{ Name=[System.IO.Path]::GetFileName($_); Len=([System.IO.FileInfo]$_).Length } } catch {}
                    } |
                    Sort-Object Len -Descending |
                    Select-Object -First 10
            } catch { @() }
        }
        $ctxTop = New-PooledPS
        $psTop = $ctxTop.PS
        [void]$psTop.AddScript($topBg).AddParameter("p", $selPath)
        $asyncTop = $psTop.BeginInvoke()
        $script:_topTimer = New-Object System.Windows.Threading.DispatcherTimer
        $topTimer = $script:_topTimer
        $topTimer.Interval = [TimeSpan]::FromMilliseconds(200)
        $script:_topCtx = $ctxTop
        $topTimer.Add_Tick({
            if (-not $asyncTop.IsCompleted) { return }
            $topTimer.Stop()
            $results = try { $psTop.EndInvoke($asyncTop) } catch { @() }
            Dispose-PooledPS $script:_topCtx
            $topFiles2 = [System.Collections.Generic.List[object]]::new()
            foreach ($r in $results) {
                if ($null -ne $r) {
                    $sz = [Formatter]::FormatBytes([long]$r.Len)
                    $topFiles2.Add([PSCustomObject]@{ FileName=$r.Name; FileSize=$sz })
                }
            }
            if ($topFiles2.Count -eq 0) { $topFiles2.Add([PSCustomObject]@{ FileName="(ningún archivo encontrado)"; FileSize="" }) }
            $icTopFiles.ItemsSource = $topFiles2
        })
        $topTimer.Start()
    }
})

# -----------------------------------------------------------------------------
# [N9] Show-FolderScanner -- ventana emergente de análisis de carpeta
# -----------------------------------------------------------------------------
function global:Show-FolderScanner {
    param([string]$FolderPath)
    Lazy-Load "Show-FolderScanner"
    Show-FolderScanner @PSBoundParameters
}

# -----------------------------------------------------------------------------
# [N8] Ventana de gestión de programas de inicio
# -----------------------------------------------------------------------------
function global:Show-StartupManager {
    Lazy-Load "Show-StartupManager"
    Show-StartupManager @args
}

# -----------------------------------------------------------------------------
# [N8b] Ventana de Reparación SFC / DISM (con salida en tiempo real)
# -----------------------------------------------------------------------------
function global:Show-SfcDismWindow {
    param([switch]$AutoRunSfc, [switch]$AutoRunDism, [switch]$IsDryRun)
    Lazy-Load "Show-SfcDismWindow"
    Show-SfcDismWindow @PSBoundParameters
}

# -----------------------------------------------------------------------------
# [N9] Ventana de Informe de Diagnóstico (resultado del Análisis Dry Run)
# -----------------------------------------------------------------------------

# -- Helper WPF: renderizar fila de diagnóstico ------------------------------
function global:Add-DiagRow {
    param(
        [System.Windows.Window]$Window,
        [System.Windows.Controls.StackPanel]$Panel,
        [string]$Status, [string]$Label, [string]$Detail, [string]$Action = ""
    )
    $styleKey = switch ($Status) {
        "OK"   { "GoodRow" }
        "WARN" { "WarnRow" }
        "CRIT" { "CritRow" }
        default{ "InfoRow" }
    }
    $border = New-Object System.Windows.Controls.Border
    $border.Style = $Window.Resources[$styleKey]

    $grid = New-Object System.Windows.Controls.Grid
    $c0 = New-Object System.Windows.Controls.ColumnDefinition; $c0.Width = [System.Windows.GridLength]::new(32)
    $c1 = New-Object System.Windows.Controls.ColumnDefinition; $c1.Width = [System.Windows.GridLength]::new(1, [System.Windows.GridUnitType]::Star)
    $c2 = New-Object System.Windows.Controls.ColumnDefinition; $c2.Width = [System.Windows.GridLength]::Auto
    $c3 = New-Object System.Windows.Controls.ColumnDefinition; $c3.Width = [System.Windows.GridLength]::Auto
    $grid.ColumnDefinitions.Add($c0); $grid.ColumnDefinitions.Add($c1)
    $grid.ColumnDefinitions.Add($c2); $grid.ColumnDefinitions.Add($c3)

    # Col 0: Status icon (Segoe MDL2 Assets)
    $ico = New-Object System.Windows.Controls.TextBlock
    $ico.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe MDL2 Assets")
    $ico.Text = switch ($Status) { "OK" { [char]0xE73E } "WARN" { [char]0xE7BA } "CRIT" { [char]0xE711 } default { [char]0xE946 } }
    $ico.FontSize = 15; $ico.VerticalAlignment = "Center"
    [System.Windows.Controls.Grid]::SetColumn($ico, 0)
    [void]$grid.Children.Add($ico)

    # Col 1: Main label text
    $lbl = New-Object System.Windows.Controls.TextBlock
    $lbl.Text       = $Label
    $lbl.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe UI")
    $lbl.FontSize   = 12
    $lbl.Foreground = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString('#D0D8F0'))
    $lbl.TextWrapping = "Wrap"; $lbl.VerticalAlignment = "Center"
    [System.Windows.Controls.Grid]::SetColumn($lbl, 1)
    [void]$grid.Children.Add($lbl)

    # Col 2: Detail value (right side)
    if ($Detail) {
        $det = New-Object System.Windows.Controls.TextBlock
        $det.Text       = $Detail
        $det.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe UI")
        $det.FontSize   = 10; $det.FontWeight = [System.Windows.FontWeights]::Medium
        $det.Foreground = New-Object System.Windows.Media.SolidColorBrush(
            [System.Windows.Media.ColorConverter]::ConvertFromString('#6B7599'))
        $det.VerticalAlignment = "Center"
        $det.Margin = New-Object System.Windows.Thickness(12,0,8,0)
        [System.Windows.Controls.Grid]::SetColumn($det, 2)
        [void]$grid.Children.Add($det)
    }

    # Col 3: Status badge
    $badgeText = switch ($Status) { "OK" { "OK" } "WARN" { (T 'DiagBadgeWarn' 'AVISO') } "CRIT" { (T 'DiagBadgeCrit' 'CRÍTICO') } default { (T 'DiagBadgeInfo' 'INFO') } }
    $badgeBg   = switch ($Status) { "OK" { '#1B4A28' } "WARN" { '#5A4010' } "CRIT" { '#5A1828' } default { '#2A3A60' } }
    $badgeFg   = switch ($Status) { "OK" { '#4ADE80' } "WARN" { '#FBBF24' } "CRIT" { '#F87171' } default { '#7BA8E0' } }
    $bb = New-Object System.Windows.Controls.Border
    $bb.CornerRadius = New-Object System.Windows.CornerRadius(5)
    $bb.Padding = New-Object System.Windows.Thickness(8,2,8,2)
    $bb.VerticalAlignment = "Center"
    $bb.Background = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString($badgeBg))
    $bt = New-Object System.Windows.Controls.TextBlock
    $bt.Text = $badgeText; $bt.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe UI")
    $bt.FontSize = 9; $bt.FontWeight = [System.Windows.FontWeights]::Bold
    $bt.Foreground = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString($badgeFg))
    $bb.Child = $bt
    [System.Windows.Controls.Grid]::SetColumn($bb, 3)
    [void]$grid.Children.Add($bb)

    $border.Child = $grid
    [void]$Panel.Children.Add($border)
}

function global:Show-DiagnosticReport {
    param([hashtable]$Report)
    Lazy-Load "Show-DiagnosticReport"
    Show-DiagnosticReport @PSBoundParameters
}

# =============================================================================
# SCRIPT DE OPTIMIZACIÓN -- se ejecuta en runspace separado
# =============================================================================
$OptimizationScript = {
    # param() DEBE ser la primera instrucción ejecutable del script block
    # $DiagReportRef se inyecta via SessionStateProxy.SetVariable (no como argumento posicional)
    param(
        $window, $ConsoleOutput, $ProgressBar, $StatusText,
        $ProgressText, $TaskText, $options, $CancelToken
    )

    # -- Cargar DLLs dentro del runspace ----------------------------------
    # IMPORTANTE: Los runspace NO heredan los assemblies del hilo principal.
    # Cada DLL debe cargarse explícitamente aquí.
    $dllDir = $options['_DllDir']   # Inyectado desde Start-Optimization
    Add-Type -Path (Join-Path $dllDir "SysOpt.Core.dll")
    Add-Type -Path (Join-Path $dllDir "SysOpt.Collector.dll")
    Add-Type -Path (Join-Path $dllDir "SysOpt.Cleanup.dll")
    Add-Type -Path (Join-Path $dllDir "SysOpt.DiskEngine.dll")
    Add-Type -Path (Join-Path $dllDir "SysOpt.MemoryHelper.dll")
    Add-Type -Path (Join-Path $dllDir "SysOpt.Optimizer.dll")
    Add-Type -Path (Join-Path $dllDir "SysOpt.Diagnostics.dll")

    # -- Mapear hashtable $options -> OptimizeOptions DTO ------------------
    $opts = New-Object SysOpt.Optimizer.OptimizeOptions
    foreach ($key in $options.Keys) {
        if ($key.StartsWith('_')) { continue }   # skip internal keys (_DllDir)
        try {
            $prop = $opts.GetType().GetProperty($key)
            if ($prop -and $prop.PropertyType -eq [bool]) {
                $prop.SetValue($opts, [bool]$options[$key], $null)
            }
        } catch { }
    }

    # -- Callback de progreso -> Dispatcher.Invoke para actualizar UI ------
    $progressCallback = [System.Action[SysOpt.Optimizer.OptimizeProgress]]{
        param($p)
        $window.Dispatcher.Invoke([action]{
            # Actualizar barra de progreso
            if ($p.Percent -ge 0) {
                $ProgressBar.Value = $p.Percent
                $ProgressText.Text = "{0}%" -f $p.Percent
            }
            # Actualizar nombre de tarea
            if ($p.TaskName) {
                $TaskText.Text = "$($LangRS['OptCurrentTask']): {0}" -f $p.TaskName
            }
            # Actualizar consola
            if ($p.Message) {
                $ConsoleOutput.AppendText("{0}`n" -f $p.Message)
                $ConsoleOutput.ScrollToEnd()
            }
            # Actualizar barra de estado
            if ($p.Status) {
                $StatusText.Text = $p.Status
            }
        }.GetNewClosure())
    }

    # -- Ejecutar orquestador ---------------------------------------------
    $result = [SysOpt.Optimizer.OptimizerEngine]::Run(
        $opts, $CancelToken, $progressCallback)

    # -- Publicar datos diagnósticos al hilo principal --------------------
    if ($null -ne $DiagReportRef) {
        try {
            $diagHash = @{}
            foreach ($p in $result.DiagData.GetType().GetProperties()) {
                $diagHash[$p.Name] = $p.GetValue($result.DiagData, $null)
            }
            $DiagReportRef.Value = $diagHash
        } catch { }
    }

    # -- Auto-reinicio ----------------------------------------------------
    if ($result.IsDryRun -eq $false -and $options['AutoRestart'] -and
        -not $result.Cancelled) {
        $window.Dispatcher.Invoke([action]{
            $ConsoleOutput.AppendText("$($LangRS['OptRestarting'])`n")
        })
        for ($i = 10; $i -gt 0; $i--) {
            $window.Dispatcher.Invoke([action]{
                $StatusText.Text = $LangRS['OptRestartingIn'] -f $i
            }.GetNewClosure())
            Start-Sleep -Seconds 1
        }
        Restart-Computer -Force
    }
}


# =============================================================================
# EVENTOS DE BOTONES
# =============================================================================

# [N1] Botón de actualizar info del sistema
$btnRefreshInfo.Add_Click({ Update-SystemInfo })

# ===============================================================================
# MODO WIZARD -- Asistente guiado de análisis y reparación
# ===============================================================================
function global:Show-WizardWindow {
    param([hashtable]$Report)
    Lazy-Load "Show-WizardWindow"
    Show-WizardWindow @PSBoundParameters
}

$script:AllOptCheckboxes = @(
    $chkOptimizeDisks, $chkRecycleBin, $chkTempFiles, $chkUserTemp,
    $chkWUCache, $chkChkdsk, $chkClearMemory, $chkCloseProcesses,
    $chkDNSCache, $chkBrowserCache, $chkBackupRegistry, $chkCleanRegistry,
    $chkSFC, $chkDISM, $chkEventLogs, $chkShowStartup
    # chkAutoRestart y chkDryRun se excluyen intencionalmente (opciones de ejecución)
)

$script:AllCheckboxes = @(
    $chkOptimizeDisks, $chkRecycleBin, $chkTempFiles, $chkUserTemp,
    $chkWUCache, $chkChkdsk, $chkClearMemory, $chkCloseProcesses,
    $chkDNSCache, $chkBrowserCache, $chkBackupRegistry, $chkCleanRegistry,
    $chkSFC, $chkDISM, $chkEventLogs, $chkShowStartup, $chkAutoRestart, $chkDryRun
)

$btnSelectAll.Add_Click({
    $allChecked = $script:AllOptCheckboxes | ForEach-Object { $_.IsChecked } | Where-Object { -not $_ }
    $targetState = ($allChecked.Count -gt 0)   # hay alguno desmarcado -> vamos a marcar todos

    foreach ($cb in $script:AllOptCheckboxes) { $cb.IsChecked = $targetState }

    $btnSelectAll.Content = if ($targetState) { "$([char]0x2716) $(T 'BtnDeselectAll' 'Deseleccionar Todo')" } else { "$([char]0x2705) $(T 'BtnSelectAll2' 'Seleccionar Todo')" }
})

# -- Función central de arranque (dry-run o real) -----------------------------
function global:Start-Optimization {
    param([bool]$DryRunOverride = $false)
    Lazy-Load "Start-Optimization"
    Start-Optimization @PSBoundParameters
}

# Botón Iniciar
$btnStart.Add_Click({ Start-Optimization -DryRunOverride $false })

# Botón Wizard -- Asistente guiado
$btnWizard.Add_Click({
    # Check all optimization tasks
    foreach ($cb in $script:AllOptCheckboxes) { $cb.IsChecked = $true }
    $script:WizardMode = $true
    Start-Optimization -DryRunOverride $true
})

# [N2] Botón Analizar (Dry Run directo)
$btnDryRun.Add_Click({
    # Seleccionar todas las opciones para análisis completo del equipo
    foreach ($cb in $script:AllOptCheckboxes) { $cb.IsChecked = $true }
    $btnSelectAll.Content = "$([char]0x2716) $(T 'BtnDeselectAll' 'Deseleccionar Todo')"
    Start-Optimization -DryRunOverride $true
})

# Botón Cancelar
$btnCancel.Add_Click({
    if ($null -ne $script:CancelSource -and -not $script:CancelSource.IsCancellationRequested) {
        $res = Show-ThemedDialog -Title ((T "TaskConfirmCancelTitle")) `
            -Message ((T "OptConfirmCancelMsg")) `
            -Type "question" -Buttons "YesNo"
        if ($res) {
            $script:WasCancelled = $true
            $script:CancelSource.Cancel()
            $btnCancel.IsEnabled = $false
            $btnCancel.Content   = "$([char]0x23F3) Cancelando..."
            Write-Log "[!] Cancelación solicitada -- esperando fin de tarea actual..." -Level "UI"
            Write-Log "[OPT] Usuario solicitó cancelación de la optimización en curso." -Level "WARN" -NoUI
        }
    }
})

# -- Context menu: Output -----------------------------------------------------
# Limpiar Output
if ($null -ne $ctxOutputClear) {
    $ctxOutputClear.Add_Click({
        $ConsoleOutput.Clear()
    })
}

# Guardar Log (moved from bottom bar button)
if ($null -ne $ctxOutputSaveLog) {
    $ctxOutputSaveLog.Add_Click({
        $logContent = $ConsoleOutput.Text
        if ([string]::IsNullOrWhiteSpace($logContent)) {
            Show-ThemedDialog -Title (T "LogEmpty" "Log vacío") `
                -Message ((T "OptConsoleEmpty")) -Type "info"
            return
        }
        $outputDir = Join-Path $PSScriptRoot "output\console"
        if (-not (Test-Path $outputDir)) {
            [System.IO.Directory]::CreateDirectory($outputDir) | Out-Null
        }
        $saveDialog = New-Object System.Windows.Forms.SaveFileDialog
        try {
            $saveDialog.Title            = (T "DlgSaveLogTitle")
            $saveDialog.Filter           = "$((T "DlgSaveLogFilter"))|$((T "DlgAllFilesFilter"))|*.*"
            $saveDialog.DefaultExt       = "txt"
            $saveDialog.FileName         = "OptimizadorLog_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"
            $saveDialog.InitialDirectory = $outputDir

            if ($saveDialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
                try {
                    $logContent | Out-File -FilePath $saveDialog.FileName -Encoding UTF8
                    Show-ThemedDialog -Title ((T "DlgLogSavedTitle")) `
                        -Message "$((T "DlgLogSavedMsg")):`n`n$($saveDialog.FileName)" -Type "success"
                } catch {
                    Show-ThemedDialog -Title ((T "DlgSaveError")) `
                        -Message "$((T "DlgSaveError")):`n$($_.Exception.Message)" -Type "error"
                }
            }
        } finally { $saveDialog.Dispose() }
    })
}

# Abrir carpeta de logs
if ($null -ne $ctxOutputOpenLogs) {
    $ctxOutputOpenLogs.Add_Click({
        $logsPath = Join-Path $PSScriptRoot "logs"
        if (-not (Test-Path $logsPath)) {
            [System.IO.Directory]::CreateDirectory($logsPath) | Out-Null
        }
        Start-Process explorer.exe $logsPath
    })
}

# Leer último log
if ($null -ne $ctxOutputReadLast) {
    $ctxOutputReadLast.Add_Click({
        $logsPath = Join-Path $PSScriptRoot "logs"
        $today = Get-Date -Format 'yyyy-MM-dd'
        $logFile = Join-Path $logsPath "SysOpt_$today.log"
        if (-not (Test-Path $logFile)) {
            # Try finding latest log if today's doesn't exist
            $latest = Get-ChildItem $logsPath -Filter "SysOpt_*.log" -ErrorAction SilentlyContinue |
                      Sort-Object LastWriteTime -Descending | Select-Object -First 1
            if ($null -ne $latest) {
                $logFile = $latest.FullName
            } else {
                Show-ThemedDialog -Title (T "LogNotFound" "Sin logs") `
                    -Message (T "LogNotFoundMsg" "No se encontraron archivos de log.") -Type "info"
                return
            }
        }
        # Launch in separate PowerShell window with Get-Content -Wait
        $cmd = "Get-Content -Path '$logFile' -Wait -Tail 50"
        Start-Process powershell.exe -ArgumentList "-NoExit", "-Command", $cmd
    })
}

# [FIX-BUG4] ContextMenu del Output -- forzar tema al abrirse
# Los ContextMenu en Popup no siempre resuelven DynamicResource desde Window.Resources.
# Igual que el disk tree ContextMenu, aplicamos brushes explícitamente al abrir.
if ($null -ne $ConsoleOutput -and $null -ne $ConsoleOutput.ContextMenu) {
    $ConsoleOutput.ContextMenu.Add_Opened({
        param($sender, $e)
        try {
            $appRes = [System.Windows.Application]::Current.Resources
            $bg = $appRes["TB_1A1E2F"]; if ($null -ne $bg) { $sender.Background = $bg }
            $bd = $appRes["TB_3A4468"]; if ($null -ne $bd) { $sender.BorderBrush = $bd }
            $fg = $appRes["TB_E8ECF4"]
            foreach ($mi in $sender.Items) {
                if ($mi -is [System.Windows.Controls.MenuItem] -and $null -ne $fg) {
                    $mi.Foreground = $fg
                }
            }
        } catch {}
    })
}

# Botón Salir
$btnExit.Add_Click({
    try { [SysOptFallbacks]::DisposeMutex() } catch { }
    $window.Close()
})

# Liberar mutex al cerrar por la X
$window.Add_Closed({
    $script:AppClosing = $true
    # [BF3] Limpiar estado cacheado para evitar errores al reiniciar
    try { [SysOptFallbacks]::DisposeMutex() } catch { }
    try { $chartTimer.Stop() } catch { }
    try { if ($null -ne $script:DiskUiTimer) { $script:DiskUiTimer.Stop() } } catch { }
    if ($null -ne $script:DiskCounter) { try { $script:DiskCounter.Dispose() } catch { } }
    # [A3] Parar auto-refresco si activo
    try { if ($null -ne $script:AutoRefreshTimer) { $script:AutoRefreshTimer.Stop(); $script:AutoRefreshTimer = $null } } catch {}
    # [TASKPOOL] Parar timer de tareas
    try { if ($null -ne $script:TaskTimer)     { $script:TaskTimer.Stop();     $script:TaskTimer     = $null } } catch {}
    # Parar timers de operaciones async que puedan estar corriendo
    try { if ($null -ne $script:_csvTimer)     { $script:_csvTimer.Stop();     $script:_csvTimer     = $null } } catch {}
    try { if ($null -ne $script:_htmlTimer)    { $script:_htmlTimer.Stop();    $script:_htmlTimer    = $null } } catch {}
    try { if ($null -ne $script:_dedupTimer)   { $script:_dedupTimer.Stop();   $script:_dedupTimer   = $null } } catch {}
    try { if ($null -ne $script:_loadTimer)    { $script:_loadTimer.Stop();    $script:_loadTimer    = $null } } catch {}
    try { if ($null -ne $script:_entTimer)     { $script:_entTimer.Stop();     $script:_entTimer     = $null } } catch {}
    try { if ($null -ne $script:_saveTimer)    { $script:_saveTimer.Stop();    $script:_saveTimer    = $null } } catch {}
    try { if ($null -ne $script:_topTimer)     { $script:_topTimer.Stop();     $script:_topTimer     = $null } } catch {}
    try { if ($null -ne $script:_scanTimer)    { $script:_scanTimer.Stop();    $script:_scanTimer    = $null } } catch {}
    try { if ($null -ne $script:ActiveTimer)   { $script:ActiveTimer.Stop();   $script:ActiveTimer   = $null } } catch {}
    # [C3] Guardar configuración al cerrar
    try { Save-Settings } catch {}
    # [LOG] Cerrar logger (delegado a LogEngine en SysOpt.Core.dll)
    try {
        Write-Log "Sesión cerrada por el usuario." -Level "INFO" -NoUI
        [LogEngine]::Close()
    } catch {}
    # [ERR] Desregistrar handlers de error boundary
    try {
        if ($null -ne $script:UnhandledExHandler)  { [System.AppDomain]::CurrentDomain.remove_UnhandledException($script:UnhandledExHandler) }
        if ($null -ne $script:DispatcherExHandler) { $window.Dispatcher.remove_UnhandledException($script:DispatcherExHandler) }
    } catch {}
    # [WMI] CimSession eliminada -- DAL usa WMI nativo en C#

    # [CTK] Dispose() cancela el token + libera recursos -> ScanCtl211.Stop = true via bridge
    try { [ScanTokenManager]::Dispose() } catch {}
    if ($null -ne $script:DiskScanRunspace) {
        try { $script:DiskScanRunspace.Close()   } catch {}
        try { $script:DiskScanRunspace.Dispose() } catch {}
        $script:DiskScanRunspace = $null
    }
    if ($null -ne $script:DiskScanPS) {
        try { $script:DiskScanPS.Dispose() } catch {}
        $script:DiskScanPS = $null
    }
    $script:DiskScanAsync = $null

    # Vaciar cola y colecciones vivas para liberar referencias y evitar errores al relanzar
    if ($null -ne $script:ScanQueue) {
        $tmp = $null
        while ($script:ScanQueue.TryDequeue([ref]$tmp)) {}
        $script:ScanQueue = $null
    }
    if ($null -ne $script:LiveList)       { try { $script:LiveList.Clear()       } catch {}; $script:LiveList       = $null }
    if ($null -ne $script:LiveItems)      { try { $script:LiveItems.Clear()      } catch {}; $script:LiveItems      = $null }
    if ($null -ne $script:AllScannedItems){ try { $script:AllScannedItems.Clear() } catch {}; $script:AllScannedItems = $null }
    if ($null -ne $script:LiveIndexMap)   { try { $script:LiveIndexMap.Clear()   } catch {}; $script:LiveIndexMap   = $null }

    if ($null -ne $script:RunspacePool) {
        try { $script:RunspacePool.Close()   } catch {}
        try { $script:RunspacePool.Dispose() } catch {}
        $script:RunspacePool = $null
    }

    # Liberar CancellationTokenSource de optimización si estaba activo
    if ($null -ne $script:CancelSource) {
        try { $script:CancelSource.Cancel()  } catch {}
        try { $script:CancelSource.Dispose() } catch {}
        $script:CancelSource = $null
    }

    # -- [EXIT-FIX] Limpiar runspace de optimización si sigue corriendo ------
    if ($null -ne $script:ActivePowershell) {
        try { $script:ActivePowershell.Stop()    } catch {}
        try { $script:ActivePowershell.Dispose() } catch {}
        $script:ActivePowershell = $null
    }
    if ($null -ne $script:ActiveRunspace) {
        try { $script:ActiveRunspace.Close()   } catch {}
        try { $script:ActiveRunspace.Dispose() } catch {}
        $script:ActiveRunspace = $null
    }
    $script:ActiveHandle = $null

    # -- [EXIT-FIX] Limpiar contextos async pooled (load/csv/html) --------
    if ($null -ne $script:_loadCtx) {
        try { Dispose-PooledPS $script:_loadCtx } catch {}
        $script:_loadCtx = $null; $script:_loadPs = $null; $script:_loadAsync = $null
    }
    if ($null -ne $script:_csvCtx) {
        try { $script:_csvPs.Stop() } catch {}
        try { Dispose-PooledPS $script:_csvCtx } catch {}
        $script:_csvCtx = $null; $script:_csvPs = $null; $script:_csvAsync = $null
    }
    if ($null -ne $script:_htmlCtx) {
        try { $script:_htmlPs.Stop() } catch {}
        try { Dispose-PooledPS $script:_htmlCtx } catch {}
        $script:_htmlCtx = $null; $script:_htmlPs = $null; $script:_htmlAsync = $null
    }

    # -- [EXIT-FIX] Limpiar async de guardado (save settings) -------------
    if ($null -ne $script:_savePs) {
        try { $script:_savePs.Stop()    } catch {}
        try { $script:_savePs.Dispose() } catch {}
        $script:_savePs = $null
    }
    if ($null -ne $script:_saveRs) {
        try { $script:_saveRs.Close()   } catch {}
        try { $script:_saveRs.Dispose() } catch {}
        $script:_saveRs = $null
    }
    $script:_saveAsync = $null

    # -- [EXIT-FIX] GC agresivo para liberar handles de DLL ---------------
    try { Invoke-AggressiveGC } catch {}

    # -- [EXIT-FIX] Forzar cierre del proceso para matar threads huérfanos -
    # Sin esto, los threads de runspaces no-background mantienen powershell.exe vivo
    try { [Environment]::Exit(0) } catch {}
})

# -----------------------------------------------------------------------------
# ARRANQUE
# -----------------------------------------------------------------------------
# Update-SystemInfo se llama ahora desde el evento Loaded de la ventana
# -----------------------------------------------------------------------------
# Función: Ventana emergente "Acerca de la versión"
# -----------------------------------------------------------------------------
function global:Show-AboutWindow {
    Lazy-Load "Show-AboutWindow"
    Show-AboutWindow @args
}



# Conectar botón ? Tareas
$btnShowTasks = (CFN $window "btnShowTasks")
if ($null -ne $btnShowTasks) {
    $btnShowTasks.Add_Click({ Show-TasksWindow })
}
# Conectar botón ? Opciones
$btnOptions = (CFN $window "btnOptions")
if ($null -ne $btnOptions) {
    $btnOptions.Add_Click({ Show-OptionsWindow })
}

# -----------------------------------------------------------------------------
# Mensaje de bienvenida simplificado en consola (novedades -> botón [i])
# -----------------------------------------------------------------------------
Write-ConsoleMain "==========================================================="
Write-ConsoleMain "SysOpt - Windows Optimizer GUI  v$($script:AppVersion)"
Write-ConsoleMain "==========================================================="
Write-ConsoleMain (T "WelcomeLine1" "Sistema iniciado correctamente")
Write-ConsoleMain ""
Write-ConsoleMain (T "WelcomeLine4" "  o '$([char]::ConvertFromUtf32(0x1F50D)) Analizar' para ver qué se liberaría sin cambios.")
Write-ConsoleMain ""

# -- Cerrar splash y mostrar ventana principal --
Set-SplashProgress 100 (T "SplashReady" "Listo.")
try { $splashWin.Hide(); $splashWin.Close() } catch {}

$window.ShowDialog() | Out-Null