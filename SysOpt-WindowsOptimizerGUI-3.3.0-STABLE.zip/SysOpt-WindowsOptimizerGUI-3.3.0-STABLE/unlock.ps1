﻿# =============================================================================
#  SysOpt Unlocker  —  Desbloquea todos los archivos del proyecto
#  Compatibilidad: PowerShell 5.1+ · Windows 10/11
#
#  Qué desbloquea:
#    1. Archivos raíz del proyecto (SysOpt.ps1, unlock.ps1)
#    2. Librerías de scripts (libs\*.ps1, compile-dlls.ps1)
#    3. Módulos — carpeta por carpeta de modules\{id}\**
#       (soporta módulos actuales y futuros de forma automática)
# =============================================================================

Write-Host ""
Write-Host "  SysOpt Unlocker v3.3.0" -ForegroundColor Cyan
Write-Host "  ─────────────────────────────────────" -ForegroundColor DarkCyan

$totalUnlocked = 0
$totalErrors   = 0

# ---------------------------------------------------------------------------
# Función interna de desbloqueo con contador
# ---------------------------------------------------------------------------
function Invoke-UnblockFile {
    param([string]$FilePath, [string]$Label)
    try {
        Unblock-File -LiteralPath $FilePath -ErrorAction Stop
        $script:totalUnlocked++
    } catch {
        Write-Warning "  No se pudo desbloquear: $Label"
        $script:totalErrors++
    }
}

# ---------------------------------------------------------------------------
# 1. Archivos raíz
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "  [1/3] Archivos raíz..." -ForegroundColor DarkGray

$rootTargets = @(
    ".\SysOpt.ps1",
    ".\unlock.ps1"
)

foreach ($path in $rootTargets) {
    if (Test-Path -LiteralPath $path) {
        Invoke-UnblockFile -FilePath (Resolve-Path $path).Path -Label $path
    }
}

# ---------------------------------------------------------------------------
# 2. Librerías de scripts
# ---------------------------------------------------------------------------
Write-Host "  [2/3] Librerías (libs\)..." -ForegroundColor DarkGray

$libTargets = @(
    ".\libs\*.ps1",
    ".\libs\csproj\compile-dlls.ps1"
)

foreach ($pattern in $libTargets) {
    Get-ChildItem -Path $pattern -File -ErrorAction SilentlyContinue | ForEach-Object {
        Invoke-UnblockFile -FilePath $_.FullName -Label $_.Name
    }
}

# ---------------------------------------------------------------------------
# 3. Módulos — carpeta por carpeta (actual + futuros)
# ---------------------------------------------------------------------------
Write-Host "  [3/3] Módulos (modules\)..." -ForegroundColor DarkGray

$modulesRoot = ".\modules"

if (Test-Path -LiteralPath $modulesRoot -PathType Container) {

    # Desbloquear modules.json (registro global)
    $modulesJson = Join-Path $modulesRoot "modules.json"
    if (Test-Path -LiteralPath $modulesJson) {
        Invoke-UnblockFile -FilePath (Resolve-Path $modulesJson).Path -Label "modules\modules.json"
    }

    # Iterar cada subcarpeta de módulo
    $moduleDirs = Get-ChildItem -Path $modulesRoot -Directory -ErrorAction SilentlyContinue

    if ($moduleDirs) {
        foreach ($moduleDir in $moduleDirs) {
            Write-Host "       → $($moduleDir.Name)" -ForegroundColor DarkCyan

            # Obtener todos los archivos de la carpeta del módulo (incluyendo
            # subcarpetas como lang\ y libs\ para módulos futuros)
            $moduleFiles = Get-ChildItem -Path $moduleDir.FullName -File -Recurse -ErrorAction SilentlyContinue

            foreach ($file in $moduleFiles) {
                Invoke-UnblockFile -FilePath $file.FullName -Label "$($moduleDir.Name)\$($file.Name)"
            }
        }
    } else {
        Write-Host "       (Sin módulos instalados)" -ForegroundColor DarkGray
    }

} else {
    Write-Host "       (Carpeta modules\ no encontrada, omitiendo)" -ForegroundColor DarkGray
}

# ---------------------------------------------------------------------------
# Resumen final
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "  ─────────────────────────────────────" -ForegroundColor DarkCyan

if ($totalErrors -eq 0) {
    Write-Host "  OK  $totalUnlocked archivo(s) desbloqueado(s)" -ForegroundColor Green
} else {
    Write-Host "  Completado con advertencias" -ForegroundColor Yellow
    Write-Host "  Desbloqueados : $totalUnlocked" -ForegroundColor White
    Write-Host "  Errores       : $totalErrors" -ForegroundColor Yellow
}

Write-Host ""

powershell -file .\libs\csproj\compile-dlls.ps1
