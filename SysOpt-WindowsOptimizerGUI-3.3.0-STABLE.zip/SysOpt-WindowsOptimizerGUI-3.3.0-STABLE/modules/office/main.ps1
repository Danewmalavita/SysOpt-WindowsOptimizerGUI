﻿# SysOpt Office Module - Plugin de reparación y diagnóstico de Microsoft Office
# Copyright (C) 2026 Danew Malavita
#
# Este programa es software libre bajo los términos de la GPL v3+.
# Consulta el archivo LICENSE o visita <https://www.gnu.org/licenses/>.

# ═══════════════════════════════════════════════════════════════════════════════
# Section 1 — Module-scoped variables
# ═══════════════════════════════════════════════════════════════════════════════

$script:OfficeCache = @{
    Installs     = $null
    License      = $null
    Services     = $null
    Addins       = $null
    CacheTargets = $null
    LastScan     = $null
}
$script:OfficeDiag       = $null   # [SysOpt.Office.Diagnostics.DiagEngine] instance
$script:BrushConv        = $null   # [System.Windows.Media.BrushConverter] shared instance (init en Initialize-ModuleUI_office)
$script:OfficeActiveNav  = 'Detection'   # current visible panel

# ── Helper: UI Dispatcher Pump (keeps UI responsive during heavy ops) ────────
function global:Office_PumpUI {
    <#
    .SYNOPSIS  Processes pending WPF dispatcher events so the UI doesn't freeze.
    #>
    try {
        $frame = [System.Windows.Threading.DispatcherFrame]::new()
        [System.Windows.Threading.Dispatcher]::CurrentDispatcher.BeginInvoke(
            [System.Windows.Threading.DispatcherPriority]::Background,
            [System.Threading.ThreadStart]{ $frame.Continue = $false }
        ) | Out-Null
        [System.Windows.Threading.Dispatcher]::PushFrame($frame)
    } catch { }
}
$script:OfficeActiveComp = 'Outlook'     # current component sub-tab

# Panel / component name lists used by navigation helpers
$script:OfficePanelNames = @(
    'Detection','License','Services','Repair',
    'Components','Addins','Auth','Cache','Report'
)
$script:OfficeCompNames = @(
    'Outlook','Word','Excel','PPT','Access','Teams'
)

# Service → XAML suffix mapping
$script:OfficeServiceMap = [ordered]@{
    'ClickToRunSvc'        = 'C2R'
    'OfficeClickToRun'     = 'C2R'
    'Microsoft365Apps'     = 'Updater'
    'TokenBroker'          = 'Broker'
}

# ─── Disk cache — datos persistentes entre sesiones ────────────────────────
# Ruta: %TEMP%\SysOpt\modules\office\
# License TTL : 300 s (5 min)  — datos SLS/WMI, costosos
# Services TTL:  30 s           — estado de servicios Windows
$script:OfficeDiskCacheDir = [System.IO.Path]::Combine($env:TEMP, 'SysOpt', 'modules', 'office')
$script:OfficeLicCachePath = [System.IO.Path]::Combine($script:OfficeDiskCacheDir, 'license-cache.json')
$script:OfficeSvcCachePath = [System.IO.Path]::Combine($script:OfficeDiskCacheDir, 'services-cache.json')
$script:OfficeLicCacheTTL  = 300   # segundos
$script:OfficeSvcCacheTTL  = 30    # segundos
try {
    if (-not [System.IO.Directory]::Exists($script:OfficeDiskCacheDir)) {
        [System.IO.Directory]::CreateDirectory($script:OfficeDiskCacheDir) | Out-Null
    }
} catch {}

function script:Read-OfficeDiskCache {
    <# Lee un archivo JSON de caché y lo devuelve si no ha expirado (TTL). #>
    param([string]$Path, [int]$TTLSeconds)
    try {
        if (-not [System.IO.File]::Exists($Path)) { return $null }
        $fi = [System.IO.FileInfo]::new($Path)
        if (([System.DateTime]::Now - $fi.LastWriteTime).TotalSeconds -gt $TTLSeconds) { return $null }
        $json = [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8)
        return (ConvertFrom-Json $json)
    } catch { return $null }
}

function script:Write-OfficeDiskCache {
    <# Serializa un objeto a JSON y lo escribe en disco como caché. #>
    param([string]$Path, [object]$Data)
    try {
        $json = ConvertTo-Json $Data -Depth 6 -Compress
        [System.IO.File]::WriteAllText($Path, $json, [System.Text.Encoding]::UTF8)
    } catch {}
}

# ═══════════════════════════════════════════════════════════════════════════════
# Section 2 — Helper functions  (global: prefix for WPF event-handler access)
# ═══════════════════════════════════════════════════════════════════════════════

# ─── Navigation ────────────────────────────────────────────────────────────────

function global:Office_SwitchPanel {
    <#
    .SYNOPSIS  Hide all panels and show the requested one; update nav-button styles.
    #>
    param(
        [string]$PanelName,
        $Content
    )

    # Active / inactive button brushes
    $activeBg   = Get-TC 'AccentPrimary'  '#0078D4'
    $activeFg   = Get-TC 'TextOnAccent'   '#FFFFFF'
    $inactiveBg = Get-TC 'SurfaceSecondary' '#2D2D30'
    $inactiveFg = Get-TC 'TextSecondary'    '#A0A0A0'

    foreach ($name in $script:OfficePanelNames) {
        # Panel visibility
        $panel = $Content.FindName("panel$name")
        if ($panel) {
            $panel.Visibility = if ($name -eq $PanelName) { 'Visible' } else { 'Collapsed' }
        }
        # Nav-button styling
        $btn = $Content.FindName("btnNav_$name")
        if ($btn) {
            if ($name -eq $PanelName) {
                $btn.Background = $script:BrushConv.ConvertFromString($activeBg)
                $btn.Foreground = $script:BrushConv.ConvertFromString($activeFg)
            } else {
                $btn.Background = $script:BrushConv.ConvertFromString($inactiveBg)
                $btn.Foreground = $script:BrushConv.ConvertFromString($inactiveFg)
            }
        }
    }

    $script:OfficeActiveNav = $PanelName

    # Lazy-load data the first time a panel is shown
    switch ($PanelName) {
        'Detection' { if (-not $script:OfficeCache.Installs)      { Office_RunDetection        $Content } }
        'License'   { if (-not $script:OfficeCache.License)       { Office_RefreshLicense      $Content } }
        'Services'  { if (-not $script:OfficeCache.Services)      { Office_RefreshServices     $Content } }
        'Addins'    { if (-not $script:OfficeCache.Addins)        { Office_ScanAddins          $Content } }
        'Cache'     { if (-not $script:OfficeCache.CacheTargets)  { Office_CalculateCacheSizes $Content } }
    }

    Write-Log "[MOD:Office] Panel cambiado a '$PanelName'" -Level DBG
}

# ─── Detection ─────────────────────────────────────────────────────────────────

function global:Office_RunDetection {
    <#
    .SYNOPSIS  Scan for installed Office products and populate detection UI.
    #>
    param($Content)

    $statusTxt = $Content.FindName('txtDetectStatus')
    $spResults = $Content.FindName('spDetectResults')
    $spApps    = $Content.FindName('spDetectApps')

    # ── Task integration ──────────────────────────────────────────────────────
    $taskId = "office-detect"
    try { Register-Task -Id $taskId -Name (T 'Office_TaskDetect' 'Office: Detectando instalaciones') -Icon "🔍" -IconBg (Get-TC 'BgInput' '#1A2A3A') | Out-Null } catch {}

    try {
        if ($statusTxt) { $statusTxt.Text = T 'Office_DetectScanning' (T 'Office_DetectScanning' 'Analizando instalaciones...') }
        if ($spResults) { $spResults.Children.Clear() }
        if ($spApps)    { $spApps.Children.Clear() }
        Office_PumpUI

        try { Update-Task -Id $taskId -Pct 20 -Detail (T 'Office_TaskDetectRegistry' (T 'Office_DetectScanning2' 'Escaneando registro...')) } catch {}
        $detector = [SysOpt.Office.Core.OfficeDetector]::new()
        Office_PumpUI
        try { Update-Task -Id $taskId -Pct 50 -Detail (T 'Office_TaskDetectProducts' (T 'Office_DetectSearching' 'Buscando productos...')) } catch {}
        $installs = $detector.DetectInstallations()
        Office_PumpUI

        $script:OfficeCache.Installs = $installs
        $script:OfficeCache.LastScan = [datetime]::Now

        if ($null -eq $installs -or $installs.Count -eq 0) {
            if ($statusTxt) { $statusTxt.Text = T 'Office_DetectNone' (T 'Office_DetectNotFound' 'No se detectó ninguna instalación de Office') }
            $script:OfficeDiag.Warn('Detection', 'Scan', (T 'Office_DetectNotFoundEn' 'No Office installations found'), '')
            return
        }

        # Populate summary fields from first install
        $primary = $installs[0]
        $txtProd    = $Content.FindName('txtDetectProduct')
        $txtVer     = $Content.FindName('txtDetectVersion')
        $txtChan    = $Content.FindName('txtDetectChannel')
        $txtArch    = $Content.FindName('txtDetectArch')
        $txtPath    = $Content.FindName('txtDetectPath')
        $txtC2R     = $Content.FindName('txtDetectC2R')

        if ($txtProd) { $txtProd.Text = $primary.ProductName }
        if ($txtVer)  { $txtVer.Text  = $primary.Version }
        if ($txtChan) { $txtChan.Text = $primary.Channel }
        if ($txtArch) { $txtArch.Text = $primary.Architecture }
        if ($txtPath) { $txtPath.Text = $primary.InstallPath }
        if ($txtC2R)  {
            $txtC2R.Text = if ($primary.IsC2R) {
                T 'Office_DetectC2R' 'Click-to-Run detectado'
            } else {
                T 'Office_DetectMSI' 'Instalación MSI detectada'
            }
        }

        # Build a card for each installation
        $cardBg    = Get-TC 'SurfaceSecondary' '#2D2D30'
        $cardFg    = Get-TC 'TextPrimary'      '#FFFFFF'
        $accentClr = Get-TC 'AccentPrimary'    '#0078D4'

        foreach ($inst in $installs) {
            $border = New-Object System.Windows.Controls.Border
            $border.Background    = $script:BrushConv.ConvertFromString($cardBg)
            $border.CornerRadius  = [System.Windows.CornerRadius]::new(6)
            $border.Padding       = [System.Windows.Thickness]::new(14)
            $border.Margin        = [System.Windows.Thickness]::new(0,0,0,8)

            $sp = New-Object System.Windows.Controls.StackPanel
            $sp.Orientation = 'Vertical'

            # Product name header
            $header = New-Object System.Windows.Controls.TextBlock
            $header.Text       = $inst.ProductName
            $header.FontSize   = 14
            $header.FontWeight = 'SemiBold'
            $header.Foreground = $script:BrushConv.ConvertFromString($cardFg)
            $sp.Children.Add($header) | Out-Null

            # Version / Channel / Arch
            $detail = New-Object System.Windows.Controls.TextBlock
            $detail.Text       = "$($inst.Version)  •  $($inst.Channel)  •  $($inst.Architecture)"
            $detail.FontSize   = 12
            $detail.Foreground = $script:BrushConv.ConvertFromString((Get-TC 'TextSecondary' '#A0A0A0'))
            $detail.Margin     = [System.Windows.Thickness]::new(0,4,0,0)
            $sp.Children.Add($detail) | Out-Null

            # Install path
            $pathTb = New-Object System.Windows.Controls.TextBlock
            $pathTb.Text       = $inst.InstallPath
            $pathTb.FontSize   = 11
            $pathTb.Foreground = $script:BrushConv.ConvertFromString((Get-TC 'TextTertiary' '#787878'))
            $pathTb.Margin     = [System.Windows.Thickness]::new(0,2,0,0)
            $sp.Children.Add($pathTb) | Out-Null

            $border.Child = $sp
            $spResults.Children.Add($border) | Out-Null
            Office_PumpUI
            try { Update-Task -Id $taskId -Pct ([math]::Min(90, 60 + ($installs.IndexOf($inst) * 30 / [math]::Max(1, $installs.Count)))) -Detail $inst.ProductName } catch {}
        }

        # App badges from primary installation
        if ($primary.InstalledApps -and $spApps) {
            foreach ($app in $primary.InstalledApps) {
                $badge = New-Object System.Windows.Controls.Border
                $badge.Background   = $script:BrushConv.ConvertFromString($accentClr)
                $badge.CornerRadius = [System.Windows.CornerRadius]::new(4)
                $badge.Padding      = [System.Windows.Thickness]::new(10,4,10,4)
                $badge.Margin       = [System.Windows.Thickness]::new(0,0,6,0)

                $lbl = New-Object System.Windows.Controls.TextBlock
                $lbl.Text       = $app
                $lbl.FontSize   = 12
                $lbl.Foreground = $script:BrushConv.ConvertFromString((Get-TC 'TextOnAccent' '#FFFFFF'))
                $badge.Child = $lbl

                $spApps.Children.Add($badge) | Out-Null
            }
        }

        if ($statusTxt) { $statusTxt.Text = "$($installs.Count) $(T 'Office_DetectTitle' (T 'Office_DetectCountPlural' 'instalaciones detectadas'))" }
        $script:OfficeDiag.Success('Detection', 'Scan', "Detected $($installs.Count) install(s)", $primary.ProductName)
        try { Complete-Task -Id $taskId -Detail "$($installs.Count) $(T 'Office_DetectTitle' (T 'Office_DetectCountPlural' 'instalaciones detectadas'))" } catch {}

    } catch {
        $errMsg = $_.Exception.Message
        if ($statusTxt) { $statusTxt.Text = T 'Office_ErrNoOffice' (T 'Office_DetectFailedMsg' 'No se detectó Microsoft Office instalado en este sistema.') }
        $script:OfficeDiag.Error('Detection', 'Scan', (T 'Office_DetectFailedTitle' 'Detection failed'), $errMsg)
        Write-Log "[MOD:Office] Detection error: $errMsg" -Level WARN
        try { Complete-Task -Id $taskId -IsError -Detail $errMsg } catch {}
    }
}

# ─── License ───────────────────────────────────────────────────────────────────

function global:Office_RefreshLicense {
    <#
    .SYNOPSIS  Query license status and illegal-activator scan.
               Checks %TEMP% disk cache first (TTL: 300s) to avoid slow SLS queries.
    #>
    param($Content, [switch]$ForceRefresh)

    # ── Disk cache fast path ───────────────────────────────────────────────
    if (-not $ForceRefresh) {
        $cached = Read-OfficeDiskCache -Path $script:OfficeLicCachePath -TTLSeconds $script:OfficeLicCacheTTL
        if ($cached) {
            $txtProd = $Content.FindName('txtLicProduct')
            $txtType = $Content.FindName('txtLicType')
            $txtStat = $Content.FindName('txtLicStatus')
            $txtSync = $Content.FindName('txtLicLastSync')
            if ($txtProd) { $txtProd.Text = $cached.ProductName }
            if ($txtType) { $txtType.Text = $cached.LicenseType }
            if ($txtStat) { $txtStat.Text = $cached.Status }
            if ($txtSync) { $txtSync.Text = if ($cached.LastActivationSync) { $cached.LastActivationSync } else { '-' } }
            $borderKms = $Content.FindName('borderLicKms')
            if ($borderKms) { $borderKms.Visibility = if ($cached.KmsFound) { 'Visible' } else { 'Collapsed' } }
            if ($cached.KmsDetail) {
                $txtKms = $Content.FindName('txtLicKmsDetail')
                if ($txtKms) { $txtKms.Text = (T 'Office_LicKmsDetail' 'Se ha encontrado software de activacion no autorizado ({0}).') -f $cached.KmsDetail }
            }
            Write-Log "[MOD:Office] License loaded from disk cache" -Level DBG -NoUI
            return
        }
    }

    try {
        $licensor = [SysOpt.Office.Core.OfficeLicensor]::new()
        $info     = $licensor.GetLicenseInfo()

        $script:OfficeCache.License = $info

        $txtProd = $Content.FindName('txtLicProduct')
        $txtType = $Content.FindName('txtLicType')
        $txtStat = $Content.FindName('txtLicStatus')
        $txtSync = $Content.FindName('txtLicLastSync')

        if ($txtProd) { $txtProd.Text = $info.ProductName }
        if ($txtType) { $txtType.Text = $info.LicenseType }
        if ($txtStat) { $txtStat.Text = $info.Status }
        if ($txtSync) { $txtSync.Text = if ($info.LastActivationSync) { $info.LastActivationSync.ToString('yyyy-MM-dd HH:mm') } else { '—' } }

        # Illegal activator check
        $kmsResults = $licensor.ScanForIllegalActivators()
        $borderKms  = $Content.FindName('borderLicKms')
        $txtKms     = $Content.FindName('txtLicKmsDetail')

        if ($kmsResults -and $kmsResults.Count -gt 0) {
            if ($borderKms) { $borderKms.Visibility = 'Visible' }
            $detailStr = ($kmsResults -join ', ')
            if ($txtKms) {
                $txtKms.Text = (T 'Office_LicKmsDetail' 'Se ha encontrado software de activación no autorizado ({0}).') -f $detailStr
            }
            $script:OfficeDiag.Warn('License', (T 'Office_LicKmsScan' 'KMS Scan'), "Illegal activator(s) found: $detailStr", '')
        } else {
            if ($borderKms) { $borderKms.Visibility = 'Collapsed' }
            $script:OfficeDiag.Info('License', (T 'Office_LicKmsScan' 'KMS Scan'), (T 'Office_LicKmsNotFound' (T 'Office_LicKmsNone' 'No detectados')), '')
        }

        # ── Save to disk cache ──────────────────────────────────────────────
        Write-OfficeDiskCache -Path $script:OfficeLicCachePath -Data @{
            ProductName         = $info.ProductName
            LicenseType         = $info.LicenseType
            Status              = $info.Status
            LastActivationSync  = if ($info.LastActivationSync) { $info.LastActivationSync.ToString('yyyy-MM-dd HH:mm') } else { $null }
            KmsFound            = ($kmsResults -and $kmsResults.Count -gt 0)
            KmsDetail           = if ($kmsResults -and $kmsResults.Count -gt 0) { $kmsResults -join ', ' } else { $null }
        }

        $script:OfficeDiag.Success('License', 'Refresh', "License: $($info.Status)", $info.LicenseType)
        try { Complete-Task -Id $taskId -Detail "$($info.Status) — $($info.LicenseType)" } catch {}

    } catch {
        $errMsg = $_.Exception.Message
        try { Complete-Task -Id $taskId -IsError -Detail $errMsg } catch {}
        $script:OfficeDiag.Error('License', 'Refresh', (T 'Office_LicQueryFailed' 'License query failed'), $errMsg)
        Write-Log "[MOD:Office] License refresh error: $errMsg" -Level WARN
    }
}

# ─── Services ──────────────────────────────────────────────────────────────────

# ─── Office_ApplySnapshot ──────────────────────────────────────────────────────

function global:Office_ApplySnapshot {
    <#
    .SYNOPSIS
        Aplica un OfficeSnapshot a la UI y disco cache.
        Se llama desde el poll timer cuando OfficeCollector termina en background.
    .PARAMETER Snapshot  El OfficeSnapshot devuelto por OfficeCollector.CollectAll()
    .PARAMETER Content   El elemento raíz del tab Office.
    #>
    param(
        [Parameter(Mandatory)]$Snapshot,
        $Content
    )
    try {
        # ── Servicios ──────────────────────────────────────────────────────────
        if ($Snapshot.Services -and $Snapshot.Services.Count -gt 0) {
            # Escribir a disco cache → próxima llamada a Office_RefreshServices leerá de aquí
            try {
                $cacheData = $Snapshot.Services | ForEach-Object {
                    @{
                        ServiceName = $_.ServiceName
                        DisplayName = $_.DisplayName
                        Status      = $_.Status.ToString()
                        CanStart    = [bool]$_.CanStart
                        CanStop     = [bool]$_.CanStop
                    }
                }
                Write-OfficeDiskCache -Path $script:OfficeSvcCachePath -Data $cacheData
            } catch {}
            # Actualizar UI desde caché recién escrita (sin relanzar WMI/ServiceController)
            try { Office_RefreshServices $Content } catch {}
        }

        # ── Licencia ──────────────────────────────────────────────────────────
        if ($Snapshot.License) {
            $lic     = $Snapshot.License
            $kmsFnd  = ($Snapshot.IllegalActivators -and $Snapshot.IllegalActivators.Count -gt 0)
            $kmsDetail = if ($kmsFnd) { $Snapshot.IllegalActivators -join ', ' } else { $null }
            # Escribir a disco cache
            try {
                Write-OfficeDiskCache -Path $script:OfficeLicCachePath -Data @{
                    ProductName        = $lic.ProductName
                    LicenseType        = $lic.LicenseType
                    Status             = $lic.Status
                    LastActivationSync = if ($lic.LastActivationSync) { $lic.LastActivationSync.ToString('yyyy-MM-dd HH:mm') } else { $null }
                    KmsFound           = $kmsFnd
                    KmsDetail          = $kmsDetail
                }
            } catch {}
            # Actualizar UI desde caché recién escrita
            try { Office_RefreshLicense $Content } catch {}
        }

        if ($Snapshot.Error) {
            Write-Log "[MOD:Office] Collector warning: $($Snapshot.Error)" -Level WARN
        }
    } catch {
        Write-Log "[MOD:Office] Error aplicando snapshot: $_" -Level WARN
    }
}

function global:Office_RefreshServices {
    <#
    .SYNOPSIS  Query Office background services and update status badges.
               Checks %TEMP% disk cache first (TTL: 30s) to avoid SCM queries on init.
    #>
    param($Content, [switch]$ForceRefresh)

    # ── Disk cache fast path ─────────────────────────────────────
    if (-not $ForceRefresh) {
        $cachedSvcs = Read-OfficeDiskCache -Path $script:OfficeSvcCachePath -TTLSeconds $script:OfficeSvcCacheTTL
        if ($cachedSvcs) {
            $colorRun  = Get-TC 'StatusSuccess' '#27AE60'
            $colorStop = Get-TC 'StatusError'   '#E74C3C'
            $colorDis  = Get-TC 'TextTertiary'  '#787878'
            foreach ($svc in $cachedSvcs) {
                $suffix = $null
                foreach ($key in $script:OfficeServiceMap.Keys) {
                    if ($svc.ServiceName -like "*$key*" -or $svc.DisplayName -like "*$key*") {
                        $suffix = $script:OfficeServiceMap[$key]; break
                    }
                }
                if (-not $suffix) { continue }
                $badge = $Content.FindName("svcStatus$suffix")
                if ($badge) {
                    $stShort = switch ($svc.StartType) {
                        'Automatic' { T 'Office_SvcAutoShort' 'AUTOMÁTICO' }
                        'Manual'    { T 'Office_SvcManualShort' 'MANUAL' }
                        'Disabled'  { T 'Office_SvcDisabledShort' 'DESHABILITADO' }
                        default     { $svc.StartType }
                    }
                    switch ($svc.Status) {
                        'Running'  { $badge.Text = "$(T 'Office_SvcRunning'  'Ejecutándose') ($stShort)";  $badge.Foreground = $script:BrushConv.ConvertFromString($colorRun) }
                        'Stopped'  { $badge.Text = "$(T 'Office_SvcStopped'  'Detenido') ($stShort)";      $badge.Foreground = $script:BrushConv.ConvertFromString($colorStop) }
                        'Disabled' { $badge.Text = "$(T 'Office_SvcDisabled' 'Deshabilitado') ($stShort)"; $badge.Foreground = $script:BrushConv.ConvertFromString($colorDis) }
                        default    { $badge.Text = "$(T 'Office_StatusUnknown' 'Desconocido') ($stShort)"; $badge.Foreground = $script:BrushConv.ConvertFromString($colorDis) }
                    }
                }

                $btnStart   = $Content.FindName("btnSvcStart$suffix")
                $btnStop    = $Content.FindName("btnSvcStop$suffix")
                $btnRestart = $Content.FindName("btnSvcRestart$suffix")
                if ($btnStart)   { $btnStart.IsEnabled   = $svc.CanStart }
                if ($btnStop)    { $btnStop.IsEnabled     = $svc.CanStop  }
                if ($btnRestart) { $btnRestart.IsEnabled  = $svc.CanStop  }

                # Visual styling — badge border + buttons
                $disabledBg  = Get-TC 'OfficeDisabledBg' '#2E3348'
                $enabledFg   = 'White'
                $disabledFg  = Get-TC 'OfficeDisabledFg' '#6B7280'
                $bgGreen     = Get-TC 'AccentGreen'  '#66BB6A'
                $bgRed       = Get-TC 'AccentRed'    '#FF5252'
                $bgOrange    = Get-TC 'AccentOrange'  '#FFB74D'

                $badgeBorder = $Content.FindName("svcBadge$suffix")
                if ($badgeBorder) {
                    $badgeColor = switch ($svc.Status) {
                        'Running'  { Get-TC 'StatusSuccess' '#27AE60' }
                        'Stopped'  { Get-TC 'StatusError'   '#E74C3C' }
                        'Disabled' { Get-TC 'TextTertiary'  '#4A4A5A' }
                        default    { Get-TC 'OfficeStatusDisabled' '#636366' }
                    }
                    $badgeBorder.Background = $script:BrushConv.ConvertFromString($badgeColor)
                }

                $borderStart = $Content.FindName("borderSvcStart$suffix")
                if ($borderStart) {
                    $borderStart.Background = $script:BrushConv.ConvertFromString($(if ($svc.CanStart) { $bgGreen } else { $disabledBg }))
                    $borderStart.Opacity = 1.0
                }
                if ($btnStart) {
                    $btnStart.Foreground = $script:BrushConv.ConvertFromString($(if ($svc.CanStart) { $enabledFg } else { $disabledFg }))
                }

                $borderStop = $Content.FindName("borderSvcStop$suffix")
                if ($borderStop) {
                    $borderStop.Background = $script:BrushConv.ConvertFromString($(if ($svc.CanStop) { $bgRed } else { $disabledBg }))
                    $borderStop.Opacity = 1.0
                }
                if ($btnStop) {
                    $btnStop.Foreground = $script:BrushConv.ConvertFromString($(if ($svc.CanStop) { $enabledFg } else { $disabledFg }))
                }

                $borderRestart = $Content.FindName("borderSvcRestart$suffix")
                if ($borderRestart) {
                    $borderRestart.Background = $script:BrushConv.ConvertFromString($(if ($svc.CanStop) { $bgOrange } else { $disabledBg }))
                    $borderRestart.Opacity = 1.0
                }
                if ($btnRestart) {
                    $btnRestart.Foreground = $script:BrushConv.ConvertFromString($(if ($svc.CanStop) { $enabledFg } else { $disabledFg }))
                }
            }
            Write-Log "[MOD:Office] Services loaded from disk cache" -Level DBG -NoUI
            return
        }
    }

    # ── Task integration ──────────────────────────────────────────────────────
    $taskId = "office-services"
    try { Register-Task -Id $taskId -Name (T 'Office_TaskServices' 'Office: Consultando servicios') -Icon "⚙" -IconBg (Get-TC 'BgInput' '#1A201E') | Out-Null } catch {}

    try {
        $svcMgr   = [SysOpt.Office.Core.OfficeServices]::new()
        $statuses = $svcMgr.GetServicesStatus()

        $script:OfficeCache.Services = $statuses

        $colorRun  = Get-TC 'StatusSuccess' '#27AE60'
        $colorStop = Get-TC 'StatusError'   '#E74C3C'
        $colorDis  = Get-TC 'TextTertiary'  '#787878'

        foreach ($svc in $statuses) {
            # Resolve XAML suffix from service name
            $suffix = $null
            foreach ($key in $script:OfficeServiceMap.Keys) {
                if ($svc.ServiceName -like "*$key*" -or $svc.DisplayName -like "*$key*") {
                    $suffix = $script:OfficeServiceMap[$key]
                    break
                }
            }
            if (-not $suffix) { continue }

            $badge = $Content.FindName("svcStatus$suffix")
            if ($badge) {
                $stShort = switch ($svc.StartType) {
                    'Automatic' { T 'Office_SvcAutoShort' 'AUTOMÁTICO' }
                    'Manual'    { T 'Office_SvcManualShort' 'MANUAL' }
                    'Disabled'  { T 'Office_SvcDisabledShort' 'DESHABILITADO' }
                    default     { $svc.StartType }
                }
                switch ($svc.Status) {
                    'Running'  { $badge.Text = "$(T 'Office_SvcRunning'  'Ejecutándose') ($stShort)";  $badge.Foreground = $script:BrushConv.ConvertFromString($colorRun) }
                    'Stopped'  { $badge.Text = "$(T 'Office_SvcStopped'  'Detenido') ($stShort)";      $badge.Foreground = $script:BrushConv.ConvertFromString($colorStop) }
                    'Disabled' { $badge.Text = "$(T 'Office_SvcDisabled' 'Deshabilitado') ($stShort)"; $badge.Foreground = $script:BrushConv.ConvertFromString($colorDis) }
                    default    { $badge.Text = "$(T 'Office_StatusUnknown' 'Desconocido') ($stShort)"; $badge.Foreground = $script:BrushConv.ConvertFromString($colorDis) }
                }
            }

            # Enable / disable action buttons
            $btnStart   = $Content.FindName("btnSvcStart$suffix")
            $btnStop    = $Content.FindName("btnSvcStop$suffix")
            $btnRestart = $Content.FindName("btnSvcRestart$suffix")

            if ($btnStart)   { $btnStart.IsEnabled   = $svc.CanStart }
            if ($btnStop)    { $btnStop.IsEnabled     = $svc.CanStop }
            if ($btnRestart) { $btnRestart.IsEnabled  = $svc.CanStop }

            # Visual styling — badge border + buttons
            $disabledBg  = Get-TC 'OfficeDisabledBg' '#2E3348'
            $enabledFg   = 'White'
            $disabledFg  = Get-TC 'OfficeDisabledFg' '#6B7280'
            $bgGreen     = Get-TC 'AccentGreen'  '#66BB6A'
            $bgRed       = Get-TC 'AccentRed'    '#FF5252'
            $bgOrange    = Get-TC 'AccentOrange' '#FFB74D'

            $badgeBorder = $Content.FindName("svcBadge$suffix")
            if ($badgeBorder) {
                $badgeColor = switch ($svc.Status) {
                    'Running'  { Get-TC 'StatusSuccess' '#27AE60' }
                    'Stopped'  { Get-TC 'StatusError'   '#E74C3C' }
                    'Disabled' { Get-TC 'TextTertiary'  '#4A4A5A' }
                    default    { Get-TC 'OfficeStatusDisabled' '#636366' }
                }
                $badgeBorder.Background = $script:BrushConv.ConvertFromString($badgeColor)
            }

            $borderStart = $Content.FindName("borderSvcStart$suffix")
            if ($borderStart) {
                $borderStart.Background = $script:BrushConv.ConvertFromString($(if ($svc.CanStart) { $bgGreen } else { $disabledBg }))
                $borderStart.Opacity = 1.0
            }
            if ($btnStart) {
                $btnStart.Foreground = $script:BrushConv.ConvertFromString($(if ($svc.CanStart) { $enabledFg } else { $disabledFg }))
            }

            $borderStop = $Content.FindName("borderSvcStop$suffix")
            if ($borderStop) {
                $borderStop.Background = $script:BrushConv.ConvertFromString($(if ($svc.CanStop) { $bgRed } else { $disabledBg }))
                $borderStop.Opacity = 1.0
            }
            if ($btnStop) {
                $btnStop.Foreground = $script:BrushConv.ConvertFromString($(if ($svc.CanStop) { $enabledFg } else { $disabledFg }))
            }

            $borderRestart = $Content.FindName("borderSvcRestart$suffix")
            if ($borderRestart) {
                $borderRestart.Background = $script:BrushConv.ConvertFromString($(if ($svc.CanStop) { $bgOrange } else { $disabledBg }))
                $borderRestart.Opacity = 1.0
            }
            if ($btnRestart) {
                $btnRestart.Foreground = $script:BrushConv.ConvertFromString($(if ($svc.CanStop) { $enabledFg } else { $disabledFg }))
            }
        }

        # ── Save to disk cache ──────────────────────────────────────────────
        try {
            $cacheData = $statuses | ForEach-Object {
                @{
                    ServiceName = $_.ServiceName
                    DisplayName = $_.DisplayName
                    Status      = $_.Status.ToString()
                    StartType   = $_.StartType
                    CanStart    = $_.CanStart
                    CanStop     = $_.CanStop
                }
            }
            Write-OfficeDiskCache -Path $script:OfficeSvcCachePath -Data $cacheData
        } catch {}

        $script:OfficeDiag.Info('Services', 'Refresh', "Queried $($statuses.Count) service(s)", '')
        try { Complete-Task -Id $taskId -Detail "$($statuses.Count) $(T 'Office_TaskSvcQueried' (T 'Office_TaskSvcQueried' 'servicios consultados'))" } catch {}

    } catch {
        $errMsg = $_.Exception.Message
        try { Complete-Task -Id $taskId -IsError -Detail $errMsg } catch {}
        $script:OfficeDiag.Error('Services', 'Refresh', (T 'Office_SvcQueryFailed' 'Service query failed'), $errMsg)
        Write-Log "[MOD:Office] Services refresh error: $errMsg" -Level WARN
    }
}

function global:Office_ServiceAction {
    <#
    .SYNOPSIS  Start, Stop, or Restart an Office service.
    #>
    param(
        [string]$ServiceName,
        [string]$Action,
        $Content
    )

    try {
        $svcMgr = [SysOpt.Office.Core.OfficeServices]::new()

        switch ($Action) {
            'Start'   { $svcMgr.StartService($ServiceName) }
            'Stop'    { $svcMgr.StopService($ServiceName) }
            'Restart' {
                $svcMgr.StopService($ServiceName)
                Start-Sleep -Milliseconds 800
                $svcMgr.StartService($ServiceName)
            }
        }

        $script:OfficeDiag.Success('Services', $Action, "$Action '$ServiceName' succeeded", '')
        Write-Log "[MOD:Office] Service $Action '$ServiceName' OK" -Level INFO

        # Refresh UI
        Office_RefreshServices $Content

    } catch {
        $errMsg = $_.Exception.Message
        $script:OfficeDiag.Error('Services', $Action, "$Action '$ServiceName' failed", $errMsg)
        Write-Log "[MOD:Office] Service $Action error: $errMsg" -Level WARN
    }
}

# ─── Repair — Basic ───────────────────────────────────────────────────────────

function global:Office_QuickRepair {
    <#
    .SYNOPSIS  Run a Click-to-Run quick repair (offline, ~5 min).
    #>
    param($Content)

    $progress  = $Content.FindName('progressRepair')
    $txtStatus = $Content.FindName('txtRepairStatus')

    try {
        $c2rPath = [SysOpt.Office.Repair.BasicRepair]::GetC2RExePath()
        if (-not $c2rPath -or -not (Test-Path $c2rPath)) {
            if ($txtStatus) { $txtStatus.Text = T 'Office_ErrC2RNotFound' 'No se encontró Click-to-Run (OfficeC2RClient.exe).' }
            $script:OfficeDiag.Error('Repair', 'QuickRepair', (T 'Office_C2RNotFound' 'C2R exe not found'), "$c2rPath")
            return
        }

        $args = [SysOpt.Office.Repair.BasicRepair]::GetQuickRepairArgs()

        if ($progress)  { $progress.IsIndeterminate = $true; $progress.Visibility = 'Visible' }
        if ($txtStatus) { $txtStatus.Text = T 'Office_RepairProgress' 'Reparando...' }

        $proc = Start-Process -FilePath $c2rPath -ArgumentList $args -PassThru -Wait
        $exitCode = $proc.ExitCode

        if ($progress)  { $progress.IsIndeterminate = $false; $progress.Visibility = 'Collapsed' }

        if ($exitCode -eq 0) {
            if ($txtStatus) { $txtStatus.Text = T 'Office_RepairSuccess' (T 'Office_QuickRepairOK' 'Reparación completada correctamente.') }
            $script:OfficeDiag.Success('Repair', 'QuickRepair', (T 'Office_QuickRepairDone' 'Quick repair completed'), "ExitCode=$exitCode")
        } else {
            $failMsg = (T 'Office_RepairFailed' 'Error durante la reparación: {0}') -f "ExitCode=$exitCode"
            if ($txtStatus) { $txtStatus.Text = $failMsg }
            $script:OfficeDiag.Warn('Repair', 'QuickRepair', (T 'Office_QuickRepairWarn' 'Quick repair finished with warnings'), "ExitCode=$exitCode")
        }

    } catch {
        $errMsg = $_.Exception.Message
        if ($progress)  { $progress.IsIndeterminate = $false; $progress.Visibility = 'Collapsed' }
        if ($txtStatus) { $txtStatus.Text = (T 'Office_RepairFailed' 'Error durante la reparación: {0}') -f $errMsg }
        $script:OfficeDiag.Error('Repair', 'QuickRepair', (T 'Office_QuickRepairFail' 'Quick repair failed'), $errMsg)
        Write-Log "[MOD:Office] QuickRepair error: $errMsg" -Level WARN
    }
}

function global:Office_OnlineRepair {
    <#
    .SYNOPSIS  Run a Click-to-Run online repair (downloads components, ~30-60 min).
    #>
    param($Content)

    # Confirm with user — this is a heavy operation
    $result = Show-ThemedDialog `
        -Title   (T 'Office_RepairOnlineWarnTitle' (T 'Office_OnlineRepairTitle' 'Advertencia — Reparación en línea')) `
        -Message (T 'Office_RepairOnlineWarnBody'  'La reparación en línea descargará e instalará componentes de Office desde Internet. Este proceso puede tardar entre 30 y 60 minutos y requiere que Office esté cerrado. ¿Desea continuar?') `
        -Type    'question' `
        -Buttons 'YesNo'

    if ($result -ne 'Yes') {
        Write-Log "[MOD:Office] OnlineRepair cancelled by user" -Level DBG
        return
    }

    $progress  = $Content.FindName('progressRepair')
    $txtStatus = $Content.FindName('txtRepairStatus')

    try {
        $c2rPath = [SysOpt.Office.Repair.BasicRepair]::GetC2RExePath()
        if (-not $c2rPath -or -not (Test-Path $c2rPath)) {
            if ($txtStatus) { $txtStatus.Text = T 'Office_ErrC2RNotFound' 'No se encontró Click-to-Run (OfficeC2RClient.exe).' }
            $script:OfficeDiag.Error('Repair', 'OnlineRepair', (T 'Office_C2RNotFound' 'C2R exe not found'), "$c2rPath")
            return
        }

        $args = [SysOpt.Office.Repair.BasicRepair]::GetOnlineRepairArgs()

        if ($progress)  { $progress.IsIndeterminate = $true; $progress.Visibility = 'Visible' }
        if ($txtStatus) { $txtStatus.Text = T 'Office_RepairProgress' 'Reparando...' }

        $proc = Start-Process -FilePath $c2rPath -ArgumentList $args -PassThru -Wait
        $exitCode = $proc.ExitCode

        if ($progress)  { $progress.IsIndeterminate = $false; $progress.Visibility = 'Collapsed' }

        if ($exitCode -eq 0) {
            if ($txtStatus) { $txtStatus.Text = T 'Office_RepairSuccess' (T 'Office_QuickRepairOK' 'Reparación completada correctamente.') }
            $script:OfficeDiag.Success('Repair', 'OnlineRepair', (T 'Office_OnlineRepairOK' 'Online repair completed'), "ExitCode=$exitCode")
        } else {
            $failMsg = (T 'Office_RepairFailed' 'Error durante la reparación: {0}') -f "ExitCode=$exitCode"
            if ($txtStatus) { $txtStatus.Text = $failMsg }
            $script:OfficeDiag.Warn('Repair', 'OnlineRepair', (T 'Office_OnlineRepairWarn' 'Online repair finished with warnings'), "ExitCode=$exitCode")
        }

    } catch {
        $errMsg = $_.Exception.Message
        if ($progress)  { $progress.IsIndeterminate = $false; $progress.Visibility = 'Collapsed' }
        if ($txtStatus) { $txtStatus.Text = (T 'Office_RepairFailed' 'Error durante la reparación: {0}') -f $errMsg }
        $script:OfficeDiag.Error('Repair', 'OnlineRepair', (T 'Office_OnlineRepairFail' 'Online repair failed'), $errMsg)
        Write-Log "[MOD:Office] OnlineRepair error: $errMsg" -Level WARN
    }
}

# ─── Components — Navigation ──────────────────────────────────────────────────

function global:Office_SwitchComponent {
    <#
    .SYNOPSIS  Switch the visible component sub-panel.
    #>
    param(
        [string]$CompName,
        $Content
    )

    $activeBg  = Get-TC 'AccentPrimary'    '#0078D4'
    $activeFg  = Get-TC 'TextOnAccent'     '#FFFFFF'
    $inactBg   = Get-TC 'SurfaceSecondary' '#2D2D30'
    $inactFg   = Get-TC 'TextSecondary'    '#A0A0A0'

    foreach ($name in $script:OfficeCompNames) {
        $panel = $Content.FindName("panelComp$name")
        if ($panel) {
            $panel.Visibility = if ($name -eq $CompName) { 'Visible' } else { 'Collapsed' }
        }
        $btn = $Content.FindName("btnComp$name")
        if ($btn) {
            if ($name -eq $CompName) {
                $btn.Background = $script:BrushConv.ConvertFromString($activeBg)
                $btn.Foreground = $script:BrushConv.ConvertFromString($activeFg)
            } else {
                $btn.Background = $script:BrushConv.ConvertFromString($inactBg)
                $btn.Foreground = $script:BrushConv.ConvertFromString($inactFg)
            }
        }
    }

    $script:OfficeActiveComp = $CompName
    Write-Log "[MOD:Office] Component panel cambiado a '$CompName'" -Level DBG
}

# ─── Components — Outlook ─────────────────────────────────────────────────────

function global:Office_RepairOutlook {
    <#
    .SYNOPSIS  Repair selected Outlook items (profile, OST, PST, search, addins).
    #>
    param($Content)

    $actions   = @()
    $anyFailed = $false

    try {
        # Rebuild profile
        $chk = $Content.FindName('chkOutlookProfile')
        if ($chk -and $chk.IsChecked) {
            try {
                $profiles = [SysOpt.Office.Repair.OutlookRepair]::GetProfileNames()
                foreach ($prof in $profiles) {
                    # Registry rebuild — requires elevation
                    $regPath = "HKCU:\Software\Microsoft\Office\16.0\Outlook\Profiles\$prof"
                    if (Test-Path $regPath) {
                        Rename-Item $regPath "$prof.bak_$(Get-Date -Format 'yyyyMMddHHmmss')" -ErrorAction Stop
                    }
                }
                $actions += 'RebuildProfile'
                $script:OfficeDiag.Success('Outlook', 'RebuildProfile', "Rebuilt $($profiles.Count) profile(s)", '')
            } catch {
                $anyFailed = $true
                $script:OfficeDiag.Error('Outlook', 'RebuildProfile', 'Failed', $_.Exception.Message)
            }
        }

        # Rebuild OST
        $chk = $Content.FindName('chkOutlookOST')
        if ($chk -and $chk.IsChecked) {
            try {
                $ostFiles = [SysOpt.Office.Repair.OutlookRepair]::FindOSTFiles()
                foreach ($ost in $ostFiles) {
                    if (Test-Path $ost) {
                        $newName = "$ost.old_$(Get-Date -Format 'yyyyMMddHHmmss')"
                        Rename-Item $ost $newName -ErrorAction Stop
                    }
                }
                $actions += 'RebuildOST'
                $script:OfficeDiag.Success('Outlook', 'RebuildOST', "Renamed $($ostFiles.Count) OST file(s)", '')
            } catch {
                $anyFailed = $true
                $script:OfficeDiag.Error('Outlook', 'RebuildOST', 'Failed', $_.Exception.Message)
            }
        }

        # Compact PST via ScanPST
        $chk = $Content.FindName('chkOutlookPST')
        if ($chk -and $chk.IsChecked) {
            try {
                $scanPst = [SysOpt.Office.Repair.OutlookRepair]::GetScanPSTPath()
                if ($scanPst -and (Test-Path $scanPst)) {
                    $pstFiles = [SysOpt.Office.Repair.OutlookRepair]::FindPSTFiles()
                    foreach ($pst in $pstFiles) {
                        if (Test-Path $pst) {
                            Start-Process -FilePath $scanPst -ArgumentList "`"$pst`"" -Wait -ErrorAction Stop
                        }
                    }
                    $actions += 'CompactPST'
                    $script:OfficeDiag.Success('Outlook', 'CompactPST', "Processed $($pstFiles.Count) PST file(s)", '')
                } else {
                    $script:OfficeDiag.Warn('Outlook', 'CompactPST', 'ScanPST.exe not found', "$scanPst")
                }
            } catch {
                $anyFailed = $true
                $script:OfficeDiag.Error('Outlook', 'CompactPST', 'Failed', $_.Exception.Message)
            }
        }

        # Repair search index
        $chk = $Content.FindName('chkOutlookSearch')
        if ($chk -and $chk.IsChecked) {
            try {
                $indexPath = [SysOpt.Office.Repair.OutlookRepair]::GetSearchIndexPath()
                if ($indexPath -and (Test-Path $indexPath)) {
                    Remove-Item $indexPath -Recurse -Force -ErrorAction Stop
                }
                $actions += 'RepairSearch'
                $script:OfficeDiag.Success('Outlook', 'RepairSearch', (T 'Office_SearchIndexCleared' 'Search index cleared'), $indexPath)
            } catch {
                $anyFailed = $true
                $script:OfficeDiag.Error('Outlook', 'RepairSearch', 'Failed', $_.Exception.Message)
            }
        }

        # Re-enable disabled addins
        $chk = $Content.FindName('chkOutlookAddins')
        if ($chk -and $chk.IsChecked) {
            try {
                $disabled = [SysOpt.Office.Repair.OutlookRepair]::GetDisabledAddins()
                foreach ($addin in $disabled) {
                    # Re-enable via registry
                    $regPath = "HKCU:\Software\Microsoft\Office\16.0\Outlook\Resiliency\DisabledItems"
                    if (Test-Path $regPath) {
                        Remove-ItemProperty -Path $regPath -Name $addin -ErrorAction SilentlyContinue
                    }
                }
                $actions += 'ResetAddins'
                $script:OfficeDiag.Success('Outlook', 'ResetAddins', "Re-enabled $($disabled.Count) addin(s)", '')
            } catch {
                $anyFailed = $true
                $script:OfficeDiag.Error('Outlook', 'ResetAddins', 'Failed', $_.Exception.Message)
            }
        }

        if ($actions.Count -gt 0) {
            # ── Feedback al usuario ──────────────────────────────────────
            $outlookLabels = @{
                'RebuildProfile' = T 'Office_OutlookActionProfile' (T 'Office_MailProfilesRebuilt' 'Perfiles de correo reconstruidos')
                'RebuildOST'     = T 'Office_OutlookActionOST'     (T 'Office_OstRenamed' 'Archivos OST renombrados (se regenerarán)')
                'CompactPST'     = T 'Office_OutlookActionPST'     (T 'Office_PstCompacted' 'Archivos PST compactados')
                'RepairSearch'   = T 'Office_OutlookActionSearch'  'Índice de búsqueda limpiado'
                'ResetAddins'    = T 'Office_OutlookActionAddins'  'Complementos deshabilitados re-habilitados'
            }
            $detailLines = $actions | ForEach-Object { $outlookLabels[$_] }
            $type = if ($anyFailed) { 'warning' } else { 'info' }
            $msg = (T 'Office_RepairDoneMsg' 'Reparación completada:') + "`n`n• " + ($detailLines -join "`n• ")
            if ($anyFailed) { $msg += "`n`n" + (T 'Office_RepairPartialWarn' 'Algunas acciones fallaron. Revisa el informe de diagnóstico para más detalles.') }
            Show-ThemedDialog -Title (T 'Office_DlgSuccessTitle' 'Operación completada') -Message $msg -Type $type -Buttons 'OK'
            Write-Log "[MOD:Office] Outlook repair completed: $($actions -join ', ')" -Level INFO
        }

    } catch {
        $script:OfficeDiag.Error('Outlook', 'Repair', (T 'Office_DiagUnexpectedError' 'Unexpected error'), $_.Exception.Message)
        Show-ThemedDialog -Title (T 'Office_DlgErrorTitle' 'Error') -Message ((T 'Office_RepairFailed' 'Error durante la reparación: {0}') -f $_.Exception.Message) -Type 'error' -Buttons 'OK'
        Write-Log "[MOD:Office] Outlook repair error: $($_.Exception.Message)" -Level WARN
    }
}

function global:Office_CheckOutlookConnectivity {
    <#
    .SYNOPSIS  Test SMTP connectivity and update status text.
    #>
    param($Content)

    $txtConn = $Content.FindName('txtOutlookConnStatus')
    if (-not $txtConn) { return }

    try {
        $smtpResult = [SysOpt.Office.Repair.OutlookRepair]::TestSMTPConnectivity('smtp.office365.com', 587)

        if ($smtpResult) {
            $txtConn.Text       = T 'Office_OutlookSMTPOK' 'SMTP accesible'
            $txtConn.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString((Get-TC 'StatusSuccess' '#27AE60'))
        } else {
            $txtConn.Text       = T 'Office_OutlookSMTPFail' 'SMTP no accesible'
            $txtConn.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString((Get-TC 'StatusError' '#E74C3C'))
        }

        $script:OfficeDiag.Info('Outlook', 'Connectivity', "SMTP test: $smtpResult", 'smtp.office365.com:587')

    } catch {
        $txtConn.Text = T 'Office_OutlookSMTPFail' 'SMTP no accesible'
        $script:OfficeDiag.Error('Outlook', 'Connectivity', (T 'Office_DiagSmtpFailed' 'SMTP test failed'), $_.Exception.Message)
    }
}

# ─── Components — Word ─────────────────────────────────────────────────────────

function global:Office_RepairWord {
    <#
    .SYNOPSIS  Repair selected Word items.
    #>
    param($Content)

    try {
        # Restore Normal.dotm
        $chk = $Content.FindName('chkWordNormal')
        if ($chk -and $chk.IsChecked) {
            try {
                $dotmPath = [SysOpt.Office.Repair.AppRepair]::GetNormalDotmPath()
                if ($dotmPath -and (Test-Path $dotmPath)) {
                    Rename-Item $dotmPath "$dotmPath.bak_$(Get-Date -Format 'yyyyMMddHHmmss')" -ErrorAction Stop
                }
                $script:OfficeDiag.Success('Word', 'RestoreNormal', (T 'Office_DiagNormalRenamed' 'Normal.dotm renamed (will regenerate)'), $dotmPath)
            } catch {
                $script:OfficeDiag.Error('Word', 'RestoreNormal', 'Failed', $_.Exception.Message)
            }
        }

        # Reset defaults
        $chk = $Content.FindName('chkWordDefaults')
        if ($chk -and $chk.IsChecked) {
            try {
                $regPath = [SysOpt.Office.Repair.AppRepair]::GetResetRegistryPath('Word')
                if ($regPath -and (Test-Path $regPath)) {
                    Remove-Item $regPath -Recurse -Force -ErrorAction Stop
                }
                $script:OfficeDiag.Success('Word', 'ResetDefaults', 'Registry defaults cleared', $regPath)
            } catch {
                $script:OfficeDiag.Error('Word', 'ResetDefaults', 'Failed', $_.Exception.Message)
            }
        }

        # Clean startup templates
        $chk = $Content.FindName('chkWordTemplates')
        if ($chk -and $chk.IsChecked) {
            try {
                $startupPath = [SysOpt.Office.Repair.AppRepair]::GetStartupFolderPath('Word')
                if ($startupPath -and (Test-Path $startupPath)) {
                    $templates = [SysOpt.Office.Repair.AppRepair]::GetStartupTemplates('Word')
                    foreach ($t in $templates) {
                        if (Test-Path $t) {
                            Remove-Item $t -Force -ErrorAction Stop
                        }
                    }
                }
                $script:OfficeDiag.Success('Word', 'CleanTemplates', (T 'Office_DiagStartupCleaned' 'Startup templates cleaned'), $startupPath)
            } catch {
                $script:OfficeDiag.Error('Word', 'CleanTemplates', 'Failed', $_.Exception.Message)
            }
        }

        # Repair addins
        $chk = $Content.FindName('chkWordAddins')
        if ($chk -and $chk.IsChecked) {
            try {
                $regPath = "HKCU:\Software\Microsoft\Office\16.0\Word\Resiliency\DisabledItems"
                if (Test-Path $regPath) {
                    Remove-Item $regPath -Recurse -Force -ErrorAction Stop
                }
                $script:OfficeDiag.Success('Word', 'RepairAddins', (T 'Office_DiagDisabledCleared' 'Disabled items cleared'), $regPath)
            } catch {
                $script:OfficeDiag.Error('Word', 'RepairAddins', 'Failed', $_.Exception.Message)
            }
        }

        # Verify macros
        $chk = $Content.FindName('chkWordMacros')
        if ($chk -and $chk.IsChecked) {
            try {
                $vbaOk = [SysOpt.Office.Repair.AppRepair]::CheckVBAProject()
                if ($vbaOk) {
                    $script:OfficeDiag.Success('Word', 'CheckMacros', (T 'Office_DiagVbaOK' 'VBA project integrity OK'), '')
                } else {
                    $script:OfficeDiag.Warn('Word', 'CheckMacros', (T 'Office_DiagVbaIssues' 'VBA project integrity issues detected'), '')
                }
            } catch {
                $script:OfficeDiag.Error('Word', 'CheckMacros', 'Failed', $_.Exception.Message)
            }
        }

        # ── Feedback al usuario ──────────────────────────────────────
        $wordActions = @()
        if ($Content.FindName('chkWordNormal')    -and $Content.FindName('chkWordNormal').IsChecked)    { $wordActions += T 'Office_WordActionNormal'    'Normal.dotm restaurado' }
        if ($Content.FindName('chkWordDefaults')   -and $Content.FindName('chkWordDefaults').IsChecked)   { $wordActions += T 'Office_WordActionDefaults'   'Configuración por defecto restablecida' }
        if ($Content.FindName('chkWordTemplates')  -and $Content.FindName('chkWordTemplates').IsChecked)  { $wordActions += T 'Office_WordActionTemplates'  'Plantillas de inicio limpiadas' }
        if ($Content.FindName('chkWordAddins')     -and $Content.FindName('chkWordAddins').IsChecked)     { $wordActions += T 'Office_WordActionAddins'     'Complementos deshabilitados re-habilitados' }
        if ($Content.FindName('chkWordMacros')     -and $Content.FindName('chkWordMacros').IsChecked)     { $wordActions += T 'Office_WordActionMacros'     'Integridad de macros verificada' }

        if ($wordActions.Count -gt 0) {
            $msg = (T 'Office_RepairDoneMsg' 'Reparación completada:') + "`n`n• " + ($wordActions -join "`n• ")
            Show-ThemedDialog -Title (T 'Office_DlgSuccessTitle' 'Operación completada') -Message $msg -Type 'info' -Buttons 'OK'
        }

        Write-Log "[MOD:Office] Word repair completed" -Level INFO

    } catch {
        $script:OfficeDiag.Error('Word', 'Repair', (T 'Office_DiagUnexpectedError' 'Unexpected error'), $_.Exception.Message)
        Show-ThemedDialog -Title (T 'Office_DlgErrorTitle' 'Error') -Message ((T 'Office_RepairFailed' 'Error durante la reparación: {0}') -f $_.Exception.Message) -Type 'error' -Buttons 'OK'
        Write-Log "[MOD:Office] Word repair error: $($_.Exception.Message)" -Level WARN
    }
}

# ─── Components — Excel ────────────────────────────────────────────────────────

function global:Office_RepairExcel {
    <#
    .SYNOPSIS  Repair selected Excel items.
    #>
    param($Content)

    try {
        # Reset defaults
        $chk = $Content.FindName('chkExcelDefaults')
        if ($chk -and $chk.IsChecked) {
            try {
                $regPath = [SysOpt.Office.Repair.AppRepair]::GetResetRegistryPath('Excel')
                if ($regPath -and (Test-Path $regPath)) {
                    Remove-Item $regPath -Recurse -Force -ErrorAction Stop
                }
                $script:OfficeDiag.Success('Excel', 'ResetDefaults', 'Registry defaults cleared', $regPath)
            } catch {
                $script:OfficeDiag.Error('Excel', 'ResetDefaults', 'Failed', $_.Exception.Message)
            }
        }

        # Clean templates
        $chk = $Content.FindName('chkExcelTemplates')
        if ($chk -and $chk.IsChecked) {
            try {
                $startupPath = [SysOpt.Office.Repair.AppRepair]::GetStartupFolderPath('Excel')
                if ($startupPath -and (Test-Path $startupPath)) {
                    $templates = [SysOpt.Office.Repair.AppRepair]::GetStartupTemplates('Excel')
                    foreach ($t in $templates) {
                        if (Test-Path $t) { Remove-Item $t -Force -ErrorAction Stop }
                    }
                }
                $script:OfficeDiag.Success('Excel', 'CleanTemplates', (T 'Office_DiagStartupCleaned' 'Startup templates cleaned'), $startupPath)
            } catch {
                $script:OfficeDiag.Error('Excel', 'CleanTemplates', 'Failed', $_.Exception.Message)
            }
        }

        # Repair addins
        $chk = $Content.FindName('chkExcelAddins')
        if ($chk -and $chk.IsChecked) {
            try {
                $regPath = "HKCU:\Software\Microsoft\Office\16.0\Excel\Resiliency\DisabledItems"
                if (Test-Path $regPath) {
                    Remove-Item $regPath -Recurse -Force -ErrorAction Stop
                }
                $script:OfficeDiag.Success('Excel', 'RepairAddins', (T 'Office_DiagDisabledCleared' 'Disabled items cleared'), $regPath)
            } catch {
                $script:OfficeDiag.Error('Excel', 'RepairAddins', 'Failed', $_.Exception.Message)
            }
        }

        # ── Feedback al usuario ──────────────────────────────────────
        $excelActions = @()
        if ($Content.FindName('chkExcelDefaults') -and $Content.FindName('chkExcelDefaults').IsChecked) { $excelActions += T 'Office_ExcelActionDefaults' 'Configuración por defecto restablecida' }
        if ($Content.FindName('chkExcelTemplates') -and $Content.FindName('chkExcelTemplates').IsChecked) { $excelActions += T 'Office_ExcelActionTemplates' 'Plantillas de inicio limpiadas' }
        if ($Content.FindName('chkExcelAddins') -and $Content.FindName('chkExcelAddins').IsChecked) { $excelActions += T 'Office_ExcelActionAddins' 'Complementos deshabilitados re-habilitados' }

        if ($excelActions.Count -gt 0) {
            $msg = (T 'Office_RepairDoneMsg' 'Reparación completada:') + "`n`n• " + ($excelActions -join "`n• ")
            Show-ThemedDialog -Title (T 'Office_DlgSuccessTitle' 'Operación completada') -Message $msg -Type 'info' -Buttons 'OK'
        }

        Write-Log "[MOD:Office] Excel repair completed" -Level INFO

    } catch {
        $script:OfficeDiag.Error('Excel', 'Repair', (T 'Office_DiagUnexpectedError' 'Unexpected error'), $_.Exception.Message)
        Show-ThemedDialog -Title (T 'Office_DlgErrorTitle' 'Error') -Message ((T 'Office_RepairFailed' 'Error durante la reparación: {0}') -f $_.Exception.Message) -Type 'error' -Buttons 'OK'
        Write-Log "[MOD:Office] Excel repair error: $($_.Exception.Message)" -Level WARN
    }
}

# ─── Components — PowerPoint ──────────────────────────────────────────────────

function global:Office_RepairPPT {
    <#
    .SYNOPSIS  Repair selected PowerPoint items.
    #>
    param($Content)

    try {
        # Reset defaults
        $chk = $Content.FindName('chkPPTDefaults')
        if ($chk -and $chk.IsChecked) {
            try {
                $regPath = [SysOpt.Office.Repair.AppRepair]::GetResetRegistryPath('PowerPoint')
                if ($regPath -and (Test-Path $regPath)) {
                    Remove-Item $regPath -Recurse -Force -ErrorAction Stop
                }
                $script:OfficeDiag.Success('PowerPoint', 'ResetDefaults', 'Registry defaults cleared', $regPath)
            } catch {
                $script:OfficeDiag.Error('PowerPoint', 'ResetDefaults', 'Failed', $_.Exception.Message)
            }
        }

        # Clean templates
        $chk = $Content.FindName('chkPPTTemplates')
        if ($chk -and $chk.IsChecked) {
            try {
                $startupPath = [SysOpt.Office.Repair.AppRepair]::GetStartupFolderPath('PowerPoint')
                if ($startupPath -and (Test-Path $startupPath)) {
                    $templates = [SysOpt.Office.Repair.AppRepair]::GetStartupTemplates('PowerPoint')
                    foreach ($t in $templates) {
                        if (Test-Path $t) { Remove-Item $t -Force -ErrorAction Stop }
                    }
                }
                $script:OfficeDiag.Success('PowerPoint', 'CleanTemplates', (T 'Office_DiagStartupCleaned' 'Startup templates cleaned'), $startupPath)
            } catch {
                $script:OfficeDiag.Error('PowerPoint', 'CleanTemplates', 'Failed', $_.Exception.Message)
            }
        }

        # Repair addins
        $chk = $Content.FindName('chkPPTAddins')
        if ($chk -and $chk.IsChecked) {
            try {
                $regPath = "HKCU:\Software\Microsoft\Office\16.0\PowerPoint\Resiliency\DisabledItems"
                if (Test-Path $regPath) {
                    Remove-Item $regPath -Recurse -Force -ErrorAction Stop
                }
                $script:OfficeDiag.Success('PowerPoint', 'RepairAddins', (T 'Office_DiagDisabledCleared' 'Disabled items cleared'), $regPath)
            } catch {
                $script:OfficeDiag.Error('PowerPoint', 'RepairAddins', 'Failed', $_.Exception.Message)
            }
        }

        # ── Feedback al usuario ──────────────────────────────────────
        $pptActions = @()
        if ($Content.FindName('chkPPTDefaults') -and $Content.FindName('chkPPTDefaults').IsChecked) { $pptActions += T 'Office_PPTActionDefaults' 'Configuración por defecto restablecida' }
        if ($Content.FindName('chkPPTTemplates') -and $Content.FindName('chkPPTTemplates').IsChecked) { $pptActions += T 'Office_PPTActionTemplates' 'Plantillas de inicio limpiadas' }
        if ($Content.FindName('chkPPTAddins') -and $Content.FindName('chkPPTAddins').IsChecked) { $pptActions += T 'Office_PPTActionAddins' 'Complementos deshabilitados re-habilitados' }

        if ($pptActions.Count -gt 0) {
            $msg = (T 'Office_RepairDoneMsg' 'Reparación completada:') + "`n`n• " + ($pptActions -join "`n• ")
            Show-ThemedDialog -Title (T 'Office_DlgSuccessTitle' 'Operación completada') -Message $msg -Type 'info' -Buttons 'OK'
        }

        Write-Log "[MOD:Office] PowerPoint repair completed" -Level INFO

    } catch {
        $script:OfficeDiag.Error('PowerPoint', 'Repair', (T 'Office_DiagUnexpectedError' 'Unexpected error'), $_.Exception.Message)
        Show-ThemedDialog -Title (T 'Office_DlgErrorTitle' 'Error') -Message ((T 'Office_RepairFailed' 'Error durante la reparación: {0}') -f $_.Exception.Message) -Type 'error' -Buttons 'OK'
        Write-Log "[MOD:Office] PowerPoint repair error: $($_.Exception.Message)" -Level WARN
    }
}

# ─── Components — Teams ───────────────────────────────────────────────────────

function global:Office_RepairTeams {
    <#
    .SYNOPSIS  Repair selected Teams items (cache, config, credentials).
    #>
    param($Content)

    try {
        # ── Check if Teams is running ────────────────────────────────
        $teamsProcs = Get-Process -Name "ms-teams","Teams" -ErrorAction SilentlyContinue
        if ($teamsProcs) {
            Show-ThemedDialog `
                -Title   (T 'Office_DlgWarningTitle' 'Advertencia') `
                -Message (T 'Office_TeamsRunning' 'Microsoft Teams está en ejecución. Ciérrelo primero para poder realizar la reparación.') `
                -Type 'warning' -Buttons 'OK'
            return
        }

        # Clear cache
        $chk = $Content.FindName('chkTeamsCache')
        if ($chk -and $chk.IsChecked) {
            try {
                $cachePaths = [SysOpt.Office.Repair.TeamsRepair]::GetTeamsCachePaths()
                foreach ($p in $cachePaths) {
                    if (Test-Path $p) {
                        Remove-Item $p -Recurse -Force -ErrorAction Stop
                    }
                }
                $script:OfficeDiag.Success('Teams', 'ClearCache', "Cleared $($cachePaths.Count) cache path(s)", '')
            } catch {
                $script:OfficeDiag.Error('Teams', 'ClearCache', 'Failed', $_.Exception.Message)
            }
        }

        # Reset config
        $chk = $Content.FindName('chkTeamsConfig')
        if ($chk -and $chk.IsChecked) {
            try {
                $configPaths = [SysOpt.Office.Repair.TeamsRepair]::GetTeamsConfigPaths()
                foreach ($p in $configPaths) {
                    if (Test-Path $p) {
                        Rename-Item $p "$p.bak_$(Get-Date -Format 'yyyyMMddHHmmss')" -ErrorAction Stop
                    }
                }
                $script:OfficeDiag.Success('Teams', 'ResetConfig', "Backed up $($configPaths.Count) config file(s)", '')
            } catch {
                $script:OfficeDiag.Error('Teams', 'ResetConfig', 'Failed', $_.Exception.Message)
            }
        }

        # Check / clear credentials
        $chk = $Content.FindName('chkTeamsCreds')
        if ($chk -and $chk.IsChecked) {
            try {
                # Clear credential-related cache in Teams
                $cachePaths = [SysOpt.Office.Repair.TeamsRepair]::GetTeamsCachePaths()
                foreach ($p in $cachePaths) {
                    $credDir = Join-Path $p 'Cookies'
                    if (Test-Path $credDir) {
                        Remove-Item $credDir -Recurse -Force -ErrorAction Stop
                    }
                }
                $script:OfficeDiag.Success('Teams', 'ClearCreds', (T 'Office_DiagCredCleared' 'Credential cache cleared'), '')
            } catch {
                $script:OfficeDiag.Error('Teams', 'ClearCreds', 'Failed', $_.Exception.Message)
            }
        }

        # ── Feedback al usuario ──────────────────────────────────────
        $teamsActions = @()
        if ($Content.FindName('chkTeamsCache')  -and $Content.FindName('chkTeamsCache').IsChecked)  { $teamsActions += T 'Office_TeamsActionCache'  'Caché de Teams limpiada' }
        if ($Content.FindName('chkTeamsConfig') -and $Content.FindName('chkTeamsConfig').IsChecked) { $teamsActions += T 'Office_TeamsActionConfig' 'Configuración respaldada y restablecida' }
        if ($Content.FindName('chkTeamsCreds')  -and $Content.FindName('chkTeamsCreds').IsChecked)  { $teamsActions += T 'Office_TeamsActionCreds'  'Caché de credenciales limpiada' }

        if ($teamsActions.Count -gt 0) {
            $msg = (T 'Office_RepairDoneMsg' 'Reparación completada:') + "`n`n• " + ($teamsActions -join "`n• ")
            Show-ThemedDialog -Title (T 'Office_DlgSuccessTitle' 'Operación completada') -Message $msg -Type 'info' -Buttons 'OK'
        }

        Write-Log "[MOD:Office] Teams repair completed" -Level INFO

    } catch {
        $script:OfficeDiag.Error('Teams', 'Repair', (T 'Office_DiagUnexpectedError' 'Unexpected error'), $_.Exception.Message)
        Show-ThemedDialog -Title (T 'Office_DlgErrorTitle' 'Error') -Message ((T 'Office_RepairFailed' 'Error durante la reparación: {0}') -f $_.Exception.Message) -Type 'error' -Buttons 'OK'
        Write-Log "[MOD:Office] Teams repair error: $($_.Exception.Message)" -Level WARN
    }
}

# ─── Components — Access ──────────────────────────────────────────────────────

function global:Office_RepairAccess {
    <#
    .SYNOPSIS  Repair selected Access items.
    #>
    param($Content)

    $txtStatus = $Content.FindName('txtAccessStatus')

    try {
        # Verify Access is installed
        $installed = [SysOpt.Office.Repair.AccessRepair]::IsAccessInstalled()
        if (-not $installed) {
            if ($txtStatus) { $txtStatus.Text = T 'Office_AccessNotInstalled' 'Access no está instalado en este equipo.' }
            $script:OfficeDiag.Warn('Access', 'Repair', (T 'Office_DiagAccessNotInstalled' 'Access is not installed'), '')
            return
        }

        # Compact & repair
        $chk = $Content.FindName('chkAccessCompact')
        if ($chk -and $chk.IsChecked) {
            try {
                $acePath = [SysOpt.Office.Repair.AccessRepair]::GetACEEnginePath()
                if ($acePath -and (Test-Path $acePath)) {
                    $script:OfficeDiag.Success('Access', 'CompactRepair', (T 'Office_DiagAceFound' 'ACE engine located'), $acePath)
                } else {
                    $script:OfficeDiag.Warn('Access', 'CompactRepair', (T 'Office_DiagAceNotFound' 'ACE engine not found'), "$acePath")
                }
            } catch {
                $script:OfficeDiag.Error('Access', 'CompactRepair', 'Failed', $_.Exception.Message)
            }
        }

        # ODBC diagnostics
        $chk = $Content.FindName('chkAccessODBC')
        if ($chk -and $chk.IsChecked) {
            try {
                # Query ODBC data sources from registry
                $odbcPath = 'HKCU:\Software\ODBC\ODBC.INI\ODBC Data Sources'
                if (Test-Path $odbcPath) {
                    $sources = Get-ItemProperty -Path $odbcPath -ErrorAction Stop
                    $script:OfficeDiag.Info('Access', 'ODBC', "Found ODBC data sources", ($sources.PSObject.Properties.Name -join ', '))
                } else {
                    $script:OfficeDiag.Info('Access', 'ODBC', (T 'Office_DiagNoOdbc' 'No ODBC data sources configured'), '')
                }
            } catch {
                $script:OfficeDiag.Error('Access', 'ODBC', 'Failed', $_.Exception.Message)
            }
        }

        # Reset config
        $chk = $Content.FindName('chkAccessConfig')
        if ($chk -and $chk.IsChecked) {
            try {
                $regPath = [SysOpt.Office.Repair.AppRepair]::GetResetRegistryPath('Access')
                if ($regPath -and (Test-Path $regPath)) {
                    Remove-Item $regPath -Recurse -Force -ErrorAction Stop
                }
                $script:OfficeDiag.Success('Access', 'ResetConfig', 'Registry config cleared', $regPath)
            } catch {
                $script:OfficeDiag.Error('Access', 'ResetConfig', 'Failed', $_.Exception.Message)
            }
        }

        if ($txtStatus) { $txtStatus.Text = T 'Office_StatusOK' 'Correcto' }
        # ── Feedback al usuario ──────────────────────────────────────
        $accessActions = @()
        if ($Content.FindName('chkAccessCompact') -and $Content.FindName('chkAccessCompact').IsChecked) { $accessActions += T 'Office_AccessActionCompact' 'Base de datos compactada y reparada' }
        if ($Content.FindName('chkAccessRefs')    -and $Content.FindName('chkAccessRefs').IsChecked)    { $accessActions += T 'Office_AccessActionRefs'    'Referencias rotas reparadas' }

        if ($accessActions.Count -gt 0) {
            $msg = (T 'Office_RepairDoneMsg' 'Reparación completada:') + "`n`n• " + ($accessActions -join "`n• ")
            Show-ThemedDialog -Title (T 'Office_DlgSuccessTitle' 'Operación completada') -Message $msg -Type 'info' -Buttons 'OK'
        }

        Write-Log "[MOD:Office] Access repair completed" -Level INFO

    } catch {
        $script:OfficeDiag.Error('Access', 'Repair', (T 'Office_DiagUnexpectedError' 'Unexpected error'), $_.Exception.Message)
        Show-ThemedDialog -Title (T 'Office_DlgErrorTitle' 'Error') -Message ((T 'Office_RepairFailed' 'Error durante la reparación: {0}') -f $_.Exception.Message) -Type 'error' -Buttons 'OK'
        Write-Log "[MOD:Office] Access repair error: $($_.Exception.Message)" -Level WARN
    }
}

# ─── Add-ins ──────────────────────────────────────────────────────────────────

function global:Office_ScanAddins {
    <#
    .SYNOPSIS  Enumerate all Office add-ins and build dynamic UI rows.
    #>
    param($Content)

    $spResults = $Content.FindName('spAddinsResults')
    if (-not $spResults) { return }
    $spResults.Children.Clear()

    try {
        $addinMgr = [SysOpt.Office.Core.OfficeAddins]::new()
        $addins   = $addinMgr.GetAllAddins()

        $script:OfficeCache.Addins = $addins

        if ($null -eq $addins -or $addins.Count -eq 0) {
            $noData = New-Object System.Windows.Controls.TextBlock
            $noData.Text       = T 'Office_AddinsNone' 'No se encontraron complementos instalados.'
            $noData.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString((Get-TC 'TextSecondary' '#A0A0A0'))
            $noData.FontSize   = 13
            $noData.Margin     = [System.Windows.Thickness]::new(0,8,0,0)
            $spResults.Children.Add($noData) | Out-Null
            $script:OfficeDiag.Info('Addins', 'Scan', 'No add-ins found', '')
            return
        }

        $brushConv   = [System.Windows.Media.BrushConverter]::new()
        $cardBg      = Get-TC 'SurfaceSecondary' '#2D2D30'
        $textPri     = Get-TC 'TextPrimary'      '#FFFFFF'
        $textSec     = Get-TC 'TextSecondary'     '#A0A0A0'
        $statusOk    = Get-TC 'StatusSuccess'     '#27AE60'
        $statusErr   = Get-TC 'StatusError'       '#E74C3C'
        $statusDis   = Get-TC 'TextTertiary'      '#787878'
        $accentClr   = Get-TC 'AccentPrimary'     '#0078D4'

        foreach ($addin in $addins) {
            $border = New-Object System.Windows.Controls.Border
            $border.Background   = $script:BrushConv.ConvertFromString($cardBg)
            $border.CornerRadius = [System.Windows.CornerRadius]::new(6)
            $border.Padding      = [System.Windows.Thickness]::new(12)
            $border.Margin       = [System.Windows.Thickness]::new(0,0,0,6)

            $grid = New-Object System.Windows.Controls.Grid
            # 4 columns: Name | App | Status | Action
            for ($i = 0; $i -lt 4; $i++) {
                $colDef = New-Object System.Windows.Controls.ColumnDefinition
                switch ($i) {
                    0 { $colDef.Width = [System.Windows.GridLength]::new(1, 'Star') }
                    1 { $colDef.Width = [System.Windows.GridLength]::new(100) }
                    2 { $colDef.Width = [System.Windows.GridLength]::new(120) }
                    3 { $colDef.Width = [System.Windows.GridLength]::new(110) }
                }
                $grid.ColumnDefinitions.Add($colDef) | Out-Null
            }

            # Name + Type
            $spName = New-Object System.Windows.Controls.StackPanel
            $spName.Orientation = 'Vertical'
            $nameText = New-Object System.Windows.Controls.TextBlock
            $nameText.Text       = $addin.Name
            $nameText.FontSize   = 13
            $nameText.Foreground = $script:BrushConv.ConvertFromString($textPri)
            $spName.Children.Add($nameText) | Out-Null
            $typeText = New-Object System.Windows.Controls.TextBlock
            $typeText.Text       = $addin.Type
            $typeText.FontSize   = 11
            $typeText.Foreground = $script:BrushConv.ConvertFromString($textSec)
            $spName.Children.Add($typeText) | Out-Null
            [System.Windows.Controls.Grid]::SetColumn($spName, 0)
            $grid.Children.Add($spName) | Out-Null

            # Application
            $appText = New-Object System.Windows.Controls.TextBlock
            $appText.Text              = $addin.Application
            $appText.FontSize          = 12
            $appText.Foreground        = $script:BrushConv.ConvertFromString($textSec)
            $appText.VerticalAlignment = 'Center'
            [System.Windows.Controls.Grid]::SetColumn($appText, 1)
            $grid.Children.Add($appText) | Out-Null

            # Status badge
            $statusBadge = New-Object System.Windows.Controls.TextBlock
            $statusBadge.FontSize          = 12
            $statusBadge.VerticalAlignment = 'Center'
            switch -Wildcard ($addin.Status) {
                '*Active*'   { $statusBadge.Text = T 'Office_AddinsStatusActive'   'Activo';       $statusBadge.Foreground = $script:BrushConv.ConvertFromString($statusOk) }
                '*Error*'    { $statusBadge.Text = T 'Office_AddinsStatusError'    'Con error';    $statusBadge.Foreground = $script:BrushConv.ConvertFromString($statusErr) }
                '*Disabled*' { $statusBadge.Text = T 'Office_AddinsStatusDisabled' 'Deshabilitado'; $statusBadge.Foreground = $script:BrushConv.ConvertFromString($statusDis) }
                default      { $statusBadge.Text = $addin.Status;                                    $statusBadge.Foreground = $script:BrushConv.ConvertFromString($textSec) }
            }
            [System.Windows.Controls.Grid]::SetColumn($statusBadge, 2)
            $grid.Children.Add($statusBadge) | Out-Null

            # Action button
            $actionBtn = New-Object System.Windows.Controls.Button
            $actionBtn.FontSize   = 11
            $actionBtn.Padding    = [System.Windows.Thickness]::new(8,4,8,4)
            $actionBtn.Background = $script:BrushConv.ConvertFromString($accentClr)
            $actionBtn.Foreground = $script:BrushConv.ConvertFromString((Get-TC 'TextOnAccent' '#FFFFFF'))
            $actionBtn.VerticalAlignment = 'Center'

            $currentApp    = $addin.Application
            $currentProgId = $addin.ProgId
            $currentLoad   = $addin.LoadBehavior

            if ($addin.LoadBehavior -eq 0 -or $addin.Status -match 'Disabled') {
                $actionBtn.Content = T 'Office_AddinsEnable' 'Habilitar'
                $newBehavior = 3
            } else {
                $actionBtn.Content = T 'Office_AddinsDisable' 'Deshabilitar'
                $newBehavior = 0
            }

            $actionBtn.Add_Click({
                Office_ToggleAddin $currentApp $currentProgId $newBehavior $Content
            }.GetNewClosure())

            [System.Windows.Controls.Grid]::SetColumn($actionBtn, 3)
            $grid.Children.Add($actionBtn) | Out-Null

            $border.Child = $grid
            $spResults.Children.Add($border) | Out-Null
        }

        $script:OfficeDiag.Success('Addins', 'Scan', "Found $($addins.Count) add-in(s)", '')

    } catch {
        $errMsg = $_.Exception.Message
        $script:OfficeDiag.Error('Addins', 'Scan', 'Add-in scan failed', $errMsg)
        Write-Log "[MOD:Office] Addin scan error: $errMsg" -Level WARN
    }
}

function global:Office_ToggleAddin {
    <#
    .SYNOPSIS  Enable or disable a specific add-in.
    #>
    param(
        [string]$AppName,
        [string]$ProgId,
        [int]$NewBehavior,
        $Content
    )

    try {
        $addinMgr = [SysOpt.Office.Core.OfficeAddins]::new()
        $addinMgr.SetAddinLoadBehavior($AppName, $ProgId, $NewBehavior)

        $action = if ($NewBehavior -eq 0) { 'Disabled' } else { 'Enabled' }
        $script:OfficeDiag.Success('Addins', "Toggle$action", "$action add-in '$ProgId' for $AppName", "LoadBehavior=$NewBehavior")
        Write-Log "[MOD:Office] $action add-in '$ProgId' ($AppName)" -Level INFO

        # Refresh UI
        Office_ScanAddins $Content

    } catch {
        $errMsg = $_.Exception.Message
        $script:OfficeDiag.Error('Addins', 'Toggle', "Failed to toggle '$ProgId'", $errMsg)
        Write-Log "[MOD:Office] Addin toggle error: $errMsg" -Level WARN
    }
}

function global:Office_DisableAllErrorAddins {
    <#
    .SYNOPSIS  Disable all add-ins that are in an error state.
    #>
    param($Content)

    try {
        $addins = $script:OfficeCache.Addins
        if (-not $addins) {
            $addinMgr = [SysOpt.Office.Core.OfficeAddins]::new()
            $addins   = $addinMgr.GetAllAddins()
        }

        $count = 0
        $addinMgr = [SysOpt.Office.Core.OfficeAddins]::new()
        foreach ($a in $addins) {
            if ($a.Status -match 'Error') {
                $addinMgr.SetAddinLoadBehavior($a.Application, $a.ProgId, 0)
                $count++
            }
        }

        $script:OfficeDiag.Success('Addins', 'DisableAllErrors', "Disabled $count error add-in(s)", '')
        Write-Log "[MOD:Office] Disabled $count error add-in(s)" -Level INFO
        Office_ScanAddins $Content

    } catch {
        $script:OfficeDiag.Error('Addins', 'DisableAllErrors', 'Failed', $_.Exception.Message)
    }
}

function global:Office_EnableAllAddins {
    <#
    .SYNOPSIS  Re-enable all disabled add-ins.
    #>
    param($Content)

    try {
        $addins = $script:OfficeCache.Addins
        if (-not $addins) {
            $addinMgr = [SysOpt.Office.Core.OfficeAddins]::new()
            $addins   = $addinMgr.GetAllAddins()
        }

        $count = 0
        $addinMgr = [SysOpt.Office.Core.OfficeAddins]::new()
        foreach ($a in $addins) {
            if ($a.LoadBehavior -eq 0 -or $a.Status -match 'Disabled') {
                $addinMgr.SetAddinLoadBehavior($a.Application, $a.ProgId, 3)
                $count++
            }
        }

        $script:OfficeDiag.Success('Addins', 'EnableAll', "Re-enabled $count add-in(s)", '')
        Write-Log "[MOD:Office] Re-enabled $count add-in(s)" -Level INFO
        Office_ScanAddins $Content

    } catch {
        $script:OfficeDiag.Error('Addins', 'EnableAll', 'Failed', $_.Exception.Message)
    }
}

# ─── Identity / Auth ──────────────────────────────────────────────────────────

function global:Office_ClearIdentityCache {
    <#
    .SYNOPSIS  Clear specific Office identity / auth cache components.
    #>
    param(
        [string]$Action,
        $Content
    )

    $txtStatus = $Content.FindName('txtAuthStatus')

    try {
        switch ($Action) {

            'ClearTokens' {
                $paths = [SysOpt.Office.Repair.IdentityRepair]::GetIdentityCachePaths()
                foreach ($p in $paths) {
                    $tokenDir = Join-Path $p 'Tokens'
                    if (Test-Path $tokenDir) {
                        Remove-Item $tokenDir -Recurse -Force -ErrorAction Stop
                    }
                }
                $script:OfficeDiag.Success('Auth', 'ClearTokens', 'Expired tokens cleared', '')
            }

            'ClearCreds' {
                $paths = [SysOpt.Office.Repair.IdentityRepair]::GetIdentityCachePaths()
                foreach ($p in $paths) {
                    $credDir = Join-Path $p 'Credentials'
                    if (Test-Path $credDir) {
                        Remove-Item $credDir -Recurse -Force -ErrorAction Stop
                    }
                }
                $script:OfficeDiag.Success('Auth', 'ClearCreds', 'Corrupted credentials cleared', '')
            }

            'ClearAAD' {
                $aadPath = Join-Path $env:LOCALAPPDATA 'Packages\Microsoft.AAD.BrokerPlugin_cw5n1h2txyewy\AC\TokenBroker'
                if (Test-Path $aadPath) {
                    Remove-Item $aadPath -Recurse -Force -ErrorAction Stop
                }
                $script:OfficeDiag.Success('Auth', 'ClearAAD', 'AAD Broker Plugin cache cleared', $aadPath)
            }

            'ResetSession' {
                $regKeys = [SysOpt.Office.Repair.IdentityRepair]::GetIdentityRegistryKeys()
                foreach ($key in $regKeys) {
                    try {
                        if (Test-Path $key) {
                            Remove-Item $key -Recurse -Force -ErrorAction Stop
                        }
                    } catch {
                        $script:OfficeDiag.Warn('Auth', 'ResetSession', "Could not remove '$key'", $_.Exception.Message)
                    }
                }
                $script:OfficeDiag.Success('Auth', 'ResetSession', 'M365 session reset', '')
            }

            'ClearIdentity' {
                $paths = [SysOpt.Office.Repair.IdentityRepair]::GetIdentityCachePaths()
                foreach ($p in $paths) {
                    if (Test-Path $p) {
                        Remove-Item $p -Recurse -Force -ErrorAction Stop
                    }
                }
                $regKeys = [SysOpt.Office.Repair.IdentityRepair]::GetIdentityRegistryKeys()
                foreach ($key in $regKeys) {
                    try {
                        if (Test-Path $key) {
                            Remove-Item $key -Recurse -Force -ErrorAction Stop
                        }
                    } catch {
                        Write-Log "[MOD:Office] Skipped registry key: $key" -Level DBG
                    }
                }
                $script:OfficeDiag.Success('Auth', 'ClearIdentity', 'Full identity folder cleared', '')
            }
        }

        if ($txtStatus) {
            $txtStatus.Text       = T 'Office_AuthSuccess' 'Caché de identidad limpiada correctamente.'
            $txtStatus.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString((Get-TC 'StatusSuccess' '#27AE60'))
        }
        Write-Log "[MOD:Office] Auth action '$Action' completed" -Level INFO

    } catch {
        $errMsg = $_.Exception.Message
        if ($txtStatus) {
            $txtStatus.Text       = (T 'Office_AuthFailed' 'Error al limpiar la caché de identidad: {0}') -f $errMsg
            $txtStatus.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString((Get-TC 'StatusError' '#E74C3C'))
        }
        $script:OfficeDiag.Error('Auth', $Action, "Identity cache action '$Action' failed", $errMsg)
        Write-Log "[MOD:Office] Auth error ($Action): $errMsg" -Level WARN
    }
}

# ─── Cache Cleanup ─────────────────────────────────────────────────────────────

function global:Office_CalculateCacheSizes {
    <#
    .SYNOPSIS  Enumerate cache targets and display sizes.
    #>
    param($Content)

    try {
        $targets = [SysOpt.Office.Repair.CacheCleanup]::EnumerateCacheTargets()
        $script:OfficeCache.CacheTargets = $targets

        # Map cache target names to XAML suffixes (CacheTarget has no Category property)
        $nameToSuffix = @{
            'Office Click-to-Run Cache'   = 'C2R'
            'Office OSPP Temp'            = 'OSPP'
            'Outlook Autocomplete Cache'  = 'OutlookAuto'
            'Outlook Form Cache'          = 'OutlookForms'
            'Word Temp Files'             = 'WordTmp'
            'Excel Temp Files'            = 'ExcelTmp'
            'Teams Logs'                  = 'TeamsLogs'
            'Teams Blob Storage'          = 'TeamsBlob'
            'Teams GPU Cache'             = 'TeamsGPU'
            'New Teams Cache'             = 'TeamsNew'
        }

        $totalBytes = [long]0

        foreach ($target in $targets) {
            $suffix = $nameToSuffix[$target.Name]
            if (-not $suffix) { continue }

            $sizeCtrl = $Content.FindName("txtCacheSize$suffix")
            if ($sizeCtrl) {
                $sizeCtrl.Text = [SysOpt.Office.Repair.CacheCleanup]::FormatSize($target.SizeBytes)
            }
            $totalBytes += $target.SizeBytes
        }

        $txtTotal = $Content.FindName('txtCacheTotal')
        if ($txtTotal) {
            $txtTotal.Text = (T 'Office_CacheTotal' 'Total recuperable:') + ' ' + [SysOpt.Office.Repair.CacheCleanup]::FormatSize($totalBytes)
        }

        $script:OfficeDiag.Info('Cache', 'Calculate', "Enumerated $($targets.Count) cache target(s), total $([math]::Round($totalBytes / 1MB, 2)) MB", '')

    } catch {
        $errMsg = $_.Exception.Message
        $script:OfficeDiag.Error('Cache', 'Calculate', 'Cache enumeration failed', $errMsg)
        Write-Log "[MOD:Office] Cache calculation error: $errMsg" -Level WARN
    }
}

function global:Office_CleanCache {
    <#
    .SYNOPSIS  Clean cache targets (all or only checked items).
    #>
    param(
        [bool]$All,
        $Content
    )

    try {
        $targets = $script:OfficeCache.CacheTargets
        if (-not $targets) {
            Office_CalculateCacheSizes $Content
            $targets = $script:OfficeCache.CacheTargets
        }
        if (-not $targets) { return }

        $nameToCheckbox = @{
            'Office Click-to-Run Cache'   = 'chkCacheC2R'
            'Office OSPP Temp'            = 'chkCacheOSPP'
            'Outlook Autocomplete Cache'  = 'chkCacheOutlookAuto'
            'Outlook Form Cache'          = 'chkCacheOutlookForms'
            'Word Temp Files'             = 'chkCacheWordTmp'
            'Excel Temp Files'            = 'chkCacheExcelTmp'
            'Teams Logs'                  = 'chkCacheTeamsLogs'
            'Teams Blob Storage'          = 'chkCacheTeamsBlob'
            'Teams GPU Cache'             = 'chkCacheTeamsGPU'
            'New Teams Cache'             = 'chkCacheTeamsNew'
        }

        $freedBytes = [long]0

        foreach ($target in $targets) {
            # Skip unchecked items unless $All
            if (-not $All) {
                $chkName = $nameToCheckbox[$target.Name]
                if ($chkName) {
                    $chk = $Content.FindName($chkName)
                    if ($chk -and -not $chk.IsChecked) { continue }
                }
            }

            if (Test-Path $target.Path) {
                try {
                    $freedBytes += $target.SizeBytes
                    Remove-Item $target.Path -Recurse -Force -ErrorAction Stop
                    $script:OfficeDiag.Success('Cache', 'Clean', "Cleaned $($target.Name)", $target.Path)
                } catch {
                    $script:OfficeDiag.Warn('Cache', 'Clean', "Partial clean of $($target.Name)", $_.Exception.Message)
                }
            }
        }

        $freedMB = [math]::Round($freedBytes / 1MB, 2)
        Write-Log "[MOD:Office] Cache cleaned: $freedMB MB freed" -Level INFO

        # Show success toast
        $successMsg = (T 'Office_CacheSuccess' 'Caché eliminada correctamente. Espacio liberado: {0} MB') -f $freedMB
        Show-ThemedDialog `
            -Title   (T 'Office_DlgSuccessTitle' 'Operación completada') `
            -Message $successMsg `
            -Type    'info' `
            -Buttons 'OK'

        # Refresh sizes
        Office_CalculateCacheSizes $Content

    } catch {
        $errMsg = $_.Exception.Message
        Show-ThemedDialog `
            -Title   (T 'Office_DlgErrorTitle' 'Error') `
            -Message ((T 'Office_CacheFailed' 'Error al limpiar: {0}') -f $errMsg) `
            -Type    'error' `
            -Buttons 'OK'
        $script:OfficeDiag.Error('Cache', 'Clean', 'Cache cleanup failed', $errMsg)
        Write-Log "[MOD:Office] Cache clean error: $errMsg" -Level WARN
    }
}

# ─── Diagnostics / Report ────────────────────────────────────────────────────

function global:Office_GenerateReport {
    <#
    .SYNOPSIS  Generate a diagnostic report from DiagEngine data.
    #>
    param($Content)

    $txtConsole  = $Content.FindName('txtReportConsole')
    $txtOS       = $Content.FindName('txtReportOS')
    $txtOffice   = $Content.FindName('txtReportOffice')
    $txtChannel  = $Content.FindName('txtReportChannel')
    $txtErrors   = $Content.FindName('txtReportErrors')
    $txtWarnings = $Content.FindName('txtReportWarnings')
    $txtOK       = $Content.FindName('txtReportOK')

    try {
        if ($txtConsole) { $txtConsole.Text = T 'Office_ReportGenerating' 'Generando informe de diagnóstico...' }

        # Ensure we have detection data
        if (-not $script:OfficeCache.Installs) {
            Office_RunDetection $Content
        }

        $summary = $script:OfficeDiag.GetSummary()

        # OS info
        $osVersion = [System.Environment]::OSVersion.VersionString
        if ($txtOS) { $txtOS.Text = $osVersion }

        # SysOpt version
        $sysOptVersion = if ($script:SysOptVersion) { $script:SysOptVersion } else { '3.3.1' }

        # Office info from cache
        $officeVersion = '—'
        $channelInfo   = '—'
        $officeLicense = '—'
        if ($script:OfficeCache.Installs -and $script:OfficeCache.Installs.Count -gt 0) {
            $primary       = $script:OfficeCache.Installs[0]
            $officeVersion = "$($primary.ProductName) $($primary.Version)"
            $channelInfo   = $primary.Channel
        }
        if ($script:OfficeCache.License) {
            $officeLicense = "$($script:OfficeCache.License.LicenseType) — $($script:OfficeCache.License.Status)"
        }
        if ($txtOffice)  { $txtOffice.Text  = $officeVersion }
        if ($txtChannel) { $txtChannel.Text = $channelInfo }

        # Generate text report — C# expects: (DiagEngine, osVersion, sysOptVersion, officeVersion, officeLicense)
        $reportText = [SysOpt.Office.Diagnostics.ReportExporter]::GenerateTextReport(
            $script:OfficeDiag, $osVersion, $sysOptVersion, $officeVersion, $officeLicense
        )

        if ($txtConsole) { $txtConsole.Text = $reportText }

        # Summary badges (DiagSummary properties: Errors, Warnings, Successes, TotalEntries)
        if ($txtErrors)   { $txtErrors.Text   = "$($summary.Errors)" }
        if ($txtWarnings) { $txtWarnings.Text = "$($summary.Warnings)" }
        if ($txtOK)       { $txtOK.Text       = "$($summary.Successes)" }

        $script:OfficeDiag.Info('Report', 'Generate', 'Report generated', "Entries=$($summary.TotalEntries)")
        Write-Log "[MOD:Office] Report generated: $($summary.TotalEntries) entries ($($summary.Errors)E/$($summary.Warnings)W/$($summary.Successes)OK)" -Level INFO

    } catch {
        $errMsg = $_.Exception.Message
        if ($txtConsole) { $txtConsole.Text = (T 'Office_ReportEmpty' 'Aún no se ha generado ningún informe.') + "`n`nError: $errMsg" }
        $script:OfficeDiag.Error('Report', 'Generate', 'Report generation failed', $errMsg)
        Write-Log "[MOD:Office] Report error: $errMsg" -Level WARN
    }
}

function global:Office_ExportReport {
    <#
    .SYNOPSIS  Export the diagnostic report to a file (HTML or TXT).
    #>
    param(
        [string]$Format,
        $Content
    )

    try {
        $summary = $script:OfficeDiag.GetSummary()

        $osVersion     = [System.Environment]::OSVersion.VersionString
        $sysOptVersion = if ($script:SysOptVersion) { $script:SysOptVersion } else { '3.3.1' }
        $officeVersion = '—'
        $officeLicense = '—'
        if ($script:OfficeCache.Installs -and $script:OfficeCache.Installs.Count -gt 0) {
            $officeVersion = "$($script:OfficeCache.Installs[0].ProductName) $($script:OfficeCache.Installs[0].Version)"
        }
        if ($script:OfficeCache.License) {
            $officeLicense = "$($script:OfficeCache.License.LicenseType) — $($script:OfficeCache.License.Status)"
        }

        # Generate content based on format — C# expects: (DiagEngine, osVersion, sysOptVersion, officeVersion, officeLicense)
        $reportContent = switch ($Format) {
            'HTML' { [SysOpt.Office.Diagnostics.ReportExporter]::GenerateHtmlReport($script:OfficeDiag, $osVersion, $sysOptVersion, $officeVersion, $officeLicense) }
            'TXT'  { [SysOpt.Office.Diagnostics.ReportExporter]::GenerateTextReport($script:OfficeDiag, $osVersion, $sysOptVersion, $officeVersion, $officeLicense) }
            default { [SysOpt.Office.Diagnostics.ReportExporter]::GenerateTextReport($script:OfficeDiag, $osVersion, $sysOptVersion, $officeVersion, $officeLicense) }
        }

        # File save dialog
        $ext = if ($Format -eq 'HTML') { 'html' } else { 'txt' }
        $defaultName = [SysOpt.Office.Diagnostics.ReportExporter]::GetDefaultFileName($ext)

        $dlg = New-Object Microsoft.Win32.SaveFileDialog
        $dlg.FileName   = $defaultName
        $dlg.DefaultExt = ".$ext"
        $dlg.Filter     = if ($Format -eq 'HTML') { "HTML files (*.html)|*.html|All files (*.*)|*.*" } else { "Text files (*.txt)|*.txt|All files (*.*)|*.*" }

        $dlgResult = $dlg.ShowDialog()
        if ($dlgResult -eq $true) {
            [SysOpt.Office.Diagnostics.ReportExporter]::ExportToFile($reportContent, $dlg.FileName)

            $successMsg = (T 'Office_ReportExportSuccess' 'Informe exportado correctamente en: {0}') -f $dlg.FileName
            Show-ThemedDialog `
                -Title   (T 'Office_DlgSuccessTitle' 'Operación completada') `
                -Message $successMsg `
                -Type    'info' `
                -Buttons 'OK'

            $script:OfficeDiag.Success('Report', "Export$Format", "Exported to $($dlg.FileName)", '')
            Write-Log "[MOD:Office] Report exported: $($dlg.FileName)" -Level INFO
        }

    } catch {
        $errMsg = $_.Exception.Message
        Show-ThemedDialog `
            -Title   (T 'Office_DlgErrorTitle' 'Error') `
            -Message ((T 'Office_ReportExportFailed' 'Error al exportar el informe: {0}') -f $errMsg) `
            -Type    'error' `
            -Buttons 'OK'
        $script:OfficeDiag.Error('Report', "Export$Format", 'Export failed', $errMsg)
        Write-Log "[MOD:Office] Report export error: $errMsg" -Level WARN
    }
}

# ═══════════════════════════════════════════════════════════════════════════════
# Section 3 — UI Initialization Callback
# ═══════════════════════════════════════════════════════════════════════════════


# ═══════════════════════════════════════════════════════════════════════════════
# Section 2B — Module Cleanup (called by Disable-SysOptModule)
# ═══════════════════════════════════════════════════════════════════════════════

function global:Cleanup-ModuleUI_office {
    <#
    .SYNOPSIS  Release all resources held by the Office module.
               Called automatically when the module is disabled/uninstalled.
    #>

    # Release icon BitmapImage
    try {
        # Icon was loaded with CacheOption.OnLoad + Freeze — no file lock,
        # but we null the reference to free memory.
        $script:OfficeCache      = $null
        $script:OfficeDiag       = $null
        $script:OfficeServiceMap = $null
        $script:OfficePanelNames = $null
        $script:OfficeActiveNav  = $null
        $script:BrushConv        = $null
    } catch {}

    # Stop preload timer if running
    try {
        if ($script:_officePreloadTimer) {
            $script:_officePreloadTimer.Stop()
            $script:_officePreloadTimer = $null
        }
    } catch {}

    # Clear disk cache path vars (files are kept in %TEMP% for next session)
    $script:OfficeDiskCacheDir = $null
    $script:OfficeLicCachePath = $null
    $script:OfficeSvcCachePath = $null

    # Remove all global Office_ functions
    Get-Command -Name 'Office_*' -CommandType Function -ErrorAction SilentlyContinue |
        ForEach-Object { Remove-Item "Function:\$($_.Name)" -Force -ErrorAction SilentlyContinue }

    Write-Log "[MOD:Office] Cleanup complete — all resources released" -Level INFO
}

function global:Initialize-ModuleUI_office {
    <#
    .SYNOPSIS  Called by the SysOpt module loader after the Office tab is mounted.
    .PARAMETER Content  The XAML tab content element.
    #>
    param($Content)

    # ── [FIX #6] Debug Stopwatch ──────────────────────────────────────────────
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    if ($script:DebugMode) { Write-Log "[MOD:Office] Initialize-ModuleUI_office INICIO" -Level DBG }

    # ── [FIX #1A] Inicializar BrushConverter compartido ──────────────────────
    $script:BrushConv = [System.Windows.Media.BrushConverter]::new()

    # ── Icono del módulo (themes/office.ico) ──────────────────────────────────
    $imgHeader = $Content.FindName('imgOfficeHeaderIcon')
    if ($imgHeader) {
        try {
            $icoPath = [System.IO.Path]::Combine($script:ModulesDir, 'office', 'themes', 'office.ico')
            if (Test-Path $icoPath) {
                $uri = [System.Uri]::new($icoPath, [System.UriKind]::Absolute)
                $bmp = [System.Windows.Media.Imaging.BitmapImage]::new()
                $bmp.BeginInit()
                $bmp.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
                $bmp.UriSource   = $uri
                $bmp.EndInit()
                $bmp.Freeze()   # make it cross-thread safe & release file handle
                $imgHeader.Source = $bmp
            }
        } catch {
            if ($script:DebugMode) { Write-Log "[MOD:Office] No se pudo cargar office.ico: $_" -Level DBG }
        }
    }

    # ── Initialize DiagEngine ─────────────────────────────────────────────────
    $script:OfficeDiag = [SysOpt.Office.Diagnostics.DiagEngine]::new()
    if ($script:DebugMode) { Write-Log "[MOD:Office] DiagEngine listo: $($sw.ElapsedMilliseconds)ms" -Level DBG }

    # ── Navigation buttons ────────────────────────────────────────────────────
    $navMap = @{
        'btnNav_Detection'  = 'Detection'
        'btnNav_License'    = 'License'
        'btnNav_Services'   = 'Services'
        'btnNav_Repair'     = 'Repair'
        'btnNav_Components' = 'Components'
        'btnNav_Addins'     = 'Addins'
        'btnNav_Auth'       = 'Auth'
        'btnNav_Cache'      = 'Cache'
        'btnNav_Report'     = 'Report'
    }
    foreach ($btnName in $navMap.Keys) {
        $btn = $Content.FindName($btnName)
        if ($btn) {
            $panelName = $navMap[$btnName]
            $btn.Add_Click({
                Office_SwitchPanel $panelName $Content
            }.GetNewClosure())
        }
    }

    # ── Slide navigation arrows ──────────────────────────────────────────────
    $scrollNav = $Content.FindName('scrollNavSidebar')
    $slideUp   = $Content.FindName('btnNavSlideUp')
    $slideDown = $Content.FindName('btnNavSlideDown')
    if ($scrollNav -and $slideUp -and $slideDown) {
        # Hide the ugly scrollbar, mouse wheel still works natively
        # Update arrow visibility when scroll position changes
        $scrollNav.Add_ScrollChanged({
            param($sender, $e)
            $slideUp.Visibility   = if ($sender.VerticalOffset -gt 0) { 'Visible' } else { 'Collapsed' }
            $slideDown.Visibility = if ($sender.VerticalOffset -lt ($sender.ScrollableHeight - 1)) { 'Visible' } else { 'Collapsed' }
        }.GetNewClosure())

        # Click handlers — scroll one item height (~42px) per click
        $slideUp.Add_MouseLeftButtonDown({
            $scrollNav.ScrollToVerticalOffset($scrollNav.VerticalOffset - 42)
        }.GetNewClosure())
        $slideDown.Add_MouseLeftButtonDown({
            $scrollNav.ScrollToVerticalOffset($scrollNav.VerticalOffset + 42)
        }.GetNewClosure())

        # Initial visibility check after layout
        $scrollNav.Dispatcher.BeginInvoke([System.Windows.Threading.DispatcherPriority]::Loaded, [Action]{
            if ($scrollNav.ScrollableHeight -gt 0) {
                $slideDown.Visibility = 'Visible'
            }
        }.GetNewClosure()) | Out-Null
    }
    if ($script:DebugMode) { Write-Log "[MOD:Office] Slide nav configurado: $($sw.ElapsedMilliseconds)ms" -Level DBG }

    # ── Detection ─────────────────────────────────────────────────────────────
    $btnScan = $Content.FindName('btnDetectScan')
    if ($btnScan) {
        $btnScan.Add_Click({ Office_RunDetection $Content }.GetNewClosure())
    }

    # ── License — KMS removal ─────────────────────────────────────────────────
    $btnKmsRemove = $Content.FindName('btnLicKmsRemove')
    if ($btnKmsRemove) {
        $btnKmsRemove.Add_Click({
            try {
                $licensor   = [SysOpt.Office.Core.OfficeLicensor]::new()
                $activators = $licensor.ScanForIllegalActivators()
                foreach ($act in $activators) {
                    $script:OfficeDiag.Info('License', 'KMS Remove', "Removing activator: $act", '')
                }
                Office_RefreshLicense $Content
            } catch {
                $script:OfficeDiag.Error('License', 'KMS Remove', 'Removal failed', $_.Exception.Message)
            }
        }.GetNewClosure())
    }

    # ── Services ──────────────────────────────────────────────────────────────
    $svcSuffixes = @('C2R', 'Updater', 'Broker')
    foreach ($suffix in $svcSuffixes) {
        # Resolve service name from suffix
        $svcName = switch ($suffix) {
            'C2R'     { 'ClickToRunSvc' }
            'Updater' { 'Microsoft365Apps' }
            'Broker'  { 'TokenBroker' }
        }

        $btnStart   = $Content.FindName("btnSvcStart$suffix")
        $btnStop    = $Content.FindName("btnSvcStop$suffix")
        $btnRestart = $Content.FindName("btnSvcRestart$suffix")

        if ($btnStart) {
            $s = $svcName
            $btnStart.Add_Click({
                Office_ServiceAction $s 'Start' $Content
            }.GetNewClosure())
        }
        if ($btnStop) {
            $s = $svcName
            $btnStop.Add_Click({
                Office_ServiceAction $s 'Stop' $Content
            }.GetNewClosure())
        }
        if ($btnRestart) {
            $s = $svcName
            $btnRestart.Add_Click({
                Office_ServiceAction $s 'Restart' $Content
            }.GetNewClosure())
        }
    }

    # ── Repair — Basic ────────────────────────────────────────────────────────
    $btnQR = $Content.FindName('btnQuickRepair')
    if ($btnQR) { $btnQR.Add_Click({ Office_QuickRepair $Content }.GetNewClosure()) }

    $btnOR = $Content.FindName('btnOnlineRepair')
    if ($btnOR) { $btnOR.Add_Click({ Office_OnlineRepair $Content }.GetNewClosure()) }

    # ── Components — Sub-tab navigation ───────────────────────────────────────
    $compMap = @{
        'btnCompOutlook' = 'Outlook'
        'btnCompWord'    = 'Word'
        'btnCompExcel'   = 'Excel'
        'btnCompPPT'     = 'PPT'
        'btnCompTeams'   = 'Teams'
        'btnCompAccess'  = 'Access'
    }
    foreach ($k in $compMap.Keys) {
        $btn = $Content.FindName($k)
        if ($btn) {
            $comp = $compMap[$k]
            $btn.Add_Click({
                Office_SwitchComponent $comp $Content
            }.GetNewClosure())
        }
    }

    # ── Components — Repair buttons per application ───────────────────────────
    $btnOutlookRepair = $Content.FindName('btnOutlookRepair')
    if ($btnOutlookRepair) {
        $btnOutlookRepair.Add_Click({ Office_RepairOutlook $Content }.GetNewClosure())
    }

    $btnOutlookConn = $Content.FindName('btnOutlookConnCheck')
    if ($btnOutlookConn) {
        $btnOutlookConn.Add_Click({ Office_CheckOutlookConnectivity $Content }.GetNewClosure())
    }

    $btnWordRepair = $Content.FindName('btnWordRepair')
    if ($btnWordRepair) {
        $btnWordRepair.Add_Click({ Office_RepairWord $Content }.GetNewClosure())
    }

    $btnExcelRepair = $Content.FindName('btnExcelRepair')
    if ($btnExcelRepair) {
        $btnExcelRepair.Add_Click({ Office_RepairExcel $Content }.GetNewClosure())
    }

    $btnPPTRepair = $Content.FindName('btnPPTRepair')
    if ($btnPPTRepair) {
        $btnPPTRepair.Add_Click({ Office_RepairPPT $Content }.GetNewClosure())
    }

    $btnTeamsRepair = $Content.FindName('btnTeamsRepair')
    if ($btnTeamsRepair) {
        $btnTeamsRepair.Add_Click({ Office_RepairTeams $Content }.GetNewClosure())
    }

    $btnAccessRepair = $Content.FindName('btnAccessRepair')
    if ($btnAccessRepair) {
        $btnAccessRepair.Add_Click({ Office_RepairAccess $Content }.GetNewClosure())
    }

    # ── Add-ins ───────────────────────────────────────────────────────────────
    $btnAddinsScan = $Content.FindName('btnAddinsScan')
    if ($btnAddinsScan) {
        $btnAddinsScan.Add_Click({ Office_ScanAddins $Content }.GetNewClosure())
    }

    $btnAddinsDisableAll = $Content.FindName('btnAddinsDisableAll')
    if ($btnAddinsDisableAll) {
        $btnAddinsDisableAll.Add_Click({ Office_DisableAllErrorAddins $Content }.GetNewClosure())
    }

    $btnAddinsEnableAll = $Content.FindName('btnAddinsEnableAll')
    if ($btnAddinsEnableAll) {
        $btnAddinsEnableAll.Add_Click({ Office_EnableAllAddins $Content }.GetNewClosure())
    }

    # ── Auth ──────────────────────────────────────────────────────────────────
    $authActions = @{
        'btnAuthClearTokens'   = 'ClearTokens'
        'btnAuthClearCreds'    = 'ClearCreds'
        'btnAuthClearAAD'      = 'ClearAAD'
        'btnAuthResetSession'  = 'ResetSession'
        'btnAuthClearIdentity' = 'ClearIdentity'
    }
    foreach ($btnName in $authActions.Keys) {
        $btn = $Content.FindName($btnName)
        if ($btn) {
            $action = $authActions[$btnName]
            $btn.Add_Click({
                Office_ClearIdentityCache $action $Content
            }.GetNewClosure())
        }
    }

    # ── Cache ─────────────────────────────────────────────────────────────────
    $btnCacheCleanAll = $Content.FindName('btnCacheCleanAll')
    if ($btnCacheCleanAll) {
        $btnCacheCleanAll.Add_Click({ Office_CleanCache $true $Content }.GetNewClosure())
    }

    $btnCacheClean = $Content.FindName('btnCacheClean')
    if ($btnCacheClean) {
        $btnCacheClean.Add_Click({ Office_CleanCache $false $Content }.GetNewClosure())
    }

    # ── Report ────────────────────────────────────────────────────────────────
    $btnGenerate = $Content.FindName('btnReportGenerate')
    if ($btnGenerate) {
        $btnGenerate.Add_Click({ Office_GenerateReport $Content }.GetNewClosure())
    }

    $btnExportHTML = $Content.FindName('btnReportExportHTML')
    if ($btnExportHTML) {
        $btnExportHTML.Add_Click({ Office_ExportReport 'HTML' $Content }.GetNewClosure())
    }

    $btnExportTXT = $Content.FindName('btnReportExportTXT')
    if ($btnExportTXT) {
        $btnExportTXT.Add_Click({ Office_ExportReport 'TXT' $Content }.GetNewClosure())
    }

    # ── [FIX #6] Milestone: callbacks vinculados ─────────────────────────────
    if ($script:DebugMode) { Write-Log "[MOD:Office] Callbacks vinculados: $($sw.ElapsedMilliseconds)ms" -Level DBG }

    # ── Initial state ─────────────────────────────────────────────────────────
    Office_SwitchPanel 'Detection' $Content
    Office_SwitchComponent 'Outlook' $Content

    # ── Pre-load License & Services — caché primero, refresco diferido ─────────
    # Paso 1: carga instantánea desde disco (si existe caché válida) → UI responsiva
    # Paso 2: refresco real en background 200ms después → datos frescos sin bloquear init
    try { Office_RefreshLicense  $Content } catch {}   # fast: reads cache
    try { Office_RefreshServices $Content } catch {}   # fast: reads cache

    # ── OPTIM-3: Refresco paralelo en background via OfficeCollector ───────────
    # Usa Task.Run internamente → no bloquea UI, datos listos en ~500ms vs ~2000ms
    $script:officeCollectJob = $null
    $script:_officePreloadTimer = [System.Windows.Threading.DispatcherTimer]::new()
    $script:_officePreloadTimer.Interval = [TimeSpan]::FromMilliseconds(200)
    $script:_officePreloadTimer.Add_Tick({
        try { $this.Stop() } catch { try { $script:_officePreloadTimer.Stop() } catch {} }
        try {
            if (([System.Management.Automation.PSTypeName]"SysOpt.Office.Core.OfficeCollector").Type) {
                # Lanzar OfficeCollector en background (paraleliza detección + licencia + servicios)
                $collectScript = { [SysOpt.Office.Core.OfficeCollector]::CollectAll() }
                $ps = [PowerShell]::Create().AddScript($collectScript)
                if ($script:rsPool) { $ps.RunspacePool = $script:rsPool }
                $script:officeCollectJob = @{
                    PS     = $ps
                    Handle = $ps.BeginInvoke()
                }
                # Timer de poll: comprueba cada 100ms si el job terminó
                $script:officeCollectPollTimer = [System.Windows.Threading.DispatcherTimer]::new()
                $script:officeCollectPollTimer.Interval = [TimeSpan]::FromMilliseconds(100)
                $script:officeCollectPollTimer.Add_Tick({
                    if ($script:officeCollectJob -and $script:officeCollectJob.Handle.IsCompleted) {
                        try { $this.Stop() } catch {}
                        try {
                            $snap = $script:officeCollectJob.PS.EndInvoke($script:officeCollectJob.Handle)
                            if ($snap -and $snap.Count -gt 0) {
                                Office_ApplySnapshot $snap[0] $Content
                                Write-Log "[MOD:Office] Collector completado en $($snap[0].ElapsedMs)ms" -Level DBG
                            }
                        } catch {
                            Write-Log "[MOD:Office] Collector error: $_" -Level WARN
                        } finally {
                            try { $script:officeCollectJob.PS.Dispose() } catch {}
                            $script:officeCollectJob = $null
                        }
                    }
                }.GetNewClosure())
                $script:officeCollectPollTimer.Start()
                Write-Log "[MOD:Office] Collector lanzado en background" -Level DBG
            } else {
                # Fallback: OfficeCollector no disponible → refresco síncrono
                # Con ServiceController (OPTIM-1) esto es rápido (~10ms servicios)
                try { Office_RefreshLicense  $Content -ForceRefresh } catch {}
                try { Office_RefreshServices $Content -ForceRefresh } catch {}
            }
        } catch {
            Write-Log "[MOD:Office] Error lanzando collector: $_" -Level WARN
            try { Office_RefreshLicense  $Content -ForceRefresh } catch {}
            try { Office_RefreshServices $Content -ForceRefresh } catch {}
        }
    }.GetNewClosure())
    $script:_officePreloadTimer.Start()

    Write-Log "[MOD:Office] UI inicializada en $($sw.ElapsedMilliseconds)ms" -Level INFO
    if ($script:DebugMode) { Write-Log "[MOD:Office] Initialize-ModuleUI_office FIN: $($sw.ElapsedMilliseconds)ms" -Level DBG }
}
