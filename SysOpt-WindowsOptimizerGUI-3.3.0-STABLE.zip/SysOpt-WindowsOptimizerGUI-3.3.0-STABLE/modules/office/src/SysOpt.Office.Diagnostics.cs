// ╔══════════════════════════════════════════════════════════════════╗
// ║  SysOpt.Office.Diagnostics.dll — v1.0.0                         ║
// ║  Generación de informes y exportación de diagnóstico            ║
// ║  Autor: Danew Malavita | Licencia: GPL-3.0                      ║
// ╚══════════════════════════════════════════════════════════════════╝
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace SysOpt.Office.Diagnostics
{
    // ─── Entrada individual del log ───
    public class DiagEntry
    {
        public DateTime Timestamp { get; set; }
        public string   Category  { get; set; }
        public string   Severity  { get; set; }
        public string   Action    { get; set; }
        public string   Message   { get; set; }
        public string   Detail    { get; set; }

        public DiagEntry()
        {
            Timestamp = DateTime.Now;
            Category  = "";
            Severity  = "Info";
            Action    = "";
            Message   = "";
            Detail    = "";
        }

        public override string ToString()
        {
            return string.Format("[{0:HH:mm:ss}] [{1,-7}] [{2,-10}] {3}: {4}", Timestamp, Severity, Category, Action, Message);
        }

        public string ToDetailedString()
        {
            var sb = new StringBuilder();
            sb.AppendLine(string.Format("[{0:yyyy-MM-dd HH:mm:ss}] [{1}] [{2}]", Timestamp, Severity, Category));
            sb.AppendLine(string.Format("  Action:  {0}", Action));
            sb.AppendLine(string.Format("  Message: {0}", Message));
            if (!string.IsNullOrEmpty(Detail))
                sb.AppendLine(string.Format("  Detail:  {0}", Detail));
            return sb.ToString();
        }
    }

    // ─── Resumen del informe ───
    public class DiagSummary
    {
        public int TotalEntries { get; set; }
        public int Errors       { get; set; }
        public int Warnings     { get; set; }
        public int Successes    { get; set; }
        public int InfoEntries  { get; set; }
        public string OverallHealth { get; set; }
        public DateTime GeneratedAt { get; set; }

        public DiagSummary()
        {
            OverallHealth = "Unknown";
            GeneratedAt = DateTime.Now;
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  MOTOR DE DIAGNÓSTICO
    // ═══════════════════════════════════════════════════════════════
    public class DiagEngine
    {
        private readonly List<DiagEntry> _log = new List<DiagEntry>();

        /// <summary>Agrega una entrada al log</summary>
        public void Log(string category, string severity, string action, string message, string detail = "")
        {
            _log.Add(new DiagEntry
            {
                Timestamp = DateTime.Now,
                Category  = category,
                Severity  = severity,
                Action    = action,
                Message   = message,
                Detail    = detail
            });
        }

        /// <summary>Agrega una entrada Info</summary>
        public void Info(string category, string action, string message, string detail = "")
        {
            Log(category, "Info", action, message, detail);
        }

        /// <summary>Agrega una entrada Success</summary>
        public void Success(string category, string action, string message, string detail = "")
        {
            Log(category, "Success", action, message, detail);
        }

        /// <summary>Agrega una entrada Warning</summary>
        public void Warn(string category, string action, string message, string detail = "")
        {
            Log(category, "Warning", action, message, detail);
        }

        /// <summary>Agrega una entrada Error</summary>
        public void Error(string category, string action, string message, string detail = "")
        {
            Log(category, "Error", action, message, detail);
        }

        /// <summary>Obtiene todas las entradas</summary>
        public List<DiagEntry> GetEntries()
        {
            return new List<DiagEntry>(_log);
        }

        /// <summary>Filtra por categoría</summary>
        public List<DiagEntry> GetByCategory(string category)
        {
            return _log.Where(e => e.Category.Equals(category, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        /// <summary>Filtra por severidad</summary>
        public List<DiagEntry> GetBySeverity(string severity)
        {
            return _log.Where(e => e.Severity.Equals(severity, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        /// <summary>Genera resumen del diagnóstico</summary>
        public DiagSummary GetSummary()
        {
            var s = new DiagSummary
            {
                TotalEntries = _log.Count,
                Errors       = _log.Count(e => e.Severity == "Error"),
                Warnings     = _log.Count(e => e.Severity == "Warning"),
                Successes    = _log.Count(e => e.Severity == "Success"),
                InfoEntries  = _log.Count(e => e.Severity == "Info")
            };

            if (s.Errors > 0)      s.OverallHealth = "Critical";
            else if (s.Warnings > 3) s.OverallHealth = "Degraded";
            else if (s.Warnings > 0) s.OverallHealth = "Fair";
            else                      s.OverallHealth = "Healthy";

            return s;
        }

        /// <summary>Limpia el log</summary>
        public void Clear()
        {
            _log.Clear();
        }

        /// <summary>Cantidad de entradas</summary>
        public int Count
        {
            get { return _log.Count; }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  EXPORTADOR DE INFORMES
    // ═══════════════════════════════════════════════════════════════
    public static class ReportExporter
    {
        /// <summary>Genera informe completo en texto plano</summary>
        public static string GenerateTextReport(
            DiagEngine engine,
            string osVersion,
            string sysOptVersion,
            string officeVersion,
            string officeLicense)
        {
            var sb = new StringBuilder();
            var summary = engine.GetSummary();

            sb.AppendLine("╔══════════════════════════════════════════════════════════════════╗");
            sb.AppendLine("║        SysOpt — Office Module Diagnostic Report                  ║");
            sb.AppendLine("╚══════════════════════════════════════════════════════════════════╝");
            sb.AppendLine();
            sb.AppendLine(string.Format("  Generated:       {0:yyyy-MM-dd HH:mm:ss}", summary.GeneratedAt));
            sb.AppendLine(string.Format("  OS Version:      {0}", osVersion));
            sb.AppendLine(string.Format("  SysOpt Version:  {0}", sysOptVersion));
            sb.AppendLine(string.Format("  Office Version:  {0}", officeVersion));
            sb.AppendLine(string.Format("  License:         {0}", officeLicense));
            sb.AppendLine();
            sb.AppendLine("─── SUMMARY ────────────────────────────────────────────────────");
            sb.AppendLine(string.Format("  Overall Health:  {0}", summary.OverallHealth));
            sb.AppendLine(string.Format("  Total Checks:    {0}", summary.TotalEntries));
            sb.AppendLine(string.Format("  ✓ Success:       {0}", summary.Successes));
            sb.AppendLine(string.Format("  ⚠ Warnings:      {0}", summary.Warnings));
            sb.AppendLine(string.Format("  ✗ Errors:        {0}", summary.Errors));
            sb.AppendLine(string.Format("  ℹ Info:           {0}", summary.InfoEntries));
            sb.AppendLine();

            var categories = engine.GetEntries()
                .Select(e => e.Category)
                .Distinct()
                .OrderBy(c => c);

            foreach (var cat in categories)
            {
                sb.AppendLine(string.Format("─── {0} ────────────────────────────────────────────", cat.ToUpper()));
                foreach (var entry in engine.GetByCategory(cat))
                {
                    var icon = entry.Severity == "Error" ? "✗" :
                               entry.Severity == "Warning" ? "⚠" :
                               entry.Severity == "Success" ? "✓" : "ℹ";
                    sb.AppendLine(string.Format("  {0} [{1:HH:mm:ss}] {2}: {3}", icon, entry.Timestamp, entry.Action, entry.Message));
                    if (!string.IsNullOrEmpty(entry.Detail))
                        sb.AppendLine(string.Format("    └─ {0}", entry.Detail));
                }
                sb.AppendLine();
            }

            sb.AppendLine("═══════════════════════════════════════════════════════════════════");
            sb.AppendLine("  End of Report — SysOpt Office Module v1.0.0");
            sb.AppendLine("═══════════════════════════════════════════════════════════════════");

            return sb.ToString();
        }

        /// <summary>Genera informe en formato HTML</summary>
        public static string GenerateHtmlReport(
            DiagEngine engine,
            string osVersion,
            string sysOptVersion,
            string officeVersion,
            string officeLicense)
        {
            var summary = engine.GetSummary();
            var sb = new StringBuilder();

            sb.AppendLine("<!DOCTYPE html><html lang='en'><head><meta charset='utf-8'>");
            sb.AppendLine("<title>SysOpt Office Diagnostic Report</title>");
            sb.AppendLine("<style>");
            sb.AppendLine("body{font-family:'Segoe UI',sans-serif;background:#1c1c1e;color:#e5e5ea;padding:2em;max-width:900px;margin:0 auto}");
            sb.AppendLine("h1{color:#0a84ff}h2{color:#64d2ff;border-bottom:1px solid #333;padding-bottom:.3em}");
            sb.AppendLine("table{width:100%;border-collapse:collapse;margin:1em 0}");
            sb.AppendLine("th,td{padding:.5em .8em;text-align:left;border-bottom:1px solid #333}");
            sb.AppendLine("th{background:#2c2c2e;color:#a1a1a6}.err{color:#ff453a}.warn{color:#ffd60a}.ok{color:#30d158}.info{color:#64d2ff}");
            sb.AppendLine(".badge{display:inline-block;padding:2px 8px;border-radius:4px;font-size:.8em;font-weight:600}");
            sb.AppendLine(".badge.critical{background:#ff453a22;color:#ff453a}.badge.degraded{background:#ffd60a22;color:#ffd60a}");
            sb.AppendLine(".badge.fair{background:#ffd60a22;color:#ffd60a}.badge.healthy{background:#30d15822;color:#30d158}");
            sb.AppendLine("</style></head><body>");

            sb.AppendLine("<h1>🔧 SysOpt Office Diagnostic Report</h1>");
            sb.AppendLine(string.Format("<p><strong>Generated:</strong> {0:yyyy-MM-dd HH:mm:ss} | ", summary.GeneratedAt));
            sb.AppendLine(string.Format("<strong>OS:</strong> {0} | <strong>Office:</strong> {1}</p>", Escape(osVersion), Escape(officeVersion)));

            var healthClass = summary.OverallHealth.ToLower();
            sb.AppendLine(string.Format("<h2>Summary <span class='badge {0}'>{1}</span></h2>", healthClass, summary.OverallHealth));
            sb.AppendLine("<table><tr><th>Metric</th><th>Count</th></tr>");
            sb.AppendLine(string.Format("<tr><td class='ok'>✓ Success</td><td>{0}</td></tr>", summary.Successes));
            sb.AppendLine(string.Format("<tr><td class='warn'>⚠ Warnings</td><td>{0}</td></tr>", summary.Warnings));
            sb.AppendLine(string.Format("<tr><td class='err'>✗ Errors</td><td>{0}</td></tr>", summary.Errors));
            sb.AppendLine(string.Format("<tr><td class='info'>ℹ Info</td><td>{0}</td></tr>", summary.InfoEntries));
            sb.AppendLine("</table>");

            var categories = engine.GetEntries()
                .Select(e => e.Category).Distinct().OrderBy(c => c);

            foreach (var cat in categories)
            {
                sb.AppendLine(string.Format("<h2>{0}</h2><table>", Escape(cat)));
                sb.AppendLine("<tr><th>Time</th><th>Status</th><th>Action</th><th>Message</th></tr>");
                foreach (var e in engine.GetByCategory(cat))
                {
                    var cls = e.Severity == "Error" ? "err" :
                              e.Severity == "Warning" ? "warn" :
                              e.Severity == "Success" ? "ok" : "info";
                    sb.AppendLine(string.Format("<tr><td>{0:HH:mm:ss}</td><td class='{1}'>{2}</td>", e.Timestamp, cls, e.Severity));
                    sb.AppendLine(string.Format("<td>{0}</td><td>{1}</td></tr>", Escape(e.Action), Escape(e.Message)));
                }
                sb.AppendLine("</table>");
            }

            sb.AppendLine("<hr><p style='color:#636366'>SysOpt Office Module v1.0.0 — GPL-3.0</p>");
            sb.AppendLine("</body></html>");
            return sb.ToString();
        }

        /// <summary>Exporta informe a archivo</summary>
        public static string ExportToFile(string content, string filePath)
        {
            try
            {
                var dir = Path.GetDirectoryName(filePath);
                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                    Directory.CreateDirectory(dir);
                File.WriteAllText(filePath, content, Encoding.UTF8);
                return filePath;
            }
            catch (Exception ex)
            {
                return "ERROR: " + ex.Message;
            }
        }

        /// <summary>Genera nombre de archivo con timestamp</summary>
        public static string GetDefaultFileName(string extension = "txt")
        {
            return string.Format("SysOpt-Office-Diag-{0:yyyyMMdd-HHmmss}.{1}", DateTime.Now, extension);
        }

        private static string Escape(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");
        }
    }
}
