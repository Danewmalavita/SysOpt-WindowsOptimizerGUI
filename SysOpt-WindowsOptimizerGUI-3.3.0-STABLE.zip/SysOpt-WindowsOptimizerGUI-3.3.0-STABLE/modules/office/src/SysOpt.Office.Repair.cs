// ╔══════════════════════════════════════════════════════════════════╗
// ║  SysOpt.Office.Repair.dll — v1.0.0                              ║
// ║  Reparación de Office, componentes, identidad y caché           ║
// ║  Autor: Danew Malavita | Licencia: GPL-3.0                      ║
// ╚══════════════════════════════════════════════════════════════════╝
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using Microsoft.Win32;

namespace SysOpt.Office.Repair
{
    // ─── Resultado genérico de reparación ───
    public class RepairResult
    {
        public string Action { get; set; }
        public bool   Success { get; set; }
        public string Message { get; set; }
        public string Severity { get; set; } // Info, Warning, Error, Success
        public DateTime Timestamp { get; set; }

        public RepairResult()
        {
            Action = "";
            Message = "";
            Severity = "Info";
            Timestamp = DateTime.Now;
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  1. REPARACIÓN BÁSICA (Quick / Online)
    // ═══════════════════════════════════════════════════════════════
    public static class BasicRepair
    {
        /// <summary>Obtiene la ruta del OfficeClickToRun.exe</summary>
        public static string GetC2RExePath()
        {
            var paths = new[]
            {
                @"C:\Program Files\Common Files\Microsoft Shared\ClickToRun\OfficeClickToRun.exe",
                @"C:\Program Files (x86)\Common Files\Microsoft Shared\ClickToRun\OfficeClickToRun.exe"
            };
            foreach (var p in paths)
                if (File.Exists(p)) return p;
            return null;
        }

        /// <summary>Genera argumentos para Quick Repair</summary>
        public static string GetQuickRepairArgs()
        {
            return "scenario=Repair platform=x64 culture=es-es RepairType=QuickRepair DisplayLevel=true";
        }

        /// <summary>Genera argumentos para Online Repair</summary>
        public static string GetOnlineRepairArgs()
        {
            return "scenario=Repair platform=x64 culture=es-es RepairType=FullRepair DisplayLevel=true";
        }

        /// <summary>Verifica integridad del C2R — comprueba archivos clave</summary>
        public static List<RepairResult> VerifyC2RIntegrity()
        {
            var results = new List<RepairResult>();
            var criticalFiles = new[]
            {
                @"C:\Program Files\Common Files\Microsoft Shared\ClickToRun\OfficeClickToRun.exe",
                @"C:\Program Files\Common Files\Microsoft Shared\ClickToRun\AppVIsvStream64.dll",
                @"C:\Program Files\Common Files\Microsoft Shared\ClickToRun\C2RINTL.dll"
            };
            foreach (var f in criticalFiles)
            {
                results.Add(new RepairResult
                {
                    Action   = "VerifyFile",
                    Success  = File.Exists(f),
                    Message  = File.Exists(f) ? "OK: " + Path.GetFileName(f) : "MISSING: " + Path.GetFileName(f),
                    Severity = File.Exists(f) ? "Success" : "Error"
                });
            }
            return results;
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  2. REPARACIÓN POR COMPONENTE: Outlook
    // ═══════════════════════════════════════════════════════════════
    public static class OutlookRepair
    {
        /// <summary>Obtiene rutas de perfiles Outlook del registro</summary>
        public static List<string> GetProfileNames()
        {
            var profiles = new List<string>();
            try
            {
                var key = Registry.CurrentUser.OpenSubKey(
                    @"Software\Microsoft\Office\16.0\Outlook\Profiles");
                if (key != null)
                {
                    profiles.AddRange(key.GetSubKeyNames());
                    key.Close();
                }
            }
            catch { }
            return profiles;
        }

        /// <summary>Localiza archivos OST del usuario</summary>
        public static List<string> FindOSTFiles()
        {
            var results = new List<string>();
            var searchPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Microsoft", "Outlook");
            if (Directory.Exists(searchPath))
            {
                results.AddRange(Directory.GetFiles(searchPath, "*.ost", SearchOption.AllDirectories));
            }
            return results;
        }

        /// <summary>Localiza archivos PST</summary>
        public static List<string> FindPSTFiles()
        {
            var results = new List<string>();
            var searchPaths = new[]
            {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Outlook Files"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Microsoft", "Outlook")
            };
            foreach (var dir in searchPaths)
            {
                if (Directory.Exists(dir))
                    results.AddRange(Directory.GetFiles(dir, "*.pst", SearchOption.AllDirectories));
            }
            return results;
        }

        /// <summary>Obtiene tamaño de un archivo PST/OST en MB</summary>
        public static double GetFileSizeMB(string path)
        {
            if (!File.Exists(path)) return 0;
            return new FileInfo(path).Length / (1024.0 * 1024.0);
        }

        /// <summary>Obtiene ruta de ScanPST.exe</summary>
        public static string GetScanPSTPath()
        {
            var paths = new[]
            {
                @"C:\Program Files\Microsoft Office\root\Office16\SCANPST.EXE",
                @"C:\Program Files (x86)\Microsoft Office\root\Office16\SCANPST.EXE",
                @"C:\Program Files\Microsoft Office\Office16\SCANPST.EXE"
            };
            foreach (var p in paths)
                if (File.Exists(p)) return p;
            return null;
        }

        /// <summary>Comprueba conectividad SMTP básica</summary>
        public static RepairResult TestSMTPConnectivity(string host = "smtp.office365.com", int port = 587)
        {
            try
            {
                using (var client = new System.Net.Sockets.TcpClient())
                {
                    var task = client.ConnectAsync(host, port);
                    if (task.Wait(5000))
                    {
                        return new RepairResult { Action = "TestSMTP", Success = true, Message = "Conectado a " + host + ":" + port, Severity = "Success" };
                    }
                    return new RepairResult { Action = "TestSMTP", Success = false, Message = "Timeout conectando a " + host + ":" + port, Severity = "Warning" };
                }
            }
            catch (Exception ex)
            {
                return new RepairResult { Action = "TestSMTP", Success = false, Message = "Error: " + ex.Message, Severity = "Error" };
            }
        }

        /// <summary>Rutas del índice de búsqueda de Outlook</summary>
        public static string GetSearchIndexPath()
        {
            return Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Microsoft", "Outlook", "RoamCache");
        }

        /// <summary>Obtiene complementos deshabilitados de Outlook</summary>
        public static List<string> GetDisabledAddins()
        {
            var addins = new List<string>();
            try
            {
                var key = Registry.CurrentUser.OpenSubKey(
                    @"Software\Microsoft\Office\16.0\Outlook\Resiliency\DisabledItems");
                if (key != null)
                {
                    foreach (var name in key.GetValueNames())
                    {
                        var valObj = key.GetValue(name);
                        var val = valObj != null ? valObj.ToString() : null;
                        if (!string.IsNullOrEmpty(val)) addins.Add(val);
                    }
                    key.Close();
                }
            }
            catch { }
            return addins;
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  3. REPARACIÓN POR COMPONENTE: Word / Excel / PowerPoint
    // ═══════════════════════════════════════════════════════════════
    public static class AppRepair
    {
        /// <summary>Localiza normal.dotm de Word</summary>
        public static string GetNormalDotmPath()
        {
            return Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "Microsoft", "Templates", "Normal.dotm");
        }

        /// <summary>Verifica si normal.dotm existe y su tamaño</summary>
        public static RepairResult CheckNormalDotm()
        {
            var path = GetNormalDotmPath();
            if (!File.Exists(path))
                return new RepairResult { Action = "CheckNormalDotm", Success = false, Message = "Normal.dotm no encontrado", Severity = "Warning" };
            
            var size = new FileInfo(path).Length / 1024.0;
            var isLarge = size > 500; // >500KB es sospechoso
            return new RepairResult
            {
                Action = "CheckNormalDotm",
                Success = !isLarge,
                Message = isLarge ? string.Format("Normal.dotm grande: {0:F0}KB (posible corrupción)", size) : string.Format("Normal.dotm OK ({0:F0}KB)", size),
                Severity = isLarge ? "Warning" : "Success"
            };
        }

        /// <summary>Obtiene la carpeta Startup de Office (plantillas auto-carga)</summary>
        public static string GetStartupFolderPath(string app = "Word")
        {
            return Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "Microsoft", app, "STARTUP");
        }

        /// <summary>Lista plantillas en la carpeta Startup</summary>
        public static List<string> GetStartupTemplates(string app = "Word")
        {
            var results = new List<string>();
            var dir = GetStartupFolderPath(app);
            if (Directory.Exists(dir))
            {
                results.AddRange(Directory.GetFiles(dir, "*.dot*"));
                results.AddRange(Directory.GetFiles(dir, "*.xla*"));
            }
            return results;
        }

        /// <summary>Resetea configuración de una app Office en registro</summary>
        public static string GetResetRegistryPath(string app)
        {
            return @"Software\Microsoft\Office\16.0\" + app + @"\Options";
        }

        /// <summary>Verifica carpeta de macros VBA del usuario</summary>
        public static RepairResult CheckVBAProject()
        {
            var vbaPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "Microsoft", "VBA");
            if (!Directory.Exists(vbaPath))
                return new RepairResult { Action = "CheckVBA", Success = true, Message = "Sin carpeta VBA personalizada", Severity = "Info" };
            
            var files = Directory.GetFiles(vbaPath, "*", SearchOption.AllDirectories);
            return new RepairResult
            {
                Action = "CheckVBA",
                Success = true,
                Message = "Carpeta VBA: " + files.Length + " archivos encontrados",
                Severity = "Info"
            };
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  4. REPARACIÓN: Teams
    // ═══════════════════════════════════════════════════════════════
    public static class TeamsRepair
    {
        /// <summary>Obtiene rutas de caché de Teams (new Teams + classic)</summary>
        public static List<string> GetTeamsCachePaths()
        {
            var localApp = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            return new List<string>
            {
                Path.Combine(localApp, "Microsoft", "Teams", "Cache"),
                Path.Combine(localApp, "Microsoft", "Teams", "blob_storage"),
                Path.Combine(localApp, "Microsoft", "Teams", "databases"),
                Path.Combine(localApp, "Microsoft", "Teams", "GPUCache"),
                Path.Combine(localApp, "Microsoft", "Teams", "IndexedDB"),
                Path.Combine(localApp, "Microsoft", "Teams", "Local Storage"),
                Path.Combine(localApp, "Microsoft", "Teams", "tmp"),
                Path.Combine(localApp, "Packages", "MSTeams_8wekyb3d8bbwe", "LocalCache")
            };
        }

        /// <summary>Calcula tamaño total de carpetas de caché existentes</summary>
        public static long GetTotalCacheSizeBytes()
        {
            long total = 0;
            foreach (var dir in GetTeamsCachePaths())
            {
                if (Directory.Exists(dir))
                {
                    try
                    {
                        total += Directory.GetFiles(dir, "*", SearchOption.AllDirectories)
                                          .Sum(f => new FileInfo(f).Length);
                    }
                    catch { }
                }
            }
            return total;
        }

        /// <summary>Rutas de configuración de Teams para reset</summary>
        public static List<string> GetTeamsConfigPaths()
        {
            var localApp = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            return new List<string>
            {
                Path.Combine(appData, "Microsoft", "Teams", "storage.json"),
                Path.Combine(appData, "Microsoft", "Teams", "desktop-config.json"),
                Path.Combine(localApp, "Packages", "MSTeams_8wekyb3d8bbwe", "Settings", "settings.dat")
            };
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  5. REPARACIÓN: Access
    // ═══════════════════════════════════════════════════════════════
    public static class AccessRepair
    {
        /// <summary>Verifica si Access está instalado</summary>
        public static bool IsAccessInstalled()
        {
            var paths = new[]
            {
                @"C:\Program Files\Microsoft Office\root\Office16\MSACCESS.EXE",
                @"C:\Program Files (x86)\Microsoft Office\root\Office16\MSACCESS.EXE"
            };
            return paths.Any(File.Exists);
        }

        /// <summary>Obtiene ruta del motor de base de datos ACE</summary>
        public static string GetACEEnginePath()
        {
            try
            {
                var key = Registry.LocalMachine.OpenSubKey(
                    @"SOFTWARE\Microsoft\Office\ClickToRun\Configuration");
                if (key != null)
                {
                    var platformObj = key.GetValue("Platform");
                    var platform = platformObj != null ? platformObj.ToString() : null;
                    key.Close();
                    var aceBase = platform == "x64"
                        ? @"C:\Program Files\Common Files\Microsoft Shared\OFFICE16"
                        : @"C:\Program Files (x86)\Common Files\Microsoft Shared\OFFICE16";
                    if (Directory.Exists(aceBase)) return aceBase;
                }
            }
            catch { }
            return null;
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  6. IDENTIDAD Y AUTENTICACIÓN
    // ═══════════════════════════════════════════════════════════════
    public static class IdentityRepair
    {
        /// <summary>Rutas de caché de identidad de Office</summary>
        public static List<string> GetIdentityCachePaths()
        {
            var localApp = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            return new List<string>
            {
                Path.Combine(localApp, "Microsoft", "Office", "16.0", "Licensing"),
                Path.Combine(localApp, "Microsoft", "Office", "Licenses"),
                Path.Combine(localApp, "Microsoft", "IdentityCache"),
                Path.Combine(localApp, "Microsoft", "OneAuth"),
                Path.Combine(localApp, "Packages", "Microsoft.AAD.BrokerPlugin_cw5n1h2txyewy", "AC", "TokenBroker")
            };
        }

        /// <summary>Claves de registro de identidad</summary>
        public static List<string> GetIdentityRegistryKeys()
        {
            return new List<string>
            {
                @"HKCU\Software\Microsoft\Office\16.0\Common\Identity",
                @"HKCU\Software\Microsoft\Office\16.0\Common\Internet\WebServiceCache",
                @"HKCU\Software\Microsoft\Office\16.0\Common\Licensing"
            };
        }

        /// <summary>Verifica si hay tokens caducados</summary>
        public static RepairResult CheckTokenHealth()
        {
            var tokenPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Packages", "Microsoft.AAD.BrokerPlugin_cw5n1h2txyewy", "AC", "TokenBroker", "Accounts");
            
            if (!Directory.Exists(tokenPath))
                return new RepairResult { Action = "CheckTokens", Success = true, Message = "No se encontró carpeta de tokens AAD", Severity = "Info" };
            
            var files = Directory.GetFiles(tokenPath, "*.tbacct");
            return new RepairResult
            {
                Action = "CheckTokens",
                Success = true,
                Message = files.Length + " cuentas de token encontradas",
                Severity = files.Length > 0 ? "Info" : "Warning"
            };
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  7. LIMPIEZA DE CACHÉ GENERAL
    // ═══════════════════════════════════════════════════════════════
    public static class CacheCleanup
    {
        public class CacheTarget
        {
            public string Name { get; set; }
            public string Path { get; set; }
            public long   SizeBytes { get; set; }
            public bool   Exists { get; set; }

            public CacheTarget()
            {
                Name = "";
                Path = "";
            }
        }

        /// <summary>Enumera todas las carpetas de caché limpiables</summary>
        public static List<CacheTarget> EnumerateCacheTargets()
        {
            var localApp = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var temp = System.IO.Path.GetTempPath();

            var targets = new[]
            {
                new { Name = "Office Click-to-Run Cache", Dir = System.IO.Path.Combine(localApp, "Microsoft", "Office", "16.0", "OfficeFileCache") },
                new { Name = "Office OSPP Temp", Dir = System.IO.Path.Combine(temp, "Office") },
                new { Name = "Outlook Autocomplete Cache", Dir = System.IO.Path.Combine(localApp, "Microsoft", "Outlook", "RoamCache") },
                new { Name = "Outlook Form Cache", Dir = System.IO.Path.Combine(localApp, "Microsoft", "FORMS") },
                new { Name = "Word Temp Files", Dir = System.IO.Path.Combine(temp, "Word") },
                new { Name = "Excel Temp Files", Dir = System.IO.Path.Combine(temp, "Excel") },
                new { Name = "Teams Logs", Dir = System.IO.Path.Combine(appData, "Microsoft", "Teams", "logs") },
                new { Name = "Teams Blob Storage", Dir = System.IO.Path.Combine(localApp, "Microsoft", "Teams", "blob_storage") },
                new { Name = "Teams GPU Cache", Dir = System.IO.Path.Combine(localApp, "Microsoft", "Teams", "GPUCache") },
                new { Name = "New Teams Cache", Dir = System.IO.Path.Combine(localApp, "Packages", "MSTeams_8wekyb3d8bbwe", "LocalCache", "Microsoft", "MSTeams") }
            };

            var results = new List<CacheTarget>();
            foreach (var t in targets)
            {
                var ct = new CacheTarget { Name = t.Name, Path = t.Dir };
                if (Directory.Exists(t.Dir))
                {
                    ct.Exists = true;
                    try
                    {
                        ct.SizeBytes = Directory.GetFiles(t.Dir, "*", SearchOption.AllDirectories)
                                                .Sum(f => new FileInfo(f).Length);
                    }
                    catch { ct.SizeBytes = -1; }
                }
                results.Add(ct);
            }
            return results;
        }

        /// <summary>Calcula tamaño total seleccionado para limpieza</summary>
        public static string FormatSize(long bytes)
        {
            if (bytes < 0) return "N/A";
            if (bytes < 1024) return bytes + " B";
            if (bytes < 1048576) return string.Format("{0:F1} KB", bytes / 1024.0);
            if (bytes < 1073741824) return string.Format("{0:F1} MB", bytes / 1048576.0);
            return string.Format("{0:F2} GB", bytes / 1073741824.0);
        }
    }
}
