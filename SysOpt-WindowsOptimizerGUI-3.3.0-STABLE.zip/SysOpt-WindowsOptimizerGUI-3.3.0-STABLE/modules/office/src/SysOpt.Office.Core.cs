// ╔══════════════════════════════════════════════════════════════════════╗
// ║  SysOpt — Office Manager Module                                     ║
// ║  Copyright (C) 2026 Danew Malavita                                  ║
// ║                                                                     ║
// ║  Version : 1.0.0  |  Assembly: SysOpt.Office.Core                  ║
// ║  License : GNU General Public License v3.0                          ║
// ║  Requires: SysOpt >= 3.3.0                                          ║
// ╚══════════════════════════════════════════════════════════════════════╝

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Management;
using Microsoft.Win32;

namespace SysOpt.Office.Core
{
    // ─── Data models ──────────────────────────────────────────────────────────

    public class OfficeInstall
    {
        public string ProductName { get; set; }
        public string Version     { get; set; }
        public string Channel     { get; set; }
        public string Architecture{ get; set; }
        public string InstallPath { get; set; }
        public string InstallType { get; set; }   // C2R | MSI
        public bool   IsM365      { get; set; }
        public string Edition     { get; set; }   // Professional Plus, Home, etc.
        public List<string> InstalledApps { get; set; }

        public OfficeInstall()
        {
            InstalledApps = new List<string>();
        }
    }

    public class LicenseInfo
    {
        public string ProductName   { get; set; }
        public string LicenseType   { get; set; }   // MSA | WorkSchool | Volume | Unknown
        public string ActivationStatus { get; set; } // Licensed | Unlicensed | OOBGrace | etc.
        public string LastActivationTime { get; set; }
        public bool   IsActivated   { get; set; }
        public string KmsHost       { get; set; }
        public List<string> IllegalActivators { get; set; }

        public LicenseInfo()
        {
            IllegalActivators = new List<string>();
        }
    }

    public class ServiceStatus
    {
        public string ServiceName   { get; set; }
        public string DisplayName   { get; set; }
        public string Status        { get; set; }   // Running | Stopped | Disabled
        public string StartType     { get; set; }
    }

    public class AddinInfo
    {
        public string Name          { get; set; }
        public string Application   { get; set; }
        public string Type          { get; set; }   // COM | Web | VSTO
        public string Status        { get; set; }   // Active | Disabled | Error
        public string LoadBehavior  { get; set; }
        public string Description   { get; set; }
        public string ProgId        { get; set; }
        public bool   HasError      { get; set; }
        public string ErrorMessage  { get; set; }
    }

    // ─── OfficeDetector ───────────────────────────────────────────────────────

    public class OfficeDetector
    {
        private static readonly string[] OfficeVersions = { "16.0", "15.0", "14.0", "12.0" };

        private static readonly Dictionary<string, string> ChannelGuids = new Dictionary<string, string>
        {
            { "55336b82-a18d-4dd6-b5f0-c047ac0be589", "Monthly Enterprise Channel" },
            { "492350f6-3a01-4f97-b9c0-c7c6ddf67d60", "Current Channel" },
            { "7ffbc6bf-bc32-4f92-8982-f9dd17fd3114", "Semi-Annual Enterprise Channel" },
            { "64256afe-f5d9-4f86-8936-8840a6a4f5be", "Current Channel (Preview)" },
            { "b8f9b850-328d-4355-ab84-b1a3c4e5fcbc", "Semi-Annual Enterprise Channel (Preview)" },
            { "5030841d-019d-442a-99e1-8a03d14f9d87", "Office 2019 Retail" },
            { "f2e724c1-748f-4b47-8fb8-8e0d210e9208", "Office 2021 Retail" },
            { "5ef33b6f-0b22-4d63-a631-daf6a3b5b1a2", "Office LTSC 2021" },
        };

        public List<OfficeInstall> DetectInstallations()
        {
            var results = new List<OfficeInstall>();
            results.AddRange(DetectC2R());
            results.AddRange(DetectMSI());
            return results;
        }

        private List<OfficeInstall> DetectC2R()
        {
            var list = new List<OfficeInstall>();
            try
            {
                var c2rKey = Registry.LocalMachine.OpenSubKey(
                    @"SOFTWARE\Microsoft\Office\ClickToRun\Configuration");
                if (c2rKey == null)
                    c2rKey = Registry.LocalMachine.OpenSubKey(
                        @"SOFTWARE\WOW6432Node\Microsoft\Office\ClickToRun\Configuration");
                if (c2rKey == null) return list;

                var install = new OfficeInstall();
                install.InstallType = "C2R";

                var _vtr = c2rKey.GetValue("VersionToReport");
                var _cvtr = c2rKey.GetValue("ClientVersionToReport");
                install.Version     = _vtr != null ? _vtr.ToString()
                                    : _cvtr != null ? _cvtr.ToString()
                                    : "Unknown";

                var _ip = c2rKey.GetValue("InstallationPath");
                install.InstallPath = _ip != null ? _ip.ToString() : "";

                var _plat = c2rKey.GetValue("Platform");
                install.Architecture = _plat != null ? _plat.ToString() : DetectArch();

                var _cdn = c2rKey.GetValue("CDNBaseUrl");
                var channelId = _cdn != null ? _cdn.ToString() : "";
                install.Channel = ResolveChannel(channelId);

                var productKey = Registry.LocalMachine.OpenSubKey(
                    @"SOFTWARE\Microsoft\Office\ClickToRun\ProductReleaseIDs\Active");
                if (productKey != null)
                {
                    var names = productKey.GetSubKeyNames();
                    install.ProductName = BuildProductDisplayName(names);
                    install.Edition     = DetectEdition(names);
                    install.IsM365      = names.Any(n =>
                        n.IndexOf("O365", StringComparison.OrdinalIgnoreCase) >= 0 ||
                        n.IndexOf("Microsoft365", StringComparison.OrdinalIgnoreCase) >= 0);
                    install.InstalledApps = DetectInstalledAppsC2R(names);
                }
                else
                {
                    install.ProductName = "Microsoft Office (Click-to-Run)";
                }

                list.Add(install);
                c2rKey.Close();
            }
            catch { }
            return list;
        }

        private List<OfficeInstall> DetectMSI()
        {
            var list = new List<OfficeInstall>();
            try
            {
                foreach (var ver in OfficeVersions)
                {
                    var keyPath = @"SOFTWARE\Microsoft\Office\" + ver + @"\Common\InstallRoot";
                    var key = Registry.LocalMachine.OpenSubKey(keyPath)
                           ?? Registry.LocalMachine.OpenSubKey(
                               @"SOFTWARE\WOW6432Node\Microsoft\Office\" + ver + @"\Common\InstallRoot");
                    if (key == null) continue;

                    var _pathVal = key.GetValue("Path");
                    var path = _pathVal != null ? _pathVal.ToString() : null;
                    if (string.IsNullOrEmpty(path)) { key.Close(); continue; }

                    var install = new OfficeInstall();
                    install.InstallType = "MSI";
                    install.Version     = ver;
                    install.InstallPath = path;
                    install.Channel     = "Retail";
                    install.Architecture = DetectArch();
                    install.IsM365      = false;
                    install.ProductName = "Microsoft Office " + VersionToYear(ver) + " (MSI)";
                    install.InstalledApps = DetectInstalledAppsMSI(ver);
                    list.Add(install);
                    key.Close();
                }
            }
            catch { }
            return list;
        }

        private string BuildProductDisplayName(string[] productIds)
        {
            if (productIds == null || productIds.Length == 0) return "Microsoft Office";
            var id = productIds.FirstOrDefault() ?? "";
            if (id.IndexOf("O365ProPlus", StringComparison.OrdinalIgnoreCase) >= 0 ||
                id.IndexOf("Microsoft365Apps", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Microsoft 365 Apps for Enterprise";
            if (id.IndexOf("O365Business", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Microsoft 365 Apps for Business";
            if (id.IndexOf("O365HomePrem", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Microsoft 365 Personal / Family";
            if (id.IndexOf("ProPlus2021", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Office LTSC 2021 Professional Plus";
            if (id.IndexOf("ProPlus2019", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Office 2019 Professional Plus";
            if (id.IndexOf("ProPlus2024", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Office LTSC 2024 Professional Plus";
            if (id.IndexOf("Standard2021", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Office LTSC 2021 Standard";
            if (id.IndexOf("Standard2019", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Office 2019 Standard";
            return "Microsoft Office";
        }

        private string DetectEdition(string[] productIds)
        {
            if (productIds == null || productIds.Length == 0) return "";
            var id = productIds.FirstOrDefault() ?? "";
            if (id.IndexOf("ProPlus", StringComparison.OrdinalIgnoreCase) >= 0) return "Professional Plus";
            if (id.IndexOf("Pro", StringComparison.OrdinalIgnoreCase) >= 0) return "Professional";
            if (id.IndexOf("Standard", StringComparison.OrdinalIgnoreCase) >= 0) return "Standard";
            if (id.IndexOf("Home", StringComparison.OrdinalIgnoreCase) >= 0) return "Home & Student";
            if (id.IndexOf("Business", StringComparison.OrdinalIgnoreCase) >= 0) return "Business";
            return "";
        }

        private List<string> DetectInstalledAppsC2R(string[] productIds)
        {
            var apps = new List<string>();
            var combined = string.Join(",", productIds ?? new string[0]);
            string[] appNames = { "Word", "Excel", "PowerPoint", "Outlook", "OneNote",
                                  "Access", "Publisher", "Teams", "OneDrive", "Visio", "Project" };
            foreach (var app in appNames)
            {
                if (combined.IndexOf(app, StringComparison.OrdinalIgnoreCase) >= 0 ||
                    combined.IndexOf("ProPlus", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    combined.IndexOf("O365", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    if (!apps.Contains(app)) apps.Add(app);
                }
            }
            if (apps.Count == 0) apps.AddRange(new[]{ "Word","Excel","PowerPoint","Outlook","OneNote" });
            return apps;
        }

        private List<string> DetectInstalledAppsMSI(string ver)
        {
            var apps = new List<string>();
            string[] appNames = { "Word", "Excel", "PowerPoint", "Outlook", "OneNote", "Access", "Publisher" };
            foreach (var app in appNames)
            {
                var key = Registry.LocalMachine.OpenSubKey(
                    @"SOFTWARE\Microsoft\Office\" + ver + @"\" + app);
                if (key != null) { apps.Add(app); key.Close(); }
            }
            return apps;
        }

        private string ResolveChannel(string cdnUrl)
        {
            if (string.IsNullOrEmpty(cdnUrl)) return "Retail";
            if (cdnUrl.IndexOf("MEC", StringComparison.OrdinalIgnoreCase) >= 0 ||
                cdnUrl.IndexOf("monthly-enterprise", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Monthly Enterprise Channel";
            if (cdnUrl.IndexOf("Current", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Current Channel";
            if (cdnUrl.IndexOf("SemiAnnual", StringComparison.OrdinalIgnoreCase) >= 0 ||
                cdnUrl.IndexOf("SAC", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Semi-Annual Enterprise Channel";
            if (cdnUrl.IndexOf("Insider", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Insider Channel";
            return "Retail";
        }

        private string DetectArch()
        {
            return Environment.Is64BitOperatingSystem ? "x64" : "x86";
        }

        private string VersionToYear(string ver)
        {
            switch (ver)
            {
                case "16.0": return "2016/2019/2021";
                case "15.0": return "2013";
                case "14.0": return "2010";
                case "12.0": return "2007";
                default: return ver;
            }
        }
    }

    // ─── OfficeLicensor ───────────────────────────────────────────────────────

    public class OfficeLicensor
    {
        private static readonly string[] IllegalActivatorNames = {
            "KMSPico", "KMSAuto", "KMS_VL_ALL", "AutoKMS", "AAct", "MAS", "HWID",
            "KMSTools", "Office Uninstall", "Activate Office"
        };

        private static readonly string[] IllegalActivatorPaths = {
            @"C:\Windows\System32\KMSSS.exe",
            @"C:\Windows\SysWOW64\KMSSS.exe",
            @"C:\Windows\System32\SppExtComObjHook.dll",
        };

        public LicenseInfo GetLicenseInfo()
        {
            var info = new LicenseInfo();
            try
            {
                info = QueryOSPP();
            }
            catch { }

            info.IllegalActivators = ScanForIllegalActivators();
            return info;
        }

        private LicenseInfo QueryOSPP()
        {
            var info = new LicenseInfo();
            try
            {
                using (var searcher = new ManagementObjectSearcher(
                    @"root\cimv2", "SELECT * FROM SoftwareLicensingProduct WHERE PartialProductKey IS NOT NULL AND Name LIKE '%Office%'"))
                {
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        var _name = obj["Name"];
                        info.ProductName     = _name != null ? _name.ToString() : "Microsoft Office";
                        var licStatus        = Convert.ToInt32(obj["LicenseStatus"] ?? 0);
                        info.IsActivated     = licStatus == 1;
                        info.ActivationStatus = LicenseStatusToString(licStatus);

                        var _evalEnd = obj["EvaluationEndDate"];
                        var lastActivation = _evalEnd != null ? _evalEnd.ToString() : null;
                        info.LastActivationTime = lastActivation ?? "N/A";

                        var _desc = obj["Description"];
                        var description = _desc != null ? _desc.ToString() : "";
                        info.LicenseType = DetectLicenseType(description, obj);

                        var _kms = obj["DiscoveredKeyManagementServiceMachineIpAddress"];
                        var kmsHost = _kms != null ? _kms.ToString() : null;
                        info.KmsHost = kmsHost;

                        break; // first relevant product
                    }
                }
            }
            catch
            {
                // Fallback: try registry
                info.ProductName     = "Microsoft Office";
                info.ActivationStatus = "Unknown";
                info.LicenseType      = "Unknown";
            }
            return info;
        }

        private string LicenseStatusToString(int status)
        {
            switch (status)
            {
                case 0: return "Unlicensed";
                case 1: return "Licensed";
                case 2: return "OOBGrace";
                case 3: return "OOTGrace";
                case 4: return "NonGenuineGrace";
                case 5: return "Notification";
                case 6: return "ExtendedGrace";
                default: return "Unknown";
            }
        }

        private string DetectLicenseType(string description, ManagementObject obj)
        {
            if (description.IndexOf("KMSCLIENT", StringComparison.OrdinalIgnoreCase) >= 0 ||
                description.IndexOf("Volume", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Volume";
            try
            {
                var _ppk = obj["PartialProductKey"];
                var partialKey = _ppk != null ? _ppk.ToString() : null;
                if (!string.IsNullOrEmpty(partialKey))
                {
                    // Work/School accounts don't have a traditional product key partial
                    var _pkc = obj["ProductKeyChannel"];
                    var subType = _pkc != null ? _pkc.ToString() : "";
                    if (subType.IndexOf("OEM", StringComparison.OrdinalIgnoreCase) >= 0) return "MSA";
                    if (subType.IndexOf("Retail", StringComparison.OrdinalIgnoreCase) >= 0) return "MSA";
                }
            }
            catch { }

            // Check C2R config for account type
            try
            {
                var key = Registry.CurrentUser.OpenSubKey(
                    @"SOFTWARE\Microsoft\Office\16.0\Common\Identity");
                if (key != null)
                {
                    var identities = key.GetSubKeyNames();
                    foreach (var id in identities)
                    {
                        var subKey = key.OpenSubKey(id);
                        if (subKey == null) continue;
                        var _auth = subKey.GetValue("AuthorityId");
                        var domain = _auth != null ? _auth.ToString() : "";
                        if (domain.IndexOf("live.com", StringComparison.OrdinalIgnoreCase) >= 0) return "MSA";
                        if (domain.IndexOf("microsoft.com", StringComparison.OrdinalIgnoreCase) >= 0) return "WorkSchool";
                        if (!string.IsNullOrEmpty(domain)) return "WorkSchool";
                        subKey.Close();
                    }
                    key.Close();
                }
            }
            catch { }

            return "Unknown";
        }

        public List<string> ScanForIllegalActivators()
        {
            var found = new List<string>();
            try
            {
                // Check known file paths
                foreach (var path in IllegalActivatorPaths)
                    if (File.Exists(path)) found.Add(Path.GetFileName(path));

                // Check running processes via WMI
                using (var searcher = new ManagementObjectSearcher(
                    "SELECT Name FROM Win32_Process"))
                {
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        var _pn = obj["Name"];
                        var procName = _pn != null ? _pn.ToString() : "";
                        foreach (var illegal in IllegalActivatorNames)
                        {
                            if (procName.IndexOf(illegal, StringComparison.OrdinalIgnoreCase) >= 0 &&
                                !found.Contains(illegal))
                                found.Add(illegal);
                        }
                    }
                }

                // Check Uninstall registry
                string[] uninstallKeys = {
                    @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
                    @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
                };
                foreach (var regPath in uninstallKeys)
                {
                    var key = Registry.LocalMachine.OpenSubKey(regPath);
                    if (key == null) continue;
                    foreach (var subName in key.GetSubKeyNames())
                    {
                        var sub = key.OpenSubKey(subName);
                        if (sub == null) continue;
                        var _dn = sub.GetValue("DisplayName");
                        var displayName = _dn != null ? _dn.ToString() : "";
                        foreach (var illegal in IllegalActivatorNames)
                        {
                            if (displayName.IndexOf(illegal, StringComparison.OrdinalIgnoreCase) >= 0 &&
                                !found.Contains(illegal))
                                found.Add(illegal);
                        }
                        sub.Close();
                    }
                    key.Close();
                }
            }
            catch { }
            return found;
        }
    }

    // ─── OfficeServices ───────────────────────────────────────────────────────

    public class OfficeServices
    {
        private static readonly Dictionary<string, string> TrackedServices = new Dictionary<string, string>
        {
            { "ClickToRunSvc",  "Office Click-to-Run" },
            { "OfficeSvcManagerAddInsWeb", "Microsoft 365 Apps Updater" },
            { "TokenBroker",    "Token Broker" },
        };

        public List<ServiceStatus> GetServicesStatus()
        {
            var results = new List<ServiceStatus>();
            foreach (var svc in TrackedServices)
            {
                var status = QueryService(svc.Key, svc.Value);
                results.Add(status);
            }
            return results;
        }

        private ServiceStatus QueryService(string name, string displayName)
        {
            var status = new ServiceStatus
            {
                ServiceName = name,
                DisplayName = displayName,
                Status      = "Unknown",
                StartType   = "Unknown"
            };
            try
            {
                using (var searcher = new ManagementObjectSearcher(
                    "SELECT * FROM Win32_Service WHERE Name='" + name + "'"))
                {
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        var _state = obj["State"];
                        status.Status    = _state != null ? _state.ToString() : "Unknown";
                        var _startMode = obj["StartMode"];
                        status.StartType = _startMode != null ? _startMode.ToString() : "Unknown";
                    }
                }
            }
            catch { }
            return status;
        }

        public bool StartService(string serviceName)
        {
            try
            {
                using (var searcher = new ManagementObjectSearcher(
                    "SELECT * FROM Win32_Service WHERE Name='" + serviceName + "'"))
                {
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        obj.InvokeMethod("StartService", null);
                        return true;
                    }
                }
            }
            catch { }
            return false;
        }

        public bool StopService(string serviceName)
        {
            try
            {
                using (var searcher = new ManagementObjectSearcher(
                    "SELECT * FROM Win32_Service WHERE Name='" + serviceName + "'"))
                {
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        obj.InvokeMethod("StopService", null);
                        return true;
                    }
                }
            }
            catch { }
            return false;
        }
    }

    // ─── OfficeAddins ─────────────────────────────────────────────────────────

    public class OfficeAddins
    {
        private static readonly string[] OfficeApps = { "Word", "Excel", "PowerPoint", "Outlook" };

        public List<AddinInfo> GetAllAddins()
        {
            var addins = new List<AddinInfo>();
            foreach (var app in OfficeApps)
            {
                addins.AddRange(GetComAddins(app));
            }
            return addins;
        }

        private List<AddinInfo> GetComAddins(string appName)
        {
            var addins = new List<AddinInfo>();
            string[] regPaths = {
                @"SOFTWARE\Microsoft\Office\" + appName + @"\Addins",
                @"SOFTWARE\WOW6432Node\Microsoft\Office\" + appName + @"\Addins",
            };
            RegistryKey[] hives = { Registry.CurrentUser, Registry.LocalMachine };

            foreach (var hive in hives)
            {
                foreach (var path in regPaths)
                {
                    try
                    {
                        var key = hive.OpenSubKey(path);
                        if (key == null) continue;
                        foreach (var subName in key.GetSubKeyNames())
                        {
                            var sub = key.OpenSubKey(subName);
                            if (sub == null) continue;
                            var _fn = sub.GetValue("FriendlyName");
                            var _descVal = sub.GetValue("Description");
                            var addin = new AddinInfo
                            {
                                Application = appName,
                                Type        = "COM",
                                ProgId      = subName,
                                Name        = _fn != null ? _fn.ToString() : subName,
                                Description = _descVal != null ? _descVal.ToString() : "",
                            };
                            var lb = Convert.ToInt32(sub.GetValue("LoadBehavior") ?? 0);
                            addin.LoadBehavior = lb.ToString();
                            addin.Status       = lb == 3 || lb == 1 ? "Active" : lb == 2 ? "Disabled" : "Disabled";

                            // Check for crash history
                            var crashKey = hive.OpenSubKey(
                                @"SOFTWARE\Microsoft\Office\" + appName + @"\Addins\" + subName + @"\ResiliencyData");
                            if (crashKey != null)
                            {
                                addin.HasError     = true;
                                addin.Status       = "Error";
                                addin.ErrorMessage = "Disabled by Office resiliency";
                                crashKey.Close();
                            }
                            if (!addins.Any(a => a.ProgId == addin.ProgId && a.Application == addin.Application))
                                addins.Add(addin);
                            sub.Close();
                        }
                        key.Close();
                    }
                    catch { }
                }
            }
            return addins;
        }

        public bool SetAddinLoadBehavior(string appName, string progId, int loadBehavior)
        {
            string[] regPaths = {
                @"SOFTWARE\Microsoft\Office\" + appName + @"\Addins\" + progId,
                @"SOFTWARE\WOW6432Node\Microsoft\Office\" + appName + @"\Addins\" + progId,
            };
            foreach (var path in regPaths)
            {
                try
                {
                    var key = Registry.CurrentUser.OpenSubKey(path, true);
                    if (key == null) key = Registry.LocalMachine.OpenSubKey(path, true);
                    if (key != null)
                    {
                        key.SetValue("LoadBehavior", loadBehavior, RegistryValueKind.DWord);
                        key.Close();
                        return true;
                    }
                }
                catch { }
            }
            return false;
        }
    }
}
