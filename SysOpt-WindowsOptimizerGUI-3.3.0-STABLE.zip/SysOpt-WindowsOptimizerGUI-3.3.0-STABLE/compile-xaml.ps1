﻿# SysOpt - Software de optimización del sistema
# Copyright (C) 2026 Danew Malavita
#
# Este programa es software libre bajo los términos de la GPL v3+.
# Consulta el archivo LICENSE o visita <https://www.gnu.org/licenses/>.

# =============================================================================
# compile-xaml.ps1  —  Compila XAML a BAML (recursos pre-compilados WPF)
# Ejecutar desde la raíz del proyecto:
#   powershell -ExecutionPolicy Bypass -File compile-xaml.ps1
#
# Requisitos: MSBuild 4.0+ con soporte WPF (Visual Studio o .NET Framework SDK)
# Salida:     libs\SysOpt.XamlResources.dll (DLL con BAML embebido)
#
# El BAML pre-compilado es 3-5x más rápido de cargar que parsing XAML raw.
# Si la DLL existe, SysOpt la detecta automáticamente al arrancar.
# Si no existe, SysOpt usa XAML raw como siempre (100% retrocompatible).
# =============================================================================

#Requires -Version 5.1
$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "  ============================================================" -ForegroundColor Cyan
Write-Host "    SysOpt — Compilación XAML → BAML (recursos pre-compilados)" -ForegroundColor Cyan
Write-Host "  ============================================================" -ForegroundColor Cyan
Write-Host ""

$xamlDir = Join-Path $PSScriptRoot "assets\xaml"
$outDir  = Join-Path $PSScriptRoot "libs"
$outDll  = "SysOpt.XamlResources.dll"

# ── Verificar que existen los XAML ────────────────────────────────────────────
if (-not (Test-Path $xamlDir)) {
    Write-Host "[ERROR] Carpeta assets\xaml no encontrada." -ForegroundColor Red
    exit 1
}

$xamlFiles = Get-ChildItem -Path $xamlDir -Filter "*.xaml" -File
if ($xamlFiles.Count -eq 0) {
    Write-Host "[WARN] No se encontraron archivos .xaml" -ForegroundColor Yellow
    exit 0
}

Write-Host "  Archivos XAML: $($xamlFiles.Count)" -ForegroundColor White
foreach ($xf in $xamlFiles) {
    $szKb = [math]::Round($xf.Length / 1KB, 1)
    Write-Host "    · $($xf.Name) ($szKb KB)" -ForegroundColor Gray
}
Write-Host ""

# ── Leer versión desde SysOpt.ps1 ────────────────────────────────────────────
$appVersion = "0.0.0"
$ps1Path = Join-Path $PSScriptRoot "SysOpt.ps1"
if (Test-Path $ps1Path) {
    $vLine = Select-String -Path $ps1Path -Pattern '\$script:AppVersion\s*=\s*"([\d\.]+)"' |
             Select-Object -First 1
    if ($vLine -and $vLine.Matches.Count -gt 0) {
        $appVersion = $vLine.Matches[0].Groups[1].Value
    }
}
Write-Host "  Versión: v$appVersion" -ForegroundColor White

# ── Buscar MSBuild ───────────────────────────────────────────────────────────
$msbuild = $null

# 1. VS2022/2019
$vsSearchPaths = @(
    "${env:ProgramFiles}\Microsoft Visual Studio\2022\*\MSBuild\Current\Bin\MSBuild.exe",
    "${env:ProgramFiles(x86)}\Microsoft Visual Studio\2022\*\MSBuild\Current\Bin\MSBuild.exe",
    "${env:ProgramFiles}\Microsoft Visual Studio\2019\*\MSBuild\Current\Bin\MSBuild.exe",
    "${env:ProgramFiles(x86)}\Microsoft Visual Studio\2019\*\MSBuild\Current\Bin\MSBuild.exe"
)
foreach ($sp in $vsSearchPaths) {
    $found = Get-ChildItem -Path $sp -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($found) { $msbuild = $found.FullName; break }
}

# 2. .NET Framework 4.x
if (-not $msbuild) {
    $fwPaths = @(
        "$env:WINDIR\Microsoft.NET\Framework\v4.0.30319\MSBuild.exe",
        "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\MSBuild.exe"
    )
    foreach ($fp in $fwPaths) {
        if (Test-Path $fp) { $msbuild = $fp; break }
    }
}

# 3. PATH
if (-not $msbuild) {
    $msbuild = (Get-Command MSBuild.exe -ErrorAction SilentlyContinue).Path
}

if (-not $msbuild) {
    Write-Host "[ERROR] MSBuild no encontrado." -ForegroundColor Red
    Write-Host "        Instala Visual Studio o .NET Framework SDK." -ForegroundColor Yellow
    Write-Host "        La compilación BAML requiere MSBuild con soporte WPF." -ForegroundColor Yellow
    exit 1
}
Write-Host "[OK] MSBuild: $msbuild" -ForegroundColor Green
Write-Host ""

# ── Verificar soporte WPF en MSBuild ─────────────────────────────────────────
$msbuildDir = Split-Path $msbuild -Parent
$winFxTargets = Join-Path $msbuildDir "Microsoft.WinFX.targets"
if (-not (Test-Path $winFxTargets)) {
    # Intentar ruta alternativa del framework
    $fwDir = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319"
    $winFxTargets = Join-Path $fwDir "Microsoft.WinFX.targets"
}
if (-not (Test-Path $winFxTargets)) {
    Write-Host "[ERROR] Microsoft.WinFX.targets no encontrado." -ForegroundColor Red
    Write-Host "        La compilación BAML requiere el SDK de WPF." -ForegroundColor Yellow
    exit 1
}
Write-Host "[OK] WPF targets: $winFxTargets" -ForegroundColor Green

# ── Crear carpeta temporal de build ──────────────────────────────────────────
$buildDir = Join-Path ([System.IO.Path]::GetTempPath()) "SysOpt_BAML_Build"
if (Test-Path $buildDir) { Remove-Item $buildDir -Recurse -Force }
New-Item -Path $buildDir -ItemType Directory -Force | Out-Null
Write-Host "[OK] Build dir: $buildDir" -ForegroundColor Green
Write-Host ""

# ── Copiar y pre-procesar XAML ───────────────────────────────────────────────
Write-Host "  Procesando XAML..." -ForegroundColor DarkGray
foreach ($xf in $xamlFiles) {
    $content = [System.IO.File]::ReadAllText($xf.FullName, [System.Text.Encoding]::UTF8)
    # Reemplazar placeholders con valores reales (BAML es pre-compilado)
    $content = $content -replace '\{\{APP_VERSION\}\}', "v$appVersion"
    $destPath = Join-Path $buildDir $xf.Name
    [System.IO.File]::WriteAllText($destPath, $content, [System.Text.Encoding]::UTF8)
    Write-Host "    ✓ $($xf.Name)" -ForegroundColor DarkCyan
}

# ── Generar AssemblyInfo.cs ──────────────────────────────────────────────────
$asmVersion = ($appVersion -split "\.")
while ($asmVersion.Count -lt 4) { $asmVersion += "0" }
$asmVersionStr = $asmVersion[0..3] -join "."

$asmInfo = @"
// AUTO-GENERADO por compile-xaml.ps1 — NO editar
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;
[assembly: AssemblyTitle("SysOpt XAML Resources")]
[assembly: AssemblyVersion("$asmVersionStr")]
[assembly: AssemblyFileVersion("$asmVersionStr")]
[assembly: AssemblyProduct("SysOpt Windows Optimizer GUI")]
[assembly: AssemblyCopyright("SysOpt $((Get-Date).Year)")]
[assembly: ComVisible(false)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
"@
$asmInfoPath = Join-Path $buildDir "AssemblyInfo.cs"
[System.IO.File]::WriteAllText($asmInfoPath, $asmInfo, [System.Text.Encoding]::UTF8)

# ── Generar .csproj ─────────────────────────────────────────────────────────
# ── Auto-detectar versión de .NET Framework disponible ───────────────────────
$fwVersion = "v4.5"
$refAsmBase = "${env:ProgramFiles(x86)}\Reference Assemblies\Microsoft\Framework\.NETFramework"
if (-not (Test-Path (Join-Path $refAsmBase "v4.5"))) {
    if (Test-Path (Join-Path $refAsmBase "v4.0")) {
        $fwVersion = "v4.0"
        Write-Host "  [INFO] Targeting pack 4.5 no encontrado, usando v4.0" -ForegroundColor Yellow
    }
}
Write-Host "  Framework target: $fwVersion" -ForegroundColor DarkGray

$pageItems = ($xamlFiles | ForEach-Object { "    <Page Include=`"$($_.Name)`" />" }) -join "`r`n"

$csproj = @"
<?xml version="1.0" encoding="utf-8"?>
<Project ToolsVersion="4.0" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <PropertyGroup>
    <AssemblyName>SysOpt.XamlResources</AssemblyName>
    <TargetFrameworkVersion>$fwVersion</TargetFrameworkVersion>
    <OutputType>Library</OutputType>
    <OutputPath>.\bin\</OutputPath>
    <RootNamespace>SysOpt.XamlResources</RootNamespace>
    <ProjectGuid>{$(([guid]::NewGuid().ToString().ToUpper()))}</ProjectGuid>
    <ResolveAssemblyWarnOrErrorOnTargetArchitectureMismatch>None</ResolveAssemblyWarnOrErrorOnTargetArchitectureMismatch>
  </PropertyGroup>
  <ItemGroup>
    <Reference Include="PresentationCore" />
    <Reference Include="PresentationFramework" />
    <Reference Include="WindowsBase" />
    <Reference Include="System" />
    <Reference Include="System.Xaml" />
  </ItemGroup>
  <ItemGroup>
    <Compile Include="AssemblyInfo.cs" />
  </ItemGroup>
  <ItemGroup>
$pageItems
  </ItemGroup>
  <Import Project="`$(MSBuildToolsPath)\Microsoft.CSharp.targets" />
</Project>
"@

$csprojPath = Join-Path $buildDir "SysOpt.XamlResources.csproj"
[System.IO.File]::WriteAllText($csprojPath, $csproj, [System.Text.Encoding]::UTF8)
Write-Host "[OK] Proyecto generado: $($xamlFiles.Count) XAML como Page" -ForegroundColor Green

# ── Compilar ─────────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "──────────────────────────────────────────────────────────────" -ForegroundColor DarkGray
Write-Host "[BUILD] XAML → BAML → $outDll" -ForegroundColor Cyan

$buildOutput = & $msbuild $csprojPath /t:Build /p:Configuration=Release /nologo /verbosity:minimal 2>&1
$buildSuccess = $LASTEXITCODE -eq 0

foreach ($line in $buildOutput) {
    $lineStr = "$line"
    if ($lineStr -match ": error ") {
        Write-Host "  $lineStr" -ForegroundColor Red
    } elseif ($lineStr -match ": warning ") {
        Write-Host "  $lineStr" -ForegroundColor Yellow
    } elseif ($lineStr.Trim() -ne "") {
        Write-Host "  $lineStr" -ForegroundColor DarkGray
    }
}

# ── Copiar resultado ─────────────────────────────────────────────────────────
$builtDll = Join-Path $buildDir "bin\$outDll"
if ($buildSuccess -and (Test-Path $builtDll)) {
    $dest = Join-Path $outDir $outDll
    Copy-Item $builtDll $dest -Force
    $sz = (Get-Item $dest).Length
    $szKb = [math]::Round($sz / 1KB, 1)
    Write-Host ""
    Write-Host "[OK] $outDll — ${szKb} KB" -ForegroundColor Green
    Write-Host "     Destino: $dest" -ForegroundColor DarkCyan
    Write-Host ""
    Write-Host "  SysOpt detectará el BAML automáticamente al arrancar." -ForegroundColor White
    Write-Host "  Para desactivar BAML, elimina libs\$outDll" -ForegroundColor DarkGray
} else {
    Write-Host ""
    Write-Host "[FAIL] La compilación BAML falló." -ForegroundColor Red
    Write-Host "       SysOpt seguirá usando XAML raw (sin impacto funcional)." -ForegroundColor Yellow
    Write-Host "       Revisa los errores de MSBuild arriba." -ForegroundColor Yellow
}

# ── Limpieza ─────────────────────────────────────────────────────────────────
try { Remove-Item $buildDir -Recurse -Force -ErrorAction SilentlyContinue } catch {}

Write-Host ""
Write-Host "  ============================================================" -ForegroundColor Cyan
Write-Host ""
