﻿// SysOpt - Software de optimización del sistema
// Copyright (C) 2026 Danew Malavita
//
// Este programa es software libre bajo los términos de la GPL v3+.
// Consulta el archivo LICENSE o visita <https://www.gnu.org/licenses/>.

// ─────────────────────────────────────────────────────────────────────────────
// SysOpt.Snapshot.cs — v3.3.0
// Native snapshot reader for SysOpt
// ─────────────────────────────────────────────────────────────────────────────
// ReadMeta()               → scan raw JSON: header + entry stats (no object graph)
// StreamEntriesToQueue()   → compiled deserializer → FIFO ConcurrentQueue
// ReadAllEntries()         → bulk load for small files
// ─────────────────────────────────────────────────────────────────────────────
// Performance vs PS1 equivalents:
//   ReadMeta         — ~60-70 % faster (string scan vs interpreted JsonTextReader)
//   StreamEntries    — ~50-60 % faster (compiled JavaScriptSerializer vs ConvertFrom-Json)
// ─────────────────────────────────────────────────────────────────────────────

using System;
using System.IO;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Web.Script.Serialization;

namespace SysOpt.Snapshot
{
    // ─── DTO ───────────────────────────────────────────────────────

    /// <summary>Snapshot metadata — header fields + entry statistics.</summary>
    public class SnapshotMeta
    {
        public string Label    = "";
        public string RootPath = "";
        public string Date     = "";
        public int    EntryCount;
        public long   TotalBytes;
        public int    RootCount;
    }

    // ─── READER ────────────────────────────────────────────────────

    /// <summary>
    /// High-performance snapshot file reader.
    /// Replaces PS1 Read-SnapshotMeta and bgEnt JSON parsing.
    /// </summary>
    public static class SnapshotReader
    {
        // ═══════════════════════════════════════════════════════════
        // ReadMeta — scan raw JSON, extract header + count entries
        // Memory: O(file_size) for the string. No object graph.
        // ═══════════════════════════════════════════════════════════

        public static SnapshotMeta ReadMeta(string filePath)
        {
            var meta = new SnapshotMeta();
            string json;
            try { json = File.ReadAllText(filePath, Encoding.UTF8); }
            catch { return meta; }

            meta.Label    = ExtractStringProp(json, "Label");
            meta.RootPath = ExtractStringProp(json, "RootPath");
            meta.Date     = ExtractStringProp(json, "Date");

            int arrStart = FindArrayStart(json, "Entries");
            if (arrStart >= 0)
            {
                int pos = arrStart;
                while (pos < json.Length)
                {
                    SkipWS(json, ref pos);
                    if (pos >= json.Length || json[pos] == ']') break;
                    if (json[pos] == ',') { pos++; continue; }
                    if (json[pos] != '{') { pos++; continue; }

                    int objEnd = FindClosingBrace(json, pos);
                    if (objEnd < 0) break;

                    meta.EntryCount++;
                    long sz = ExtractNumberProp(json, pos, objEnd, "SizeBytes");
                    int  dp = (int)ExtractNumberProp(json, pos, objEnd, "Depth");
                    if (dp == 0) { meta.TotalBytes += sz; meta.RootCount++; }

                    pos = objEnd + 1;
                }
            }
            return meta;
        }

        // ═══════════════════════════════════════════════════════════
        // StreamEntriesToQueue — deserialize + FIFO enqueue
        // Compatible with PS1 ConcurrentQueue[object] + Hashtable
        // ═══════════════════════════════════════════════════════════

        /// <param name="onProgress">
        /// Optional: (phase, progress%, itemsDone, itemsTotal). Pass null to skip.
        /// </param>
        public static int StreamEntriesToQueue(
            string filePath,
            ConcurrentQueue<object> queue,
            Action<string, int, int, int> onProgress)
        {
            string json = File.ReadAllText(filePath, Encoding.UTF8);
            if (onProgress != null) onProgress("Deserializing\u2026", 30, 0, 0);

            var ser = new JavaScriptSerializer();
            ser.MaxJsonLength = int.MaxValue;
            var data = ser.Deserialize<Dictionary<string, object>>(json);
            json = null;

            object raw;
            if (!data.TryGetValue("Entries", out raw) || !(raw is ArrayList))
            { data = null; return 0; }

            var entries = (ArrayList)raw;
            data = null;
            int total = entries.Count;
            if (onProgress != null) onProgress("Queuing\u2026", 50, 0, total);

            int i = 0;
            foreach (Dictionary<string, object> e in entries)
            {
                var ht = new Hashtable(6);
                ht["Name"]      = Str(e, "Name");
                ht["FullPath"]  = Str(e, "FullPath");
                ht["SizeBytes"] = Lng(e, "SizeBytes");
                ht["FileCount"] = Str(e, "FileCount");
                ht["Depth"]     = Int(e, "Depth");
                queue.Enqueue(ht);
                i++;
                if (i % 500 == 0 && onProgress != null)
                    onProgress("Queuing\u2026 (" + i + "/" + total + ")",
                               50 + (int)((long)i * 46 / Math.Max(1, total)),
                               i, total);
            }
            entries = null;
            if (onProgress != null) onProgress("Completed", 100, i, i);
            return i;
        }

        // ═══════════════════════════════════════════════════════════
        // ReadAllEntries — bulk load for small/medium files
        // ═══════════════════════════════════════════════════════════

        public static List<Hashtable> ReadAllEntries(string filePath)
        {
            var result = new List<Hashtable>();
            string json = File.ReadAllText(filePath, Encoding.UTF8);
            var ser = new JavaScriptSerializer();
            ser.MaxJsonLength = int.MaxValue;
            var data = ser.Deserialize<Dictionary<string, object>>(json);
            json = null;

            object raw;
            if (!data.TryGetValue("Entries", out raw) || !(raw is ArrayList))
                return result;

            var entries = (ArrayList)raw;
            data = null;
            result.Capacity = entries.Count;

            foreach (Dictionary<string, object> e in entries)
            {
                var ht = new Hashtable(6);
                ht["Name"]      = Str(e, "Name");
                ht["FullPath"]  = Str(e, "FullPath");
                ht["SizeBytes"] = Lng(e, "SizeBytes");
                ht["FileCount"] = Str(e, "FileCount");
                ht["Depth"]     = Int(e, "Depth");
                result.Add(ht);
            }
            return result;
        }

        // ─── PRIVATE HELPERS ───────────────────────────────────────

        static string ExtractStringProp(string j, string prop)
        {
            string pat = "\"" + prop + "\"";
            int idx = j.IndexOf(pat, StringComparison.Ordinal);
            if (idx < 0) return "";
            idx += pat.Length;
            while (idx < j.Length && " :\t\n\r".IndexOf(j[idx]) >= 0) idx++;
            if (idx >= j.Length || j[idx] != '"') return "";
            idx++;
            var sb = new StringBuilder(64);
            bool esc = false;
            while (idx < j.Length)
            {
                char c = j[idx++];
                if (esc) { sb.Append(c); esc = false; continue; }
                if (c == '\\') { esc = true; continue; }
                if (c == '"') break;
                sb.Append(c);
            }
            return sb.ToString();
        }

        static int FindArrayStart(string j, string prop)
        {
            string pat = "\"" + prop + "\"";
            int idx = j.IndexOf(pat, StringComparison.Ordinal);
            if (idx < 0) return -1;
            idx += pat.Length;
            while (idx < j.Length && j[idx] != '[') idx++;
            return idx < j.Length ? idx + 1 : -1;
        }

        static long ExtractNumberProp(string j, int start, int end, string prop)
        {
            string pat = "\"" + prop + "\"";
            int idx = j.IndexOf(pat, start, end - start, StringComparison.Ordinal);
            if (idx < 0) return 0;
            idx += pat.Length;
            while (idx < end && " :\t\n\r".IndexOf(j[idx]) >= 0) idx++;
            long r = 0; bool neg = false;
            if (idx < end && j[idx] == '-') { neg = true; idx++; }
            while (idx < end && j[idx] >= '0' && j[idx] <= '9')
            { r = r * 10 + (j[idx] - '0'); idx++; }
            return neg ? -r : r;
        }

        static int FindClosingBrace(string j, int start)
        {
            int d = 0; bool inStr = false, esc = false;
            for (int i = start; i < j.Length; i++)
            {
                char c = j[i];
                if (inStr)
                {
                    if (esc) { esc = false; continue; }
                    if (c == '\\') { esc = true; continue; }
                    if (c == '"') inStr = false;
                    continue;
                }
                if (c == '"') { inStr = true; continue; }
                if (c == '{') d++;
                else if (c == '}') { d--; if (d == 0) return i; }
            }
            return -1;
        }

        static void SkipWS(string j, ref int i)
        { while (i < j.Length && " \t\n\r".IndexOf(j[i]) >= 0) i++; }

        static string Str(Dictionary<string, object> d, string k)
        { object v; return d.TryGetValue(k, out v) && v != null ? v.ToString() : ""; }

        static long Lng(Dictionary<string, object> d, string k)
        { object v; if (!d.TryGetValue(k, out v) || v == null) return 0;
          try { return Convert.ToInt64(v); } catch { return 0; } }

        static int Int(Dictionary<string, object> d, string k)
        { object v; if (!d.TryGetValue(k, out v) || v == null) return 0;
          try { return Convert.ToInt32(v); } catch { return 0; } }
    }
}
