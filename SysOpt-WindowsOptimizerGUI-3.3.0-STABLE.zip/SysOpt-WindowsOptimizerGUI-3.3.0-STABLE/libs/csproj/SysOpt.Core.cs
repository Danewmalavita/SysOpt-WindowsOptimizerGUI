﻿// SysOpt - Software de optimización del sistema
// Copyright (C) 2026 Danew Malavita
//
// Este programa es software libre bajo los términos de la GPL v3+.
// Consulta el archivo LICENSE o visita <https://www.gnu.org/licenses/>.


// =============================================================================
// SysOpt.Core — v3.3.0
// Kernel reducido: Motor de idiomas · XAML loader · Settings · Log · Fallbacks
//
// Compilar:
//   csc /target:library /out:SysOpt.Core.dll SysOpt.Core.cs
//       /r:System.dll /r:System.Core.dll
// =============================================================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Diagnostics;
using System.Threading;

// ─────────────────────────────────────────────────────────────────────────────
// SECCIÓN 1 — EXISTENTE (sin cambios de firma, retro-compatible)
// ─────────────────────────────────────────────────────────────────────────────

// ═══════════════════════════════════════════════════════════════════════════════
// LangEngine — Parsing de archivos .lang (formato INI: [meta] + [ui])
// ═══════════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════════
// Loc — Minimal localization helper. PS1 calls Loc.SetDict() after loading language.
// ═══════════════════════════════════════════════════════════════════════════════
public static class Loc
{
    private static Dictionary<string, string> _d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

    public static void SetDict(Dictionary<string, string> d)
    {
        _d = d ?? new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
    }

    public static string T(string key, string fallback)
    {
        return (_d != null && _d.ContainsKey(key)) ? _d[key] : fallback;
    }
}

public static class LangEngine
{
    public static Dictionary<string, string> ParseLangFile(string path)
    {
        if (string.IsNullOrEmpty(path))  throw new ArgumentNullException("path");
        if (!File.Exists(path))          throw new FileNotFoundException("Lang file not found: " + path);

        var strings = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        string section = "";

        foreach (var rawLine in File.ReadAllLines(path))
        {
            var line = rawLine.Trim();
            if (line.Length == 0 || line[0] == '#') continue;
            if (line[0] == '[' && line[line.Length - 1] == ']')
            {
                section = line.Substring(1, line.Length - 2).ToLowerInvariant();
                continue;
            }
            if (section != "ui") continue;
            int eq = line.IndexOf('=');
            if (eq <= 0) continue;
            string key = line.Substring(0, eq).Trim();
            string val = line.Substring(eq + 1).Trim().Replace("\\n", "\n");
            // Strip surrounding quotes if present
            if (val.Length >= 2 && val[0] == '"' && val[val.Length - 1] == '"')
                val = val.Substring(1, val.Length - 2);
            strings[key] = val;
        }
        return strings;
    }

    public static Dictionary<string, string> GetLangMeta(string path)
    {
        if (string.IsNullOrEmpty(path))  throw new ArgumentNullException("path");
        if (!File.Exists(path))          throw new FileNotFoundException("Lang file not found: " + path);

        var meta = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        string section = "";

        foreach (var rawLine in File.ReadAllLines(path))
        {
            var line = rawLine.Trim();
            if (line.Length == 0 || line[0] == '#') continue;
            if (line[0] == '[' && line[line.Length - 1] == ']')
            {
                section = line.Substring(1, line.Length - 2).ToLowerInvariant();
                continue;
            }
            if (section != "meta") continue;
            int eq = line.IndexOf('=');
            if (eq <= 0) continue;
            meta[line.Substring(0, eq).Trim()] = line.Substring(eq + 1).Trim();
        }
        return meta;
    }

    public static string[] ListLanguages(string langFolder)
    {
        if (!Directory.Exists(langFolder)) return new string[0];
        var files = Directory.GetFiles(langFolder, "*.lang");
        var names = new string[files.Length];
        for (int i = 0; i < files.Length; i++)
            names[i] = Path.GetFileNameWithoutExtension(files[i]);
        Array.Sort(names, StringComparer.OrdinalIgnoreCase);
        return names;
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// XamlLoader — Carga de archivos .xaml externos
// ═══════════════════════════════════════════════════════════════════════════════
public static class XamlLoader
{
    public static string Load(string xamlFolder, string name)
    {
        if (string.IsNullOrEmpty(xamlFolder)) throw new ArgumentNullException("xamlFolder");
        if (string.IsNullOrEmpty(name))        throw new ArgumentNullException("name");

        string fileName = name.EndsWith(".xaml", StringComparison.OrdinalIgnoreCase)
            ? name : name + ".xaml";
        string path = Path.Combine(xamlFolder, fileName);

        if (!File.Exists(path))
            throw new FileNotFoundException("XAML file not found: " + path);

        return File.ReadAllText(path, System.Text.Encoding.UTF8);
    }

    /// <summary>
    /// v3.3.0-OPT-2: Carga una ventana/control desde BAML pre-compilado.
    /// Requiere SysOpt.XamlResources.dll (generado por compile-xaml.ps1)
    /// y Application.Current activo. Devuelve null si BAML no disponible.
    /// Usa reflexión para evitar dependencia de compilación con PresentationFramework.
    /// </summary>
    public static object LoadBaml(string libsFolder, string name)
    {
        string dllPath = Path.Combine(libsFolder, "SysOpt.XamlResources.dll");
        if (!File.Exists(dllPath)) return null;

        try
        {
            // Verificar Application.Current via reflexión (sin ref a PresentationFramework)
            var appType = Type.GetType(
                "System.Windows.Application, PresentationFramework, " +
                "Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35");
            if (appType == null) return null;

            var currentProp = appType.GetProperty("Current",
                System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
            if (currentProp == null || currentProp.GetValue(null) == null) return null;

            // Asegurar que el ensamblado de recursos BAML está cargado
            string asmName = "SysOpt.XamlResources";
            bool found = false;
            foreach (var a in AppDomain.CurrentDomain.GetAssemblies())
            {
                try { if (a.GetName().Name == asmName) { found = true; break; } }
                catch { }
            }
            if (!found)
            {
                // LoadFrom (no Load(bytes)) necesario para resolución pack:// URI
                System.Reflection.Assembly.LoadFrom(dllPath);
            }

            // Cargar desde BAML via pack:// URI
            string component = name.EndsWith(".xaml", StringComparison.OrdinalIgnoreCase)
                ? name.ToLowerInvariant()
                : name.ToLowerInvariant() + ".xaml";
            var uri = new Uri("/" + asmName + ";component/" + component, UriKind.Relative);

            var loadMethod = appType.GetMethod("LoadComponent",
                System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static,
                null, new Type[] { typeof(Uri) }, null);
            if (loadMethod == null) return null;

            return loadMethod.Invoke(null, new object[] { uri });
        }
        catch
        {
            return null; // silently fall back to raw XAML
        }
    }

    public static string[] ListXaml(string xamlFolder)
    {
        if (!Directory.Exists(xamlFolder)) return new string[0];
        var files = Directory.GetFiles(xamlFolder, "*.xaml");
        var names = new string[files.Length];
        for (int i = 0; i < files.Length; i++)
            names[i] = Path.GetFileNameWithoutExtension(files[i]);
        Array.Sort(names, StringComparer.OrdinalIgnoreCase);
        return names;
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// SettingsHelper — Lectura de configuración JSON simple (sin Newtonsoft)
// ═══════════════════════════════════════════════════════════════════════════════
public static class SettingsHelper
{
    public static string ReadKey(string jsonPath, string key)
    {
        if (!File.Exists(jsonPath)) return null;
        var text   = File.ReadAllText(jsonPath);
        string search = "\"" + key + "\"";
        int idx    = text.IndexOf(search, StringComparison.OrdinalIgnoreCase);
        if (idx < 0) return null;
        int colon  = text.IndexOf(':', idx + search.Length);
        if (colon < 0) return null;
        int start  = text.IndexOf('"', colon + 1);
        if (start < 0) return null;
        int end    = text.IndexOf('"', start + 1);
        if (end < 0) return null;
        return text.Substring(start + 1, end - start - 1);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SECCIÓN 2 — NUEVO: CTK (CancellationToken Manager)
// ─────────────────────────────────────────────────────────────────────────────

// ═══════════════════════════════════════════════════════════════════════════════
// ScanTokenManager — CancellationToken global para todos los runspaces
//
// Reemplaza el flag booleano ScanCtl211.Stop.
// Uso en PS:
//   [ScanTokenManager]::RequestNew()          # antes de iniciar escaneo
//   [ScanTokenManager]::Token                 # pasa al runspace / task
//   [ScanTokenManager]::Cancel()              # desde botón Stop
//   [ScanTokenManager]::IsCancellationRequested  # equivale a ScanCtl211.Stop
// ═══════════════════════════════════════════════════════════════════════════════
public static class ScanTokenManager
{
    private static CancellationTokenSource _cts = new CancellationTokenSource();
    private static readonly object _lock = new object();

    /// <summary>Token actual. Pásalo a runspaces y tasks.</summary>
    public static CancellationToken Token
    {
        get { lock (_lock) { return _cts.Token; } }
    }

    /// <summary>True si se ha pedido cancelación — equivale a ScanCtl211.Stop.</summary>
    public static bool IsCancellationRequested
    {
        get { lock (_lock) { return _cts.IsCancellationRequested; } }
    }

    /// <summary>
    /// Crea un nuevo CTS limpio para una nueva operación.
    /// Llama siempre antes de iniciar un escaneo/operación larga.
    /// Cancela y libera el anterior automáticamente.
    /// </summary>
    public static void RequestNew()
    {
        lock (_lock)
        {
            try   { _cts.Cancel(); }  catch { }
            try   { _cts.Dispose(); } catch { }
            _cts = new CancellationTokenSource();
        }
    }

    /// <summary>Cancela la operación en curso. Seguro llamar varias veces.</summary>
    public static void Cancel()
    {
        lock (_lock)
        {
            try { if (!_cts.IsCancellationRequested) _cts.Cancel(); }
            catch { }
        }
    }

    /// <summary>
    /// Crea un CTS vinculado con timeout opcional.
    /// Útil para operaciones con tiempo máximo (p. ej. CimSession).
    /// </summary>
    /// <summary>
    /// Crea un CTS vinculado con timeout opcional.
    /// IMPORTANTE: El caller debe disponer el CTS retornado (.Dispose()).
    /// </summary>
    public static CancellationTokenSource GetCtsWithTimeout(int timeoutMs)
    {
        lock (_lock)
        {
            var timeoutCts = new CancellationTokenSource(timeoutMs);
            var linked = CancellationTokenSource.CreateLinkedTokenSource(
                _cts.Token, timeoutCts.Token);
            linked.Token.Register(() => { try { timeoutCts.Dispose(); } catch {} });
            return linked;
        }
    }

    /// <summary>Libera el CTS actual. Llamar en Add_Closed.</summary>
    public static void Dispose()
    {
        lock (_lock)
        {
            try { _cts.Cancel();  } catch { }
            try { _cts.Dispose(); } catch { }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// =============================================================================
// SECCIÓN 6 — LogEngine
// Logger thread-safe con rotación diaria y mutex con nombre.
// Reemplaza el StreamWriter + Mutex inline de SysOpt.ps1 (línea ~819).
//
// Uso en PS:
//   [LogEngine]::Initialize($logDir)          # una vez al arrancar
//   [LogEngine]::Write("mensaje", "INFO")     # desde cualquier runspace
//   [LogEngine]::Header("SysOpt", "3.2.0")   # cabecera de sesión
//   [LogEngine]::Close()                      # en Add_Closed
// =============================================================================

public static class LogEngine
{
    // ── Estado interno ────────────────────────────────────────────────────────
    private static StreamWriter  _writer      = null;
    private static Mutex         _mutex       = null;
    private static string        _currentDate = null;
    private static string        _logDir      = null;
    private static readonly object _initLock  = new object();

    // ── Debug toggle ──────────────────────────────────────────────────────────
    /// <summary>
    /// Cuando es false (por defecto), los mensajes con nivel "DBG" se descartan.
    /// Activable desde Opciones → "Habilitar logs de depuración".
    /// </summary>
    public static bool DebugEnabled { get; set; }

    // ── Initialize ────────────────────────────────────────────────────────────
    /// <summary>
    /// Inicializa (o reinicializa por rotación diaria) el logger.
    /// Llama una vez al arrancar y siempre que cambie el día.
    /// Idempotente: si ya está inicializado para hoy, no hace nada.
    /// </summary>
    public static void Initialize(string logDir)
    {
        if (string.IsNullOrEmpty(logDir)) throw new ArgumentNullException("logDir");

        lock (_initLock)
        {
            string today = DateTime.Now.ToString("yyyy-MM-dd");

            // Ya inicializado para hoy
            if (_currentDate == today && _writer != null) return;

            _logDir = logDir;

            // Cerrar writer anterior si existe (rotación)
            CloseWriter();

            if (!Directory.Exists(logDir))
                Directory.CreateDirectory(logDir);

            string logFile = Path.Combine(logDir, "SysOpt_" + today + ".log");

            var fs     = File.Open(logFile, FileMode.Append, FileAccess.Write, FileShare.ReadWrite);
            _writer    = new StreamWriter(fs, System.Text.Encoding.UTF8);
            _writer.AutoFlush = true;
            _currentDate = today;

            // Mutex con nombre único por PID — permite que runspaces lo adquieran
            if (_mutex == null)
            {
                string mutexName = "SysOpt_LogMutex_" + System.Diagnostics.Process.GetCurrentProcess().Id;
                _mutex = new Mutex(false, mutexName);
            }
        }
    }

    // ── Header ────────────────────────────────────────────────────────────────
    /// <summary>Escribe la cabecera de sesión al archivo de log.</summary>
    public static void Header(string appName, string version)
    {
        EnsureDay();
        string sep  = new string('═', 60);
        string line = string.Format(Loc.T("CoreSessionStarted", "  {0} v{1}  —  Sesión iniciada: {2}"),
            appName, version, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
        string host = string.Format("  Usuario: {0}  |  Host: {1}",
            Environment.UserName, Environment.MachineName);

        WriteRaw("");
        WriteRaw(sep);
        WriteRaw(line);
        WriteRaw(host);
        WriteRaw(sep);
    }

    // ── Write ─────────────────────────────────────────────────────────────────
    /// <summary>
    /// Escribe una línea al log. Seguro desde cualquier runspace/hilo.
    /// level: "DBG" | "INFO" | "WARN" | "ERR" | "CRIT"  (cualquier otro valor se admite tal cual)
    /// </summary>
    public static void Write(string message, string level)
    {
        if (message == null) message = "";
        if (string.IsNullOrEmpty(level)) level = "INFO";

        // Nivel UI y líneas vacías en INFO no van al archivo
        if (level == "UI") return;
        if (level == "INFO" && message.Trim().Length == 0) return;

        // DBG solo se escribe si DebugEnabled está activo
        if (level == "DBG" && !DebugEnabled) return;

        EnsureDay();

        string line = string.Format("[{0}][{1}] {2}",
            DateTime.Now.ToString("HH:mm:ss"), level, message);

        bool acquired = false;
        try
        {
            if (_mutex != null) acquired = _mutex.WaitOne(200);
            if (acquired && _writer != null) _writer.WriteLine(line);
        }
        catch { }
        finally
        {
            if (acquired) { try { _mutex.ReleaseMutex(); } catch { } }
        }
    }

    // ── Close ─────────────────────────────────────────────────────────────────
    /// <summary>Cierra el writer y libera el mutex. Llama en Add_Closed.</summary>
    public static void Close()
    {
        lock (_initLock)
        {
            CloseWriter();
            if (_mutex != null)
            {
                try { _mutex.Dispose(); } catch { }
                _mutex = null;
            }
        }
    }

    // ── Helpers privados ──────────────────────────────────────────────────────
    private static void EnsureDay()
    {
        if (_logDir == null || _writer != null && _currentDate == DateTime.Now.ToString("yyyy-MM-dd"))
            return;
        Initialize(_logDir);   // rotación silenciosa
    }

    private static void CloseWriter()
    {
        if (_writer != null)
        {
            try { _writer.Flush();   } catch { }
            try { _writer.Close();   } catch { }
            try { _writer.Dispose(); } catch { }
            _writer = null;
        }
        _currentDate = null;
    }

    private static void WriteRaw(string line)
    {
        bool acquired = false;
        try
        {
            if (_mutex != null) acquired = _mutex.WaitOne(200);
            if (acquired && _writer != null) _writer.WriteLine(line);
        }
        catch { }
        finally
        {
            if (acquired) { try { _mutex.ReleaseMutex(); } catch { } }
        }
    }
}
// =============================================================================
// SECCIÓN 7 — SysOptFallbacks
// Lógica de arranque que antes vivía inline en SysOpt.ps1:
//   · AppMutex — instancia única de la aplicación
//   · DllLoader — carga y guarda de DLLs con guard-type
//   · RunspacePoolState — flag que el PS consulta para saber si el pool está vivo
//
// Uso en PS (reemplaza el bloque inline de ~línea 305-415):
//   [SysOptFallbacks]::InitMutex("Global\OptimizadorSistemaGUI_v5")
//   if (-not [SysOptFallbacks]::AcquireMutex()) { exit }
//   [SysOptFallbacks]::RunspacePoolAvailable = $true   # lo escribe Initialize-RunspacePool
//   [SysOptFallbacks]::ReleaseMutex()                  # en Add_Closed
// =============================================================================
public static class SysOptFallbacks
{
    // ── AppMutex ─────────────────────────────────────────────────────────────
    private static Mutex  _appMutex     = null;
    private static bool   _mutexOwned   = false;
    private static readonly object _mLock = new object();

    /// <summary>
    /// Crea el mutex de instancia única.
    /// Llama UNA SOLA VEZ al arrancar, antes de mostrar ninguna ventana.
    /// </summary>
    public static void InitMutex(string mutexName)
    {
        if (string.IsNullOrEmpty(mutexName)) throw new ArgumentNullException("mutexName");
        lock (_mLock)
        {
            if (_appMutex != null) return;
            _appMutex = new Mutex(false, mutexName);
        }
    }

    /// <summary>
    /// Intenta adquirir el mutex (timeout 0 ms).
    /// Devuelve true si esta instancia es la primera; false si ya hay otra corriendo.
    /// Maneja AbandonedMutexException (proceso anterior murió sin liberar).
    /// </summary>
    public static bool AcquireMutex()
    {
        lock (_mLock)
        {
            if (_appMutex == null) return true; // sin mutex → siempre permitir
            try
            {
                _mutexOwned = _appMutex.WaitOne(0);
                return _mutexOwned;
            }
            catch (AbandonedMutexException)
            {
                // El proceso anterior murió sin liberar — el mutex nos pertenece
                _mutexOwned = true;
                return true;
            }
            catch
            {
                return true; // ante duda, permitir arranque
            }
        }
    }

    /// <summary>Libera el mutex al cerrar la aplicación.</summary>
    public static void ReleaseMutex()
    {
        lock (_mLock)
        {
            if (_appMutex == null || !_mutexOwned) return;
            try   { _appMutex.ReleaseMutex(); _mutexOwned = false; }
            catch { }
        }
    }

    /// <summary>Libera y descarta el mutex (llamar en Add_Closed).</summary>
    public static void DisposeMutex()
    {
        lock (_mLock)
        {
            ReleaseMutex();
            try   { if (_appMutex != null) _appMutex.Dispose(); } catch { }
            _appMutex = null;
        }
    }

    // ── RunspacePool state ────────────────────────────────────────────────────
    /// <summary>
    /// True cuando Initialize-RunspacePool consiguió abrir el pool.
    /// False cuando falló y el PS usa runspaces individuales como fallback.
    /// PowerShell lo escribe; New-TrackedPS lo lee para decidir el modo.
    /// </summary>
    public static volatile bool RunspacePoolAvailable = false;

    // ── DllLoader registry ────────────────────────────────────────────────────
    // Registro de ensamblados ya cargados en esta sesión, evitando
    // llamadas redundantes a Add-Type que lanzan errores por duplicado.
    private static readonly System.Collections.Generic.HashSet<string> _loaded
        = new System.Collections.Generic.HashSet<string>(StringComparer.OrdinalIgnoreCase);
    private static readonly object _loadLock = new object();

    /// <summary>
    /// Devuelve true si el guardType ya fue registrado como cargado.
    /// El PS llama a RegisterLoaded() justo después de Add-Type exitoso.
    /// </summary>
    public static bool IsLoaded(string guardType)
    {
        if (string.IsNullOrEmpty(guardType)) return false;
        lock (_loadLock) { return _loaded.Contains(guardType); }
    }

    /// <summary>Marca un guardType como cargado en esta sesión.</summary>
    public static void RegisterLoaded(string guardType)
    {
        if (string.IsNullOrEmpty(guardType)) return;
        lock (_loadLock) { _loaded.Add(guardType); }
    }

    /// <summary>
    /// Intenta cargar un ensamblado externo vía reflexión.
    /// Devuelve null si ya estaba cargado o si la carga falla.
    /// En caso de fallo: si hard=true lanza excepción; si false retorna null.
    /// El PS ya no necesita el bloque try/catch de Load-SysOptDll.
    /// </summary>
    public static System.Reflection.Assembly LoadDll(
        string dllPath, string guardType, bool hard)
    {
        if (IsLoaded(guardType)) return null;

        if (!File.Exists(dllPath))
        {
            string msg = "SysOpt DLL no encontrada: " + dllPath + " (guard=" + guardType + ")";
            if (hard) throw new FileNotFoundException(msg, dllPath);
            return null;
        }

        try
        {
            // v3.3.0-OPT-6: Load(bytes) — carga directa desde memoria, evita validación
            var bytes = File.ReadAllBytes(dllPath);
            var asm = System.Reflection.Assembly.Load(bytes);
            RegisterLoaded(guardType);
            return asm;
        }
        catch (Exception ex)
        {
            string msg = "SysOpt: no se pudo cargar " + dllPath + " — " + ex.Message;
            if (hard) throw new InvalidOperationException(msg, ex);
            return null;
        }
    }
}
// ═══════════════════════════════════════════════════════════════════════════════
// Formatter — Formatting utilities (replaces PS1 Format-Bytes, Format-Rate, etc.)
// ═══════════════════════════════════════════════════════════════════════════════
public static class Formatter
{
    public static string FormatBytes(long bytes)
    {
        if (bytes >= 1073741824L) return string.Format("{0:N1} GB", bytes / 1073741824.0);
        if (bytes >= 1048576L)    return string.Format("{0:N0} MB", bytes / 1048576.0);
        if (bytes >= 1024L)       return string.Format("{0:N0} KB", bytes / 1024.0);
        return bytes + " B";
    }

    public static string FormatRate(double bps)
    {
        if (bps >= 1048576.0) return string.Format("{0:N1} MB/s", bps / 1048576.0);
        if (bps >= 1024.0)    return string.Format("{0:N0} KB/s", bps / 1024.0);
        if (bps > 0)          return string.Format("{0:N0} B/s", bps);
        return "0 B/s";
    }

    public static string FormatLinkSpeed(ulong bps)
    {
        if (bps >= 1000000000UL) return Math.Round(bps / 1e9, 0) + " Gbps";
        if (bps >= 1000000UL)    return Math.Round(bps / 1e6, 0) + " Mbps";
        if (bps > 0)             return bps + " bps";
        return "\u2014";
    }

    public static ulong ParseLinkBps(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return 0;
        ulong n;
        if (ulong.TryParse(raw.Trim(), out n)) return n;
        var m = System.Text.RegularExpressions.Regex.Match(raw, @"([\d\.]+)\s*(G|M|K)?bps");
        if (m.Success)
        {
            double v = double.Parse(m.Groups[1].Value, System.Globalization.CultureInfo.InvariantCulture);
            string u = m.Groups[2].Value;
            double mul = u == "G" ? 1e9 : u == "M" ? 1e6 : u == "K" ? 1e3 : 1;
            return (ulong)(v * mul);
        }
        return 0;
    }
}
