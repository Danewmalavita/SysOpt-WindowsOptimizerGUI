﻿// SysOpt - Software de optimización del sistema
// Copyright (C) 2026 Danew Malavita
//
// Este programa es software libre bajo los términos de la GPL v3+.
// Consulta el archivo LICENSE o visita <https://www.gnu.org/licenses/>.

// =============================================================================
// SysOpt.Modules — v3.3.0
// Module system engine: DTOs, ISysOptModule contract, manifest/registry I/O,
// cache management, ZIP validation & extraction.
//
// ┌────────────────────────────────────────────────────────────────────────────┐
// │ AGENT-READY: Interfaces designed for future SysOpt Server deployment.     │
// │ Current : standalone for Windows 10/11                                    │
// │ Future  : agent ↔ server for centralized module push/policy/telemetry     │
// │ Based on: Tanium agent model (sensors, packages, actions)                 │
// └────────────────────────────────────────────────────────────────────────────┘
//
// Compilar:
//   csc /target:library /out:SysOpt.Modules.dll SysOpt.Modules.cs ^
//       /r:System.dll /r:System.Core.dll /r:System.Web.Extensions.dll ^
//       /r:System.IO.Compression.dll /r:System.IO.Compression.FileSystem.dll
// =============================================================================

using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Web.Script.Serialization;

// ═══════════════════════════════════════════════════════════════════════════════
// SECTION 1 — DTOs
// ═══════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Represents a module.json manifest. Properties are PascalCase in C#.
/// PS1 accesses: $manifest.Id, $manifest.Name, $manifest.TabHeader, etc.
/// </summary>
public class ModuleManifest
{
    public string Id               { get; set; }
    public string Name             { get; set; }
    public string Version          { get; set; }
    public string Author           { get; set; }
    public string Description      { get; set; }
    public string Icon             { get; set; }
    public string Category         { get; set; }
    public string EntryPoint       { get; set; }
    public string MinSysOptVersion { get; set; }

    // UI section (flattened from ui.*)
    public string TabHeader { get; set; }
    public string TabName   { get; set; }
    public string UiXaml    { get; set; }

    // Agent-ready fields (future SysOpt Server)
    public string   Source      { get; set; }  // "local" | "server" | "marketplace"
    public string   Checksum    { get; set; }  // SHA256 integrity
    public string[] Permissions { get; set; }  // requested capabilities

    internal static ModuleManifest FromDictionary(Dictionary<string, object> d)
    {
        if (d == null) return null;
        var m = new ModuleManifest
        {
            Id               = DH.Str(d, "id"),
            Name             = DH.Str(d, "name"),
            Version          = DH.Str(d, "version"),
            Author           = DH.Str(d, "author"),
            Description      = DH.Str(d, "description"),
            Icon             = DH.Str(d, "icon", "\U0001F9E9"),
            Category         = DH.Str(d, "category"),
            EntryPoint       = DH.Str(d, "entryPoint"),
            MinSysOptVersion = DH.Str(d, "minSysOptVersion"),
            Source           = DH.Str(d, "source", "local"),
            Checksum         = DH.Str(d, "checksum"),
        };

        // Parse nested "ui" section
        object uiObj;
        if (d.TryGetValue("ui", out uiObj) && uiObj is Dictionary<string, object>)
        {
            var ui = (Dictionary<string, object>)uiObj;
            m.TabHeader = DH.Str(ui, "tabHeader");
            m.TabName   = DH.Str(ui, "tabName");
            m.UiXaml    = DH.Str(ui, "xaml");
        }

        // Parse permissions array
        object permsObj;
        if (d.TryGetValue("permissions", out permsObj) && permsObj is ArrayList)
        {
            var al = (ArrayList)permsObj;
            var perms = new string[al.Count];
            for (int i = 0; i < al.Count; i++)
                perms[i] = al[i] != null ? al[i].ToString() : "";
            m.Permissions = perms;
        }
        else m.Permissions = new string[0];

        return m;
    }

    /// <summary>Serializable dictionary for JSON output.</summary>
    public Dictionary<string, object> ToDictionary()
    {
        var d = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
        d["id"]          = Id;
        d["name"]        = Name;
        d["version"]     = Version;
        d["author"]      = Author ?? "";
        d["description"] = Description ?? "";
        d["icon"]        = Icon ?? "\U0001F9E9";
        d["category"]    = Category ?? "";
        d["entryPoint"]  = EntryPoint;
        if (!string.IsNullOrEmpty(MinSysOptVersion)) d["minSysOptVersion"] = MinSysOptVersion;
        if (!string.IsNullOrEmpty(Source) && Source != "local") d["source"] = Source;
        if (!string.IsNullOrEmpty(Checksum)) d["checksum"] = Checksum;
        if (Permissions != null && Permissions.Length > 0) d["permissions"] = Permissions;

        var ui = new Dictionary<string, object>();
        if (!string.IsNullOrEmpty(TabHeader)) ui["tabHeader"] = TabHeader;
        if (!string.IsNullOrEmpty(TabName))   ui["tabName"]   = TabName;
        if (!string.IsNullOrEmpty(UiXaml))    ui["xaml"]      = UiXaml;
        if (ui.Count > 0) d["ui"] = ui;

        return d;
    }
}

/// <summary>
/// A module entry in modules.json registry.
/// </summary>
public class RegistryEntry
{
    public string Installed  { get; set; }
    public bool   Enabled    { get; set; }
    public string Version    { get; set; }
    public int    LoadOrder  { get; set; }

    // Agent-ready
    public string DeployedBy { get; set; }  // "user" | "server-policy"
    public string PolicyId   { get; set; }  // server policy ID

    internal static RegistryEntry FromDictionary(Dictionary<string, object> d)
    {
        if (d == null) return null;
        return new RegistryEntry
        {
            Installed  = DH.Str(d, "installed"),
            Enabled    = DH.Bool(d, "enabled"),
            Version    = DH.Str(d, "version"),
            LoadOrder  = DH.Int(d, "loadOrder"),
            DeployedBy = DH.Str(d, "deployedBy", "user"),
            PolicyId   = DH.Str(d, "policyId"),
        };
    }

    public Dictionary<string, object> ToDictionary()
    {
        var d = new Dictionary<string, object>();
        d["installed"] = Installed;
        d["enabled"]   = Enabled;
        d["version"]   = Version;
        d["loadOrder"] = LoadOrder;
        if (!string.IsNullOrEmpty(DeployedBy) && DeployedBy != "user") d["deployedBy"] = DeployedBy;
        if (!string.IsNullOrEmpty(PolicyId)) d["policyId"] = PolicyId;
        return d;
    }
}

/// <summary>
/// Combined module info for UI display (registry + manifest merged).
/// PS1 binds this to ItemsControl in OptionsWindow.
/// </summary>
public class ModuleInfo
{
    public string Id          { get; set; }
    public string Name        { get; set; }
    public string Version     { get; set; }
    public string Author      { get; set; }
    public string Description { get; set; }
    public string Icon        { get; set; }
    public string Category    { get; set; }
    public bool   Enabled     { get; set; }
    public string Installed   { get; set; }
    public int    LoadOrder   { get; set; }
    public bool   Valid       { get; set; }
    public string Source      { get; set; }
}

/// <summary>Result of manifest validation.</summary>
public class ModuleValidation
{
    public bool     IsValid  { get; set; }
    public string[] Errors   { get; set; }
    public string[] Warnings { get; set; }
    public ModuleValidation() { Errors = new string[0]; Warnings = new string[0]; }
}


// ═══════════════════════════════════════════════════════════════════════════════
// SECTION 2 — Interfaces (Agent-ready for SysOpt Server)
// ═══════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Contract for SysOpt modules. Current modules are PS1 scripts; future C# DLL
/// modules implement this interface for tighter integration and server commands.
///
/// Lifecycle: OnLoad → (active) → OnUnload
/// Server:    OnCommand receives remote instructions from SysOpt Server.
/// Tanium model: modules = sensors (report status) + packages (execute actions).
/// </summary>
public interface ISysOptModule
{
    string Id      { get; }
    string Name    { get; }
    string Version { get; }

    // ── Lifecycle ──
    void OnLoad(ISysOptAPI api);
    void OnUnload();
    void OnThemeChange(Dictionary<string, string> themeColors);

    // ── Agent-ready: server commands (Tanium action model) ──
    /// <summary>Execute a command pushed from SysOpt Server.</summary>
    void OnCommand(string command, Dictionary<string, string> parameters);
    /// <summary>Sensor: return current module status for server telemetry.</summary>
    Dictionary<string, object> GetStatus();
}

/// <summary>
/// API surface exposed to modules. Modules call these methods instead of
/// reaching into SysOpt internals — decoupling for standalone + server modes.
///
/// Current: PS1 bridge (T(), Write-Log, Get-TC, Show-Toast)
/// Future:  adds ReportStatus, RequestData for server communication.
/// </summary>
public interface ISysOptAPI
{
    // ── Identity ──
    string AppVersion { get; }
    string AppDir     { get; }
    string DataDir    { get; }

    // ── Core services ──
    void   Log(string message, string level);
    string T(string key, string fallback);
    string GetThemeColor(string key, string fallback);
    void   ShowToast(string title, string message, string type);

    // ── Module events (pub/sub) ──
    void SendEvent(string eventName, Dictionary<string, object> data);

    // ── Agent-ready: server communication ──
    void ReportStatus(string moduleId, Dictionary<string, object> status);
    void RequestModuleUpdate(string moduleId);
}


// ═══════════════════════════════════════════════════════════════════════════════
// SECTION 3 — ModuleEngine (static, all pure logic)
// ═══════════════════════════════════════════════════════════════════════════════

public static class ModuleEngine
{
    private static readonly JavaScriptSerializer _json = new JavaScriptSerializer
        { MaxJsonLength = int.MaxValue };
    private static readonly object _ioLock = new object();

    // ── Directory initialization ────────────────────────────────────────────

    /// <summary>
    /// Ensures modules/ dir and modules.json exist. Returns registry path.
    /// </summary>
    public static string EnsureDirectories(string modulesDir)
    {
        if (string.IsNullOrEmpty(modulesDir))
            throw new ArgumentNullException("modulesDir");

        if (!Directory.Exists(modulesDir))
            Directory.CreateDirectory(modulesDir);

        string registryPath = Path.Combine(modulesDir, "modules.json");
        if (!File.Exists(registryPath))
        {
            var initial = new Dictionary<string, object>
            {
                { "version", 1 },
                { "modules", new Dictionary<string, object>() }
            };
            AtomicWriteJson(registryPath, initial);
        }
        return registryPath;
    }

    // ── Manifest I/O ────────────────────────────────────────────────────────

    /// <summary>Reads module.json from disk → ModuleManifest. Null if missing.</summary>
    public static ModuleManifest ReadManifest(string manifestPath)
    {
        if (!File.Exists(manifestPath)) return null;
        string json = File.ReadAllText(manifestPath, Encoding.UTF8);
        var dict = _json.Deserialize<Dictionary<string, object>>(json);
        return ModuleManifest.FromDictionary(dict);
    }

    /// <summary>
    /// Reads module.json from inside a ZIP without full extraction.
    /// Throws if ZIP has no module.json.
    /// </summary>
    public static ModuleManifest ReadManifestFromZip(string zipPath)
    {
        string dummy;
        return ReadManifestFromZip(zipPath, out dummy);
    }

    /// <summary>Overload that also returns the root prefix for extraction.</summary>
    public static ModuleManifest ReadManifestFromZip(string zipPath, out string rootPrefix)
    {
        rootPrefix = "";
        if (!File.Exists(zipPath))
            throw new FileNotFoundException("ZIP not found: " + zipPath);

        using (var zip = ZipFile.OpenRead(zipPath))
        {
            ZipArchiveEntry manifestEntry = null;
            foreach (var e in zip.Entries)
            {
                if (e.Name.Equals("module.json", StringComparison.OrdinalIgnoreCase))
                {
                    manifestEntry = e;
                    int pLen = e.FullName.Length - "module.json".Length;
                    if (pLen > 0) rootPrefix = e.FullName.Substring(0, pLen);
                    break;
                }
            }
            if (manifestEntry == null)
                throw new InvalidOperationException("ZIP does not contain module.json");

            using (var stream = manifestEntry.Open())
            using (var reader = new StreamReader(stream, Encoding.UTF8))
            {
                string json = reader.ReadToEnd();
                var dict = _json.Deserialize<Dictionary<string, object>>(json);
                return ModuleManifest.FromDictionary(dict);
            }
        }
    }

    // ── Validation ──────────────────────────────────────────────────────────

    /// <summary>Validates manifest fields and version compatibility.</summary>
    public static ModuleValidation ValidateManifest(ModuleManifest m, string currentVersion)
    {
        var r = new ModuleValidation();
        var err  = new List<string>();
        var warn = new List<string>();

        if (m == null) { err.Add("Manifest is null"); r.IsValid = false; r.Errors = err.ToArray(); return r; }

        if (string.IsNullOrEmpty(m.Id))         err.Add("Missing: id");
        if (string.IsNullOrEmpty(m.Name))       err.Add("Missing: name");
        if (string.IsNullOrEmpty(m.Version))    err.Add("Missing: version");
        if (string.IsNullOrEmpty(m.EntryPoint)) err.Add("Missing: entryPoint");

        if (!string.IsNullOrEmpty(m.MinSysOptVersion) && !string.IsNullOrEmpty(currentVersion))
        {
            try
            {
                if (new Version(currentVersion) < new Version(m.MinSysOptVersion))
                    err.Add(string.Format("Requires v{0}, current v{1}", m.MinSysOptVersion, currentVersion));
            }
            catch { warn.Add("Cannot parse minSysOptVersion: " + m.MinSysOptVersion); }
        }

        if (string.IsNullOrEmpty(m.Author))     warn.Add("No author");
        if (string.IsNullOrEmpty(m.Description)) warn.Add("No description");
        if (string.IsNullOrEmpty(m.TabHeader))   warn.Add("No UI tab header");

        r.IsValid  = err.Count == 0;
        r.Errors   = err.ToArray();
        r.Warnings = warn.ToArray();
        return r;
    }

    /// <summary>Check version compatibility. True = compatible.</summary>
    public static bool IsCompatible(ModuleManifest m, string currentVersion)
    {
        if (m == null || string.IsNullOrEmpty(m.MinSysOptVersion)) return true;
        try { return new Version(currentVersion) >= new Version(m.MinSysOptVersion); }
        catch { return true; }
    }

    // ── Registry I/O ────────────────────────────────────────────────────────

    /// <summary>Reads modules.json → Dictionary&lt;moduleId, RegistryEntry&gt;.</summary>
    public static Dictionary<string, RegistryEntry> ReadRegistry(string registryPath)
    {
        var result = new Dictionary<string, RegistryEntry>(StringComparer.OrdinalIgnoreCase);
        if (!File.Exists(registryPath)) return result;

        string json = File.ReadAllText(registryPath, Encoding.UTF8);
        var root = _json.Deserialize<Dictionary<string, object>>(json);

        object modulesObj;
        if (root != null && root.TryGetValue("modules", out modulesObj) &&
            modulesObj is Dictionary<string, object>)
        {
            foreach (var kv in (Dictionary<string, object>)modulesObj)
            {
                if (kv.Value is Dictionary<string, object>)
                {
                    var entry = RegistryEntry.FromDictionary((Dictionary<string, object>)kv.Value);
                    if (entry != null) result[kv.Key] = entry;
                }
            }
        }
        return result;
    }

    /// <summary>Saves registry with atomic write (tmp → copy → delete).</summary>
    public static void SaveRegistry(string registryPath,
                                     Dictionary<string, RegistryEntry> registry)
    {
        var modules = new Dictionary<string, object>();
        if (registry != null)
            foreach (var kv in registry)
                modules[kv.Key] = kv.Value.ToDictionary();

        var root = new Dictionary<string, object>
        {
            { "version", 1 },
            { "modules", modules }
        };
        lock (_ioLock) { AtomicWriteJson(registryPath, root); }
    }

    /// <summary>Returns the next available loadOrder.</summary>
    public static int GetNextLoadOrder(Dictionary<string, RegistryEntry> registry)
    {
        int max = 0;
        if (registry != null)
            foreach (var e in registry.Values)
                if (e.LoadOrder > max) max = e.LoadOrder;
        return max + 1;
    }

    /// <summary>Creates a fresh RegistryEntry for a just-installed module.</summary>
    public static RegistryEntry CreateRegistryEntry(string version, int loadOrder)
    {
        return new RegistryEntry
        {
            Installed  = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ"),
            Enabled    = false,
            Version    = version,
            LoadOrder  = loadOrder,
            DeployedBy = "user"
        };
    }

    /// <summary>Returns enabled module IDs sorted by loadOrder.</summary>
    public static string[] GetEnabledModuleIds(string registryPath)
    {
        var registry = ReadRegistry(registryPath);
        var enabled = new List<KeyValuePair<string, int>>();
        foreach (var kv in registry)
            if (kv.Value.Enabled)
                enabled.Add(new KeyValuePair<string, int>(kv.Key, kv.Value.LoadOrder));

        enabled.Sort((a, b) => a.Value.CompareTo(b.Value));
        var result = new string[enabled.Count];
        for (int i = 0; i < enabled.Count; i++) result[i] = enabled[i].Key;
        return result;
    }

    // ── Cache management ────────────────────────────────────────────────────

    /// <summary>True if cache file is newer than registry file.</summary>
    public static bool IsCacheValid(string cachePath, string registryPath)
    {
        if (!File.Exists(cachePath) || !File.Exists(registryPath)) return false;
        return File.GetLastWriteTimeUtc(cachePath) >= File.GetLastWriteTimeUtc(registryPath);
    }

    /// <summary>Builds cache combining registry + all manifests → single JSON.</summary>
    public static void BuildCache(string registryPath, string modulesDir, string cachePath)
    {
        var registry = ReadRegistry(registryPath);
        var manifests = new Dictionary<string, object>();

        foreach (var kv in registry)
        {
            string mPath = Path.Combine(modulesDir, kv.Key, "module.json");
            if (File.Exists(mPath))
            {
                try
                {
                    string j = File.ReadAllText(mPath, Encoding.UTF8);
                    manifests[kv.Key] = _json.Deserialize<Dictionary<string, object>>(j);
                }
                catch { }
            }
        }

        var cache = new Dictionary<string, object>
        {
            { "timestamp", DateTime.UtcNow.ToString("o") },
            { "registryPath", registryPath },
            { "manifests", manifests }
        };

        string cacheDir = Path.GetDirectoryName(cachePath);
        if (!string.IsNullOrEmpty(cacheDir) && !Directory.Exists(cacheDir))
            Directory.CreateDirectory(cacheDir);

        lock (_ioLock) { AtomicWriteJson(cachePath, cache); }
    }

    /// <summary>Reads a single cached manifest. Null if not found.</summary>
    public static ModuleManifest ReadCachedManifest(string cachePath, string moduleId)
    {
        if (!File.Exists(cachePath)) return null;
        try
        {
            string json = File.ReadAllText(cachePath, Encoding.UTF8);
            var cache = _json.Deserialize<Dictionary<string, object>>(json);
            object mObj;
            if (cache.TryGetValue("manifests", out mObj) && mObj is Dictionary<string, object>)
            {
                var ms = (Dictionary<string, object>)mObj;
                object modObj;
                if (ms.TryGetValue(moduleId, out modObj) && modObj is Dictionary<string, object>)
                    return ModuleManifest.FromDictionary((Dictionary<string, object>)modObj);
            }
        }
        catch { }
        return null;
    }

    // ── Module info for UI ──────────────────────────────────────────────────

    /// <summary>
    /// Returns ModuleInfo[] combining registry + manifests (cache-first).
    /// Replaces PS1 Get-InstalledModules entirely.
    /// </summary>
    public static ModuleInfo[] GetInstalledModules(string registryPath,
                                                    string modulesDir,
                                                    string cachePath)
    {
        var registry = ReadRegistry(registryPath);
        bool useCache = IsCacheValid(cachePath, registryPath);
        var result = new List<ModuleInfo>();

        foreach (var kv in registry)
        {
            string mid = kv.Key;
            var entry = kv.Value;

            var info = new ModuleInfo
            {
                Id = mid, Name = mid, Version = entry.Version,
                Author = "", Description = "", Icon = "\U0001F9E9", Category = "",
                Enabled = entry.Enabled, Installed = entry.Installed,
                LoadOrder = entry.LoadOrder, Valid = false, Source = "local"
            };

            // Try cache first, then disk
            ModuleManifest manifest = null;
            if (useCache) manifest = ReadCachedManifest(cachePath, mid);
            if (manifest == null)
                manifest = ReadManifest(Path.Combine(modulesDir, mid, "module.json"));

            if (manifest != null)
            {
                info.Name        = !string.IsNullOrEmpty(manifest.Name) ? manifest.Name : mid;
                info.Author      = manifest.Author ?? "";
                info.Description = manifest.Description ?? "";
                info.Icon        = !string.IsNullOrEmpty(manifest.Icon) ? manifest.Icon : "\U0001F9E9";
                info.Category    = manifest.Category ?? "";
                info.Valid       = true;
                info.Source      = manifest.Source ?? "local";
            }
            result.Add(info);
        }
        return result.ToArray();
    }

    // ── ZIP extraction ──────────────────────────────────────────────────────

    /// <summary>Extracts module ZIP to targetDir, handling root prefix.</summary>
    public static void ExtractModuleZip(string zipPath, string targetDir)
    {
        string rootPrefix;
        ReadManifestFromZip(zipPath, out rootPrefix);   // validates ZIP

        if (!Directory.Exists(targetDir))
            Directory.CreateDirectory(targetDir);

        using (var zip = ZipFile.OpenRead(zipPath))
        {
            foreach (var entry in zip.Entries)
            {
                if (entry.FullName.EndsWith("/")) continue;
                string relPath = entry.FullName;
                if (!string.IsNullOrEmpty(rootPrefix) && relPath.StartsWith(rootPrefix))
                    relPath = relPath.Substring(rootPrefix.Length);
                else if (!string.IsNullOrEmpty(rootPrefix))
                    continue;
                if (string.IsNullOrEmpty(relPath)) continue;

                // Security: reject path traversal
                if (relPath.Contains("..")) continue;

                string destPath = Path.Combine(targetDir, relPath);
                string destDir  = Path.GetDirectoryName(destPath);
                if (!string.IsNullOrEmpty(destDir) && !Directory.Exists(destDir))
                    Directory.CreateDirectory(destDir);

                entry.ExtractToFile(destPath, true);
            }
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private static void AtomicWriteJson(string path, object data)
    {
        string json = _json.Serialize(data);
        json = PrettyPrint(json);

        string tmp = path + ".tmp";
        File.WriteAllText(tmp, json, Encoding.UTF8);
        File.Copy(tmp, path, true);
        try { File.Delete(tmp); } catch { }
    }

    /// <summary>Basic JSON pretty printer (2-space indent).</summary>
    private static string PrettyPrint(string json)
    {
        if (string.IsNullOrEmpty(json)) return json;
        var sb = new StringBuilder(json.Length + 128);
        int indent = 0;
        bool inStr = false;
        char prev = '\0';

        for (int i = 0; i < json.Length; i++)
        {
            char c = json[i];
            if (c == '"' && prev != '\\') inStr = !inStr;

            if (!inStr)
            {
                if (c == '{' || c == '[')
                {
                    sb.Append(c);
                    if (i + 1 < json.Length && (json[i + 1] == '}' || json[i + 1] == ']'))
                    { sb.Append(json[++i]); prev = json[i]; continue; }
                    sb.AppendLine(); indent++;
                    sb.Append(' ', indent * 2);
                }
                else if (c == '}' || c == ']')
                {
                    sb.AppendLine(); indent--;
                    sb.Append(' ', indent * 2); sb.Append(c);
                }
                else if (c == ',')
                { sb.Append(c); sb.AppendLine(); sb.Append(' ', indent * 2); }
                else if (c == ':')
                { sb.Append(c); sb.Append(' '); }
                else sb.Append(c);
            }
            else sb.Append(c);
            prev = c;
        }
        return sb.ToString();
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// SECTION 4 — DH (internal Dictionary Helper)
// ═══════════════════════════════════════════════════════════════════════════════
internal static class DH
{
    public static string Str(Dictionary<string, object> d, string k, string fb = "")
    {
        object v; return (d.TryGetValue(k, out v) && v != null) ? v.ToString() : fb;
    }
    public static bool Bool(Dictionary<string, object> d, string k, bool fb = false)
    {
        object v;
        if (!d.TryGetValue(k, out v)) return fb;
        if (v is bool) return (bool)v;
        if (v != null) { bool b; if (bool.TryParse(v.ToString(), out b)) return b; }
        return fb;
    }
    public static int Int(Dictionary<string, object> d, string k, int fb = 0)
    {
        object v;
        if (!d.TryGetValue(k, out v)) return fb;
        if (v is int) return (int)v;
        if (v != null) { int n; if (int.TryParse(v.ToString(), out n)) return n; }
        return fb;
    }
}
