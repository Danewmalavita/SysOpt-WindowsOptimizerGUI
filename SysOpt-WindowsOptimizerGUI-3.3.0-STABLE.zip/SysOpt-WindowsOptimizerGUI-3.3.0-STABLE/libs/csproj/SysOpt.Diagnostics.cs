﻿// SysOpt - Software de optimización del sistema
// Copyright (C) 2026 Danew Malavita
//
// Este programa es software libre bajo los términos de la GPL v3+.
// Consulta el archivo LICENSE o visita <https://www.gnu.org/licenses/>.

// SysOpt.Diagnostics.cs — Motor de diagnóstico del sistema
// v3.3.0-DEV — Extended DiagInput + OkCount/SkipCount + GenerateHtmlReport
// Compatible con C# 5 / .NET Framework 4.x
using System;
using System.Collections.Generic;
using System.Text;

namespace SysOpt.Diagnostics
{
    // Loc is provided by SysOpt.Core.dll (global namespace, no using needed)

    // ═══════════════════════════════════════════════════════════════════════
    // DTOs
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>Datos de entrada recogidos por el Optimizer (dry-run).</summary>
    public class DiagInput
    {
        // ── Campos originales (v3.2.0) ─────────────────────────────────
        public double TempFilesMB    { get; set; }
        public double UserTempMB     { get; set; }
        public double RecycleBinMB   { get; set; }
        public double WUCacheMB      { get; set; }
        public double BrowserCacheMB { get; set; }
        public double DnsEntries     { get; set; }
        public double OrphanedKeys   { get; set; }
        public double EventLogsMB    { get; set; }
        public double RamUsedPct     { get; set; }
        public double DiskCUsedPct   { get; set; }

        // ── Campos nuevos (v3.3.0) — Info del Sistema ──────────────────
        /// <summary>Nombre del equipo (Environment.MachineName)</summary>
        public string ComputerName   { get; set; }
        /// <summary>Modelo CPU (ej: "Intel Core i7-12700K")</summary>
        public string CpuModel       { get; set; }
        /// <summary>Versión SO (ej: "Windows 11 Pro 23H2")</summary>
        public string OsVersion      { get; set; }

        // ── Campos nuevos (v3.3.0) — Memoria y Disco (absolutos) ──────
        /// <summary>RAM total en GB</summary>
        public double RamTotalGB     { get; set; }
        /// <summary>RAM libre en GB</summary>
        public double RamFreeGB      { get; set; }
        /// <summary>Disco C: total en GB</summary>
        public double DiskTotalGB    { get; set; }
        /// <summary>Disco C: libre en GB</summary>
        public double DiskFreeGB     { get; set; }

        // ── Campos nuevos (v3.3.0) — Conteos ──────────────────────────
        /// <summary>Número de archivos temporales encontrados</summary>
        public int    TempFileCount      { get; set; }
        /// <summary>Número de apps de inicio</summary>
        public int    StartupCount       { get; set; }
        /// <summary>Servicios bloatware detectados</summary>
        public int    ServicesBloatCount { get; set; }
        /// <summary>Total de servicios en ejecución</summary>
        public int    ServicesTotalCount { get; set; }

        // ── Campos nuevos (v3.3.0) — Misc ─────────────────────────────
        /// <summary>Horas de uptime del sistema</summary>
        public double UptimeHours    { get; set; }

        // ── Campos nuevos (v3.3.0) — Seguridad ──────────────────────────
        public string AntivirusName    { get; set; }
        public bool   AntivirusEnabled { get; set; }
        public bool   FirewallEnabled  { get; set; }
        public string FirewallName     { get; set; }  // "Windows Firewall", "Kaspersky", etc.
        public int    UacLevel         { get; set; }  // 0=off, 1-3=levels
        public bool   WindowsUpdateOk  { get; set; }
        public string WindowsUpdateDetail { get; set; }

        // ── Campos nuevos (v3.3.0) — Sistema ────────────────────────────
        public string SfcStatus        { get; set; }  // "OK","WARN","UNKNOWN"
        public string SfcDetail        { get; set; }

        // ── Campos nuevos (v3.3.0) — Disco ─────────────────────────────
        public bool   SmartOkC         { get; set; }
        public string SmartDetailC     { get; set; }

        // ── Campos nuevos (v3.3.0) — Inicio ────────────────────────────
        public double BootTimeSeconds  { get; set; }

        // ── Campos nuevos (v3.3.0) — Servicios ─────────────────────────
        public int    CriticalSvcOk    { get; set; }
        public int    CriticalSvcTotal { get; set; }
        public string StoppedCriticalSvcNames { get; set; }

        // ── Campos nuevos (v3.3.0) — Red ───────────────────────────────
        public bool   NetworkConnected { get; set; }
        public string NetworkDetail    { get; set; }
        public bool   DnsResolutionOk  { get; set; }
        public double DnsLatencyMs     { get; set; }
    }

    /// <summary>Elemento individual del informe (fila o cabecera de sección).</summary>
    public class DiagItem
    {
        /// <summary>true = cabecera de sección; false = fila de datos.</summary>
        public bool   IsSection   { get; set; }
        public string SectionTitle{ get; set; }
        public string SectionIcon { get; set; }

        /// <summary>OK | WARN | CRIT | INFO | SKIP</summary>
        public string Status      { get; set; }
        public string Label       { get; set; }
        public string Detail      { get; set; }
        public string Action      { get; set; }
        public int    Deduction   { get; set; }
        public string ExportLine  { get; set; }
    }

    /// <summary>Resultado completo del análisis diagnóstico.</summary>
    public class DiagResult
    {
        public List<DiagItem> Items     { get; set; }
        public int    Score             { get; set; }
        public int    CritCount         { get; set; }
        public int    WarnCount         { get; set; }
        // ── Nuevos contadores (v3.3.0) ─────────────────────────────────
        public int    OkCount           { get; set; }
        public int    SkipCount         { get; set; }
        public int    InfoCount         { get; set; }
        public string ScoreLabel        { get; set; }
        public string ScoreColor        { get; set; }
        public List<string> ExportLines { get; set; }
    }

    /// <summary>Parámetros adicionales para la generación del informe HTML.</summary>
    public class HtmlReportParams
    {
        /// <summary>Contenido de la plantilla HTML (analysisreport.html).</summary>
        public string TemplateHtml  { get; set; }
        /// <summary>Versión de la app (ej: "v3.3.0-DEV").</summary>
        public string AppVersion    { get; set; }
        /// <summary>Logo PNG en base64 (opcional — si vacío, usa fallback emoji).</summary>
        public string LogoBase64    { get; set; }
        /// <summary>Duración del análisis (ej: "2.3s").</summary>
        public string AnalysisTime  { get; set; }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Motor
    // ═══════════════════════════════════════════════════════════════════════

    public static class DiagnosticsEngine
    {
        // ── Agrupación interna de secciones para pie chart ─────────────
        private class SectionGroup
        {
            public string Title;
            public string Icon;
            public List<DiagItem> Items;
        }

        // ── Paleta de colores para pie chart ───────────────────────────
        private static readonly string[] PieColors = new string[] {
            "#5BA3FF", "#2EDFBF", "#9B7EFF", "#FFB547", "#4AE896", "#FF6B84", "#7880A0"
        };

        /// <summary>
        /// Analiza los datos del sistema y devuelve el informe completo
        /// con secciones, filas, puntuación y texto exportable.
        /// </summary>
        public static DiagResult Analyze(DiagInput report)
        {
            if (report == null) report = new DiagInput();

            List<DiagItem> items = new List<DiagItem>();
            List<string> export  = new List<string>();
            int deductions = 0;
            int critCount  = 0;
            int warnCount  = 0;
            int okCount    = 0;
            int infoCount  = 0;
            int skipCount  = 0;

            string dateStr = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
            export.Add(Loc.T("DiagReportTitle", "INFORME DE DIAGNÓSTICO DEL SISTEMA — SysOpt v3.3.0"));
            export.Add(string.Format(Loc.T("DiagExportDate", "Fecha: {0}"), dateStr));
            if (!string.IsNullOrEmpty(report.ComputerName))
            {
                export.Add(string.Format(Loc.T("DiagExportComputer", "Equipo: {0}"), report.ComputerName));
            }
            export.Add("");

            // ══════════════════════════════════════════════════════════════
            // 1. SISTEMA
            // ══════════════════════════════════════════════════════════════
            AddSection(items, export, Loc.T("DiagSectSistema", "SISTEMA"), "\uE770");

            // Uptime
            if (report.UptimeHours > 0)
            {
                if (report.UptimeHours > 168) // > 7 días
                {
                    AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                        "WARN", Loc.T("DiagUptimeWarn", "Sistema sin reiniciar por mucho tiempo"),
                        string.Format(Loc.T("DiagUptimeWarnDetail", "{0} horas de uptime — se recomienda reiniciar"), Math.Round(report.UptimeHours, 0)),
                        Loc.T("DiagUptimeAction", "Reiniciar el equipo"), 3);
                }
                else
                {
                    AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                        "OK", Loc.T("DiagUptimeOk", "Uptime dentro de lo normal"),
                        string.Format(Loc.T("DiagUptimeOkDetail", "{0} horas"), Math.Round(report.UptimeHours, 1)),
                        "", 0);
                }
            }

            // SFC integrity
            string sfcStatus = report.SfcStatus ?? "";
            if (sfcStatus == "OK")
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "OK", Loc.T("DiagSfcOk", "Integridad del sistema verificada"),
                    !string.IsNullOrEmpty(report.SfcDetail) ? report.SfcDetail : Loc.T("DiagSfcOkDetail", "Sin problemas de integridad"),
                    "", 0);
            }
            else if (sfcStatus == "WARN")
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "WARN", Loc.T("DiagSfcWarn", "SFC detectó problemas de integridad"),
                    !string.IsNullOrEmpty(report.SfcDetail) ? report.SfcDetail : Loc.T("DiagSfcWarnDetail", "Se detectaron archivos corruptos"),
                    Loc.T("DiagSfcAction", "Ejecutar sfc /scannow"), 5);
            }
            else
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "INFO", Loc.T("DiagSfcUnknown", "Estado SFC desconocido"),
                    !string.IsNullOrEmpty(report.SfcDetail) ? report.SfcDetail : Loc.T("DiagSfcUnknownDetail", "No se encontraron resultados recientes de SFC"),
                    "", 0);
            }

            // RAM usage
            double ramPct = report.RamUsedPct;
            string ramDetailSuffix = "";
            if (report.RamTotalGB > 0)
            {
                ramDetailSuffix = string.Format(" ({0}/{1} GB)",
                    Math.Round(report.RamTotalGB - report.RamFreeGB, 1),
                    Math.Round(report.RamTotalGB, 1));
            }
            if (ramPct > 85)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "CRIT", Loc.T("DiagRamCritical", "Memoria RAM crítica"),
                    string.Format(Loc.T("DiagRamCritDetail", "{0}% en uso — riesgo de lentitud severa"), ramPct) + ramDetailSuffix,
                    Loc.T("DiagRamCritAction", "Liberar RAM urgente"), 20);
            }
            else if (ramPct > 70)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "WARN", Loc.T("DiagRamWarn", "Uso de RAM elevado"),
                    string.Format(Loc.T("DiagRamPctInUse", "{0}% en uso"), ramPct) + ramDetailSuffix,
                    Loc.T("DiagRamWarnAction", "Liberar RAM recomendado"), 10);
            }
            else
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "OK", Loc.T("DiagRamOk", "Memoria RAM en niveles normales"),
                    string.Format(Loc.T("DiagRamPctInUse", "{0}% en uso"), ramPct) + ramDetailSuffix,
                    "", 0);
            }

            // OS Version (informational)
            if (!string.IsNullOrEmpty(report.OsVersion))
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "INFO", Loc.T("DiagOsVersion", "Versión del sistema operativo"),
                    report.OsVersion,
                    "", 0);
            }

            // ══════════════════════════════════════════════════════════════
            // 2. LIMPIEZA
            // ══════════════════════════════════════════════════════════════
            AddSection(items, export, Loc.T("DiagSectLimpieza", "LIMPIEZA"), "\uE74D");

            // Temp files
            double tempTotal = report.TempFilesMB + report.UserTempMB;
            if (tempTotal > 1000)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "CRIT", Loc.T("DiagTempCrit", "Archivos temporales acumulados"),
                    string.Format(Loc.T("DiagTempCritDetail", "{0} MB en carpetas Temp ({1} archivos)"),
                        Math.Round(tempTotal, 0), report.TempFileCount),
                    Loc.T("DiagTempCritAction", "Limpiar Temp Windows + Usuario"), 15);
            }
            else if (tempTotal > 200)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "WARN", Loc.T("DiagTempWarn", "Archivos temporales moderados"),
                    string.Format(Loc.T("DiagTempWarnDetail", "{0} MB — recomendable limpiar ({1} archivos)"),
                        Math.Round(tempTotal, 0), report.TempFileCount),
                    Loc.T("DiagTempWarnAction", "Limpiar carpetas Temp"), 7);
            }
            else
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "OK", Loc.T("DiagTempOk", "Carpetas temporales limpias"),
                    string.Format(Loc.T("DiagOptimalLevel", "{0} MB — nivel óptimo"), Math.Round(tempTotal, 1)),
                    "", 0);
            }

            // Recycle bin
            double recycleSize = report.RecycleBinMB;
            if (recycleSize > 500)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "WARN", Loc.T("DiagRecycleBinFull", "Papelera de reciclaje llena"),
                    string.Format(Loc.T("DiagRecycleBinDetail", "{0} MB ocupados"), Math.Round(recycleSize, 0)),
                    Loc.T("DiagRecycleBinAction", "Vaciar papelera"), 5);
            }
            else if (recycleSize > 0)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "INFO", Loc.T("DiagRecycleBinInfo", "Papelera con contenido"),
                    string.Format("{0} MB", Math.Round(recycleSize, 1)),
                    "", 0);
            }
            else
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "OK", Loc.T("DiagRecycleBinEmpty", "Papelera vacía"),
                    Loc.T("DiagRecycleBinEmptyDetail", "Sin archivos pendientes de eliminar"), "", 0);
            }

            // DNS cache
            double dnsCount = report.DnsEntries;
            if (dnsCount > 500)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "WARN", Loc.T("DiagDnsCacheLarge", "Caché DNS muy grande"),
                    string.Format(Loc.T("DiagDnsSlowResolution", "{0} entradas — puede ralentizar resolución"), dnsCount),
                    Loc.T("DiagCleanDns", "Limpiar caché DNS"), 5);
            }
            else
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "OK", Loc.T("DiagDnsCacheNormal", "Caché DNS normal"),
                    string.Format(Loc.T("DiagDnsEntries", "{0} entradas"), dnsCount),
                    "", 0);
            }

            // Event logs
            double eventMB = report.EventLogsMB;
            if (eventMB > 100)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "WARN", Loc.T("DiagEventLogWarn", "Logs de eventos grandes"),
                    string.Format(Loc.T("DiagEventLogDetail", "{0} MB en System+Application+Setup"), Math.Round(eventMB, 1)),
                    Loc.T("DiagEventLogAction", "Limpiar Event Logs"), 3);
            }
            else
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "OK", Loc.T("DiagEventLogsOk", "Logs de eventos dentro de límites"),
                    string.Format("{0} MB", Math.Round(eventMB, 1)),
                    "", 0);
            }

            // ══════════════════════════════════════════════════════════════
            // 3. DISCO
            // ══════════════════════════════════════════════════════════════
            AddSection(items, export, Loc.T("DiagSectDisco", "DISCO"), "\uEDA2");

            // Disk C: space
            double diskPct = report.DiskCUsedPct;
            string diskDetailSuffix = "";
            if (report.DiskTotalGB > 0)
            {
                diskDetailSuffix = string.Format(" ({0}/{1} GB libre)",
                    Math.Round(report.DiskFreeGB, 1),
                    Math.Round(report.DiskTotalGB, 1));
            }
            if (diskPct > 90)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "CRIT", Loc.T("DiagDiskCrit", "Disco C: casi lleno"),
                    string.Format(Loc.T("DiagDiskCritDetail", "{0}% ocupado — rendimiento muy degradado"), diskPct) + diskDetailSuffix,
                    Loc.T("DiagDiskCritAction", "Liberar espacio urgente"), 20);
            }
            else if (diskPct > 75)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "WARN", Loc.T("DiagDiskWarn", "Disco C: con poco espacio libre"),
                    string.Format(Loc.T("DiagDiskPctUsed", "{0}% ocupado"), diskPct) + diskDetailSuffix,
                    Loc.T("DiagDiskWarnAction", "Limpiar archivos"), 10);
            }
            else
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "OK", Loc.T("DiagDiskOk", "Espacio en disco C: saludable"),
                    string.Format(Loc.T("DiagDiskPctUsed", "{0}% ocupado"), diskPct) + diskDetailSuffix,
                    "", 0);
            }

            // WU Cache
            double wuSize = report.WUCacheMB;
            if (wuSize > 2000)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "WARN", Loc.T("DiagWUCacheLarge", "Caché de Windows Update grande"),
                    string.Format(Loc.T("DiagWUCacheDetail", "{0} MB en SoftwareDistribution"), Math.Round(wuSize, 0)),
                    Loc.T("DiagWUCacheAction", "Limpiar WU Cache"), 8);
            }
            else if (wuSize > 0)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "INFO", Loc.T("DiagWUCachePresent", "Caché Windows Update presente"),
                    string.Format("{0} MB", Math.Round(wuSize, 1)),
                    "", 0);
            }
            else
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "OK", Loc.T("DiagWUCacheClean", "Caché de Windows Update limpia"),
                    Loc.T("DiagNoUpdateResidues", "Sin residuos de actualización"), "", 0);
            }

            // SMART status
            string smartDetail = report.SmartDetailC ?? "";
            if (report.SmartOkC)
            {
                if (!string.IsNullOrEmpty(smartDetail))
                {
                    AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                        "OK", Loc.T("DiagSmartHealthy", "Estado SMART saludable"),
                        smartDetail, "", 0);
                }
                else
                {
                    AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                        "INFO", Loc.T("DiagSmartNA", "SMART no disponible"),
                        Loc.T("DiagSmartNADetail", "No se pudo consultar el estado SMART"), "", 0);
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(smartDetail))
                {
                    AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                        "CRIT", Loc.T("DiagSmartFail", "Disco con problemas SMART"),
                        smartDetail,
                        Loc.T("DiagSmartAction", "Respaldar datos inmediatamente"), 15);
                }
                else
                {
                    AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                        "INFO", Loc.T("DiagSmartNA", "SMART no disponible"),
                        Loc.T("DiagSmartNADetail", "No se pudo consultar el estado SMART"), "", 0);
                }
            }

            // ══════════════════════════════════════════════════════════════
            // 4. SEGURIDAD
            // ══════════════════════════════════════════════════════════════
            AddSection(items, export, Loc.T("DiagSectSeguridad", "SEGURIDAD"), "\uE72E");

            // Antivirus
            if (report.AntivirusEnabled)
            {
                string avName = !string.IsNullOrEmpty(report.AntivirusName) ? report.AntivirusName : "Antivirus";
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "OK", Loc.T("DiagAvOk", "Antivirus activo"),
                    avName, "", 0);
            }
            else
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "CRIT", Loc.T("DiagAvCrit", "Sin antivirus activo"),
                    Loc.T("DiagAvCritDetail", "No se detectó protección antivirus habilitada"),
                    Loc.T("DiagAvAction", "Activar antivirus"), 15);
            }

            // Firewall
            if (report.FirewallEnabled)
            {
                string fwName = string.IsNullOrEmpty(report.FirewallName) ? "Windows Firewall" : report.FirewallName;
                string detail = string.Format(Loc.T("DiagFwOkDetail", "Firewall habilitado ({0})"), fwName);
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "OK", Loc.T("DiagFwOk", "Firewall activo"),
                    detail, "", 0);
            }
            else
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "WARN", Loc.T("DiagFwWarn", "Firewall desactivado"),
                    Loc.T("DiagFwWarnDetail", "Ningún perfil de firewall activo"),
                    Loc.T("DiagFwAction", "Activar Firewall de Windows"), 8);
            }

            // UAC
            if (report.UacLevel >= 2)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "OK", Loc.T("DiagUacOk", "UAC configurado correctamente"),
                    string.Format(Loc.T("DiagUacLevel", "Nivel {0}"), report.UacLevel), "", 0);
            }
            else if (report.UacLevel == 1)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "WARN", Loc.T("DiagUacWarn", "UAC en nivel bajo"),
                    Loc.T("DiagUacWarnDetail", "Protección UAC reducida"),
                    Loc.T("DiagUacAction", "Subir nivel de UAC"), 5);
            }
            else
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "CRIT", Loc.T("DiagUacCrit", "UAC desactivado"),
                    Loc.T("DiagUacCritDetail", "El sistema está desprotegido sin UAC"),
                    Loc.T("DiagUacAction", "Subir nivel de UAC"), 10);
            }

            // Windows Update
            if (report.WindowsUpdateOk)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "OK", Loc.T("DiagWuOk", "Windows Update al día"),
                    !string.IsNullOrEmpty(report.WindowsUpdateDetail) ? report.WindowsUpdateDetail : Loc.T("DiagWuOkDetail", "Sistema actualizado"),
                    "", 0);
            }
            else
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "WARN", Loc.T("DiagWuWarn", "Actualizaciones pendientes"),
                    !string.IsNullOrEmpty(report.WindowsUpdateDetail) ? report.WindowsUpdateDetail : Loc.T("DiagWuWarnDetail", "Hay actualizaciones sin instalar"),
                    Loc.T("DiagWuAction", "Instalar actualizaciones"), 5);
            }

            // Registry orphaned keys
            double orphaned = report.OrphanedKeys;
            if (orphaned > 20)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "WARN", Loc.T("DiagOrphanKeys", "Claves huérfanas en el registro"),
                    string.Format(Loc.T("DiagOrphanDetail", "{0} claves de programas desinstalados"), orphaned),
                    Loc.T("DiagOrphanAction", "Limpiar registro"), 5);
            }
            else if (orphaned > 0)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "INFO", Loc.T("DiagSomeOrphanKeys", "Algunas claves huérfanas"),
                    string.Format(Loc.T("DiagMinimalImpact", "{0} claves — impacto mínimo"), orphaned),
                    "", 0);
            }
            else
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "OK", Loc.T("DiagRegistryClean", "Registro sin claves huérfanas"),
                    Loc.T("DiagRegistryCleanDetail", "No se detectaron entradas obsoletas"), "", 0);
            }

            // ══════════════════════════════════════════════════════════════
            // 5. INICIO
            // ══════════════════════════════════════════════════════════════
            AddSection(items, export, Loc.T("DiagSectStartup", "INICIO"), "\uE768");

            // Startup apps
            int startupApps = report.StartupCount;
            if (startupApps > 15)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "WARN", Loc.T("DiagStartupWarn", "Demasiadas apps de inicio"),
                    string.Format(Loc.T("DiagStartupWarnDetail", "{0} programas al arrancar — ralentiza el inicio"), startupApps),
                    Loc.T("DiagStartupWarnAction", "Revisar Startup Manager"), 8);
            }
            else if (startupApps > 0)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "OK", Loc.T("DiagStartupOk", "Apps de inicio controladas"),
                    string.Format(Loc.T("DiagStartupOkDetail", "{0} programas al arrancar"), startupApps),
                    "", 0);
            }

            // Boot time
            if (report.BootTimeSeconds > 120)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "WARN", Loc.T("DiagBootSlow", "Arranque lento"),
                    string.Format(Loc.T("DiagBootSlowDetail", "{0} segundos de arranque"), Math.Round(report.BootTimeSeconds, 1)),
                    Loc.T("DiagBootAction", "Revisar programas de inicio"), 5);
            }
            else if (report.BootTimeSeconds > 0)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "OK", Loc.T("DiagBootOk", "Tiempo de arranque normal"),
                    string.Format(Loc.T("DiagBootOkDetail", "{0} segundos"), Math.Round(report.BootTimeSeconds, 1)),
                    "", 0);
            }

            // ══════════════════════════════════════════════════════════════
            // 6. SERVICIOS
            // ══════════════════════════════════════════════════════════════
            AddSection(items, export, Loc.T("DiagSectServices", "SERVICIOS"), "\uE713");

            // Bloatware services
            int bloatSvc = report.ServicesBloatCount;
            int totalSvc = report.ServicesTotalCount;
            if (bloatSvc > 10)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "WARN", Loc.T("DiagServicesBloat", "Servicios bloatware detectados"),
                    string.Format(Loc.T("DiagServicesBloatDetail", "{0} servicios innecesarios de {1} totales"), bloatSvc, totalSvc),
                    Loc.T("DiagServicesBloatAction", "Desactivar servicios bloatware"), 5);
            }
            else if (totalSvc > 0)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "OK", Loc.T("DiagServicesOk", "Servicios en buen estado"),
                    string.Format(Loc.T("DiagServicesOkDetail", "{0} servicios en ejecución ({1} bloatware)"), totalSvc, bloatSvc),
                    "", 0);
            }

            // Critical services
            if (report.CriticalSvcTotal > 0)
            {
                if (report.CriticalSvcOk < report.CriticalSvcTotal)
                {
                    string svcDetail = string.Format(Loc.T("DiagCritSvcDetail", "{0} de {1} servicios críticos activos"), report.CriticalSvcOk, report.CriticalSvcTotal);
                    if (!string.IsNullOrEmpty(report.StoppedCriticalSvcNames))
                    {
                        svcDetail += " — " + string.Format(Loc.T("DiagCritSvcStopped", "Detenidos: {0}"), report.StoppedCriticalSvcNames);
                    }
                    AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                        "WARN", Loc.T("DiagCritSvcWarn", "Servicios críticos detenidos"),
                        svcDetail,
                        Loc.T("DiagCritSvcAction", "Iniciar servicios detenidos"), 5);
                }
                else
                {
                    AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                        "OK", Loc.T("DiagCritSvcOk", "Servicios críticos funcionando"),
                        string.Format(Loc.T("DiagCritSvcOkDetail", "{0}/{1} servicios críticos activos"), report.CriticalSvcOk, report.CriticalSvcTotal),
                        "", 0);
                }
            }

            // ══════════════════════════════════════════════════════════════
            // 7. RED
            // ══════════════════════════════════════════════════════════════
            AddSection(items, export, Loc.T("DiagSectNetwork", "RED"), "\uE774");

            // Network connection
            if (report.NetworkConnected)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "OK", Loc.T("DiagNetOk", "Conexión a Internet activa"),
                    !string.IsNullOrEmpty(report.NetworkDetail) ? report.NetworkDetail : Loc.T("DiagNetOkDetail", "Conectado a Internet"),
                    "", 0);
            }
            else
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "CRIT", Loc.T("DiagNetCrit", "Sin conexión a Internet"),
                    !string.IsNullOrEmpty(report.NetworkDetail) ? report.NetworkDetail : Loc.T("DiagNetCritDetail", "No se detectó conexión a Internet"),
                    Loc.T("DiagNetAction", "Verificar conexión de red"), 10);
            }

            // DNS resolution
            if (report.DnsResolutionOk)
            {
                string dnsDetail = report.DnsLatencyMs > 0
                    ? string.Format(Loc.T("DiagDnsOkDetail", "Resolución DNS OK ({0} ms)"), Math.Round(report.DnsLatencyMs, 0))
                    : Loc.T("DiagDnsOkSimple", "Resolución DNS funcionando");
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "OK", Loc.T("DiagDnsOk", "Resolución DNS operativa"),
                    dnsDetail, "", 0);
            }
            else
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "WARN", Loc.T("DiagDnsFail", "Resolución DNS fallida"),
                    Loc.T("DiagDnsFailDetail", "No se pudo resolver nombres de dominio"),
                    Loc.T("DiagDnsFailAction", "Verificar configuración DNS"), 5);
            }

            // Browser cache
            double browserMB = report.BrowserCacheMB;
            if (browserMB > 1000)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "WARN", Loc.T("DiagBrowserCacheLarge", "Caché de navegadores muy grande"),
                    string.Format(Loc.T("DiagBrowserWarnDetail", "{0} MB — recomendable limpiar"), Math.Round(browserMB, 0)),
                    Loc.T("DiagCleanBrowsers", "Limpiar caché navegadores"), 5);
            }
            else if (browserMB > 200)
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "INFO", Loc.T("DiagBrowserCachePresent", "Caché de navegadores presente"),
                    string.Format("{0} MB", Math.Round(browserMB, 1)),
                    "", 0);
            }
            else
            {
                AddRow(items, ref deductions, ref critCount, ref warnCount, ref okCount, ref infoCount, ref skipCount, export,
                    "OK", Loc.T("DiagBrowserCacheClean", "Caché de navegadores limpia"),
                    string.Format("{0} MB", Math.Round(browserMB, 1)),
                    "", 0);
            }

            // ── PUNTUACIÓN ──────────────────────────────────────────────
            int finalScore = Math.Max(0, 100 - deductions);
            string scoreColor;
            string scoreLabel;
            if (finalScore >= 80)
            {
                scoreColor = "#4AE896";
                scoreLabel = Loc.T("DiagScoreGood", "Sistema en buen estado");
            }
            else if (finalScore >= 55)
            {
                scoreColor = "#FFB547";
                scoreLabel = Loc.T("DiagScoreRecommended", "Mantenimiento recomendado");
            }
            else
            {
                scoreColor = "#FF6B84";
                scoreLabel = Loc.T("DiagUrgent", "Atención urgente");
            }

            export.Add("");
            export.Add(Loc.T("DiagExportSummary", "=== RESUMEN ==="));
            export.Add(string.Format(Loc.T("DiagScore", "Puntuación: {0} / 100"), finalScore));
            export.Add(string.Format(Loc.T("DiagCritWarn", "Críticos: {0}  |  Avisos: {1}"), critCount, warnCount));
            export.Add(string.Format("OK: {0}  |  Info: {1}  |  Skip: {2}", okCount, infoCount, skipCount));
            export.Add(string.Format(Loc.T("DiagExportState", "Estado: {0}"), scoreLabel));

            return new DiagResult
            {
                Items      = items,
                Score      = finalScore,
                CritCount  = critCount,
                WarnCount  = warnCount,
                OkCount    = okCount,
                InfoCount  = infoCount,
                SkipCount  = skipCount,
                ScoreLabel = scoreLabel,
                ScoreColor = scoreColor,
                ExportLines = export
            };
        }

        // ═══════════════════════════════════════════════════════════════
        // GenerateHtmlReport  —  34 placeholders
        // ═══════════════════════════════════════════════════════════════

        /// <summary>
        /// Genera el informe HTML completo reemplazando 34 placeholders
        /// en la plantilla con datos reales del análisis.
        /// </summary>
        public static string GenerateHtmlReport(DiagInput input, DiagResult result, HtmlReportParams p)
        {
            if (input == null) input = new DiagInput();
            if (result == null) throw new ArgumentNullException("result");
            if (p == null) p = new HtmlReportParams();

            string html = p.TemplateHtml ?? "";
            System.Globalization.CultureInfo ci = System.Globalization.CultureInfo.InvariantCulture;

            // ── 1. Fechas ──────────────────────────────────────────────
            string dateShort = DateTime.Now.ToString("yyyy-MM-dd");
            string dateLong  = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");

            // ── 2. Logo ────────────────────────────────────────────────
            string logoTag;
            if (!string.IsNullOrEmpty(p.LogoBase64))
            {
                logoTag = string.Format(
                    "<img class=\"logo-img\" src=\"data:image/png;base64,{0}\" alt=\"SysOpt\"/>",
                    p.LogoBase64);
            }
            else
            {
                logoTag = "<div class=\"logo-fallback\">\u2699</div>";
            }

            // ── 3. Computer name ───────────────────────────────────────
            string computerName = !string.IsNullOrEmpty(input.ComputerName)
                ? input.ComputerName
                : Environment.MachineName;

            // ── 4. Score gauge arc (377 = arco completo 75%) ───────────
            double scoreArc = result.Score * 3.77;

            // ── 5. System info grid ────────────────────────────────────
            string sysInfoHtml = BuildSystemInfoItems(input);

            // ── 6. Stats colors ────────────────────────────────────────
            string ramColor  = input.RamUsedPct > 85 ? "c-red"
                             : input.RamUsedPct > 70 ? "c-amber" : "c-green";
            string diskColor = input.DiskCUsedPct > 90 ? "c-red"
                             : input.DiskCUsedPct > 75 ? "c-amber" : "c-green";
            string svcColor  = input.ServicesBloatCount > 10 ? "c-red"
                             : input.ServicesBloatCount > 5  ? "c-amber" : "c-green";

            // ── 7. Temp size formatting ────────────────────────────────
            double tempTotal = input.TempFilesMB + input.UserTempMB;
            string tempSize  = tempTotal > 1024
                ? string.Format(ci, "{0:F1} GB", tempTotal / 1024.0)
                : string.Format(ci, "{0:F0} MB", tempTotal);

            // ── 8. Group sections for pie chart ────────────────────────
            List<SectionGroup> sections = GroupSections(result.Items);

            // ── 9. Pie chart SVG + legend ──────────────────────────────
            string legendHtml;
            string pieSlicesHtml = BuildPieSlices(sections, out legendHtml);

            // ── 10. Total checks ───────────────────────────────────────
            int totalChecks = result.OkCount + result.WarnCount
                            + result.CritCount + result.InfoCount + result.SkipCount;

            // ── 11. Check rows table ───────────────────────────────────
            string checkRowsHtml = BuildCheckRows(result.Items);

            // ── 12. Recommendations ────────────────────────────────────
            string recsHtml = BuildRecommendations(result.Items);
            bool hasRecs = false;
            foreach (DiagItem item in result.Items)
            {
                if (!item.IsSection && !string.IsNullOrEmpty(item.Action))
                { hasRecs = true; break; }
            }
            string recCardClass = hasRecs ? "card-warn" : "card-ok";

            // ── 13. Extra stats (uptime) ───────────────────────────────
            string extraStats = "";
            if (input.UptimeHours > 0)
            {
                string uptimeStr;
                if (input.UptimeHours >= 24)
                {
                    uptimeStr = string.Format(ci, "{0:F0}d {1:F0}h",
                        Math.Floor(input.UptimeHours / 24),
                        input.UptimeHours % 24);
                }
                else
                {
                    uptimeStr = string.Format(ci, "{0:F1}h", input.UptimeHours);
                }
                string uptimeColor = input.UptimeHours > 168 ? "c-amber" : "c-green";
                extraStats = string.Format(
                    "<div class=\"stat-box\">"
                    + "<div class=\"stat-lbl\">Uptime</div>"
                    + "<div class=\"stat-val {0}\">{1}</div>"
                    + "<div class=\"stat-sub\">{2}</div>"
                    + "</div>",
                    uptimeColor, uptimeStr,
                    Loc.T("DiagHtmlUptime", "encendido"));
            }

            // ── 14. Replace all 34 placeholders ───────────────────────
            html = html.Replace("{{REPORT_DATE}}", dateShort);
            html = html.Replace("{{REPORT_DATE_LONG}}", Enc(dateLong));
            html = html.Replace("{{LOGO_TAG}}", logoTag);
            html = html.Replace("{{COMPUTER_NAME}}", Enc(computerName));
            html = html.Replace("{{ANALYSIS_TIME}}", Enc(p.AnalysisTime ?? "N/A"));
            html = html.Replace("{{APP_VERSION}}", Enc(p.AppVersion ?? "v3.3.0"));

            html = html.Replace("{{SCORE}}", result.Score.ToString());
            html = html.Replace("{{SCORE_COLOR}}", result.ScoreColor);
            html = html.Replace("{{SCORE_ARC}}", scoreArc.ToString("F1", ci));
            html = html.Replace("{{SCORE_LABEL}}", Enc(result.ScoreLabel));

            html = html.Replace("{{CHECKS_OK}}", result.OkCount.ToString());
            html = html.Replace("{{CHECKS_WARN}}", result.WarnCount.ToString());
            html = html.Replace("{{CHECKS_FAIL}}", result.CritCount.ToString());
            html = html.Replace("{{CHECKS_SKIP}}", result.SkipCount.ToString());

            html = html.Replace("{{SYSTEM_INFO_ITEMS}}", sysInfoHtml);

            html = html.Replace("{{RAM_COLOR}}", ramColor);
            html = html.Replace("{{RAM_FREE}}", FormatGB(input.RamFreeGB, ci));
            html = html.Replace("{{RAM_TOTAL}}", FormatGB(input.RamTotalGB, ci));
            html = html.Replace("{{DISK_COLOR}}", diskColor);
            html = html.Replace("{{DISK_FREE}}", FormatGB(input.DiskFreeGB, ci));
            html = html.Replace("{{DISK_TOTAL}}", FormatGB(input.DiskTotalGB, ci));

            html = html.Replace("{{TEMP_SIZE}}", tempSize);
            html = html.Replace("{{TEMP_FILES}}", input.TempFileCount.ToString());
            html = html.Replace("{{STARTUP_COUNT}}", input.StartupCount.ToString());

            html = html.Replace("{{SERVICES_COLOR}}", svcColor);
            html = html.Replace("{{SERVICES_BLOAT}}", input.ServicesBloatCount.ToString());
            html = html.Replace("{{SERVICES_TOTAL}}", input.ServicesTotalCount.ToString());
            html = html.Replace("{{EXTRA_STATS}}", extraStats);

            html = html.Replace("{{PIE_SLICES}}", pieSlicesHtml);
            html = html.Replace("{{TOTAL_CHECKS}}", totalChecks.ToString());
            html = html.Replace("{{PIE_LEGEND}}", legendHtml);

            html = html.Replace("{{CHECK_ROWS}}", checkRowsHtml);
            html = html.Replace("{{RECOMMENDATION_ITEMS}}", recsHtml);
            html = html.Replace("{{REC_CARD_CLASS}}", recCardClass);

            return html;
        }

        // ═══════════════════════════════════════════════════════════════
        // HTML builder helpers
        // ═══════════════════════════════════════════════════════════════

        /// <summary>Builds the system info grid items HTML.</summary>
        private static string BuildSystemInfoItems(DiagInput input)
        {
            StringBuilder sb = new StringBuilder();

            string compName = !string.IsNullOrEmpty(input.ComputerName)
                ? input.ComputerName : Environment.MachineName;
            AppendInfoItem(sb, Loc.T("DiagInfoComputer", "Equipo"), compName);

            if (!string.IsNullOrEmpty(input.OsVersion))
                AppendInfoItem(sb, Loc.T("DiagInfoOS", "Sistema Operativo"), input.OsVersion);

            if (!string.IsNullOrEmpty(input.CpuModel))
                AppendInfoItem(sb, Loc.T("DiagInfoCPU", "Procesador"), input.CpuModel);

            if (input.RamTotalGB > 0)
            {
                AppendInfoItem(sb, Loc.T("DiagInfoRAM", "Memoria RAM"),
                    string.Format("{0:F1} GB ({1:F0}% en uso)", input.RamTotalGB, input.RamUsedPct));
            }

            if (input.DiskTotalGB > 0)
            {
                AppendInfoItem(sb, Loc.T("DiagInfoDisk", "Disco C:"),
                    string.Format("{0:F1} GB total \u2014 {1:F1} GB libre",
                        input.DiskTotalGB, input.DiskFreeGB));
            }

            if (input.StartupCount > 0)
            {
                AppendInfoItem(sb, Loc.T("DiagInfoStartup", "Apps de inicio"),
                    input.StartupCount.ToString());
            }

            if (input.ServicesTotalCount > 0)
            {
                AppendInfoItem(sb, Loc.T("DiagInfoServices", "Servicios activos"),
                    string.Format("{0} ({1} bloatware)",
                        input.ServicesTotalCount, input.ServicesBloatCount));
            }

            if (input.UptimeHours > 0)
            {
                string uptimeStr;
                if (input.UptimeHours >= 24)
                    uptimeStr = string.Format("{0:F0} {1}, {2:F0} {3}",
                        Math.Floor(input.UptimeHours / 24),
                        Loc.T("DiagDays", "días"),
                        input.UptimeHours % 24,
                        Loc.T("DiagHours", "horas"));
                else
                    uptimeStr = string.Format("{0:F1} {1}",
                        input.UptimeHours, Loc.T("DiagHours", "horas"));
                AppendInfoItem(sb, Loc.T("DiagInfoUptime", "Uptime"), uptimeStr);
            }

            return sb.ToString();
        }

        private static void AppendInfoItem(StringBuilder sb, string key, string val)
        {
            sb.AppendFormat(
                "      <div class=\"info-item\">"
                + "<span class=\"info-key\">{0}</span>"
                + "<span class=\"info-val\">{1}</span>"
                + "</div>\n",
                Enc(key), Enc(val));
        }

        /// <summary>Builds all check rows (sections + data rows) for the table.</summary>
        private static string BuildCheckRows(List<DiagItem> items)
        {
            StringBuilder sb = new StringBuilder();

            foreach (DiagItem item in items)
            {
                if (item.IsSection)
                {
                    sb.AppendFormat(
                        "        <tr><td colspan=\"5\" style=\"padding:14px 14px 8px;"
                        + " font-weight:700; font-size:13px; color:var(--blue);"
                        + " border-bottom:1px solid var(--border)\">"
                        + "{0} {1}</td></tr>\n",
                        item.SectionIcon ?? "", Enc(item.SectionTitle));
                    continue;
                }

                string badgeClass, badgeText, icon;
                GetStatusBadge(item.Status, out badgeClass, out badgeText, out icon);

                string impact, impactColor;
                if (item.Deduction > 0)
                {
                    impact = string.Format("-{0}", item.Deduction);
                    impactColor = item.Deduction >= 15 ? "c-red"
                                : item.Deduction >= 5  ? "c-amber" : "c-muted";
                }
                else
                {
                    impact = "\u2014"; // em dash
                    impactColor = "c-muted";
                }

                sb.AppendFormat(
                    "        <tr>"
                    + "<td class=\"td-icon\">{0}</td>"
                    + "<td class=\"td-name\">{1}</td>"
                    + "<td class=\"td-desc\">{2}</td>"
                    + "<td class=\"td-status\"><span class=\"badge {3}\">{4}</span></td>"
                    + "<td class=\"td-impact {5}\">{6}</td>"
                    + "</tr>\n",
                    icon, Enc(item.Label), Enc(item.Detail),
                    badgeClass, badgeText, impactColor, impact);
            }

            return sb.ToString();
        }

        /// <summary>Builds SVG donut pie chart slices and legend HTML.</summary>
        private static string BuildPieSlices(List<SectionGroup> sections, out string legendHtml)
        {
            StringBuilder sliceSb  = new StringBuilder();
            StringBuilder legendSb = new StringBuilder();
            System.Globalization.CultureInfo ci = System.Globalization.CultureInfo.InvariantCulture;

            int totalChecks = 0;
            foreach (SectionGroup sec in sections)
                totalChecks += sec.Items.Count;

            if (totalChecks == 0)
            {
                legendHtml = "";
                return "";
            }

            double cx = 160.0, cy = 160.0;
            double outerR = 100.0, innerR = 62.0;
            double currentAngle = 0.0; // degrees from 12 o'clock, clockwise

            for (int i = 0; i < sections.Count; i++)
            {
                SectionGroup sec = sections[i];
                if (sec.Items.Count == 0) continue;

                double fraction = (double)sec.Items.Count / totalChecks;
                double angleDeg = fraction * 360.0;
                string color = PieColors[i % PieColors.Length];

                string path;
                if (angleDeg >= 359.9)
                {
                    // Full circle — draw two semi-arcs to avoid SVG zero-length arc issue
                    path = BuildFullCirclePath(cx, cy, outerR, innerR, ci);
                }
                else
                {
                    double startRad = currentAngle * Math.PI / 180.0;
                    double endRad   = (currentAngle + angleDeg) * Math.PI / 180.0;

                    double x1o = cx + outerR * Math.Sin(startRad);
                    double y1o = cy - outerR * Math.Cos(startRad);
                    double x2o = cx + outerR * Math.Sin(endRad);
                    double y2o = cy - outerR * Math.Cos(endRad);

                    double x2i = cx + innerR * Math.Sin(endRad);
                    double y2i = cy - innerR * Math.Cos(endRad);
                    double x1i = cx + innerR * Math.Sin(startRad);
                    double y1i = cy - innerR * Math.Cos(startRad);

                    int largeArc = angleDeg > 180.0 ? 1 : 0;

                    path = string.Format(ci,
                        "M {0:F2},{1:F2} A {2:F0},{2:F0} 0 {3},1 {4:F2},{5:F2}"
                        + " L {6:F2},{7:F2} A {8:F0},{8:F0} 0 {3},0 {9:F2},{10:F2} Z",
                        x1o, y1o, outerR, largeArc, x2o, y2o,
                        x2i, y2i, innerR, x1i, y1i);
                }

                sliceSb.AppendFormat(
                    "          <path class=\"slice\" d=\"{0}\" fill=\"{1}\""
                    + " data-name=\"{2}\" data-val=\"{3} checks\"/>\n",
                    path, color, Enc(sec.Title), sec.Items.Count);

                legendSb.AppendFormat(
                    "        <div class=\"legend-item\">"
                    + "<span class=\"legend-dot\" style=\"background:{0}\"></span>"
                    + "<span class=\"legend-name\">{1}</span>"
                    + "<span class=\"legend-val\">{2}</span>"
                    + "</div>\n",
                    color, Enc(sec.Title), sec.Items.Count);

                currentAngle += angleDeg;
            }

            legendHtml = legendSb.ToString();
            return sliceSb.ToString();
        }

        /// <summary>Builds recommendation cards from items that have an Action.</summary>
        private static string BuildRecommendations(List<DiagItem> items)
        {
            StringBuilder sb = new StringBuilder();
            bool any = false;

            foreach (DiagItem item in items)
            {
                if (item.IsSection || string.IsNullOrEmpty(item.Action)) continue;

                string icon = item.Status == "CRIT" ? "\U0001F534" : "\U0001F7E1"; // red/yellow circle
                string badgeCls = item.Status == "CRIT" ? "badge-fail" : "badge-warn";
                string prioText = item.Status == "CRIT"
                    ? Loc.T("DiagRecPrioHigh", "Prioridad alta")
                    : Loc.T("DiagRecPrioMedium", "Prioridad media");

                sb.AppendFormat(
                    "      <div class=\"rec-item\">"
                    + "<div class=\"rec-icon\">{0}</div>"
                    + "<div class=\"rec-text\"><h4>{1}</h4><p>{2}</p></div>"
                    + "<span class=\"badge {3}\">{4}</span>"
                    + "</div>\n",
                    icon, Enc(item.Action), Enc(item.Detail),
                    badgeCls, Enc(prioText));

                any = true;
            }

            if (!any)
            {
                sb.AppendFormat(
                    "      <div class=\"rec-item\">"
                    + "<div class=\"rec-icon\">\u2705</div>"
                    + "<div class=\"rec-text\"><h4>{0}</h4><p>{1}</p></div>"
                    + "<span class=\"badge badge-ok\">OK</span>"
                    + "</div>\n",
                    Enc(Loc.T("DiagRecAllGood", "Sistema en buen estado")),
                    Enc(Loc.T("DiagRecNoAction", "No se requieren acciones inmediatas")));
            }

            return sb.ToString();
        }

        // ═══════════════════════════════════════════════════════════════
        // Micro-helpers
        // ═══════════════════════════════════════════════════════════════

        /// <summary>Groups DiagItems into sections for pie chart.</summary>
        private static List<SectionGroup> GroupSections(List<DiagItem> items)
        {
            List<SectionGroup> groups = new List<SectionGroup>();
            SectionGroup current = null;
            foreach (DiagItem item in items)
            {
                if (item.IsSection)
                {
                    current = new SectionGroup();
                    current.Title = item.SectionTitle;
                    current.Icon  = item.SectionIcon;
                    current.Items = new List<DiagItem>();
                    groups.Add(current);
                }
                else if (current != null)
                {
                    current.Items.Add(item);
                }
            }
            return groups;
        }

        /// <summary>SVG full-circle donut path (two half-arcs).</summary>
        private static string BuildFullCirclePath(double cx, double cy,
            double outerR, double innerR,
            System.Globalization.CultureInfo ci)
        {
            // Top and bottom points
            double topOx = cx;          double topOy = cy - outerR;
            double botOx = cx;          double botOy = cy + outerR;
            double topIx = cx;          double topIy = cy - innerR;
            double botIx = cx;          double botIy = cy + innerR;

            return string.Format(ci,
                "M {0:F2},{1:F2} A {2:F0},{2:F0} 0 0,1 {3:F2},{4:F2}"
                + " A {2:F0},{2:F0} 0 0,1 {0:F2},{1:F2}"
                + " L {5:F2},{6:F2} A {7:F0},{7:F0} 0 0,0 {8:F2},{9:F2}"
                + " A {7:F0},{7:F0} 0 0,0 {5:F2},{6:F2} Z",
                topOx, topOy, outerR, botOx, botOy,
                topIx, topIy, innerR, botIx, botIy);
        }

        /// <summary>Returns badge CSS class, text, and status icon.</summary>
        private static void GetStatusBadge(string status,
            out string badgeClass, out string badgeText, out string icon)
        {
            if (status == "CRIT")      { badgeClass = "badge-fail"; badgeText = "CRIT"; icon = "\U0001F534"; } // red circle
            else if (status == "WARN") { badgeClass = "badge-warn"; badgeText = "WARN"; icon = "\U0001F7E1"; } // yellow circle
            else if (status == "INFO") { badgeClass = "badge-info"; badgeText = "INFO"; icon = "\U0001F535"; } // blue circle
            else if (status == "SKIP") { badgeClass = "badge-skip"; badgeText = "SKIP"; icon = "\u26AA";     } // white circle
            else                       { badgeClass = "badge-ok";   badgeText = "OK";   icon = "\U0001F7E2"; } // green circle
        }

        /// <summary>Formats GB value for display.</summary>
        private static string FormatGB(double gb, System.Globalization.CultureInfo ci)
        {
            if (gb >= 1024) return string.Format(ci, "{0:F1} TB", gb / 1024.0);
            if (gb >= 100)  return string.Format(ci, "{0:F0} GB", gb);
            if (gb >= 10)   return string.Format(ci, "{0:F1} GB", gb);
            return string.Format(ci, "{0:F2} GB", gb);
        }

        /// <summary>Minimal HTML encode (ampersand, angle brackets, quotes).</summary>
        private static string Enc(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("&", "&amp;")
                    .Replace("<", "&lt;")
                    .Replace(">", "&gt;")
                    .Replace("\"", "&quot;");
        }

        // ═══════════════════════════════════════════════════════════════
        // Analyze() helpers (unchanged from Task 1)
        // ═══════════════════════════════════════════════════════════════

        private static void AddSection(List<DiagItem> items, List<string> export,
            string title, string icon)
        {
            items.Add(new DiagItem
            {
                IsSection    = true,
                SectionTitle = title,
                SectionIcon  = icon
            });
            if (export.Count > 3) export.Add(""); // separador entre secciones
            export.Add(string.Format("=== {0} ===", title));
        }

        private static void AddRow(List<DiagItem> items,
            ref int deductions, ref int critCount, ref int warnCount,
            ref int okCount, ref int infoCount, ref int skipCount,
            List<string> export,
            string status, string label, string detail, string action,
            int deduction)
        {
            items.Add(new DiagItem
            {
                IsSection  = false,
                Status     = status,
                Label      = label,
                Detail     = detail,
                Action     = action,
                Deduction  = deduction
            });

            deductions += deduction;
            if (status == "CRIT") critCount++;
            else if (status == "WARN") warnCount++;
            else if (status == "OK") okCount++;
            else if (status == "INFO") infoCount++;
            else if (status == "SKIP") skipCount++;

            // Línea de exportación
            string prefix;
            if (status == "CRIT") prefix = Loc.T("DiagCritPrefix", "[CRÍTICO]");
            else if (status == "WARN") prefix = Loc.T("DiagPrefixWarn", "[AVISO]");
            else if (status == "INFO") prefix = Loc.T("DiagPrefixInfo", "[INFO]");
            else if (status == "SKIP") prefix = "[SKIP]";
            else prefix = Loc.T("DiagPrefixOk", "[OK]");

            string exportLine = string.Format("{0} {1}: {2}", prefix, label, detail);
            if (!string.IsNullOrEmpty(action))
            {
                exportLine = string.Format("{0} — {1}", exportLine, action);
            }
            export.Add(exportLine);
        }
    }
}
