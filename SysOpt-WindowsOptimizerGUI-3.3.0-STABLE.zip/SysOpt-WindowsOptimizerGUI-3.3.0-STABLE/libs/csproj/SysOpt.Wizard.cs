// SysOpt - Software de optimización del sistema
// Copyright (C) 2026 Danew Malavita
//
// Este programa es software libre bajo los términos de la GPL v3+.
// Consulta el archivo LICENSE o visita <https://www.gnu.org/licenses/>.

// SysOpt.Wizard.cs — Motor del asistente guiado (Wizard)
// v3.3.0-DEV — Clasifica diagnósticos, genera tareas de reparación
// Compatible con C# 5 / .NET Framework 4.x
using System;
using System.Collections.Generic;

namespace SysOpt.Wizard
{
    // Loc is provided by SysOpt.Core.dll (global namespace, no using needed)

    // ═══════════════════════════════════════════════════════════════════════
    // DTOs
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>Represents a diagnostic entry classified for wizard display.</summary>
    public class WizardItem
    {
        public string Section   { get; set; }  // "Sistema", "Limpieza", "Disco", "Seguridad", "Inicio", "Servicios", "Red"
        public string Status    { get; set; }  // "OK", "WARN", "CRIT", "INFO", "SKIP"
        public string Label     { get; set; }
        public string Detail    { get; set; }
        public string Action    { get; set; }
        public int    Deduction { get; set; }
    }

    /// <summary>Represents a repair task in the wizard checklist.</summary>
    public class WizardRepairTask
    {
        public string   Key             { get; set; }  // "TempFiles", "RecycleBin", etc.
        public string   Label           { get; set; }  // Localized label
        public bool     Recommended     { get; set; }  // true if related problems were found
        public string[] RelatedSections { get; set; }  // sections that trigger recommendation
    }

    /// <summary>Complete wizard analysis result.</summary>
    public class WizardResult
    {
        public List<WizardItem>       AllItems     { get; set; }
        public List<WizardItem>       ProblemItems { get; set; }  // Only WARN and CRIT
        public List<WizardRepairTask> RepairTasks  { get; set; }
        public int    Score      { get; set; }
        public string ScoreLabel { get; set; }
        public string ScoreColor { get; set; }
        public int    CritCount  { get; set; }
        public int    WarnCount  { get; set; }
        public int    OkCount    { get; set; }
        public bool   HasProblems{ get; set; }  // convenience: ProblemItems.Count > 0
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Engine
    // ═══════════════════════════════════════════════════════════════════════

    public static class WizardEngine
    {
        // Standard section names mapped by index order
        private static readonly string[] SectionNames = new string[]
        {
            "Sistema", "Limpieza", "Disco", "Seguridad", "Inicio", "Servicios", "Red"
        };

        /// <summary>
        /// Takes a DiagResult from DiagnosticsEngine.Analyze() and classifies
        /// all items into WizardItems with section names.
        /// Also identifies problems and builds the repair task list.
        /// </summary>
        public static WizardResult ProcessDiagnostics(SysOpt.Diagnostics.DiagResult diagResult)
        {
            // 1. Classify items by walking diagResult.Items
            List<WizardItem> allItems = new List<WizardItem>();
            List<WizardItem> problemItems = new List<WizardItem>();
            int sectionIdx = -1;
            string currentSection = "";

            foreach (SysOpt.Diagnostics.DiagItem item in diagResult.Items)
            {
                if (item.IsSection)
                {
                    sectionIdx++;
                    if (sectionIdx < SectionNames.Length)
                    {
                        currentSection = SectionNames[sectionIdx];
                    }
                    else
                    {
                        currentSection = "Otros";
                    }
                }
                else
                {
                    WizardItem wi = new WizardItem();
                    wi.Section   = currentSection;
                    wi.Status    = item.Status;
                    wi.Label     = item.Label;
                    wi.Detail    = item.Detail;
                    wi.Action    = item.Action;
                    wi.Deduction = item.Deduction;
                    allItems.Add(wi);

                    // 2. Filter problemItems
                    if (item.Status == "WARN" || item.Status == "CRIT")
                    {
                        problemItems.Add(wi);
                    }
                }
            }

            // 3. Build repair tasks
            // Collect problem sections
            HashSet<string> problemSections = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (WizardItem pi in problemItems)
            {
                if (!string.IsNullOrEmpty(pi.Section))
                {
                    problemSections.Add(pi.Section);
                }
            }

            List<WizardRepairTask> repairTasks = GetDefaultRepairTasks();
            foreach (WizardRepairTask task in repairTasks)
            {
                bool recommended = false;
                if (task.RelatedSections != null)
                {
                    foreach (string rs in task.RelatedSections)
                    {
                        if (problemSections.Contains(rs))
                        {
                            recommended = true;
                            break;
                        }
                    }
                }
                task.Recommended = recommended;
            }

            // 4. Build and return WizardResult
            WizardResult result = new WizardResult();
            result.AllItems     = allItems;
            result.ProblemItems = problemItems;
            result.RepairTasks  = repairTasks;
            result.Score        = diagResult.Score;
            result.ScoreLabel   = diagResult.ScoreLabel;
            result.ScoreColor   = diagResult.ScoreColor;
            result.CritCount    = diagResult.CritCount;
            result.WarnCount    = diagResult.WarnCount;
            result.OkCount      = diagResult.OkCount;
            result.HasProblems  = problemItems.Count > 0;

            return result;
        }

        /// <summary>
        /// Returns the default repair task definitions.
        /// All labels use Loc.T() for internationalization.
        /// </summary>
        public static List<WizardRepairTask> GetDefaultRepairTasks()
        {
            List<WizardRepairTask> tasks = new List<WizardRepairTask>();

            WizardRepairTask t1 = new WizardRepairTask();
            t1.Key = "TempFiles";
            t1.Label = Loc.T("ChkTempFiles", "Archivos temporales de Windows");
            t1.RelatedSections = new string[] { "Limpieza" };
            tasks.Add(t1);

            WizardRepairTask t2 = new WizardRepairTask();
            t2.Key = "RecycleBin";
            t2.Label = Loc.T("ChkRecycleBin", "Vaciar papelera de reciclaje");
            t2.RelatedSections = new string[] { "Limpieza" };
            tasks.Add(t2);

            WizardRepairTask t3 = new WizardRepairTask();
            t3.Key = "BrowserCache";
            t3.Label = Loc.T("ChkBrowserCache", "Caché de navegadores");
            t3.RelatedSections = new string[] { "Limpieza", "Red" };
            tasks.Add(t3);

            WizardRepairTask t4 = new WizardRepairTask();
            t4.Key = "DNSCache";
            t4.Label = Loc.T("ChkDNSFlush", "Limpiar caché DNS");
            t4.RelatedSections = new string[] { "Red", "Limpieza" };
            tasks.Add(t4);

            WizardRepairTask t5 = new WizardRepairTask();
            t5.Key = "EventLogs";
            t5.Label = Loc.T("ChkEventLogs", "Limpiar logs de eventos");
            t5.RelatedSections = new string[] { "Limpieza" };
            tasks.Add(t5);

            WizardRepairTask t6 = new WizardRepairTask();
            t6.Key = "OptimizeDisks";
            t6.Label = Loc.T("ChkOptimizeDisks", "Optimizar discos");
            t6.RelatedSections = new string[] { "Disco" };
            tasks.Add(t6);

            WizardRepairTask t7 = new WizardRepairTask();
            t7.Key = "SFC";
            t7.Label = "SFC (" + Loc.T("WizSfcDesc", "Reparar archivos del sistema") + ")";
            t7.RelatedSections = new string[] { "Sistema" };
            tasks.Add(t7);

            WizardRepairTask t8 = new WizardRepairTask();
            t8.Key = "DISM";
            t8.Label = "DISM (" + Loc.T("WizDismDesc", "Reparar imagen del sistema") + ")";
            t8.RelatedSections = new string[] { "Sistema" };
            tasks.Add(t8);

            WizardRepairTask t9 = new WizardRepairTask();
            t9.Key = "CleanRegistry";
            t9.Label = Loc.T("ChkCleanRegistry", "Limpiar registro");
            t9.RelatedSections = new string[] { "Seguridad" };
            tasks.Add(t9);

            WizardRepairTask t10 = new WizardRepairTask();
            t10.Key = "ClearMemory";
            t10.Label = Loc.T("ChkClearMemory", "Liberar memoria RAM");
            t10.RelatedSections = new string[] { "Sistema" };
            tasks.Add(t10);

            return tasks;
        }

        /// <summary>
        /// Maps selected repair task keys to optimization task names
        /// as expected by Start-Optimization (checkbox names).
        /// Returns a dictionary of taskKey → checkboxName.
        /// </summary>
        public static Dictionary<string, string> GetTaskCheckboxMap()
        {
            Dictionary<string, string> map = new Dictionary<string, string>();
            map["TempFiles"]     = "chkTempFiles";
            map["RecycleBin"]    = "chkRecycleBin";
            map["BrowserCache"]  = "chkBrowserCache";
            map["DNSCache"]      = "chkDNSCache";
            map["EventLogs"]     = "chkEventLogs";
            map["OptimizeDisks"] = "chkOptimizeDisks";
            map["SFC"]           = "chkSFC";
            map["DISM"]          = "chkDISM";
            map["CleanRegistry"] = "chkCleanRegistry";
            map["ClearMemory"]   = "chkClearMemory";
            return map;
        }

        /// <summary>
        /// Returns the status icon emoji for a given status string.
        /// </summary>
        public static string GetStatusIcon(string status)
        {
            if (status == "OK")   return "\u2705";        // ✅
            if (status == "WARN") return "\u26A0\uFE0F";  // ⚠️
            if (status == "CRIT") return "\U0001F534";     // 🔴
            return "\u2139\uFE0F";                          // ℹ️
        }

        /// <summary>
        /// Returns status background color hex for a given status.
        /// </summary>
        public static string GetStatusBackground(string status)
        {
            if (status == "OK")   return "#182A1E";
            if (status == "WARN") return "#2A2010";
            if (status == "CRIT") return "#2A1018";
            return "#1A2540";
        }

        /// <summary>
        /// Returns status border color hex for a given status.
        /// </summary>
        public static string GetStatusBorderColor(string status)
        {
            if (status == "OK")   return "#2A4A35";
            if (status == "WARN") return "#5A4010";
            if (status == "CRIT") return "#5A1828";
            return "#2A3A60";
        }
    }
}
