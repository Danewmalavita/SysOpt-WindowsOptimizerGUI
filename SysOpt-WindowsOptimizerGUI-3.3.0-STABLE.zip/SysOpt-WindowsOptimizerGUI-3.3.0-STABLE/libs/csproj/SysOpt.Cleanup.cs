﻿// SysOpt - Software de optimización del sistema
// Copyright (C) 2026 Danew Malavita
//
// Este programa es software libre bajo los términos de la GPL v3+.
// Consulta el archivo LICENSE o visita <https://www.gnu.org/licenses/>.

// =============================================================================
// SysOpt.Cleanup — v3.3.0
// CleanupEngine + CleanupResult — Motor de limpieza del sistema.
// Se carga LAZY: solo cuando el usuario ejecuta optimización.
//
// Compilar:
//   csc /target:library /out:SysOpt.Cleanup.dll SysOpt.Cleanup.cs
//       /r:System.dll /r:System.Core.dll
// =============================================================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Diagnostics;


// ═══════════════════════════════════════════════════════════════════════════════
// CleanupResult — Result container for cleanup operations
// ═══════════════════════════════════════════════════════════════════════════════
public class CleanupResult
{
    public double FreedMB        { get; set; }
    public int    FilesProcessed { get; set; }
    public int    Errors         { get; set; }
    public bool   Success        { get; set; }
    public string Summary        { get; set; }
    public System.Collections.Generic.List<string> Messages { get; set; }

    public CleanupResult()
    {
        Messages = new System.Collections.Generic.List<string>();
        Success  = true;
        Summary  = "";
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// CleanupEngine — Core cleanup operations (replaces PS1 optimization blocks)
// ═══════════════════════════════════════════════════════════════════════════════
public static class CleanupEngine
{
    /// <summary>
    /// Recursively scan and optionally delete files in given paths.
    /// Replaces PS1 Invoke-CleanTempPaths (~60 lines).
    /// </summary>
    public static CleanupResult CleanPaths(string[] paths, bool dryRun)
    {
        var result = new CleanupResult();
        int pathIdx = 0;
        foreach (string path in paths)
        {
            pathIdx++;
            string tag = "[" + pathIdx + "/" + paths.Length + "]";
            if (!System.IO.Directory.Exists(path))
            {
                result.Messages.Add("  " + tag + " Ruta no encontrada: " + path);
                continue;
            }
            result.Messages.Add("  " + tag + " Analizando: " + path);
            try
            {
                long beforeSize = GetDirectorySize(path);
                double beforeMB = Math.Round(beforeSize / 1048576.0, 2);
                result.Messages.Add("    Tama\u00f1o: " + beforeMB + " MB");

                if (!dryRun)
                {
                    int deleted = 0;
                    foreach (string file in SafeEnumerateFiles(path))
                    {
                        try { System.IO.File.Delete(file); deleted++; }
                        catch { result.Errors++; }
                    }
                    // Remove empty directories bottom-up
                    foreach (string dir in SafeEnumerateDirectories(path))
                    {
                        try { System.IO.Directory.Delete(dir, true); } catch { }
                    }
                    long afterSize = GetDirectorySize(path);
                    double freed = Math.Round((beforeSize - afterSize) / 1048576.0, 2);
                    result.FreedMB += freed;
                    result.FilesProcessed += deleted;
                    result.Messages.Add("    \u2713 Eliminados: " + deleted + " archivos \u2014 " + freed + " MB liberados");
                }
                else
                {
                    result.FreedMB += beforeMB;
                    result.Messages.Add("    [DRY RUN] Se liberar\u00edan ~" + beforeMB + " MB");
                }
            }
            catch (Exception ex)
            {
                result.Errors++;
                result.Messages.Add("    ! Error: " + ex.Message);
            }
        }
        return result;
    }

    /// <summary>
    /// Clean Recycle Bin on all drives.
    /// Replaces PS1 RecycleBin block (~43 lines).
    /// </summary>
    public static CleanupResult EmptyRecycleBin(bool dryRun)
    {
        var result = new CleanupResult();
        try
        {
            double totalMB = 0;
            foreach (var drive in System.IO.DriveInfo.GetDrives())
            {
                if (drive.DriveType != System.IO.DriveType.Fixed) continue;
                string rbPath = System.IO.Path.Combine(drive.RootDirectory.FullName, "$Recycle.Bin");
                if (System.IO.Directory.Exists(rbPath))
                {
                    long sz = GetDirectorySize(rbPath);
                    totalMB += sz / 1048576.0;
                }
            }
            totalMB = Math.Round(totalMB, 2);
            result.FreedMB = totalMB;
            result.Messages.Add("  Contenido total en papelera: " + totalMB + " MB");

            if (dryRun)
            {
                result.Messages.Add("  [DRY RUN] Se liberar\u00edan ~" + totalMB + " MB");
            }
            else
            {
                foreach (var drive in System.IO.DriveInfo.GetDrives())
                {
                    if (drive.DriveType != System.IO.DriveType.Fixed) continue;
                    string rbPath = System.IO.Path.Combine(drive.RootDirectory.FullName, "$Recycle.Bin");
                    if (System.IO.Directory.Exists(rbPath))
                    {
                        foreach (string item in SafeEnumerateEntries(rbPath))
                        {
                            try
                            {
                                if (System.IO.File.Exists(item))
                                    System.IO.File.Delete(item);
                                else if (System.IO.Directory.Exists(item))
                                    System.IO.Directory.Delete(item, true);
                            }
                            catch { result.Errors++; }
                        }
                    }
                }
                result.Messages.Add("  \u2713 Papelera vaciada para todas las unidades \u2014 " + totalMB + " MB liberados");
            }
        }
        catch (Exception ex)
        {
            result.Success = false;
            result.Messages.Add("  \u274c Error: " + ex.Message);
        }
        return result;
    }

    /// <summary>
    /// Clean browser caches (Chrome, Edge, Brave, Opera, Opera GX, Firefox).
    /// Replaces PS1 BrowserCache block (~105 lines).
    /// </summary>
    public static CleanupResult CleanBrowserCaches(bool dryRun)
    {
        var result = new CleanupResult();
        string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        string appData      = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);

        var browsers = new System.Collections.Generic.Dictionary<string, string[]>
        {
            { "Chrome", new[] {
                System.IO.Path.Combine(localAppData, @"Google\Chrome\User Data\Default\Cache"),
                System.IO.Path.Combine(localAppData, @"Google\Chrome\User Data\Default\Cache2"),
                System.IO.Path.Combine(localAppData, @"Google\Chrome\User Data\Default\Code Cache"),
                System.IO.Path.Combine(localAppData, @"Google\Chrome\User Data\Default\GPUCache") }},
            { "Edge", new[] {
                System.IO.Path.Combine(localAppData, @"Microsoft\Edge\User Data\Default\Cache"),
                System.IO.Path.Combine(localAppData, @"Microsoft\Edge\User Data\Default\Cache2"),
                System.IO.Path.Combine(localAppData, @"Microsoft\Edge\User Data\Default\Code Cache"),
                System.IO.Path.Combine(localAppData, @"Microsoft\Edge\User Data\Default\GPUCache") }},
            { "Brave", new[] {
                System.IO.Path.Combine(localAppData, @"BraveSoftware\Brave-Browser\User Data\Default\Cache"),
                System.IO.Path.Combine(localAppData, @"BraveSoftware\Brave-Browser\User Data\Default\Cache2"),
                System.IO.Path.Combine(localAppData, @"BraveSoftware\Brave-Browser\User Data\Default\Code Cache"),
                System.IO.Path.Combine(localAppData, @"BraveSoftware\Brave-Browser\User Data\Default\GPUCache") }},
            { "Opera", new[] {
                System.IO.Path.Combine(appData, @"Opera Software\Opera Stable\Cache"),
                System.IO.Path.Combine(appData, @"Opera Software\Opera Stable\Cache2"),
                System.IO.Path.Combine(appData, @"Opera Software\Opera Stable\Code Cache"),
                System.IO.Path.Combine(appData, @"Opera Software\Opera Stable\GPUCache") }},
            { "Opera GX", new[] {
                System.IO.Path.Combine(appData, @"Opera Software\Opera GX Stable\Cache"),
                System.IO.Path.Combine(appData, @"Opera Software\Opera GX Stable\Cache2"),
                System.IO.Path.Combine(appData, @"Opera Software\Opera GX Stable\Code Cache"),
                System.IO.Path.Combine(appData, @"Opera Software\Opera GX Stable\GPUCache") }},
        };

        int bIdx = 0;
        int bCount = browsers.Count + 1; // +1 for Firefox

        foreach (var kv in browsers)
        {
            bIdx++;
            result.Messages.Add("  [" + bIdx + "/" + bCount + "] " + kv.Key + "...");
            double totalCleared = 0;
            bool cleared = false;

            foreach (string path in kv.Value)
            {
                if (System.IO.Directory.Exists(path))
                {
                    long sz = GetDirectorySize(path);
                    totalCleared += sz / 1048576.0;
                    if (!dryRun)
                    {
                        foreach (string item in SafeEnumerateEntries(path))
                        {
                            try
                            {
                                if (System.IO.File.Exists(item))
                                    System.IO.File.Delete(item);
                                else if (System.IO.Directory.Exists(item))
                                    System.IO.Directory.Delete(item, true);
                            }
                            catch { }
                        }
                    }
                    cleared = true;
                }
            }
            totalCleared = Math.Round(totalCleared, 2);
            result.FreedMB += totalCleared;
            if (cleared)
                result.Messages.Add("    " + (dryRun ? "[DRY RUN]" : "\u2713") + " " + kv.Key + " \u2014 " + totalCleared + " MB " + (dryRun ? "por liberar" : "liberados"));
            else
                result.Messages.Add("    \u2192 " + kv.Key + " no encontrado o sin cach\u00e9");
        }

        // Firefox — special handling (profiles)
        bIdx++;
        result.Messages.Add("  [" + bIdx + "/" + bCount + "] Firefox...");
        string ffProfilesPath = System.IO.Path.Combine(localAppData, @"Mozilla\Firefox\Profiles");
        double ffCleared = 0;
        bool ffFound = false;
        if (System.IO.Directory.Exists(ffProfilesPath))
        {
            foreach (string profileDir in System.IO.Directory.GetDirectories(ffProfilesPath))
            {
                foreach (string cacheSub in new[] { "cache", "cache2" })
                {
                    string cp = System.IO.Path.Combine(profileDir, cacheSub);
                    if (System.IO.Directory.Exists(cp))
                    {
                        long sz = GetDirectorySize(cp);
                        ffCleared += sz / 1048576.0;
                        if (!dryRun)
                        {
                            foreach (string item in SafeEnumerateEntries(cp))
                            {
                                try
                                {
                                    if (System.IO.File.Exists(item))
                                        System.IO.File.Delete(item);
                                    else if (System.IO.Directory.Exists(item))
                                        System.IO.Directory.Delete(item, true);
                                }
                                catch { }
                            }
                        }
                        ffFound = true;
                    }
                }
            }
        }
        ffCleared = Math.Round(ffCleared, 2);
        result.FreedMB += ffCleared;
        if (ffFound)
            result.Messages.Add("    " + (dryRun ? "[DRY RUN]" : "\u2713") + " Firefox \u2014 " + ffCleared + " MB " + (dryRun ? "por liberar" : "liberados"));
        else
            result.Messages.Add("    \u2192 Firefox no encontrado o sin cach\u00e9");

        result.Messages.Add("");
        result.Messages.Add("  \u2713 Limpieza de navegadores " + (dryRun ? "analizada" : "completada"));
        return result;
    }

    /// <summary>
    /// Clean orphaned registry uninstall keys.
    /// Replaces PS1 CleanRegistry block (~63 lines).
    /// </summary>
    public static CleanupResult CleanRegistryOrphans(bool dryRun)
    {
        var result = new CleanupResult();
        string[] regPaths = new[]
        {
            @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
            @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall",
        };
        int orphaned = 0, deleted = 0;

        // HKLM paths
        foreach (string regPath in regPaths)
        {
            result.Messages.Add("  Analizando: HKLM\\" + regPath);
            try
            {
                using (var key = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(regPath))
                {
                    if (key == null) continue;
                    foreach (string subName in key.GetSubKeyNames())
                    {
                        try
                        {
                            using (var sub = key.OpenSubKey(subName))
                            {
                                if (sub == null) continue;
                                string installLoc = sub.GetValue("InstallLocation") as string;
                                string displayName = (sub.GetValue("DisplayName") as string) ?? subName;
                                if (!string.IsNullOrWhiteSpace(installLoc) && !System.IO.Directory.Exists(installLoc))
                                {
                                    orphaned++;
                                    result.Messages.Add("    \u2192 Hu\u00e9rfana: " + displayName);
                                    if (!dryRun)
                                    {
                                        try
                                        {
                                            using (var parent = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(regPath, true))
                                            {
                                                parent.DeleteSubKeyTree(subName);
                                                deleted++;
                                                result.Messages.Add("      \u2713 Eliminada");
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            result.Messages.Add("      ! No se pudo eliminar: " + ex.Message);
                                        }
                                    }
                                    else
                                    {
                                        result.Messages.Add("      [DRY RUN] Se eliminar\u00eda");
                                    }
                                }
                            }
                        }
                        catch { }
                    }
                }
            }
            catch { }
        }

        // HKCU path
        string hkcuPath = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall";
        result.Messages.Add("  Analizando: HKCU\\" + hkcuPath);
        try
        {
            using (var key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(hkcuPath))
            {
                if (key != null)
                {
                    foreach (string subName in key.GetSubKeyNames())
                    {
                        try
                        {
                            using (var sub = key.OpenSubKey(subName))
                            {
                                if (sub == null) continue;
                                string installLoc = sub.GetValue("InstallLocation") as string;
                                string displayName = (sub.GetValue("DisplayName") as string) ?? subName;
                                if (!string.IsNullOrWhiteSpace(installLoc) && !System.IO.Directory.Exists(installLoc))
                                {
                                    orphaned++;
                                    result.Messages.Add("    \u2192 Hu\u00e9rfana: " + displayName);
                                    if (!dryRun)
                                    {
                                        try
                                        {
                                            using (var parent = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(hkcuPath, true))
                                            {
                                                parent.DeleteSubKeyTree(subName);
                                                deleted++;
                                                result.Messages.Add("      \u2713 Eliminada");
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            result.Messages.Add("      ! No se pudo eliminar: " + ex.Message);
                                        }
                                    }
                                    else
                                    {
                                        result.Messages.Add("      [DRY RUN] Se eliminar\u00eda");
                                    }
                                }
                            }
                        }
                        catch { }
                    }
                }
            }
        }
        catch { }

        result.Messages.Add("");
        result.Messages.Add("  \u2713 Hu\u00e9rfanas encontradas: " + orphaned + " \u2014 Eliminadas: " + deleted);
        result.Summary = orphaned.ToString();
        result.FilesProcessed = orphaned;
        return result;
    }

    /// <summary>
    /// Clear Windows Event Logs (System, Application, Setup).
    /// Replaces PS1 EventLogs block (~45 lines).
    /// </summary>
    public static CleanupResult CleanEventLogs(string[] logNames, bool dryRun)
    {
        var result = new CleanupResult();
        int lIdx = 0;
        foreach (string logName in logNames)
        {
            lIdx++;
            string tag = "[" + lIdx + "/" + logNames.Length + "]";
            try
            {
                System.Diagnostics.Eventing.Reader.EventLogConfiguration config =
                    new System.Diagnostics.Eventing.Reader.EventLogConfiguration(logName);
                double sizeMB = Math.Round(config.LogFilePath != null ?
                    new System.IO.FileInfo(
                        Environment.ExpandEnvironmentVariables(
                            config.LogFilePath)).Length / 1048576.0 : 0, 2);
                result.FreedMB += sizeMB;

                result.Messages.Add("  " + tag + " " + logName + " \u2014 " + sizeMB + " MB");

                if (dryRun)
                {
                    result.Messages.Add("    [DRY RUN] Se limpiar\u00eda este log");
                }
                else
                {
                    var psi = new System.Diagnostics.ProcessStartInfo
                    {
                        FileName = "wevtutil.exe",
                        Arguments = "cl " + logName,
                        UseShellExecute = false,
                        CreateNoWindow = true,
                        RedirectStandardOutput = true,
                        RedirectStandardError = true
                    };
                    using (var proc = System.Diagnostics.Process.Start(psi))
                    {
                        proc.WaitForExit(30000);
                    }
                    result.Messages.Add("    \u2713 Log limpiado");
                }
            }
            catch (Exception ex)
            {
                result.Messages.Add("  " + tag + " " + logName + " \u2014 Error: " + ex.Message);
            }
        }
        result.Messages.Add("");
        result.Messages.Add("  \u2713 Event Logs " + (dryRun ? "analizados" : "limpiados"));
        result.Messages.Add("  NOTA: El log 'Security' NO fue modificado (requiere auditor\u00eda)");
        return result;
    }

    /// <summary>
    /// Flush DNS cache via ipconfig /flushdns.
    /// Replaces PS1 DNS block (~45 lines).
    /// </summary>
    public static CleanupResult FlushDns(bool dryRun)
    {
        var result = new CleanupResult();
        if (dryRun)
        {
            result.Messages.Add("  [DRY RUN] Se ejecutar\u00eda ipconfig /flushdns");
            return result;
        }
        try
        {
            var psi = new System.Diagnostics.ProcessStartInfo
            {
                FileName = "cmd.exe",
                Arguments = "/c chcp 65001 >nul 2>&1 & ipconfig /flushdns",
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                StandardOutputEncoding = System.Text.Encoding.UTF8
            };
            using (var proc = System.Diagnostics.Process.Start(psi))
            {
                if (proc == null) { result.Success = false; result.Messages.Add("  Error: no se pudo iniciar cmd.exe"); return result; }
                string output = proc.StandardOutput.ReadToEnd();
                proc.WaitForExit(15000);
                foreach (string line in output.Split('\n'))
                {
                    string trimmed = line.Trim();
                    if (!string.IsNullOrEmpty(trimmed))
                        result.Messages.Add("  " + trimmed);
                }
            }
            result.Messages.Add("  \u2713 Cach\u00e9 DNS limpiada");
        }
        catch (Exception ex)
        {
            result.Success = false;
            result.Messages.Add("  Error: " + ex.Message);
        }
        return result;
    }

    /// <summary>
    /// Backup registry hives via reg.exe export.
    /// Replaces PS1 BackupRegistry block (~51 lines).
    /// </summary>
    public static CleanupResult BackupRegistry(string outputFolder, bool dryRun)
    {
        var result = new CleanupResult();
        var hives = new[] {
            new { Name = "HKEY_CURRENT_USER",           File = "HKCU_backup.reg" },
            new { Name = "HKEY_LOCAL_MACHINE\\SOFTWARE", File = "HKLM_SOFTWARE_backup.reg" }
        };

        if (dryRun)
        {
            result.Messages.Add("  [DRY RUN] Se crear\u00eda backup en: " + outputFolder);
            result.Messages.Add("  [DRY RUN] Exportar\u00eda: " + string.Join(", ", System.Linq.Enumerable.Select(hives, h => h.Name)));
            return result;
        }

        try
        {
            System.IO.Directory.CreateDirectory(outputFolder);
            result.Messages.Add("  Carpeta: " + outputFolder);

            int hi = 0;
            foreach (var hive in hives)
            {
                hi++;
                result.Messages.Add("  [" + hi + "/" + hives.Length + "] Exportando " + hive.Name + "...");
                string exportFile = System.IO.Path.Combine(outputFolder, hive.File);
                var psi = new System.Diagnostics.ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = "/c reg export \"" + hive.Name + "\" \"" + exportFile + "\" /y",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = false,
                    RedirectStandardError = false
                };
                using (var proc = System.Diagnostics.Process.Start(psi))
                {
                    if (proc == null) { result.Messages.Add("    ! Error: no se pudo iniciar reg.exe"); continue; }
                    proc.WaitForExit(120000);
                }
                if (System.IO.File.Exists(exportFile))
                {
                    double sz = Math.Round(new System.IO.FileInfo(exportFile).Length / 1048576.0, 2);
                    result.Messages.Add("    \u2713 " + sz + " MB");
                }
                else
                {
                    result.Messages.Add("    ! No se pudo exportar");
                }
            }
            result.Messages.Add("");
            result.Messages.Add("  \u2713 Backup completado en: " + outputFolder);
        }
        catch (Exception ex)
        {
            result.Success = false;
            result.Messages.Add("  Error: " + ex.Message);
        }
        return result;
    }

    /// <summary>
    /// Run an external tool and capture output.
    /// Replaces inline Process.Start patterns for SFC, DISM, defrag, etc.
    /// </summary>
    public static CleanupResult RunExternalTool(string fileName, string arguments, int timeoutMs = 0)
    {
        var result = new CleanupResult();
        try
        {
            var psi = new System.Diagnostics.ProcessStartInfo
            {
                FileName = fileName,
                Arguments = arguments,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                StandardOutputEncoding = System.Text.Encoding.UTF8
            };
            using (var proc = System.Diagnostics.Process.Start(psi))
            {
                var stderrTask = proc.StandardError.ReadToEndAsync();
                string stdout = proc.StandardOutput.ReadToEnd();
                string stderr = stderrTask.GetAwaiter().GetResult();
                if (timeoutMs > 0)
                    proc.WaitForExit(timeoutMs);
                else
                    proc.WaitForExit();

                foreach (string line in stdout.Split('\n'))
                {
                    string t = line.TrimEnd();
                    if (!string.IsNullOrEmpty(t))
                        result.Messages.Add("    " + t);
                }
                result.Summary = proc.ExitCode.ToString();
            }
        }
        catch (Exception ex)
        {
            result.Success = false;
            result.Messages.Add("  Error: " + ex.Message);
        }
        return result;
    }


    /// <summary>
    /// Run SFC /SCANNOW and interpret results.
    /// Replaces PS1 SFC block (~38 lines).
    /// </summary>
    /// <summary>
    /// Run SFC /SCANNOW with real-time progress reporting.
    /// Reads stdout asynchronously to avoid deadlocks and parses % complete.
    /// </summary>
    /// <param name="dryRun">If true, only simulate.</param>
    /// <param name="onLine">Optional callback for real-time line output (e.g., "Verification 42% complete").</param>
    /// <returns>CleanupResult with messages and exit status.</returns>
    public static CleanupResult RunSfc(bool dryRun, Action<string> onLine = null)
    {
        var result = new CleanupResult();
        // Modo análisis: sfc /verifyonly (solo lectura, no repara)
        // Modo real:     sfc /scannow   (verificación + reparación)
        result.Messages.Add(dryRun
            ? "    Ejecutando: sfc /verifyonly (Modo Análisis — sin cambios)"
            : "    NOTA: puede tardar entre 10-30 minutos");

        try
        {
            // FIX: ejecutar SFC via cmd.exe /u (modo Unicode) para correcta codificación.
            // SFC.exe lanza WriteConsoleW internamente; envolverlo con cmd /u fuerza
            // la salida a UTF-16 LE que podemos leer con Encoding.Unicode.
            // CreateNoWindow=true + cmd /u + RedirectStdout permite capturar la salida.
            var psi = new System.Diagnostics.ProcessStartInfo
            {
                FileName  = "cmd.exe",
                Arguments = dryRun ? "/u /c sfc /verifyonly" : "/u /c sfc /scannow",
                UseShellExecute        = false,
                CreateNoWindow         = true,
                RedirectStandardOutput = true,
                RedirectStandardError  = true,
                StandardOutputEncoding = System.Text.Encoding.Unicode
            };

            using (var proc = System.Diagnostics.Process.Start(psi))
            {
                // ── FIX: null check — Process.Start devuelve null si falla el inicio ──
                if (proc == null)
                {
                    result.Success = false;
                    result.Messages.Add("  ! Error: no se pudo iniciar sfc.exe (¿ejecutas SysOpt como Administrador?)");
                    return result;
                }

                // ── Async stdout reader ─────────────────────────────
                var outputDone = new System.Threading.ManualResetEventSlim(false);
                proc.OutputDataReceived += (sender, e) =>
                {
                    if (e.Data == null) { outputDone.Set(); return; }
                    string line = e.Data.Trim();
                    if (string.IsNullOrEmpty(line)) return;

                    // FIX: onLine wrapped in try/catch — una excepción en el callback
                    // propagaría al thread pool y mataría el proceso completo.
                    try { if (onLine != null) onLine(line); } catch { }
                };
                proc.BeginOutputReadLine();

                // FIX: consumir stderr de forma asíncrona para evitar deadlock
                // (si el buffer de stderr se llena, SFC se bloquearía indefinidamente)
                proc.ErrorDataReceived += (sender, e) => { };
                proc.BeginErrorReadLine();

                // ── Wait with timeout (60 min max) ──────────────────
                bool exited = proc.WaitForExit(60 * 60 * 1000);
                if (!exited)
                {
                    try { proc.Kill(); } catch { }
                    result.Messages.Add("  ! SFC: Tiempo agotado (60 min)");
                    result.Success = false;
                    outputDone.Dispose();
                    return result;
                }
                outputDone.Wait(5000); // Wait for async buffer flush
                outputDone.Dispose();

                // ── Read CBS.log for detailed results (solo modo real) ──────
                // sfc /verifyonly no actualiza CBS.log de forma fiable
                if (!dryRun)
                {
                    string cbsLog = System.IO.Path.Combine(
                        Environment.GetEnvironmentVariable("SystemRoot") ?? @"C:\Windows",
                        @"Logs\CBS\CBS.log");

                    if (System.IO.File.Exists(cbsLog))
                    {
                        result.Messages.Add("  \u00daltimas l\u00edneas CBS.log:");
                        try
                        {
                            // Read with FileShare to avoid lock conflicts
                            string[] lines;
                            using (var fs = new System.IO.FileStream(cbsLog, System.IO.FileMode.Open,
                                System.IO.FileAccess.Read, System.IO.FileShare.ReadWrite))
                            using (var sr = new System.IO.StreamReader(fs))
                            {
                                lines = sr.ReadToEnd().Split(new[] { '\r', '\n' },
                                    StringSplitOptions.RemoveEmptyEntries);
                            }
                            int start = Math.Max(0, lines.Length - 20);
                            for (int i = start; i < lines.Length; i++)
                                result.Messages.Add("    " + lines[i]);
                        }
                        catch { }
                    }
                }

                // ── Exit code interpretation ────────────────────────
                if (dryRun)
                {
                    switch (proc.ExitCode)
                    {
                        case 0: result.Messages.Add("  \u2713 SFC /verifyonly: Sin infracciones de integridad"); break;
                        case 2: result.Messages.Add("  \u26a0 SFC /verifyonly: Se detectaron infracciones de integridad (ejecutar reparaci\u00f3n)"); result.Success = false; break;
                        case 3: result.Messages.Add("  ! SFC /verifyonly: No se pudo realizar la verificaci\u00f3n"); break;
                        default: result.Messages.Add("  ! SFC /verifyonly c\u00f3digo: " + proc.ExitCode); break;
                    }
                }
                else
                {
                    switch (proc.ExitCode)
                    {
                        case 0: result.Messages.Add("  \u2713 SFC: No se encontraron infracciones"); break;
                        case 1: result.Messages.Add("  \u2713 SFC: Archivos corruptos reparados"); break;
                        case 2: result.Messages.Add("  ! SFC: Archivos corruptos que no pudieron repararse"); break;
                        case 3: result.Messages.Add("  ! SFC: No se pudo realizar la verificaci\u00f3n"); break;
                        default: result.Messages.Add("  ! SFC c\u00f3digo" + ": " + proc.ExitCode); break;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            result.Success = false;
            result.Messages.Add("  Error: " + ex.Message);
        }
        return result;
    }

    /// <summary>
    /// Run DISM health checks (CheckHealth, ScanHealth, RestoreHealth).
    /// Replaces PS1 DISM block (~35 lines).
    /// </summary>
    /// <summary>
    /// Run DISM health checks with real-time progress reporting.
    /// Executes CheckHealth, ScanHealth, RestoreHealth sequentially.
    /// </summary>
    /// <param name="dryRun">If true, only simulate.</param>
    /// <param name="onLine">Optional callback for real-time line output.</param>
    /// <returns>CleanupResult with step-by-step messages.</returns>
    public static CleanupResult RunDism(bool dryRun, Action<string> onLine = null)
    {
        var result = new CleanupResult();
        // Modo análisis: solo CheckHealth (verificación rápida, sin cambios)
        // Modo real:     CheckHealth + ScanHealth + RestoreHealth (reparación completa)
        result.Messages.Add(dryRun
            ? "    Ejecutando: DISM /CheckHealth (Modo Análisis — sin cambios)"
            : "    NOTA: puede tardar entre 15-45 minutos");

        var steps = dryRun
            ? new[] { new { Label = "CheckHealth (Modo Análisis)...", Args = "/Online /Cleanup-Image /CheckHealth" } }
            : new[]
              {
                  new { Label = "Paso 1/3: CheckHealth...",   Args = "/Online /Cleanup-Image /CheckHealth" },
                  new { Label = "Paso 2/3: ScanHealth...",    Args = "/Online /Cleanup-Image /ScanHealth" },
                  new { Label = "Paso 3/3: RestoreHealth...", Args = "/Online /Cleanup-Image /RestoreHealth" }
              };

        int stepNum = 0;
        foreach (var step in steps)
        {
            stepNum++;
            result.Messages.Add("");
            result.Messages.Add("  " + step.Label);
            if (onLine != null) onLine("[DISM " + stepNum + "/3] " + step.Label);

            try
            {
                var psi = new System.Diagnostics.ProcessStartInfo
                {
                    FileName  = "DISM.exe",
                    Arguments = step.Args,
                    UseShellExecute        = false,
                    CreateNoWindow         = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError  = true,
                    StandardOutputEncoding = System.Text.Encoding.UTF8
                };

                using (var proc = System.Diagnostics.Process.Start(psi))
                {
                    // FIX: null check — Process.Start devuelve null si falla la elevación
                    if (proc == null)
                    {
                        result.Messages.Add("  ! Error: no se pudo iniciar DISM.exe (¿ejecutas como Administrador?)");
                        result.Success = false;
                        continue;
                    }

                    // Async stdout to avoid deadlock + real-time progress
                    var outputDone = new System.Threading.ManualResetEventSlim(false);

                    proc.OutputDataReceived += (sender, e) =>
                    {
                        if (e.Data == null) { outputDone.Set(); return; }
                        string t = e.Data.Trim();
                        if (string.IsNullOrEmpty(t)) return;

                        result.Messages.Add("    " + t);
                        // FIX: try/catch para evitar que una excepción en el callback
                        // propague al thread pool y mate el proceso
                        try { if (onLine != null) onLine(t); } catch { }
                    };
                    proc.BeginOutputReadLine();
                    // FIX: consumir stderr para evitar deadlock de buffer
                    proc.ErrorDataReceived += (sender, e) => { };
                    proc.BeginErrorReadLine();

                    // Wait with timeout (45 min per step max)
                    bool exited = proc.WaitForExit(45 * 60 * 1000);
                    if (!exited)
                    {
                        try { proc.Kill(); } catch { }
                        result.Messages.Add("  ! DISM: Tiempo agotado");
                        result.Success = false;
                        outputDone.Dispose();
                        break;
                    }
                    outputDone.Wait(5000);
                    outputDone.Dispose();
                }
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.Messages.Add("  Error: " + ex.Message);
            }
        }
        result.Messages.Add("");
        if (result.Success)
            result.Messages.Add("  \u2713 DISM completado");
        else
            result.Messages.Add("  \u2717 DISM completado con errores");
        return result;
    }

    // ── Internal helpers ────────────────────────────────────────────────────

    private static long GetDirectorySize(string path)
    {
        long size = 0;
        try
        {
            foreach (string file in SafeEnumerateFiles(path))
            {
                try { size += new System.IO.FileInfo(file).Length; }
                catch { }
            }
        }
        catch { }
        return size;
    }

    private static System.Collections.Generic.IEnumerable<string> SafeEnumerateFiles(string path)
    {
        var stack = new System.Collections.Generic.Stack<string>();
        stack.Push(path);
        while (stack.Count > 0)
        {
            string dir = stack.Pop();
            string[] files = null;
            try { files = System.IO.Directory.GetFiles(dir); } catch { }
            if (files != null)
                foreach (string f in files) yield return f;
            string[] dirs = null;
            try { dirs = System.IO.Directory.GetDirectories(dir); } catch { }
            if (dirs != null)
                foreach (string d in dirs) stack.Push(d);
        }
    }

    private static System.Collections.Generic.List<string> SafeEnumerateDirectories(string path)
    {
        // Return directories sorted deepest-first for safe bottom-up deletion
        var all = new System.Collections.Generic.List<string>();
        var stack = new System.Collections.Generic.Stack<string>();
        stack.Push(path);
        while (stack.Count > 0)
        {
            string dir = stack.Pop();
            string[] dirs = null;
            try { dirs = System.IO.Directory.GetDirectories(dir); } catch { }
            if (dirs != null)
            {
                foreach (string d in dirs)
                {
                    all.Add(d);
                    stack.Push(d);
                }
            }
        }
        all.Sort((a, b) => b.Length.CompareTo(a.Length)); // deepest first
        return all;
    }

    private static string[] SafeEnumerateEntries(string path)
    {
        try { return System.IO.Directory.GetFileSystemEntries(path); }
        catch { return new string[0]; }
    }
}
