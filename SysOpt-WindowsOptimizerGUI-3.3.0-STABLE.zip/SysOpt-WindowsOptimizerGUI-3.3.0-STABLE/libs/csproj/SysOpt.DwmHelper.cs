﻿// SysOpt - Software de optimización del sistema
// Copyright (C) 2026 Danew Malavita
//
// Este programa es software libre bajo los términos de la GPL v3+.
// Consulta el archivo LICENSE o visita <https://www.gnu.org/licenses/>.

using System;
using System.Runtime.InteropServices;

/// <summary>
/// Helper para pintar la barra de título nativa con los colores del tema activo.
/// Usa DwmSetWindowAttribute (Windows 10 1809+ / Windows 11 22000+).
/// Fallback silencioso en OS anteriores.
/// </summary>
public static class DwmHelper {
    [DllImport("dwmapi.dll", PreserveSig = true)]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int val, int size);

    /// <summary>Activa/desactiva dark mode en la barra de título (DWMWA_USE_IMMERSIVE_DARK_MODE = 20, Win10 1809+).</summary>
    public static void SetDarkMode(IntPtr hwnd, bool dark) {
        int v = dark ? 1 : 0;
        DwmSetWindowAttribute(hwnd, 20, ref v, 4);
    }

    /// <summary>Establece el color de fondo de la barra de título (DWMWA_CAPTION_COLOR = 35, Win11 22000+).</summary>
    public static void SetCaptionColor(IntPtr hwnd, byte r, byte g, byte b) {
        int c = (int)r | ((int)g << 8) | ((int)b << 16);
        DwmSetWindowAttribute(hwnd, 35, ref c, 4);
    }

    /// <summary>Establece el color del texto de la barra de título (DWMWA_TEXT_COLOR = 36, Win11 22000+).</summary>
    public static void SetTextColor(IntPtr hwnd, byte r, byte g, byte b) {
        int c = (int)r | ((int)g << 8) | ((int)b << 16);
        DwmSetWindowAttribute(hwnd, 36, ref c, 4);
    }
}
