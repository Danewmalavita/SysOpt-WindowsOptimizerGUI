﻿// SysOpt - Software de optimización del sistema
// Copyright (C) 2026 Danew Malavita
//
// Este programa es software libre bajo los términos de la GPL v3+.
// Consulta el archivo LICENSE o visita <https://www.gnu.org/licenses/>.

// =============================================================================
// SysOpt.LazyLoader.cs — Indexador estático + dinámico de funciones PowerShell
//
// Concepto: funciona como un "índice de base de datos" para código PS1.
// - Conoce las coordenadas (archivo + líneas) de cada función del bundle
// - Clasifica cada función en su fase (BOOT / TAB_* / ON_DEMAND)
// - En boot extrae SOLO el código mínimo → Invoke-Expression
// - Al hacer click en un tab → extrae y carga esas funciones + DLLs
//
// Compilar:  csc /target:library /optimize+ /out:SysOpt.LazyLoader.dll
//            /r:System.dll /r:System.Core.dll SysOpt.LazyLoader.cs
// =============================================================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace SysOpt
{
    // ── Modelo del índice ──────────────────────────────────────────────────────
    public class FunctionEntry
    {
        public string Name;           // "Show-DiagnosticReport"
        public string SourceFile;     // "libs\\SysOpt.Functions.bundle.ps1"
        public int    StartLine;      // 405  (1-indexed, inclusive)
        public int    EndLine;        // 1306 (1-indexed, inclusive)
        public string Phase;          // "BOOT" | "TAB_RENDIMIENTO" | ...
        public string[] RequiredDlls; // ["SysOpt.Diagnostics.dll"]
    }

    // ── Constantes de fase ─────────────────────────────────────────────────────
    public static class Phases
    {
        public const string BOOT             = "BOOT";
        public const string TAB_OPTIMIZATION = "TAB_OPTIMIZATION";
        public const string TAB_RENDIMIENTO  = "TAB_RENDIMIENTO";
        public const string TAB_DISCO        = "TAB_DISCO";
        public const string TAB_HISTORIAL    = "TAB_HISTORIAL";
        public const string TAB_MODULOS      = "TAB_MODULOS";
        public const string ON_DEMAND        = "ON_DEMAND";
        public const string COLD             = "COLD";  // v3.3.0-OPT-7: funciones raramente usadas
    }

    // ── Motor principal ────────────────────────────────────────────────────────
    public static class LazyLoader
    {
        private static string _appDir;
        private static readonly List<FunctionEntry> _staticIndex = new List<FunctionEntry>();
        private static readonly Dictionary<string, List<FunctionEntry>> _moduleIndex =
            new Dictionary<string, List<FunctionEntry>>(StringComparer.OrdinalIgnoreCase);
        private static readonly HashSet<string> _loadedPhases =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private static string _cacheDir;

        // Caché de líneas leídas para evitar re-lectura del mismo archivo
        private static readonly Dictionary<string, string[]> _fileCache =
            new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase);

        /// <summary>Traza interna — solo escribe si LogEngine está inicializado.</summary>
        private static void Log(string msg, string level = "DBG")
        {
            try { LogEngine.Write(msg, level); } catch { }
        }

        // ══════════════════════════════════════════════════════════════════════
        // CONSTRUCTOR ESTÁTICO — build del índice hardcoded (0 ms overhead)
        // ══════════════════════════════════════════════════════════════════════
        static LazyLoader()
        {
            BuildStaticIndex();
        }

        // ── Inicialización (llamar desde PS1 al arranque) ─────────────────────
        public static void Initialize(string appDir)
        {
            _appDir = appDir;
            _cacheDir = Path.Combine(Path.GetTempPath(), "SysOpt");
            EnsureDir(_cacheDir);
            EnsureDir(Path.Combine(_cacheDir, "index"));
            EnsureDir(Path.Combine(_cacheDir, "cache"));
            Log("[LazyLoader] Initialized — appDir=" + appDir + ", cacheDir=" + _cacheDir + ", staticIndex=" + _staticIndex.Count + " functions");
        }

        // ══════════════════════════════════════════════════════════════════════
        // ÍNDICE ESTÁTICO — 27 funciones del bundle, precalculadas
        // ══════════════════════════════════════════════════════════════════════
        private static void BuildStaticIndex()
        {
            // Ruta relativa al bundle desde la raíz del proyecto
            string B = "libs\\SysOpt.Functions.bundle.ps1";
            string[] none = new string[0];

            // ── BOOT (2 funciones, ~238 líneas) ─────────────────────────────
            Add(B, "Show-ThemedDialog",         3237, 3364, Phases.BOOT, none);
            Add(B, "Show-ThemedInput",          3365, 3474, Phases.BOOT, none);

            // ── TAB_HISTORIAL (4 funciones, ~1352 líneas) ───────────────────
            Add(B, "Get-SnapshotEntriesAsync",  15,   160,  Phases.TAB_HISTORIAL,
                new[] { "SysOpt.Snapshot.dll" });
            Add(B, "Load-SnapshotList",         161,  303,  Phases.TAB_HISTORIAL,
                new[] { "SysOpt.Snapshot.dll" });
            Add(B, "Show-DiagnosticReport",     405,  1306, Phases.TAB_HISTORIAL,
                new[] { "SysOpt.Diagnostics.dll" });
            Add(B, "Show-ExportProgressDialog", 1307, 1467, Phases.TAB_HISTORIAL, none);

            // ── TAB_DISCO (2 funciones, ~910 líneas) ────────────────────────
            Add(B, "Show-FolderScanner",        1468, 1933, Phases.TAB_DISCO,
                new[] { "SysOpt.DiskEngine.dll" });
            Add(B, "Start-DiskScan",            3821, 4264, Phases.TAB_DISCO,
                new[] { "SysOpt.DiskEngine.dll" });

            // ── TAB_MODULOS (9 funciones, ~349 líneas) ──────────────────────
            Add(B, "Initialize-ModuleSystem",   4536, 4651, Phases.TAB_MODULOS,
                new[] { "SysOpt.Modules.dll" });
            Add(B, "Mount-ModuleTabs",          4652, 4668, Phases.TAB_MODULOS, none);
            Add(B, "Mount-SingleModuleTab",     4669, 4730, Phases.TAB_MODULOS, none);
            Add(B, "Unmount-ModuleTab",         4731, 4742, Phases.TAB_MODULOS, none);
            Add(B, "Install-SysOptModule",      4743, 4805, Phases.TAB_MODULOS,
                new[] { "SysOpt.Modules.dll" });
            Add(B, "Enable-SysOptModule",       4806, 4863, Phases.TAB_MODULOS,
                new[] { "SysOpt.Modules.dll" });
            Add(B, "Disable-SysOptModule",      4864, 4897, Phases.TAB_MODULOS, none);
            Add(B, "Uninstall-SysOptModule",    4898, 4922, Phases.TAB_MODULOS,
                new[] { "SysOpt.Modules.dll" });
            Add(B, "Save-ModulesRegistry",      4923, 4928, Phases.TAB_MODULOS, none);
            Add(B, "Update-ModuleCache",        4929, 4938, Phases.TAB_MODULOS, none);
            Add(B, "Get-InstalledModules",      4939, 4944, Phases.TAB_MODULOS, none);

            // ── ON_DEMAND (5 funciones, ~1623 líneas) ───────────────────────
            Add(B, "Show-OptionsWindow",        1934, 2695, Phases.ON_DEMAND, none);
            Add(B, "Show-SfcDismWindow",        2696, 2985, Phases.ON_DEMAND, none);
            Add(B, "Show-StartupManager",       2986, 3060, Phases.ON_DEMAND,
                new[] { "SysOpt.StartupManager.dll" });
            Add(B, "Show-TasksWindow",          3061, 3236, Phases.ON_DEMAND, none);
            Add(B, "Start-Optimization",        4265, 4535, Phases.ON_DEMAND,
                new[] { "SysOpt.Cleanup.dll", "SysOpt.Optimizer.dll" });

            // ── COLD (3 funciones, ~398 líneas) — carga individual bajo demanda ─
            // v3.3.0-OPT-7: Reclasificadas por perfil de uso real (raramente accedidas)
            Add(B, "Show-AboutWindow",          304,  345,  Phases.COLD, none);
            Add(B, "Show-BreakoutGame",         346,  404,  Phases.COLD,
                new[] { "SysOpt.Breakout.dll" });
            Add(B, "Show-WizardWindow",         3475, 3820, Phases.COLD,
                new[] { "SysOpt.Wizard.dll" });
        }

        private static void Add(string src, string name, int start, int end,
                                string phase, string[] dlls)
        {
            _staticIndex.Add(new FunctionEntry
            {
                Name         = name,
                SourceFile   = src,
                StartLine    = start,
                EndLine      = end,
                Phase        = phase,
                RequiredDlls = dlls
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // EXTRACCIÓN DE CÓDIGO
        // ══════════════════════════════════════════════════════════════════════

        /// <summary>Extrae todas las funciones de una fase del índice estático.</summary>
        public static string ExtractPhase(string phase)
        {
            var entries = _staticIndex.Where(e =>
                string.Equals(e.Phase, phase, StringComparison.OrdinalIgnoreCase)).ToList();
            Log("[LazyLoader] ExtractPhase('" + phase + "') — " + entries.Count + " functions");
            if (entries.Count == 0)
            {
                Log("[LazyLoader] ExtractPhase('" + phase + "') — no functions found", "WARN");
                return string.Empty;
            }
            return ExtractEntries(entries);
        }

        /// <summary>Extrae funciones de múltiples fases a la vez.</summary>
        public static string ExtractPhases(string[] phases)
        {
            var set = new HashSet<string>(phases, StringComparer.OrdinalIgnoreCase);
            var entries = _staticIndex.Where(e => set.Contains(e.Phase)).ToList();
            string joined = string.Join(", ", phases);
            Log("[LazyLoader] ExtractPhases([" + joined + "]) — " + entries.Count + " functions");
            if (entries.Count == 0) return string.Empty;
            return ExtractEntries(entries);
        }

        /// <summary>Extrae una única función por nombre.</summary>
        public static string ExtractFunction(string name)
        {
            var entry = _staticIndex.FirstOrDefault(e =>
                string.Equals(e.Name, name, StringComparison.OrdinalIgnoreCase));
            if (entry == null)
            {
                Log("[LazyLoader] ExtractFunction('" + name + "') — NOT FOUND in index", "WARN");
                return string.Empty;
            }
            Log("[LazyLoader] ExtractFunction('" + name + "') — from " + entry.SourceFile + ":" + entry.StartLine + "-" + entry.EndLine);
            return ExtractEntry(entry);
        }

        // ══════════════════════════════════════════════════════════════════════
        // CONSULTA DEL ÍNDICE
        // ══════════════════════════════════════════════════════════════════════

        /// <summary>Devuelve las entradas del índice para una fase.</summary>
        public static FunctionEntry[] GetFunctionsForPhase(string phase)
        {
            return _staticIndex.Where(e =>
                string.Equals(e.Phase, phase, StringComparison.OrdinalIgnoreCase)).ToArray();
        }

        /// <summary>Devuelve las DLLs necesarias para una fase (sin duplicados).</summary>
        public static string[] GetRequiredDlls(string phase)
        {
            return _staticIndex
                .Where(e => string.Equals(e.Phase, phase, StringComparison.OrdinalIgnoreCase))
                .SelectMany(e => e.RequiredDlls)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToArray();
        }

        /// <summary>¿Se cargó ya esta fase?</summary>
        public static bool IsPhaseLoaded(string phase)
        {
            return _loadedPhases.Contains(phase);
        }

        /// <summary>Marcar una fase como cargada.</summary>
        public static void MarkPhaseLoaded(string phase)
        {
            _loadedPhases.Add(phase);
            Log("[LazyLoader] Phase '" + phase + "' marked as loaded — total loaded: " + _loadedPhases.Count);
        }

        /// <summary>Número total de funciones en el índice estático.</summary>
        public static int StaticIndexCount
        {
            get { return _staticIndex.Count; }
        }

        /// <summary>Fases ya cargadas (para debug/log).</summary>
        public static string[] LoadedPhases
        {
            get { return _loadedPhases.ToArray(); }
        }

        // ══════════════════════════════════════════════════════════════════════
        // MÓDULOS — ÍNDICE DINÁMICO
        // ══════════════════════════════════════════════════════════════════════

        /// <summary>
        /// Parsea un module/*/main.ps1 y cachea el índice de funciones.
        /// Si existe caché JSON válida en %TEMP%\SysOpt\index\{name}.json, la usa.
        /// </summary>
        public static void IndexModule(string modulePath)
        {
            string moduleName = Path.GetFileName(modulePath);
            string mainPs1 = Path.Combine(modulePath, "main.ps1");
            if (!File.Exists(mainPs1))
            {
                Log("[LazyLoader] IndexModule('" + moduleName + "') — main.ps1 not found", "WARN");
                return;
            }

            // ── Intentar caché ────────────────────────────────────────────────
            string cacheFile = Path.Combine(_cacheDir, "index", moduleName + ".json");
            if (File.Exists(cacheFile))
            {
                try
                {
                    string cacheJson = File.ReadAllText(cacheFile, Encoding.UTF8);
                    long mainSize    = new FileInfo(mainPs1).Length;
                    string mainDate  = File.GetLastWriteTimeUtc(mainPs1).ToString("o");

                    // Verificar que el caché corresponde al mismo archivo
                    if (cacheJson.Contains("\"size\":" + mainSize) &&
                        cacheJson.Contains("\"modified\":\"" + mainDate + "\""))
                    {
                        var entries = ParseCachedIndex(cacheJson, mainPs1);
                        if (entries != null && entries.Count > 0)
                        {
                            _moduleIndex[moduleName] = entries;
                            Log("[LazyLoader] IndexModule('" + moduleName + "') — loaded from cache (" + entries.Count + " functions)");
                            return;
                        }
                    }
                }
                catch { /* caché corrupta, parsear de nuevo */ }
            }

            // ── Parseo real ───────────────────────────────────────────────────
            var parsed = ParsePs1Functions(mainPs1);
            _moduleIndex[moduleName] = parsed;
            Log("[LazyLoader] IndexModule('" + moduleName + "') — parsed " + parsed.Count + " functions from " + mainPs1);

            // ── Guardar caché ─────────────────────────────────────────────────
            try
            {
                var sb = new StringBuilder();
                sb.Append("{\"size\":");
                sb.Append(new FileInfo(mainPs1).Length);
                sb.Append(",\"modified\":\"");
                sb.Append(File.GetLastWriteTimeUtc(mainPs1).ToString("o"));
                sb.Append("\",\"functions\":[");
                for (int i = 0; i < parsed.Count; i++)
                {
                    if (i > 0) sb.Append(",");
                    var e = parsed[i];
                    sb.Append("{\"n\":\""); sb.Append(EscapeJson(e.Name));
                    sb.Append("\",\"s\":"); sb.Append(e.StartLine);
                    sb.Append(",\"e\":");   sb.Append(e.EndLine);
                    sb.Append("}");
                }
                sb.Append("]}");
                File.WriteAllText(cacheFile, sb.ToString(), Encoding.UTF8);
                Log("[LazyLoader] IndexModule('" + moduleName + "') — cache saved to " + cacheFile);
            }
            catch { /* no-op: caché es opcional */ }
        }

        /// <summary>Devuelve las funciones indexadas de un módulo.</summary>
        public static FunctionEntry[] GetModuleFunctions(string moduleName)
        {
            List<FunctionEntry> list;
            if (_moduleIndex.TryGetValue(moduleName, out list))
                return list.ToArray();
            return new FunctionEntry[0];
        }

        /// <summary>Extrae una función concreta de un módulo.</summary>
        public static string ExtractModuleFunction(string moduleName, string functionName)
        {
            List<FunctionEntry> list;
            if (!_moduleIndex.TryGetValue(moduleName, out list))
            {
                Log("[LazyLoader] ExtractModuleFunction('" + moduleName + "', '" + functionName + "') — not found", "WARN");
                return string.Empty;
            }
            var entry = list.FirstOrDefault(e =>
                string.Equals(e.Name, functionName, StringComparison.OrdinalIgnoreCase));
            if (entry == null)
            {
                Log("[LazyLoader] ExtractModuleFunction('" + moduleName + "', '" + functionName + "') — not found", "WARN");
                return string.Empty;
            }
            return ExtractEntryAbsolute(entry);
        }

        /// <summary>
        /// Extrae funciones de un módulo que coincidan con una lista de nombres.
        /// Se usa para cargar por fase según module.json "phases".
        /// </summary>
        public static string ExtractModuleFunctions(string moduleName, string[] functionNames)
        {
            List<FunctionEntry> list;
            if (!_moduleIndex.TryGetValue(moduleName, out list)) return string.Empty;
            var nameSet = new HashSet<string>(functionNames, StringComparer.OrdinalIgnoreCase);
            var matches = list.Where(e => nameSet.Contains(e.Name)).ToList();
            if (matches.Count == 0) return string.Empty;

            // Los SourceFile de módulos son rutas absolutas
            var sb = new StringBuilder();
            foreach (var entry in matches.OrderBy(e => e.StartLine))
            {
                string code = ExtractEntryAbsolute(entry);
                if (code.Length > 0)
                {
                    sb.Append(code);
                    sb.AppendLine();
                }
            }
            return sb.ToString();
        }

        // ══════════════════════════════════════════════════════════════════════
        // CACHÉ JSON GENÉRICA
        // ══════════════════════════════════════════════════════════════════════

        /// <summary>Escribe datos JSON con TTL en segundos.</summary>
        public static void WriteCache(string key, string jsonData, int ttlSeconds)
        {
            Log("[LazyLoader] Cache WRITE: " + key + " (TTL=" + ttlSeconds + "s)");
            string dir = Path.Combine(_cacheDir, "cache");
            EnsureDir(dir);
            string filePath = Path.Combine(dir, SanitizeKey(key) + ".json");

            string expiry = DateTime.UtcNow.AddSeconds(ttlSeconds).ToString("o");
            string content = "{\"expiry\":\"" + expiry + "\",\"data\":" + jsonData + "}";

            // Escritura atómica (tmp → rename)
            string tmp = filePath + ".tmp";
            File.WriteAllText(tmp, content, Encoding.UTF8);
            if (File.Exists(filePath)) File.Delete(filePath);
            File.Move(tmp, filePath);
        }

        /// <summary>Lee datos JSON cacheados. Devuelve null si expirado o inexistente.</summary>
        public static string ReadCache(string key)
        {
            string filePath = Path.Combine(_cacheDir, "cache", SanitizeKey(key) + ".json");
            if (!File.Exists(filePath))
            {
                Log("[LazyLoader] Cache MISS: " + key);
                return null;
            }

            try
            {
                string content = File.ReadAllText(filePath, Encoding.UTF8);
                // Parseo ligero del wrapper {"expiry":"...","data":...}
                int expiryStart = content.IndexOf("\"expiry\":\"", StringComparison.Ordinal);
                if (expiryStart < 0) return null;
                expiryStart += 10;
                int expiryEnd = content.IndexOf("\"", expiryStart, StringComparison.Ordinal);
                if (expiryEnd < 0) return null;

                string expiryStr = content.Substring(expiryStart, expiryEnd - expiryStart);
                DateTime expiry;
                if (!DateTime.TryParse(expiryStr, null,
                        System.Globalization.DateTimeStyles.RoundtripKind, out expiry))
                    return null;

                if (expiry <= DateTime.UtcNow)
                {
                    // Expirado
                    Log("[LazyLoader] Cache EXPIRED: " + key);
                    try { File.Delete(filePath); } catch { }
                    return null;
                }

                // Extraer "data":...}
                int dataStart = content.IndexOf("\"data\":", StringComparison.Ordinal);
                if (dataStart < 0) return null;
                dataStart += 7;
                // data va hasta el penúltimo carácter (el último es '}' del wrapper)
                Log("[LazyLoader] Cache HIT: " + key);
                return content.Substring(dataStart, content.Length - dataStart - 1);
            }
            catch
            {
                return null;
            }
        }

        /// <summary>Invalida (borra) una entrada de caché.</summary>
        public static void InvalidateCache(string key)
        {
            Log("[LazyLoader] Cache INVALIDATE: " + key);
            string filePath = Path.Combine(_cacheDir, "cache", SanitizeKey(key) + ".json");
            try { if (File.Exists(filePath)) File.Delete(filePath); } catch { }
        }

        // ══════════════════════════════════════════════════════════════════════
        // MÉTODOS INTERNOS
        // ══════════════════════════════════════════════════════════════════════

        /// <summary>Lee líneas de un archivo con caché en memoria.</summary>
        private static string[] ReadLines(string fullPath)
        {
            string[] lines;
            if (_fileCache.TryGetValue(fullPath, out lines))
                return lines;

            lines = File.ReadAllLines(fullPath, Encoding.UTF8);
            _fileCache[fullPath] = lines;
            return lines;
        }

        /// <summary>Libera la caché de archivos leídos (llamar tras boot).</summary>
        public static void FlushFileCache()
        {
            Log("[LazyLoader] File cache flushed (" + _fileCache.Count + " entries)");
            _fileCache.Clear();
        }

        // ══════════════════════════════════════════════════════════════════════
        // v3.3.0-OPT-7: PROFILER — registra primera invocación de cada función
        // Datos usados para reclasificar fases en futuras versiones.
        // ══════════════════════════════════════════════════════════════════════
        private static readonly Dictionary<string, DateTime> _callProfile =
            new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
        private static DateTime _bootTime = DateTime.UtcNow;

        /// <summary>Registra la primera invocación de una función (llamar desde stubs).</summary>
        public static void ProfileCall(string functionName)
        {
            if (!_callProfile.ContainsKey(functionName))
            {
                _callProfile[functionName] = DateTime.UtcNow;
                double ms = (DateTime.UtcNow - _bootTime).TotalMilliseconds;
                Log("[PROFILE] +" + ms.ToString("F0") + "ms — " + functionName);
            }
        }

        /// <summary>Vuelca el perfil de uso a un archivo para análisis.</summary>
        public static void DumpProfile(string outputPath)
        {
            var sb = new StringBuilder();
            sb.AppendLine("# SysOpt Function Profile — " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            sb.AppendLine("# Boot: " + _bootTime.ToString("HH:mm:ss.fff"));
            foreach (var kv in _callProfile.OrderBy(k => k.Value))
            {
                double ms = (kv.Value - _bootTime).TotalMilliseconds;
                sb.AppendLine("+" + ms.ToString("F0").PadLeft(8) + "ms  " + kv.Key);
            }
            File.WriteAllText(outputPath, sb.ToString(), Encoding.UTF8);
            Log("[PROFILE] Dumped to " + outputPath + " (" + _callProfile.Count + " entries)");
        }

        /// <summary>Número de funciones en el perfil.</summary>
        public static int ProfileCount { get { return _callProfile.Count; } }

        /// <summary>Extrae código de una entrada cuyo SourceFile es relativo a _appDir.</summary>
        private static string ExtractEntry(FunctionEntry entry)
        {
            string fullPath = Path.Combine(_appDir, entry.SourceFile);
            if (!File.Exists(fullPath)) return string.Empty;

            string[] lines = ReadLines(fullPath);
            int start = Math.Max(0, entry.StartLine - 1);
            int end   = Math.Min(lines.Length, entry.EndLine);

            var sb = new StringBuilder((end - start) * 80);
            for (int i = start; i < end; i++)
            {
                sb.AppendLine(lines[i]);
            }
            return sb.ToString();
        }

        /// <summary>Extrae código de una entrada cuyo SourceFile es ruta absoluta (módulos).</summary>
        private static string ExtractEntryAbsolute(FunctionEntry entry)
        {
            if (!File.Exists(entry.SourceFile)) return string.Empty;

            string[] lines = ReadLines(entry.SourceFile);
            int start = Math.Max(0, entry.StartLine - 1);
            int end   = Math.Min(lines.Length, entry.EndLine);

            var sb = new StringBuilder((end - start) * 80);
            for (int i = start; i < end; i++)
            {
                sb.AppendLine(lines[i]);
            }
            return sb.ToString();
        }

        /// <summary>Extrae múltiples entradas agrupadas por archivo.</summary>
        private static string ExtractEntries(List<FunctionEntry> entries)
        {
            var grouped = entries.GroupBy(e => e.SourceFile);
            var sb = new StringBuilder(4096);

            foreach (var group in grouped)
            {
                string fullPath = Path.Combine(_appDir, group.Key);
                if (!File.Exists(fullPath)) continue;

                string[] lines = ReadLines(fullPath);
                foreach (var entry in group.OrderBy(e => e.StartLine))
                {
                    int start = Math.Max(0, entry.StartLine - 1);
                    int end   = Math.Min(lines.Length, entry.EndLine);
                    for (int i = start; i < end; i++)
                    {
                        sb.AppendLine(lines[i]);
                    }
                    sb.AppendLine(); // separador entre funciones
                }
            }
            return sb.ToString();
        }

        /// <summary>
        /// Parsea un archivo .ps1 buscando declaraciones de función y sus rangos.
        /// Usa conteo de llaves { } para determinar el final de cada función.
        /// </summary>
        private static List<FunctionEntry> ParsePs1Functions(string filePath)
        {
            var entries = new List<FunctionEntry>();
            string[] lines = File.ReadAllLines(filePath, Encoding.UTF8);

            string currentName = null;
            int currentStart   = 0;
            int braceDepth     = 0;
            bool inFunction    = false;

            for (int i = 0; i < lines.Length; i++)
            {
                string trimmed = lines[i].TrimStart();

                // Detectar inicio de función (soporta global: y script: scopes)
                if (!inFunction && (trimmed.StartsWith("function ") || trimmed.StartsWith("function\t")))
                {
                    // Extraer nombre: "function global:FuncName {" o "function FuncName("
                    string rest = trimmed.Substring(9).TrimStart();
                    int nameEnd = rest.IndexOfAny(new char[] { ' ', '(', '{', '\t' });
                    if (nameEnd < 0) nameEnd = rest.Length;
                    currentName = rest.Substring(0, nameEnd)
                        .Replace("global:", "")
                        .Replace("script:", "");
                    currentStart = i + 1; // 1-indexed
                    braceDepth = 0;
                    inFunction = false; // aún no encontramos la primera {
                }

                // Contar llaves (ignorar las que están dentro de strings/comments)
                // Aproximación simple pero efectiva para PS1 bien formateado
                bool inString = false;
                bool inComment = false;
                for (int c = 0; c < lines[i].Length; c++)
                {
                    char ch = lines[i][c];
                    if (inComment) break;
                    if (ch == '#' && !inString) { inComment = true; break; }
                    if (ch == '"' || ch == '\'') { inString = !inString; continue; }
                    if (inString) continue;
                    if (ch == '{')
                    {
                        braceDepth++;
                        if (!inFunction && currentName != null) inFunction = true;
                    }
                    else if (ch == '}')
                    {
                        braceDepth--;
                        if (inFunction && braceDepth == 0)
                        {
                            entries.Add(new FunctionEntry
                            {
                                Name         = currentName,
                                SourceFile   = filePath,  // ruta absoluta para módulos
                                StartLine    = currentStart,
                                EndLine      = i + 1,     // 1-indexed inclusive
                                Phase        = "MODULE",
                                RequiredDlls = new string[0]
                            });
                            currentName = null;
                            inFunction  = false;
                        }
                    }
                }
            }
            return entries;
        }

        /// <summary>Parsea un índice JSON cacheado de módulo.</summary>
        private static List<FunctionEntry> ParseCachedIndex(string json, string mainPs1Path)
        {
            var entries = new List<FunctionEntry>();
            try
            {
                // Parseo ligero sin JavaScriptSerializer (evita dependencia)
                int pos = 0;
                while (true)
                {
                    int nStart = json.IndexOf("\"n\":\"", pos, StringComparison.Ordinal);
                    if (nStart < 0) break;
                    nStart += 5;
                    int nEnd = json.IndexOf("\"", nStart, StringComparison.Ordinal);
                    string name = json.Substring(nStart, nEnd - nStart);

                    int sStart = json.IndexOf("\"s\":", nEnd, StringComparison.Ordinal) + 4;
                    int sEnd   = json.IndexOfAny(new char[] { ',', '}' }, sStart);
                    int start  = int.Parse(json.Substring(sStart, sEnd - sStart).Trim());

                    int eStart = json.IndexOf("\"e\":", sEnd, StringComparison.Ordinal) + 4;
                    int eEnd   = json.IndexOfAny(new char[] { ',', '}' }, eStart);
                    int end    = int.Parse(json.Substring(eStart, eEnd - eStart).Trim());

                    entries.Add(new FunctionEntry
                    {
                        Name         = name,
                        SourceFile   = mainPs1Path,
                        StartLine    = start,
                        EndLine      = end,
                        Phase        = "MODULE",
                        RequiredDlls = new string[0]
                    });
                    pos = eEnd;
                }
            }
            catch { return null; }
            return entries;
        }

        // ── Utilidades ────────────────────────────────────────────────────────

        private static void EnsureDir(string path)
        {
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);
        }

        private static string SanitizeKey(string key)
        {
            // Reemplazar caracteres no válidos para nombre de archivo
            var sb = new StringBuilder(key.Length);
            foreach (char c in key)
            {
                if (char.IsLetterOrDigit(c) || c == '-' || c == '_' || c == '.')
                    sb.Append(c);
                else
                    sb.Append('_');
            }
            return sb.ToString();
        }

        private static string EscapeJson(string s)
        {
            return s.Replace("\\", "\\\\").Replace("\"", "\\\"");
        }
    }
}
