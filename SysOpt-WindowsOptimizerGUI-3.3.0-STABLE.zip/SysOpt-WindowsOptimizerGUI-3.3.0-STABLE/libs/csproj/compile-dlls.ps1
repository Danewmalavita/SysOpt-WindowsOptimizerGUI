﻿# SysOpt - Software de optimización del sistema
# Copyright (C) 2026 Danew Malavita
#
# Este programa es software libre bajo los términos de la GPL v3+.
# Consulta el archivo LICENSE o visita <https://www.gnu.org/licenses/>.

# =============================================================================
# compile-dlls.ps1  —  Compila TODAS las DLL de SysOpt desde codigo fuente C#
# Ejecutar desde la carpeta .\libs\ :
#   powershell -ExecutionPolicy Bypass -File compile-dlls.ps1
#
# Auto-descubre todos los .cs de la carpeta y determina referencias adicionales
# segun el contenido del archivo (System.Management, System.Net, etc.)
# =============================================================================

#Requires -Version 5.1

# v3.3.0-OPT-3: Modo merge — compila DLLs agrupadas (18 → 5)
# Ejecutar con:  compile-dlls.ps1 -Merge
param([switch]$Merge)

$ErrorActionPreference = "Stop"


$here   = Split-Path -Parent $MyInvocation.MyCommand.Path   # .\libs\csproj\
$outDir = Split-Path $here -Parent                            # .\libs\  (destino de los .dll)
if (-not (Test-Path $outDir)) { $outDir = $here }             # fallback: si no hay padre, mismo dir

# ── Banner ────────────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "  ============================================================" -ForegroundColor Cyan
Write-Host "    SysOpt — Compilacion automatica de DLL externos           " -ForegroundColor Cyan
Write-Host "  ============================================================" -ForegroundColor Cyan
Write-Host ""

# ── Leer version desde SysOpt.ps1 ────────────────────────────────────────────
# Busca $script:AppVersion = "X.Y.Z" en el .ps1 que está un nivel arriba
$appVersion  = "0.0.0"
$buildDate   = Get-Date -Format "yyyy-MM-dd"
# SysOpt.ps1 esta en la raiz del proyecto (padre de .\libs\)
$ps1Path = Join-Path $outDir "SysOpt.ps1"
if (-not (Test-Path $ps1Path)) {
    $ps1Path = Join-Path (Split-Path $outDir -Parent) "SysOpt.ps1"
}
if (Test-Path $ps1Path) {
    $versionLine = Select-String -Path $ps1Path -Pattern '\$script:AppVersion\s*=\s*"([\d\.]+)"' |
                   Select-Object -First 1
    if ($versionLine -and $versionLine.Matches.Count -gt 0) {
        $appVersion = $versionLine.Matches[0].Groups[1].Value
    }
}
# Convertir "3.2.0" → "3.2.0.0" (AssemblyVersion requiere 4 componentes)
$asmVersion = ($appVersion -split "\.")
while ($asmVersion.Count -lt 4) { $asmVersion += "0" }
$asmVersionStr = $asmVersion[0..3] -join "."

Write-Host "  Version detectada : $appVersion  →  AssemblyVersion $asmVersionStr" -ForegroundColor White
Write-Host ""

# ── Generar AssemblyInfo.cs temporal con la version leida ────────────────────
# Se compila junto con cada .cs y se elimina al finalizar.
# Los .cs fuente NO se modifican nunca.
$asmInfoPath = Join-Path $here "_AssemblyInfo_tmp.cs"
$asmInfoContent = @"
// AUTO-GENERADO por compile-dlls.ps1 — NO editar manualmente
// Generado: $buildDate
using System.Reflection;
[assembly: AssemblyVersion("$asmVersionStr")]
[assembly: AssemblyFileVersion("$asmVersionStr")]
[assembly: AssemblyInformationalVersion("$appVersion")]
[assembly: AssemblyProduct("SysOpt Windows Optimizer GUI")]
[assembly: AssemblyCopyright("SysOpt $((Get-Date).Year)")]
"@
[System.IO.File]::WriteAllText($asmInfoPath, $asmInfoContent, [System.Text.Encoding]::UTF8)
Write-Host "[OK] AssemblyInfo temporal generado: $asmVersionStr" -ForegroundColor Green
Write-Host ""

# ── Localizar csc.exe (NET Framework, compatible PS 5.1) ─────────────────────
$csc = Join-Path ([Runtime.InteropServices.RuntimeEnvironment]::GetRuntimeDirectory()) "csc.exe"
if (-not (Test-Path $csc)) {
    # Fallback: buscar en rutas habituales de .NET Framework
    $candidates = @(
        "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe",
        "$env:WINDIR\Microsoft.NET\Framework\v4.0.30319\csc.exe"
    )
    foreach ($c in $candidates) {
        if (Test-Path $c) { $csc = $c; break }
    }
}

if (-not (Test-Path $csc)) {
    Write-Host "[ERROR] No se encontro csc.exe." -ForegroundColor Red
    Write-Host "        Instala .NET Framework 4.x o ejecuta desde Developer Command Prompt." -ForegroundColor Yellow
    exit 1
}
Write-Host "[OK] csc.exe : $csc" -ForegroundColor Green

# ── Referencias adicionales por DLL ──────────────────────────────────────────
# Mapa: nombre del .cs -> /r: extra que necesita ese archivo
# (las referencias basicas System.dll y System.Core.dll van siempre)
$extraRefs = @{
    "SysOpt.Core.cs"        = @(
        "System.dll",
        "System.Core.dll"
    )
    "SysOpt.Collector.cs"   = @(
        "System.Management.dll",
        "System.dll",
        "System.Core.dll",
        "System.Net.dll",
        "System.Net.NetworkInformation.dll"
    )
    "SysOpt.Cleanup.cs"     = @(
        "System.dll",
        "System.Core.dll"
    )
    "SysOpt.ThemeEngine.cs" = @(
        "PresentationFramework.dll",
        "PresentationCore.dll",
        "WindowsBase.dll",
        "System.Xaml.dll"
    )
    "DiskEngine.cs"         = @(
        "System.dll",
        "System.Core.dll"
    )
    "MemoryHelper.cs"       = @()
    "WseTrim.cs"            = @()
    "SysOpt.Optimizer.cs"   = @(
        "System.dll",
        "System.Core.dll",
        "System.Management.dll",          # WMI: ManagementObjectSearcher (parent PID, disk C:)
        "System.ServiceProcess.dll"       # ServiceController (wuauserv start/stop)
    )
    "SysOpt.StartupManager.cs" = @(
        "System.dll",
        "System.Core.dll"
    )
    "SysOpt.Diagnostics.cs" = @(
        "System.dll",
        "System.Core.dll"
    )
    "SysOpt.Wizard.cs"      = @(
        "System.dll",
        "System.Core.dll"
    )
    "SysOpt.Toast.cs"       = @(
        "PresentationFramework.dll",
        "PresentationCore.dll",
        "WindowsBase.dll",
        "System.Xaml.dll"
    )
    "SysOpt.Breakout.cs"    = @(
        "PresentationFramework.dll",
        "PresentationCore.dll",
        "WindowsBase.dll",
        "System.Xaml.dll"
    )
    "SysOpt.DwmHelper.cs"  = @()
    "SysOpt.Modules.cs"    = @(
        "System.dll",
        "System.Core.dll",
        "System.Web.Extensions.dll",
        "System.IO.Compression.dll",
        "System.IO.Compression.FileSystem.dll"
    )
    "SysOpt.Snapshot.cs"   = @(
        "System.dll",
        "System.Web.Extensions.dll"
    )
    "SysOpt.LazyLoader.cs" = @(
        "System.dll",
        "System.Core.dll"
    )
}

# Mapa: nombre del .cs -> DLLs locales del proyecto que necesita como /r:
# Estas DLLs DEBEN compilarse antes que la que las referencia.
# El orden alfabetico de los .cs lo garantiza actualmente:
#   DiskEngine -> MemoryHelper -> SysOpt.Cleanup -> SysOpt.Collector -> SysOpt.Core -> SysOpt.Diagnostics -> SysOpt.Optimizer -> SysOpt.StartupManager -> SysOpt.ThemeEngine -> WseTrim
$localRefs = @{
    "SysOpt.Optimizer.cs" = @(
        "SysOpt.Core.dll",                # LangEngine, Loc, Formatter
        "SysOpt.Collector.dll",           # SystemDataCollector, RamSnapshot
        "SysOpt.Cleanup.dll",             # CleanupEngine, CleanupResult
        "SysOpt.DiskEngine.dll",          # DiskOptimizer, VolumeInfo, DiskResult
        "SysOpt.MemoryHelper.dll"         # MemoryHelper (P/Invoke: OpenProcess, EmptyWorkingSet)
    )
    "SysOpt.Diagnostics.cs" = @(
        "SysOpt.Core.dll",                # Loc, Formatter, LogEngine
        "SysOpt.Collector.dll"            # SystemDataCollector, SystemSnapshot
    )
    "SysOpt.Wizard.cs" = @(
        "SysOpt.Core.dll",
        "SysOpt.Diagnostics.dll"
    )
    "SysOpt.Modules.cs" = @(
        "SysOpt.Core.dll"                 # ModuleManifest usa LangEngine via Loc
    )
    "SysOpt.LazyLoader.cs" = @(
        "SysOpt.Core.dll"                 # LogEngine para trazas de debug
    )
}

# Mapa: nombre del .cs -> nombre del .dll de salida
# Si el .cs no esta en este mapa se usa el mismo nombre con extension .dll
$outputNames = @{
    "DiskEngine.cs"         = "SysOpt.DiskEngine.dll"
    "MemoryHelper.cs"       = "SysOpt.MemoryHelper.dll"
    "WseTrim.cs"            = "SysOpt.WseTrim.dll"
    "SysOpt.Core.cs"        = "SysOpt.Core.dll"
    "SysOpt.Collector.cs"      = "SysOpt.Collector.dll"
    "SysOpt.Cleanup.cs"        = "SysOpt.Cleanup.dll"
    "SysOpt.ThemeEngine.cs" = "SysOpt.ThemeEngine.dll"
    "SysOpt.Optimizer.cs"   = "SysOpt.Optimizer.dll"
    "SysOpt.StartupManager.cs" = "SysOpt.StartupManager.dll"
    "SysOpt.Diagnostics.cs"    = "SysOpt.Diagnostics.dll"
    "SysOpt.Wizard.cs"        = "SysOpt.Wizard.dll"
    "SysOpt.Toast.cs"          = "SysOpt.Toast.dll"
    "SysOpt.Breakout.cs"       = "SysOpt.Breakout.dll"
    "SysOpt.DwmHelper.cs"      = "SysOpt.DwmHelper.dll"
    "SysOpt.Modules.cs"        = "SysOpt.Modules.dll"
    "SysOpt.Snapshot.cs"       = "SysOpt.Snapshot.dll"
    "SysOpt.LazyLoader.cs"     = "SysOpt.LazyLoader.dll"
}

# ── Auto-descubrir todos los .cs (excluir archivos _old / _bak / Copy) ────────
$sources = Get-ChildItem -Path $here -Filter "*.cs" |
    Where-Object { $_.Name -notmatch "_old|_bak|_copy|-Copy|\.Test\.|_AssemblyInfo" } |
    Sort-Object Name

if ($sources.Count -eq 0) {
    Write-Host "[WARN] No se encontraron archivos .cs en $here" -ForegroundColor Yellow
    exit 0
}

Write-Host ""
Write-Host "  Archivos .cs encontrados: $($sources.Count)" -ForegroundColor White
foreach ($s in $sources) {
    Write-Host "    · $($s.Name)" -ForegroundColor Gray
}
Write-Host ""

# ── Compilar ──────────────────────────────────────────────────────────────────
$ok   = 0
$fail = 0
$skip = 0

foreach ($src in $sources) {

    # Nombre de salida
    $outName = if ($outputNames.ContainsKey($src.Name)) {
        $outputNames[$src.Name]
    } else {
        [System.IO.Path]::GetFileNameWithoutExtension($src.Name) + ".dll"
    }
    $outPath = Join-Path $outDir $outName   # DLL va a .\libs\, no a .\libs\csproj\

    Write-Host "──────────────────────────────────────────────────────────────" -ForegroundColor DarkGray
    Write-Host "[BUILD] $($src.Name)  →  $outName" -ForegroundColor Cyan

    # Construir lista de /r: adicionales
    $refs = @()
    if ($extraRefs.ContainsKey($src.Name)) {
        foreach ($ref in $extraRefs[$src.Name]) {
            # Primero buscar en el runtime dir, luego en GAC
            $refFull = Join-Path ([Runtime.InteropServices.RuntimeEnvironment]::GetRuntimeDirectory()) $ref
            if (Test-Path $refFull) {
                $refs += "/r:$refFull"
            } else {
                # Intentar resolver desde GAC via [System.Reflection.Assembly]
                try {
                    $asmName = [System.IO.Path]::GetFileNameWithoutExtension($ref)
                    $asm = [System.Reflection.Assembly]::LoadWithPartialName($asmName)
                    if ($asm) { $refs += "/r:$($asm.Location)" }
                } catch {}
            }
        }
    }

    # Resolver referencias LOCALES (DLLs del propio proyecto)
    if ($localRefs.ContainsKey($src.Name)) {
        foreach ($localRef in $localRefs[$src.Name]) {
            $localPath = Join-Path $outDir $localRef
            if (Test-Path $localPath) {
                $refs += "/r:$localPath"
                Write-Host "    [REF] $localRef" -ForegroundColor DarkCyan
            } else {
                Write-Host "    [WARN] Referencia local no encontrada: $localRef" -ForegroundColor Yellow
                Write-Host "           Asegurar que se compila antes que $($src.Name)" -ForegroundColor Yellow
            }
        }
    }

    # Argumentos del compilador — incluye AssemblyInfo temporal para versionar el DLL
    $cscArgs = @(
        "/target:library",
        "/optimize+",
        "/nologo",
        "/nowarn:1701,1702",          # suprimir warnings de versión de assembly
        "/out:$outPath"
    ) + $refs + @($src.FullName, $asmInfoPath)

    # Ejecutar compilador
    $output = & $csc @cscArgs 2>&1

    # Mostrar output del compilador
    $hasError = $false
    foreach ($line in $output) {
        $lineStr = "$line"
        if ($lineStr -match ": error ") {
            Write-Host "  $lineStr" -ForegroundColor Red
            $hasError = $true
        } elseif ($lineStr -match ": warning ") {
            Write-Host "  $lineStr" -ForegroundColor Yellow
        } elseif ($lineStr.Trim() -ne "") {
            Write-Host "  $lineStr" -ForegroundColor DarkGray
        }
    }

    # Resultado
    if ((Test-Path $outPath) -and -not $hasError) {
        $sz      = (Get-Item $outPath).Length
        $szKb    = [math]::Round($sz / 1KB, 1)
        $ts      = (Get-Item $outPath).LastWriteTime.ToString("HH:mm:ss")
        Write-Host "[OK] $outName — ${szKb} KB  ($ts)" -ForegroundColor Green
        $ok++
    } else {
        Write-Host "[FAIL] $outName — revisa los errores anteriores" -ForegroundColor Red
        $fail++
    }
}

# ═══════════════════════════════════════════════════════════════════════════════
# v3.3.0-OPT-3: Modo MERGE — Compilación agrupada (18 DLLs → 5)
# Reduce overhead I/O de carga: cada Load = abrir archivo + parsear PE + JIT
# Grupos:
#   SysOpt.Foundation.dll = MemoryHelper + Core + DiskEngine + WseTrim + DwmHelper
#   SysOpt.Features.dll   = Collector + Cleanup + Diagnostics + Optimizer + Modules + Snapshot
#   SysOpt.UI.dll         = ThemeEngine + Toast + Wizard + StartupManager
#   SysOpt.LazyLoader.dll (separado — necesario en boot temprano)
#   SysOpt.Breakout.dll   (separado — juego opcional, carga aislada)
# ═══════════════════════════════════════════════════════════════════════════════
if ($Merge) {
    Write-Host ""
    Write-Host "  ============================================================" -ForegroundColor Magenta
    Write-Host "    Modo MERGE — Compilación agrupada (18 → 5 DLLs)          " -ForegroundColor Magenta
    Write-Host "  ============================================================" -ForegroundColor Magenta
    Write-Host ""

    $mergeOk = 0; $mergeFail = 0

    $mergeGroups = @(
        @{
            Name    = "SysOpt.Foundation"
            Sources = @("MemoryHelper.cs","SysOpt.Core.cs","DiskEngine.cs","WseTrim.cs","SysOpt.DwmHelper.cs")
            Refs    = @("System.dll","System.Core.dll")
            Local   = @()
        },
        @{
            Name    = "SysOpt.Features"
            Sources = @("SysOpt.Collector.cs","SysOpt.Cleanup.cs","SysOpt.Diagnostics.cs","SysOpt.Optimizer.cs","SysOpt.Modules.cs","SysOpt.Snapshot.cs")
            Refs    = @("System.dll","System.Core.dll","System.Management.dll","System.Net.dll","System.Net.NetworkInformation.dll","System.ServiceProcess.dll","System.Web.Extensions.dll","System.IO.Compression.dll","System.IO.Compression.FileSystem.dll")
            Local   = @("SysOpt.Foundation.dll")
        },
        @{
            Name    = "SysOpt.UI"
            Sources = @("SysOpt.ThemeEngine.cs","SysOpt.Toast.cs","SysOpt.Wizard.cs","SysOpt.StartupManager.cs")
            Refs    = @("PresentationFramework.dll","PresentationCore.dll","WindowsBase.dll","System.Xaml.dll","System.dll","System.Core.dll")
            Local   = @("SysOpt.Foundation.dll","SysOpt.Features.dll")
        }
    )

    foreach ($grp in $mergeGroups) {
        Write-Host "──────────────────────────────────────────────────────────────" -ForegroundColor DarkGray
        $srcNames = $grp.Sources -join " + "
        Write-Host "[MERGE] $($grp.Name).dll  ←  $srcNames" -ForegroundColor Magenta

        $mergeOutPath = Join-Path $outDir "$($grp.Name).dll"
        $mergeSrcs = @()
        $missing = $false
        foreach ($s in $grp.Sources) {
            $sp = Join-Path $here $s
            if (Test-Path $sp) { $mergeSrcs += $sp }
            else { Write-Host "    [WARN] $s no encontrado" -ForegroundColor Yellow; $missing = $true }
        }
        if ($missing) { Write-Host "[SKIP] Fuentes incompletas" -ForegroundColor Yellow; $mergeFail++; continue }

        # Resolver referencias externas
        $mergeRefs = @()
        foreach ($ref in $grp.Refs) {
            $refFull = Join-Path ([Runtime.InteropServices.RuntimeEnvironment]::GetRuntimeDirectory()) $ref
            if (Test-Path $refFull) { $mergeRefs += "/r:$refFull" }
            else {
                try {
                    $asmN = [System.IO.Path]::GetFileNameWithoutExtension($ref)
                    $asm = [System.Reflection.Assembly]::LoadWithPartialName($asmN)
                    if ($asm) { $mergeRefs += "/r:$($asm.Location)" }
                } catch {}
            }
        }
        # Resolver referencias locales (DLLs ya compiladas en este modo merge)
        foreach ($lr in $grp.Local) {
            $lrPath = Join-Path $outDir $lr
            if (Test-Path $lrPath) {
                $mergeRefs += "/r:$lrPath"
                Write-Host "    [REF] $lr" -ForegroundColor DarkCyan
            } else {
                Write-Host "    [WARN] Ref local no encontrada: $lr" -ForegroundColor Yellow
            }
        }

        $mergeArgs = @("/target:library","/optimize+","/nologo","/nowarn:1701,1702","/out:$mergeOutPath") + $mergeRefs + $mergeSrcs + @($asmInfoPath)
        $mergeOutput = & $csc @mergeArgs 2>&1
        $mergeHasError = $false
        foreach ($line in $mergeOutput) {
            $ls = "$line"
            if ($ls -match ": error ") { Write-Host "  $ls" -ForegroundColor Red; $mergeHasError = $true }
            elseif ($ls -match ": warning ") { Write-Host "  $ls" -ForegroundColor Yellow }
            elseif ($ls.Trim() -ne "") { Write-Host "  $ls" -ForegroundColor DarkGray }
        }
        if ((Test-Path $mergeOutPath) -and -not $mergeHasError) {
            $msz = [math]::Round((Get-Item $mergeOutPath).Length / 1KB, 1)
            Write-Host "[OK] $($grp.Name).dll — ${msz} KB" -ForegroundColor Green
            $mergeOk++
        } else {
            Write-Host "[FAIL] $($grp.Name).dll" -ForegroundColor Red
            $mergeFail++
        }
    }

    Write-Host ""
    Write-Host "  ════════════════════════════════════════════════════════════" -ForegroundColor Magenta
    Write-Host "    Merge: $mergeOk OK" -ForegroundColor Green -NoNewline
    if ($mergeFail -gt 0) { Write-Host "  $mergeFail FAIL" -ForegroundColor Red -NoNewline }
    Write-Host ""
    Write-Host "  ════════════════════════════════════════════════════════════" -ForegroundColor Magenta
    Write-Host "  NOTA: Para usar DLLs merged, actualiza SysOpt.ps1" -ForegroundColor DarkGray
    Write-Host "        Load-SysOptDll apunta a los nombres individuales" -ForegroundColor DarkGray
    Write-Host "        Foundation = MemoryHelper+Core+DiskEngine+WseTrim+DwmHelper" -ForegroundColor DarkGray
    Write-Host "        Features   = Collector+Cleanup+Diagnostics+Optimizer+Modules+Snapshot" -ForegroundColor DarkGray
    Write-Host "        UI         = ThemeEngine+Toast+Wizard+StartupManager" -ForegroundColor DarkGray
    Write-Host ""
}

# ── Limpiar AssemblyInfo temporal ─────────────────────────────────────────────
try {
    if (Test-Path $asmInfoPath) {
        Remove-Item $asmInfoPath -Force
        Write-Host ""
        Write-Host "[OK] AssemblyInfo temporal eliminado." -ForegroundColor DarkGray
    }
} catch {}

# ── Resumen final ──────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "  ============================================================" -ForegroundColor Cyan
Write-Host "    Resultado:  v$appVersion  —  " -ForegroundColor Cyan -NoNewline
Write-Host "$ok OK  " -ForegroundColor Green -NoNewline
if ($fail -gt 0) {
    Write-Host "$fail ERRORES  " -ForegroundColor Red -NoNewline
}
Write-Host ""
Write-Host "  ============================================================" -ForegroundColor Cyan
Write-Host ""

if ($fail -gt 0) { exit 1 } else { exit 0 }