﻿# SysOpt - Software de optimización del sistema
# Copyright (C) 2026 Danew Malavita
#
# Este programa es software libre bajo los términos de la GPL v3+.
# Consulta el archivo LICENSE o visita <https://www.gnu.org/licenses/>.

# =============================================================================
# SysOpt.Functions.bundle.ps1
# Lazy-loaded function bundle -- todas las funciones GUI secundarias.
# Se carga bajo demanda la primera vez que se llama cualquiera de ellas.
# NOTA: Este archivo se auto-desbloquea desde SysOpt.ps1 (no necesita Unblock manual)
# =============================================================================

# --- Get-SnapshotEntriesAsync ----------------------------------------------
function global:Get-SnapshotEntriesAsync {
    param(
        [string]$FilePath,
        [string]$OperationTitle = ((T "SnapLoadingMsg")),
        [scriptblock]$OnComplete,
        [scriptblock]$OnError
    )

    # (carga snapshot B) pise el estado de la primera (snapshot A) antes de que
    # su DispatcherTimer haya terminado. $script:ExportState era compartido y se
    # reiniciaba aquí, corrompiendo la condición de parada del timer anterior.
    $localExportState = [hashtable]::Synchronized(@{
        Phase      = ((T "SnapReadingFile"))
        Progress   = 0
        ItemsDone  = 0
        ItemsTotal = 0
        Done       = $false
        Error      = ""
        Result     = $null
    })

    # Generar ID único para esta tarea (puede haber varias en cadena: A luego B)
    $script:TaskIdSeq++
    $entTaskId = "snap-ent-$($script:TaskIdSeq)"
    Register-Task -Id $entTaskId -Name $OperationTitle -Icon "$([char]::ConvertFromUtf32(0x1F4C1))" -IconBg (Get-TC 'BgInput' '#1A2A3A') | Out-Null

    # -- [FIFO-02] FIFO streaming load via JsonTextReader + ConcurrentQueue ---
    $entState = [hashtable]::Synchronized(@{
        Queue    = [System.Collections.Concurrent.ConcurrentQueue[object]]::new()
        FeedDone = $false
        Error    = ""
        Total    = 0   # estimado, desconocido hasta parsear
    })

    # [i18n] Pre-resolve T() for bgEnt background runspace
    # [i18n] Pre-resolve T() -- DLL handles intermediate phases internally
    $_bgE = @{
        ReadingFile = (T 'SnapReadingFile' 'Leyendo archivo')
        Completed   = (T 'PhaseCompleted' 'Completado')
    }

    $bgEnt = {
        param($EntState, $ExportState, $FilePath, $_bgE)
        # -- [DLL-SNAP] Streaming nativo via SysOpt.Snapshot.dll --
        try {
            $ExportState.Phase = $_bgE.ReadingFile; $ExportState.Progress = 10
            $count = [SysOpt.Snapshot.SnapshotReader]::StreamEntriesToQueue($FilePath, $EntState.Queue, $null)
            $ExportState.ItemsDone  = $count
            $ExportState.ItemsTotal = $count
            $ExportState.Progress   = 100
            $ExportState.Phase      = $_bgE.Completed
        } catch {
            $EntState.Error    = $_.Exception.Message
            $ExportState.Error = $_.Exception.Message
        } finally {
            $EntState.FeedDone = $true
            $ExportState.Done  = $true
        }
    }

    $ctxEnt = New-PooledPS
    $ps = $ctxEnt.PS
    [void]$ps.AddScript($bgEnt)
    [void]$ps.AddParameter("EntState",    $entState)
    [void]$ps.AddParameter("ExportState", $localExportState)
    [void]$ps.AddParameter("FilePath",    $FilePath)
    [void]$ps.AddParameter("_bgE",        $_bgE)
    $async = $ps.BeginInvoke()

    $prog = Show-ExportProgressDialog
    if ($null -ne $prog.Title) { $prog.Title.Text = $OperationTitle }
    $prog.Window.Show()

    if ($null -ne $script:_entTimer) { try { $script:_entTimer.Stop() } catch {} }
    $t = New-Object System.Windows.Threading.DispatcherTimer
    $t.Interval = [TimeSpan]::FromMilliseconds(150)
    # [FIX-RACE] NO guardar en $script:_ent* -- capturar todo en variables locales
    # que el closure del tick vea a través del scope de la función, no del script.
    $script:_entTimer      = $t   # solo para poder detenerlo desde afuera si fuera necesario

    $localProg       = $prog
    $localPs         = $ps
    $localCtx        = $ctxEnt
    $localAsync      = $async
    $localOnComplete = $OnComplete
    $localOnError    = $OnError
    $localEntState   = $entState
    $localAccum      = [System.Collections.Generic.List[object]]::new()
    $localTaskId     = $entTaskId
    $localTimer      = $t

    # ($localExportState, $localEntState, $localAccum, etc.) en el scriptblock.
    # Sin esto, PowerShell resuelve esas variables en el scope del script al ejecutar
    # el tick, donde valen $null -- causando "You cannot call a method on a null-valued
    # expression" en $entSt.Queue.TryDequeue().
    $tickBlock = {
        $st    = $localExportState
        $pg    = $localProg
        $pct   = [int]$st.Progress
        $entSt = $localEntState

        # [FIFO] Drenar queue en el tick del UI -- procesa lotes sin bloquear
        $item    = $null
        $drained = 0
        if ($null -ne $entSt -and $null -ne $entSt.Queue) {
            # [OPT] Batch adaptativo para snapshot load
            $drainLimit = [math]::Min(1000, [math]::Max(200, $entSt.Queue.Count + $drained))
            while ($drained -lt $drainLimit -and $entSt.Queue.TryDequeue([ref]$item)) {
                $localAccum.Add($item)
                $item = $null
                $drained++
            }
        }

        $cntStr = "$($localAccum.Count) $(T 'SnapEntriesRead' 'entradas leídas')"
        Update-ProgressDialog $pg $pct $st.Phase $cntStr
        Update-Task -Id $localTaskId -Pct $pct -Detail $cntStr

        if ($st.Done -and $entSt.FeedDone -and $entSt.Queue.IsEmpty) {
            $localTimer.Stop()
            Close-ProgressDialog $localProg
            try { $localPs.EndInvoke($localAsync) | Out-Null } catch {}
            Dispose-PooledPS $localCtx
            [System.GC]::Collect(2, [System.GCCollectionMode]::Forced, $true, $true)
            [System.GC]::WaitForPendingFinalizers()
            try {
                [System.Runtime.GCSettings]::LargeObjectHeapCompactionMode = `
                    [System.Runtime.GCLargeObjectHeapCompactionMode]::CompactOnce
                [System.GC]::Collect()
            } catch {}

            if ($st.Error -ne "") {
                Complete-Task -Id $localTaskId -IsError -Detail $st.Error
                if ($null -ne $localOnError) { & $localOnError $st.Error }
            } else {
                $nEnt = $localAccum.Count
                Complete-Task -Id $localTaskId -Detail "$nEnt $((T 'SnapEntriesLoaded' 'entradas cargadas'))"
                if ($null -ne $localOnComplete) { & $localOnComplete $localAccum }
            }
        }
    }.GetNewClosure()
    $t.Add_Tick($tickBlock)
    $t.Start()
}

# --- Load-SnapshotList -----------------------------------------------------
function global:Load-SnapshotList {
    Write-Log "[SNAP] Load-SnapshotList invocada" -Level "DBG"
    $snapDir   = $script:SnapshotDir
    $jsonFiles = @()
    if (Test-Path $snapDir) {
        $jsonFiles = @(Get-ChildItem -Path $snapDir -Filter "*.json" -ErrorAction SilentlyContinue |
                       Sort-Object LastWriteTime)
    }

    if ($jsonFiles.Count -eq 0) {
        $lbSnapshots.ItemsSource        = [System.Collections.Generic.List[object]]::new()
        $txtSnapshotDetailTitle.Text    = (T "SnapSelectToView")
        $txtSnapshotDetailMeta.Text     = ""
        $lbSnapshotDetail.ItemsSource   = $null
        $chkSnapshotSelectAll.IsChecked = $false
        $txtSnapshotStatus.Text         = (T "SnapNoneSaved")
        Update-SnapshotCheckState
        return
    }

    $txtSnapshotStatus.Text = "$([char]0x23F3) $((T "SnapLoadingMsg"))"
    Register-Task -Id "snap-list" -Name (T "SnapLoadingHistory") -Icon "$([char]::ConvertFromUtf32(0x1F4CB))" -IconBg (Get-TC 'HdrBtnBg' '#1A2040') | Out-Null

    $filePaths = [System.Collections.Generic.List[string]]::new()
    foreach ($f in $jsonFiles) { $filePaths.Add($f.FullName) }

    $script:LoadSnapState = [hashtable]::Synchronized(@{
        Phase = (T "PhaseStarting" "Iniciando..."); Progress = 0; ItemsDone = 0; ItemsTotal = $filePaths.Count
        Done = $false; Error = ""
        Results = [System.Collections.Concurrent.ConcurrentBag[object]]::new()
    })

    # [i18n] Pre-resolve T() -- background runspaces cannot access T()
    $_bgL = @{
        RootFolders = (T 'SnapRootFolders' 'carpetas raíz')
        Completed   = (T 'PhaseCompleted' 'Completado')
        Reading     = (T 'SnapReadingFile' 'Leyendo')
    }

    $bgLoad = {
        param($State, $FilePaths, $_bgL)
        # -- [DLL-SNAP] Metadata nativa via SysOpt.Snapshot.dll --
        try {
            $total = $FilePaths.Count
            for ($i = 0; $i -lt $total; $i++) {
                $fp = $FilePaths[$i]
                $State.Phase     = "$($_bgL.Reading) $([System.IO.Path]::GetFileName($fp))..."
                $State.ItemsDone = $i
                $State.Progress  = [int](($i / $total) * 92)
                try {
                    $m = [SysOpt.Snapshot.SnapshotReader]::ReadMeta($fp)
                    $State.Results.Add(@{
                        FilePath   = $fp
                        Label      = $m.Label
                        RootPath   = $m.RootPath
                        DateStr    = $m.Date
                        EntryCount = $m.EntryCount
                        TotalBytes = $m.TotalBytes
                        RootCount  = $m.RootCount
                        SummaryStr = "$($m.RootCount) $($_bgL.RootFolders) * $($m.EntryCount) total * $([Formatter]::FormatBytes($m.TotalBytes))"
                    })
                } catch {}
            }
            $State.Phase = $_bgL.Completed; $State.Progress = 100; $State.ItemsDone = $total
            $State.Done = $true
        } catch { $State.Error = $_.Exception.Message; $State.Done = $true }
    }

    $ctx = New-PooledPS
    $ps = $ctx.PS
    [void]$ps.AddScript($bgLoad)
    [void]$ps.AddParameter("State",     $script:LoadSnapState)
    [void]$ps.AddParameter("FilePaths", $filePaths)
    [void]$ps.AddParameter("_bgL",      $_bgL)
    $async = $ps.BeginInvoke()

    $prog = Show-ExportProgressDialog
    if ($null -ne $prog.Title)  { $prog.Title.Text = (T "SnapLoadingHistory" "Cargando historial de snapshots") }
    if ($null -ne $prog.Phase)  { $prog.Phase.Text = (T "SnapReadingFiles") }
    $prog.Window.Show()

    Write-Log "[SNAP] Encontrados $($filePaths.Count) archivos snapshot" -Level "DBG"
    if ($null -ne $script:_loadTimer) { try { $script:_loadTimer.Stop() } catch {} }
    $t = New-Object System.Windows.Threading.DispatcherTimer
    $t.Interval = [TimeSpan]::FromMilliseconds(150)
    $script:_loadTimer  = $t
    $script:_loadProg   = $prog
    $script:_loadPs     = $ps
    $script:_loadCtx    = $ctx
    $script:_loadAsync  = $async
    $script:_loadFiles  = $filePaths

    $t.Add_Tick({
        $st  = $script:LoadSnapState
        $pg  = $script:_loadProg
        $pct = [int]$st.Progress
        $cntStr = if ($st.ItemsTotal -gt 0) { "$($st.ItemsDone) / $($st.ItemsTotal) snapshots" } else { "" }
        Update-ProgressDialog $pg $pct $st.Phase $cntStr
        Update-Task -Id "snap-list" -Pct $pct -Detail $cntStr

        if ($st.Done) {
            $script:_loadTimer.Stop()
            Close-ProgressDialog $script:_loadProg
            try { $script:_loadPs.EndInvoke($script:_loadAsync) | Out-Null } catch {}
            Dispose-PooledPS $script:_loadCtx

            # Reconstruir lista en el orden original (por fecha desc)
            $map = @{}
            foreach ($r in $st.Results) { $map[$r.FilePath] = $r }
            $ordered = [System.Collections.Generic.List[object]]::new()
            foreach ($fp in $script:_loadFiles) {
                if ($map.ContainsKey($fp)) {
                    $r = $map[$fp]
                    $ordered.Add((New-Object PSObject -Property ([ordered]@{
                        FilePath   = $r.FilePath;   Label      = $r.Label
                        RootPath   = $r.RootPath;   DateStr    = $r.DateStr
                        EntryCount = $r.EntryCount; TotalBytes = $r.TotalBytes
                        RootCount  = $r.RootCount;  SummaryStr = $r.SummaryStr
                        IsChecked  = $false
                    })))
                }
            }
            $lbSnapshots.ItemsSource        = $ordered
            $txtSnapshotDetailTitle.Text    = (T "SnapSelectToView" "Selecciona un snapshot para ver sus carpetas")
            $txtSnapshotDetailMeta.Text     = ""
            $lbSnapshotDetail.ItemsSource   = $null
            $chkSnapshotSelectAll.IsChecked = $false
            $n = $ordered.Count
            $txtSnapshotStatus.Text = if ($n -eq 0) { (T "SnapNoneSaved") } else { "$n $((T "SnapAvailable"))" }
            Update-SnapshotCheckState
            Invoke-AggressiveGC
            if ($st.Error -ne "") {
                $txtSnapshotStatus.Text = "$((T "SnapLoadError")): $($st.Error)"
                Complete-Task -Id "snap-list" -IsError -Detail $st.Error
            } else {
                Complete-Task -Id "snap-list" -Detail "$n $(T 'SnapLoaded' 'snapshot(s) cargados')"
            }
        }
    })
    $t.Start()
}

# --- Show-AboutWindow ------------------------------------------------------
function global:Show-AboutWindow {
    $aboutXaml = [XamlLoader]::Load($script:XamlFolder, "AboutWindow")
    $aboutXaml = $ExecutionContext.InvokeCommand.ExpandString($aboutXaml)
    try {
        $aboutReader = [System.Xml.XmlNodeReader]::new([xml]$aboutXaml)
        $aboutWin    = [Windows.Markup.XamlReader]::Load($aboutReader)
        $aboutWin.Owner = $window

        # -- Custom title bar: DragMove + close --
        $aboutTitleBar = $aboutWin.FindName("titleBarAbout")
        if ($null -ne $aboutTitleBar) { $aboutTitleBar.Add_MouseLeftButtonDown({ $aboutWin.DragMove() }.GetNewClosure()) }
        $btnTitleCloseAbout = $aboutWin.FindName("btnTitleCloseAbout")
        if ($null -ne $btnTitleCloseAbout) { $btnTitleCloseAbout.Add_Click({ $aboutWin.Close() }.GetNewClosure()) }
        $aboutWin.Add_Closed({ try { $window.Activate() } catch {} })

        # Cargar logo en la ventana about también
        $aboutLogoCtrl = $aboutWin.FindName("aboutLogo")
        if ($null -ne $imgLogo -and $null -ne $imgLogo.Source -and $null -ne $aboutLogoCtrl) {
            $aboutLogoCtrl.Source = $imgLogo.Source
        }

        $btnAboutClose = $aboutWin.FindName("btnAboutClose")
        $btnAboutClose.Add_Click({ $aboutWin.Close() })

        # Enlace GitHub funcional
        $lnkGh = $aboutWin.FindName("lnkGithub")
        if ($null -ne $lnkGh) {
            $lnkGh.Add_RequestNavigate({
                param($s, $e)
                Start-Process $e.Uri.AbsoluteUri
                $e.Handled = $true
            })
        }

        $aboutWin.ShowDialog() | Out-Null
    } catch {
        Show-ThemedDialog -Title "Error" `
            -Message "$((T "ErrNewsWindow")):`n$($_.Exception.Message)" -Type "error"
    }
}

# --- Show-BreakoutGame -----------------------------------------------------
function global:Show-BreakoutGame {
    # -- Easter Egg: Atari Breakout (proceso aislado) --
    # Runs in a separate powershell.exe process so the game loop
    # never competes with SysOpt's UI thread, Dispatcher or GC.

    # Resolve absolute paths
    $brkDll  = (Join-Path $script:_libsDir   "SysOpt.Breakout.dll").Replace("'","''")
    $brkXaml = (Join-Path $script:XamlFolder "BreakoutWindow.xaml").Replace("'","''")

    # Collect theme colors + lang strings (baked into the child script)
    $cBg     = Get-TC 'BgDeep'       '#0D0F1A'
    $cBall   = Get-TC 'TextPrimary'  '#E8EAF6'
    $cPaddle = Get-TC 'AccentBlue'   '#5BA3FF'
    $cHud    = Get-TC 'TextMuted'    '#6B7494'
    $cAccent = Get-TC 'AccentBlue'   '#5BA3FF'
    $cBorder = Get-TC 'BorderSubtle' '#252B40'

    $sPlay  = $LangRS.BrkClickToPlay
    $sCont  = $LangRS.BrkClickContinue
    $sOver  = $LangRS.BrkGameOver
    $sWin   = $LangRS.BrkYouWin
    $sScore = $LangRS.BrkScore
    $sLives = $LangRS.BrkLives
    $sPts   = $LangRS.BrkPts

    # Build self-contained script -- all deps resolved, no external refs
    $code = @"
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -Path '$brkDll'
[xml]`$x = Get-Content -LiteralPath '$brkXaml' -Encoding UTF8
`$r = [System.Xml.XmlNodeReader]::new(`$x)
`$w = [System.Windows.Markup.XamlReader]::Load(`$r)
`$titleBarBrk = `$w.FindName('titleBarBrk')
if (`$null -ne `$titleBarBrk) { `$titleBarBrk.Add_MouseLeftButtonDown({ `$w.DragMove() }) }
`$btnCloseBrk = `$w.FindName('btnTitleCloseBrk')
if (`$null -ne `$btnCloseBrk) { `$btnCloseBrk.Add_Click({ `$w.Close() }) }
`$w.Topmost = `$true
`$w.Add_ContentRendered({ `$w.Topmost = `$false })
`$c = `$w.FindName('gameCanvas')
`$e = [SysOpt.Breakout.BreakoutEngine]::new()
`$e.Init(`$c,'$cBg','$cBall','$cPaddle','$cHud','$cAccent','$cBorder','$sPlay','$sCont','$sOver','$sWin','$sScore','$sLives','$sPts')
`$w.Add_Closed({ `$e.Stop() })
[void]`$w.ShowDialog()
"@

    # Encode as Base64 to avoid all escaping issues on the command line
    $bytes = [System.Text.Encoding]::Unicode.GetBytes($code)
    $enc   = [Convert]::ToBase64String($bytes)

    # Fire & forget -- completely isolated process
    Start-Process powershell.exe -ArgumentList @(
        '-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden',
        '-EncodedCommand', $enc
    ) -WindowStyle Hidden
}

# --- Show-DiagnosticReport -------------------------------------------------
function global:Show-DiagnosticReport {
    param([hashtable]$Report)

    $diagXaml = [XamlLoader]::Load($script:XamlFolder, "DiagnosticWindow")
    $diagXaml = $ExecutionContext.InvokeCommand.ExpandString($diagXaml)

    $dReader  = [System.Xml.XmlNodeReader]::new([xml]$diagXaml)
    $dWindow  = [Windows.Markup.XamlReader]::Load($dReader)
    $diagStartTime = Get-Date

    # -- Construir DiagInput desde hashtable ----------------------------------
    $input = New-Object SysOpt.Diagnostics.DiagInput
    foreach ($key in $Report.Keys) {
        try {
            $prop = $input.GetType().GetProperty($key)
            if ($prop) {
                $val = $Report[$key]
                $t = $prop.PropertyType
                if     ($t -eq [int])    { $val = [int]$val }
                elseif ($t -eq [double]) { $val = [double]$val }
                elseif ($t -eq [string]) { $val = [string]$val }
                elseif ($t -eq [bool])   { $val = [bool]$val }
                $prop.SetValue($input, $val, $null)
            }
        } catch { }
    }

    # -- v3.3.0-Phase4: Parallel data collection via RunspacePool ------------
    # 5 independent collectors run simultaneously (~13s -> ~3-5s)
    # Bottleneck = Windows Update COM (~3-5s), everything else overlaps
    if (-not $input.ComputerName) { $input.ComputerName = $env:COMPUTERNAME }

    # -- Collector 1: CIM (OS, CPU, Disk, SMART, BootEvent) --------------
    $sbCIM = {
        $r = @{}
        try {
            $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
            if ($os) {
                $r.OsCaption  = $os.Caption
                $r.RamTotalKB = $os.TotalVisibleMemorySize
                $r.RamFreeKB  = $os.FreePhysicalMemory
                $r.BootTime   = $os.LastBootUpTime
            }
        } catch {}
        try { $r.CpuName = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue).Name } catch {}
        try {
            $d = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'" -ErrorAction SilentlyContinue
            if ($d) { $r.DiskSize = $d.Size; $r.DiskFree = $d.FreeSpace }
        } catch {}
        try {
            $sm = Get-CimInstance -Namespace "root\wmi" -ClassName MSStorageDriver_FailurePredictStatus -ErrorAction SilentlyContinue
            $r.SmartFail = if ($sm) { [bool]$sm[0].PredictFailure } else { $null }
        } catch { $r.SmartFail = $null }
        try {
            $ev = Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Diagnostics-Performance/Operational';Id=100} -MaxEvents 1 -ErrorAction SilentlyContinue
            if ($ev) { $r.BootMs = $ev.Properties[1].Value }
        } catch {}
        $r
    }

    # -- Collector 2: Services (running, bloat, critical) ----------------
    $sbServices = {
        $r = @{}
        try {
            $all = Get-Service -ErrorAction SilentlyContinue
            $running = @($all | Where-Object { $_.Status -eq 'Running' })
            $r.RunningCount = $running.Count
            $bloat = @('DiagTrack','dmwappushservice','MapsBroker','lfsvc','SharedAccess','WMPNetworkSvc','WerSvc','RetailDemo','wisvc','PhoneSvc')
            $r.BloatCount = @($running | Where-Object { $bloat -contains $_.ServiceName }).Count
            # Critical services (default 10 -- AV adjustment in main thread)
            $crit = @('wuauserv','WinDefend','mpssvc','BFE','EventLog','Dhcp','Dnscache','LanmanWorkstation','Schedule','Winmgmt')
            $cs = @($all | Where-Object { $crit -contains $_.Name })
            $r.CritTotal   = $crit.Count
            $r.CritRunning = @($cs | Where-Object { $_.Status -eq 'Running' }).Count
            $stopped = @($cs | Where-Object { $_.Status -ne 'Running' })
            $r.CritStoppedDisplay = if ($stopped.Count -gt 0) { ($stopped | ForEach-Object { $_.DisplayName }) -join ', ' } else { '' }
            $r.CritStoppedNames   = if ($stopped.Count -gt 0) { ($stopped | ForEach-Object { $_.Name }) -join ',' } else { '' }
        } catch {}
        $r
    }

    # -- Collector 3: Security (AV, Firewall, UAC, SFC/CBS.log) ---------
    $sbSecurity = {
        $r = @{}
        # Antivirus
        try {
            $av = Get-CimInstance -Namespace "root/SecurityCenter2" -ClassName AntiVirusProduct -ErrorAction SilentlyContinue
            if ($av) { $r.AvName = $av[0].displayName; $r.AvEnabled = (([int]$av[0].productState -band 0x1000) -ne 0) }
            else     { $r.AvName = ''; $r.AvEnabled = $false }
        } catch { $r.AvEnabled = $false }
        # Firewall
        try {
            $fw = Get-NetFirewallProfile -ErrorAction SilentlyContinue
            $winFw = @($fw | Where-Object { $_.Enabled -eq $true }).Count -gt 0
            $fwP = Get-CimInstance -Namespace "root\SecurityCenter2" -ClassName FirewallProduct -ErrorAction SilentlyContinue
            if ($winFw)                        { $r.FwEnabled = $true;  $r.FwName = 'Windows Firewall' }
            elseif ($fwP -and $fwP.Count -gt 0){ $r.FwEnabled = $true;  $r.FwName = ($fwP | Select-Object -First 1).displayName }
            else                               { $r.FwEnabled = $false; $r.FwName = '' }
        } catch { $r.FwEnabled = $false; $r.FwName = '' }
        # UAC
        try {
            $u = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -ErrorAction SilentlyContinue
            $r.UacLevel = if ($u.EnableLUA -eq 0) { 0 } elseif ($u.ConsentPromptBehaviorAdmin -le 0) { 1 } elseif ($u.ConsentPromptBehaviorAdmin -le 3) { 2 } else { 3 }
        } catch { $r.UacLevel = 3 }
        # SFC (CBS.log)
        try {
            $cbs = "$env:windir\Logs\CBS\CBS.log"
            if (Test-Path $cbs) {
                $lines = Get-Content $cbs -Tail 50 -ErrorAction SilentlyContinue | Out-String
                if     ($lines -match 'Verify complete.*no integrity violations') { $r.Sfc = 'OK' }
                elseif ($lines -match 'corrupt|violation')                        { $r.Sfc = 'WARN' }
                else   { $r.Sfc = 'UNKNOWN' }
            } else { $r.Sfc = 'UNKNOWN' }
        } catch { $r.Sfc = 'UNKNOWN' }
        $r
    }

    # -- Collector 4: Network (.NET Ping + DNS + Windows Update) --------
    $sbNetwork = {
        $r = @{}
        # Ping via .NET (faster than Test-Connection, configurable 2s timeout)
        try {
            $ping = (New-Object System.Net.NetworkInformation.Ping).Send('8.8.8.8', 2000)
            $r.NetOk = ($ping.Status -eq [System.Net.NetworkInformation.IPStatus]::Success)
        } catch { $r.NetOk = $false }
        # DNS via .NET (always available in runspace, no module needed)
        try {
            $t0 = Get-Date
            [void][System.Net.Dns]::GetHostEntry("www.google.com")
            $t1 = Get-Date
            $r.DnsOk = $true; $r.DnsMs = [math]::Round(($t1 - $t0).TotalMilliseconds, 0)
        } catch { $r.DnsOk = $false }
        # Windows Update (slowest: 2-5s -- runs in parallel, not blocking)
        try {
            $wuS = New-Object -ComObject Microsoft.Update.Session
            $pending = $wuS.CreateUpdateSearcher().Search("IsInstalled=0 and IsHidden=0").Updates.Count
            $r.WuOk = ($pending -eq 0); $r.WuPending = $pending
        } catch { $r.WuOk = $true; $r.WuPending = 0 }
        $r
    }

    # -- Collector 5: Files (temp count) --------------------------------
    $sbFiles = {
        $r = @{}
        try {
            $tmp = [System.IO.Path]::GetTempPath()
            $r.TempCount = @(Get-ChildItem $tmp -Recurse -File -ErrorAction SilentlyContinue).Count
        } catch { $r.TempCount = 0 }
        $r
    }

    # -- Launch all 5 collectors ----------------------------------------
    $diagSbs = @($sbCIM, $sbServices, $sbSecurity, $sbNetwork, $sbFiles)
    $usePool = ($null -ne $script:RunspacePool -and $script:RunspacePool.RunspacePoolStateInfo.State -eq 'Opened')

    if ($usePool) {
        # -- PARALLEL: RunspacePool available -> ~3-5s total --
        $diagJobs = @()
        foreach ($sb in $diagSbs) {
            $ps = [PowerShell]::Create()
            $ps.RunspacePool = $script:RunspacePool
            [void]$ps.AddScript($sb)
            $diagJobs += [PSCustomObject]@{ PS = $ps; Handle = $ps.BeginInvoke() }
        }
        # Main-thread work while parallel runs (needs loaded DLLs)
        if ($input.StartupCount -eq 0) {
            try { $input.StartupCount = ([SysOpt.StartupManager.StartupEngine]::GetEntries()).Count } catch {}
        }
        # Collect parallel results (blocks until all complete)
        $pR = @($null, $null, $null, $null, $null)
        for ($i = 0; $i -lt $diagJobs.Count; $i++) {
            try {
                $raw = $diagJobs[$i].PS.EndInvoke($diagJobs[$i].Handle)
                $pR[$i] = if ($raw.Count -gt 0) { $raw[0] } else { @{} }
            } catch { $pR[$i] = @{} }
            $diagJobs[$i].PS.Dispose()
        }
    } else {
        # -- FALLBACK: No RunspacePool -> sequential execution --
        $pR = @()
        foreach ($sb in $diagSbs) {
            try { $pR += ,$sb.Invoke()[0] } catch { $pR += ,@{} }
        }
        if ($input.StartupCount -eq 0) {
            try { $input.StartupCount = ([SysOpt.StartupManager.StartupEngine]::GetEntries()).Count } catch {}
        }
    }

    # ==================================================================
    # MERGE PARALLEL RESULTS -> DiagInput
    # ==================================================================

    # -- CIM results (group 0) --------------------------------------
    $cim = $pR[0]; if (-not $cim) { $cim = @{} }
    if (-not $input.CpuModel  -and $cim.CpuName)   { $input.CpuModel  = $cim.CpuName }
    if (-not $input.OsVersion -and $cim.OsCaption)  { $input.OsVersion = $cim.OsCaption }
    if ($input.RamTotalGB -eq 0 -and $cim.RamTotalKB) {
        $input.RamTotalGB = [math]::Round([double]$cim.RamTotalKB / 1048576, 1)
        $input.RamFreeGB  = [math]::Round([double]$cim.RamFreeKB  / 1048576, 1)
    }
    if ($input.DiskTotalGB -eq 0 -and $cim.DiskSize) {
        $input.DiskTotalGB = [math]::Round([double]$cim.DiskSize / 1073741824, 1)
        $input.DiskFreeGB  = [math]::Round([double]$cim.DiskFree / 1073741824, 1)
    }
    if ($input.UptimeHours -eq 0 -and $cim.BootTime) {
        $input.UptimeHours = [math]::Round(((Get-Date) - [datetime]$cim.BootTime).TotalHours, 1)
    }
    if ($null -eq $cim.SmartFail) {
        $input.SmartOkC = $true; $input.SmartDetailC = (T 'DiagSmartNA' 'SMART no disponible')
    } elseif ($cim.SmartFail) {
        $input.SmartOkC = $false; $input.SmartDetailC = (T 'DiagSmartFail' 'Fallo predicho')
    } else {
        $input.SmartOkC = $true; $input.SmartDetailC = (T 'DiagSmartOk' 'Disco saludable')
    }
    if ($cim.BootMs -is [int] -or $cim.BootMs -is [int64] -or $cim.BootMs -is [double]) {
        $input.BootTimeSeconds = [math]::Round([double]$cim.BootMs / 1000, 1)
    }
    # NOTE: Fallback (Get-Date)-BootTime removed -- that calculates UPTIME, not boot duration.
    # BootTimeSeconds stays 0 if Event Log 100 is unavailable (rare).

    # -- Services results (group 1) ---------------------------------
    $svc = $pR[1]; if (-not $svc) { $svc = @{} }
    if ($input.ServicesTotalCount -eq 0 -and $svc.RunningCount) {
        $input.ServicesTotalCount = [int]$svc.RunningCount
        $input.ServicesBloatCount = [int]$svc.BloatCount
    }

    # -- Security results (group 2) ---------------------------------
    $sec = $pR[2]; if (-not $sec) { $sec = @{} }
    if ($sec.AvName)    { $input.AntivirusName    = [string]$sec.AvName }
    if ($sec.AvEnabled) { $input.AntivirusEnabled = [bool]$sec.AvEnabled }
    else                { $input.AntivirusEnabled = $false }
    if ($sec.FwEnabled) { $input.FirewallEnabled  = [bool]$sec.FwEnabled }
    else                { $input.FirewallEnabled  = $false }
    if ($sec.FwName)    { $input.FirewallName     = [string]$sec.FwName }
    $input.UacLevel = if ($null -ne $sec.UacLevel) { [int]$sec.UacLevel } else { 3 }
    # SFC (localization applied in main thread where T() is available)
    $sfcRaw = if ($sec.Sfc) { $sec.Sfc } else { 'UNKNOWN' }
    switch ($sfcRaw) {
        'OK'      { $input.SfcStatus = 'OK';      $input.SfcDetail = (T 'DiagSfcOkDetail'      'Sin problemas de integridad') }
        'WARN'    { $input.SfcStatus = 'WARN';     $input.SfcDetail = (T 'DiagSfcWarnDetail'    'Se detectaron archivos corruptos') }
        default   { $input.SfcStatus = 'UNKNOWN';  $input.SfcDetail = (T 'DiagSfcUnknownDetail' 'No se encontraron resultados recientes de SFC') }
    }

    # -- Network results (group 3) ----------------------------------
    $net = $pR[3]; if (-not $net) { $net = @{} }
    $input.NetworkConnected = [bool]$net.NetOk
    $input.NetworkDetail    = if ($net.NetOk) { (T 'DiagNetOk' 'Conectado a Internet') } else { (T 'DiagNetFail' 'Sin conexión a Internet') }
    $input.DnsResolutionOk  = [bool]$net.DnsOk
    if ($net.DnsMs) { $input.DnsLatencyMs = [double]$net.DnsMs }
    if ($null -ne $net.WuOk) {
        if ([bool]$net.WuOk) {
            $input.WindowsUpdateOk     = $true
            $input.WindowsUpdateDetail = (T 'DiagWuOkDetail' 'Sistema actualizado')
        } elseif ($net.WuPending -and [int]$net.WuPending -gt 0) {
            $input.WindowsUpdateOk     = $false
            $input.WindowsUpdateDetail = "$([int]$net.WuPending) $(T 'DiagWuPending' 'actualizaciones pendientes')"
        } else {
            $input.WindowsUpdateOk     = $true
            $input.WindowsUpdateDetail = (T 'DiagWuUnknown' 'No se pudo verificar')
        }
    }

    # -- Files results (group 4) ------------------------------------
    $fil = $pR[4]; if (-not $fil) { $fil = @{} }
    if ($input.TempFileCount -eq 0 -and $fil.TempCount) { $input.TempFileCount = [int]$fil.TempCount }

    # -- AV-aware critical services (post-merge: needs Security + Services) --
    if ($svc.CritTotal) {
        $hasThirdPartyAv = $input.AntivirusEnabled -and $input.AntivirusName -and ($input.AntivirusName -notmatch 'Defender|Windows')
        if ($hasThirdPartyAv -and $svc.CritStoppedNames -and ($svc.CritStoppedNames -match 'WinDefend')) {
            # Third-party AV active -> WinDefend stopped is expected, exclude from count
            $input.CriticalSvcTotal = [int]$svc.CritTotal - 1
            $input.CriticalSvcOk    = [int]$svc.CritRunning
            $parts = @(($svc.CritStoppedDisplay -split ',\s*') | Where-Object { $_ -notmatch 'Defender' })
            $input.StoppedCriticalSvcNames = ($parts -join ', ').Trim(', ')
        } else {
            $input.CriticalSvcTotal = [int]$svc.CritTotal
            $input.CriticalSvcOk    = [int]$svc.CritRunning
            $input.StoppedCriticalSvcNames = [string]$svc.CritStoppedDisplay
        }
    }

    # -- Ejecutar motor de diagnóstico vía DLL --------------------------------
    $result = [SysOpt.Diagnostics.DiagnosticsEngine]::Analyze($input)
    $diagElapsed = [math]::Round(((Get-Date) - $diagStartTime).TotalSeconds, 1)

    # -- Mapear secciones C# -> paneles XAML -----------------------------------
    # El motor produce secciones en orden fijo (v3.3.0):
    #   0: SISTEMA -> Sistema   3: SEGURIDAD  -> Seguridad  6: RED       -> Red
    #   1: LIMPIEZA-> Limpieza  4: INICIO     -> Inicio
    #   2: DISCO   -> Disco     5: SERVICIOS  -> Servicios
    $sectionMap = @('Sistema','Limpieza','Disco','Seguridad','Inicio','Servicios','Red')
    $catKeys    = @('Sistema','Limpieza','Disco','Seguridad','Inicio','Servicios','Red')
    $allPages   = @('Resumen','Sistema','Limpieza','Disco','Seguridad','Inicio','Servicios','Red','InfoSistema')

    # Contadores por categoría
    $catOk = @{}; $catWarn = @{}; $catCrit = @{}; $catInfo = @{}
    foreach ($k in $catKeys) { $catOk[$k] = 0; $catWarn[$k] = 0; $catCrit[$k] = 0; $catInfo[$k] = 0 }

    $sectionIdx = -1
    $currentKey = $null

    foreach ($item in $result.Items) {
        if ($item.IsSection) {
            $sectionIdx++
            $currentKey = if ($sectionIdx -lt $sectionMap.Count) { $sectionMap[$sectionIdx] } else { $null }
        } else {
            if ($currentKey) {
                $panel = $dWindow.FindName("panel$currentKey")
                if ($panel) {
                    Add-DiagRow -Window $dWindow -Panel $panel `
                        -Status $item.Status -Label $item.Label `
                        -Detail $item.Detail -Action $item.Action
                    switch ($item.Status) {
                        'OK'   { $catOk[$currentKey]++ }
                        'WARN' { $catWarn[$currentKey]++ }
                        'CRIT' { $catCrit[$currentKey]++ }
                        default{ $catInfo[$currentKey]++ }
                    }
                }
            }
        }
    }

    # -- Sidebar: badges + indicadores de estado ------------------------------
    foreach ($k in $catKeys) {
        $total = $catOk[$k] + $catWarn[$k] + $catCrit[$k] + $catInfo[$k]
        $badge = $dWindow.FindName("badge$k")
        $txtB  = $dWindow.FindName("txtBadge$k")
        if ($badge -and $txtB) {
            if ($total -gt 0) {
                $txtB.Text = "$total"
                $badge.Visibility = 'Visible'
            } else {
                $badge.Visibility = 'Collapsed'
            }
        }
    }

    # -- Status dots sidebar --------------------------------------------------
    foreach ($k in $catKeys) {
        $dot = $dWindow.FindName("dot$k")
        if ($dot) {
            $dotColor = if ($catCrit[$k] -gt 0) { '#F87171' } `
                        elseif ($catWarn[$k] -gt 0) { '#FBBF24' } `
                        else { '#4ADE80' }
            $dot.Fill = New-Object System.Windows.Media.SolidColorBrush(
                [System.Windows.Media.ColorConverter]::ConvertFromString($dotColor))
        }
    }

    # -- Per-panel headers (icon + title + description + stats) ---------------
    $phIcons = @{
        'Sistema'=[char]0xE770; 'Limpieza'=[char]0xE74D; 'Disco'=[char]0xEDA2;
        'Seguridad'=[char]0xE72E; 'Inicio'=[char]0xE768; 'Servicios'=[char]0xE713; 'Red'=[char]0xE774
    }
    $phDescs = @{
        'Sistema'   = T 'DiagDescSistema'   'Estado general del sistema operativo, RAM y actividad'
        'Limpieza'  = T 'DiagDescLimpieza'  'Archivos temporales, papelera, caché de DNS y logs'
        'Disco'     = T 'DiagDescDisco'     'Espacio en unidades, estado SMART y particiones'
        'Seguridad' = T 'DiagDescSeguridad' 'Antivirus, firewall, UAC y actualizaciones'
        'Inicio'    = T 'DiagDescInicio'    'Programas de arranque automático y tiempo de boot'
        'Servicios' = T 'DiagDescServicios' 'Servicios del sistema, bloatware detectado'
        'Red'       = T 'DiagDescRed'       'Conectividad, DNS y latencia'
    }
    foreach ($k in $catKeys) {
        $panel = $dWindow.FindName("panel$k")
        if (-not $panel) { continue }

        $hdr = New-Object System.Windows.Controls.Border
        $hdr.BorderThickness = New-Object System.Windows.Thickness(0,0,0,1)
        $hdr.BorderBrush = New-Object System.Windows.Media.SolidColorBrush(
            [System.Windows.Media.ColorConverter]::ConvertFromString((Get-TC 'BorderSubtle' '#1A2540')))
        $hdr.Padding = New-Object System.Windows.Thickness(0,0,0,12)
        $hdr.Margin  = New-Object System.Windows.Thickness(0,0,0,12)

        $hg = New-Object System.Windows.Controls.Grid
        $hgc0 = New-Object System.Windows.Controls.ColumnDefinition; $hgc0.Width = [System.Windows.GridLength]::Auto
        $hgc1 = New-Object System.Windows.Controls.ColumnDefinition; $hgc1.Width = [System.Windows.GridLength]::new(1, [System.Windows.GridUnitType]::Star)
        $hgc2 = New-Object System.Windows.Controls.ColumnDefinition; $hgc2.Width = [System.Windows.GridLength]::Auto
        $hg.ColumnDefinitions.Add($hgc0); $hg.ColumnDefinitions.Add($hgc1); $hg.ColumnDefinitions.Add($hgc2)

        $hi = New-Object System.Windows.Controls.TextBlock
        $hi.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe MDL2 Assets")
        $hi.Text = $phIcons[$k]; $hi.FontSize = 22; $hi.VerticalAlignment = "Center"
        $hi.Margin = New-Object System.Windows.Thickness(0,0,10,0)
        [System.Windows.Controls.Grid]::SetColumn($hi, 0)
        [void]$hg.Children.Add($hi)

        $htSp = New-Object System.Windows.Controls.StackPanel
        [System.Windows.Controls.Grid]::SetColumn($htSp, 1)
        $htT = New-Object System.Windows.Controls.TextBlock
        $htT.Text = $k; $htT.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe UI")
        $htT.FontSize = 16; $htT.FontWeight = [System.Windows.FontWeights]::Bold
        $htT.Foreground = New-Object System.Windows.Media.SolidColorBrush(
            [System.Windows.Media.ColorConverter]::ConvertFromString((Get-TC 'TextPrimary' '#F0F3FA')))
        [void]$htSp.Children.Add($htT)
        $htD = New-Object System.Windows.Controls.TextBlock
        $htD.Text = $phDescs[$k]; $htD.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe UI")
        $htD.FontSize = 11; $htD.Margin = New-Object System.Windows.Thickness(0,2,0,0)
        $htD.Foreground = New-Object System.Windows.Media.SolidColorBrush(
            [System.Windows.Media.ColorConverter]::ConvertFromString((Get-TC 'TextMuted' '#6B7599')))
        [void]$htSp.Children.Add($htD)
        [void]$hg.Children.Add($htSp)

        $hs = New-Object System.Windows.Controls.StackPanel
        $hs.Orientation = "Horizontal"; $hs.VerticalAlignment = "Center"
        [System.Windows.Controls.Grid]::SetColumn($hs, 2)
        $tdefs = @(
            @($catOk[$k],   'OK',                                    '#182A1E', '#4ADE80'),
            @($catWarn[$k], (T 'DiagTagWarn' 'Aviso'),               '#2A2010', '#FBBF24'),
            @($catCrit[$k], (T 'DiagTagCrit' 'Crítico'),             '#2A1018', '#F87171'),
            @($catInfo[$k], 'Info',                                   '#1A2540', '#7BA8E0')
        )
        foreach ($td in $tdefs) {
            if ($td[0] -le 0) { continue }
            $tb = New-Object System.Windows.Controls.Border
            $tb.CornerRadius = New-Object System.Windows.CornerRadius(4)
            $tb.Padding = New-Object System.Windows.Thickness(6,2,6,2)
            $tb.Margin  = New-Object System.Windows.Thickness(4,0,0,0)
            $tb.Background = New-Object System.Windows.Media.SolidColorBrush(
                [System.Windows.Media.ColorConverter]::ConvertFromString($td[2]))
            $tt = New-Object System.Windows.Controls.TextBlock
            $tt.Text = "$($td[0]) $($td[1])"; $tt.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe UI")
            $tt.FontSize = 9; $tt.FontWeight = [System.Windows.FontWeights]::Bold
            $tt.Foreground = New-Object System.Windows.Media.SolidColorBrush(
                [System.Windows.Media.ColorConverter]::ConvertFromString($td[3]))
            $tb.Child = $tt
            [void]$hs.Children.Add($tb)
        }
        [void]$hg.Children.Add($hs)
        $hdr.Child = $hg
        $panel.Children.Insert(0, $hdr)
    }

    # -- Stats bar ------------------------------------------------------------
    $el = $dWindow.FindName("txtStatsOk");   if ($el) { $el.Text = "$($result.OkCount)" }
    $el = $dWindow.FindName("txtStatsWarn");  if ($el) { $el.Text = "$($result.WarnCount)" }
    $el = $dWindow.FindName("txtStatsCrit");  if ($el) { $el.Text = "$($result.CritCount)" }
    $el = $dWindow.FindName("txtStatsInfo");  if ($el) { $el.Text = "$($result.InfoCount)" }

    # -- Score ring color -----------------------------------------------------
    $scoreColor = if ($result.ScoreColor) { $result.ScoreColor } else { '#5BA3FF' }
    $scoreBrush = New-Object System.Windows.Media.SolidColorBrush(
        [System.Windows.Media.ColorConverter]::ConvertFromString($scoreColor))

    $el = $dWindow.FindName("scoreRingFg")
    if ($el) {
        $el.Stroke = $scoreBrush
        # Progress arc: StrokeDashArray proportional to score
        $circumference = [Math]::PI * (70 - 5)   # effective diameter = Width - StrokeThickness
        $dashUnits     = $circumference / 5       # normalize by StrokeThickness
        $scoreFrac     = [Math]::Max(0, [Math]::Min(100, $result.Score)) / 100
        $dashLen       = $dashUnits * $scoreFrac
        $gapLen        = $dashUnits                # gap big enough to cover the rest
        $dc = New-Object System.Windows.Media.DoubleCollection
        $dc.Add($dashLen); $dc.Add($gapLen)
        $el.StrokeDashArray = $dc
    }

    # -- Duration pill --------------------------------------------------------
    $el = $dWindow.FindName("txtDiagDuration")
    if ($el) { $el.Text = "${diagElapsed}s" }

    # -- Header subtitle ------------------------------------------------------
    $el = $dWindow.FindName("txtDiagSubtitle")
    if ($el) { $el.Text = "SysOpt v$($script:AppVersion) -- $(T 'DiagSubtitleCompleted' 'Análisis completado el') $(Get-Date -Format 'dd/MM/yyyy') $(T 'DiagSubtitleAt' 'a las') $(Get-Date -Format 'HH:mm')" }

    # -- Header: score --------------------------------------------------------

    $el = $dWindow.FindName("ScoreText")
    if ($el) { $el.Text = "$($result.Score)"; $el.Foreground = $scoreBrush }
    $el = $dWindow.FindName("ScoreLabel")
    if ($el) { $el.Text = (T 'DiagScoreLabel' 'PUNTUACIÓN') }

    $el = $dWindow.FindName("txtSectionSubtitle")
    if ($el) {
        $el.Text = "$(Get-Date -Format 'dd/MM/yyyy HH:mm')  |  $($result.OkCount) OK  *  $($result.WarnCount) $(T 'DiagWarnings' 'avisos')  *  $($result.CritCount) $(T 'DiagCriticals' 'críticos')"
    }

    # -- Página Resumen: barras por categoría ------------------

    # 4 summary count cards
    $el = $dWindow.FindName("txtSummaryOk");   if ($el) { $el.Text = "$($result.OkCount)" }
    $el = $dWindow.FindName("txtSummaryWarn"); if ($el) { $el.Text = "$($result.WarnCount)" }
    $el = $dWindow.FindName("txtSummaryCrit"); if ($el) { $el.Text = "$($result.CritCount)" }
    $el = $dWindow.FindName("txtSummaryInfo"); if ($el) { $el.Text = "$($result.InfoCount)" }

    # Barras de progreso por categoría
    $barPanel = $dWindow.FindName("panelCategoryBars")
    if ($barPanel) {
        foreach ($k in $catKeys) {
            $total = $catOk[$k] + $catWarn[$k] + $catCrit[$k] + $catInfo[$k]
            if ($total -eq 0) { continue }
            $g = New-Object System.Windows.Controls.Grid
            $c0 = New-Object System.Windows.Controls.ColumnDefinition; $c0.Width = [System.Windows.GridLength]::new(120)
            $c1 = New-Object System.Windows.Controls.ColumnDefinition; $c1.Width = [System.Windows.GridLength]::new(1, [System.Windows.GridUnitType]::Star)
            $g.ColumnDefinitions.Add($c0); $g.ColumnDefinitions.Add($c1)
            $g.Margin = "0,4"

            # Category name with MDL2 icon
            $catSp = New-Object System.Windows.Controls.StackPanel
            $catSp.Orientation = "Horizontal"; $catSp.VerticalAlignment = "Center"
            [System.Windows.Controls.Grid]::SetColumn($catSp, 0)
            $catIconTb = New-Object System.Windows.Controls.TextBlock
            $catIconTb.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe MDL2 Assets")
            $catIconTb.Text = $phIcons[$k]; $catIconTb.FontSize = 11; $catIconTb.VerticalAlignment = "Center"
            $catIconTb.Margin = New-Object System.Windows.Thickness(0,0,4,0)
            $catIconTb.Foreground = New-Object System.Windows.Media.SolidColorBrush(
                [System.Windows.Media.ColorConverter]::ConvertFromString('#9BA4C0'))
            [void]$catSp.Children.Add($catIconTb)
            $navRun = $dWindow.FindName("runNav$k")
            $lb = New-Object System.Windows.Controls.TextBlock
            $lb.Text = if ($navRun) { $navRun.Text } else { $k }
            $lb.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe UI")
            $lb.FontSize = 11
            $lb.Foreground = New-Object System.Windows.Media.SolidColorBrush(
                [System.Windows.Media.ColorConverter]::ConvertFromString('#9BA4C0'))
            $lb.VerticalAlignment = "Center"
            [void]$catSp.Children.Add($lb)
            [void]$g.Children.Add($catSp)

            # Segmented bar track
            $outer = New-Object System.Windows.Controls.Border
            $outer.CornerRadius = "5"; $outer.Height = 22; $outer.VerticalAlignment = "Center"
            $outer.Background = New-Object System.Windows.Media.SolidColorBrush(
                [System.Windows.Media.ColorConverter]::ConvertFromString('#1A2540'))
            [System.Windows.Controls.Grid]::SetColumn($outer, 1)
            $barG = New-Object System.Windows.Controls.Grid
            $segments = @(
                @($catOk[$k],   '#22C55E'),
                @($catWarn[$k], '#FBBF24'),
                @($catCrit[$k], '#F87171'),
                @($catInfo[$k], '#5BA3FF')
            )
            $segLabels = @('OK','','','')
            $colIdx = 0
            foreach ($si in 0..3) {
                $seg = $segments[$si]
                if ($seg[0] -le 0) { continue }
                $bc = New-Object System.Windows.Controls.ColumnDefinition
                $bc.Width = [System.Windows.GridLength]::new($seg[0], [System.Windows.GridUnitType]::Star)
                $barG.ColumnDefinitions.Add($bc)
                $fillB = New-Object System.Windows.Controls.Border
                $fillB.CornerRadius = "5"
                $fillB.Background = New-Object System.Windows.Media.SolidColorBrush(
                    [System.Windows.Media.ColorConverter]::ConvertFromString($seg[1]))
                $segLbl = New-Object System.Windows.Controls.TextBlock
                $segTxt = if ($si -eq 0 -and $seg[0] -gt 0) { "$($seg[0]) OK" } else { "$($seg[0])" }
                $segLbl.Text = $segTxt
                $segLbl.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe UI")
                $segLbl.FontSize = 9; $segLbl.FontWeight = [System.Windows.FontWeights]::Bold
                $segLbl.Foreground = [System.Windows.Media.Brushes]::White
                $segLbl.HorizontalAlignment = "Center"; $segLbl.VerticalAlignment = "Center"
                $fillB.Child = $segLbl
                [System.Windows.Controls.Grid]::SetColumn($fillB, $colIdx)
                [void]$barG.Children.Add($fillB)
                $colIdx++
            }
            $outer.Child = $barG
            [void]$g.Children.Add($outer)

            [void]$barPanel.Children.Add($g)
        }
    }

    # Recomendaciones
    $recPanel = $dWindow.FindName("panelRecommendations")
    if ($recPanel) {
        $hasRecs = $false
        foreach ($item in $result.Items) {
            if (-not $item.IsSection -and ($item.Status -eq 'CRIT' -or $item.Status -eq 'WARN')) {
                $hasRecs = $true
                $recSp = New-Object System.Windows.Controls.StackPanel
                $recSp.Orientation = "Horizontal"; $recSp.Margin = "0,2"
                $recIco = New-Object System.Windows.Controls.TextBlock
                $recIco.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe MDL2 Assets")
                $recIco.Text = if ($item.Status -eq 'CRIT') { [char]0xE711 } else { [char]0xE7BA }
                $recIco.FontSize = 12; $recIco.VerticalAlignment = "Center"
                $recIco.Margin = New-Object System.Windows.Thickness(0,0,6,0)
                $recIcoColor = if ($item.Status -eq 'CRIT') { '#F87171' } else { '#FBBF24' }
                $recIco.Foreground = New-Object System.Windows.Media.SolidColorBrush(
                    [System.Windows.Media.ColorConverter]::ConvertFromString($recIcoColor))
                [void]$recSp.Children.Add($recIco)
                $rec = New-Object System.Windows.Controls.TextBlock
                $recTxt = $item.Label
                if ($item.Action) { $recTxt += " -- $($item.Action)" }
                $rec.Text = $recTxt
                $rec.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe UI")
                $rec.FontSize = 12
                $rec.Foreground = New-Object System.Windows.Media.SolidColorBrush(
                    [System.Windows.Media.ColorConverter]::ConvertFromString((Get-TC 'TextPrimary' '#E8ECF4')))
                $rec.TextWrapping = "Wrap"; $rec.VerticalAlignment = "Center"
                [void]$recSp.Children.Add($rec)
                [void]$recPanel.Children.Add($recSp)
            }
        }
        if (-not $hasRecs) {
            $okSp = New-Object System.Windows.Controls.StackPanel
            $okSp.Orientation = "Horizontal"
            $okIco = New-Object System.Windows.Controls.TextBlock
            $okIco.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe MDL2 Assets")
            $okIco.Text = [char]0xE73E; $okIco.FontSize = 12; $okIco.VerticalAlignment = "Center"
            $okIco.Margin = New-Object System.Windows.Thickness(0,0,6,0)
            $okIco.Foreground = New-Object System.Windows.Media.SolidColorBrush(
                [System.Windows.Media.ColorConverter]::ConvertFromString((Get-TC 'GoodGreen' '#4AE896')))
            [void]$okSp.Children.Add($okIco)
            $ok = New-Object System.Windows.Controls.TextBlock
            $ok.Text = (T 'DiagNoRecommendations' 'No hay recomendaciones críticas')
            $ok.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe UI")
            $ok.FontSize = 12; $ok.VerticalAlignment = "Center"
            $ok.Foreground = New-Object System.Windows.Media.SolidColorBrush(
                [System.Windows.Media.ColorConverter]::ConvertFromString((Get-TC 'GoodGreen' '#4AE896')))
            [void]$okSp.Children.Add($ok)
            [void]$recPanel.Children.Add($okSp)
        }
    }

    # -- Summary status box (like mockup) -------------------------------------
Set-SplashProgress 99 (T "SplashLoading99" "Informe y wizard...")
    $resumenParent = $recPanel.Parent
    if ($resumenParent) {
        $stIcon  = if ($result.CritCount -gt 0) { [char]0xE7BA } elseif ($result.WarnCount -gt 0) { [char]0xE72E } else { [char]0xE73E }
        $stColor = if ($result.CritCount -gt 0) { '#F87171' } elseif ($result.WarnCount -gt 0) { '#FBBF24' } else { '#4ADE80' }
        $stBg    = if ($result.CritCount -gt 0) { '#2A1018' } elseif ($result.WarnCount -gt 0) { '#2A2010' } else { '#182A1E' }
        $stBdr   = if ($result.CritCount -gt 0) { '#5A1828' } elseif ($result.WarnCount -gt 0) { '#5A4010' } else { '#2A4A35' }

        $sBox = New-Object System.Windows.Controls.Border
        $sBox.CornerRadius = New-Object System.Windows.CornerRadius(10)
        $sBox.Padding = New-Object System.Windows.Thickness(16,14,20,14)
        $sBox.Margin  = New-Object System.Windows.Thickness(0,16,0,0)
        $sBox.BorderThickness = New-Object System.Windows.Thickness(1)
        $sBox.BorderBrush = New-Object System.Windows.Media.SolidColorBrush(
            [System.Windows.Media.ColorConverter]::ConvertFromString($stBdr))
        $sBox.Background = New-Object System.Windows.Media.SolidColorBrush(
            [System.Windows.Media.ColorConverter]::ConvertFromString($stBg))

        $sg = New-Object System.Windows.Controls.Grid
        $sgc0 = New-Object System.Windows.Controls.ColumnDefinition; $sgc0.Width = [System.Windows.GridLength]::Auto
        $sgc1 = New-Object System.Windows.Controls.ColumnDefinition; $sgc1.Width = [System.Windows.GridLength]::new(1, [System.Windows.GridUnitType]::Star)
        $sg.ColumnDefinitions.Add($sgc0); $sg.ColumnDefinitions.Add($sgc1)

        $sIco = New-Object System.Windows.Controls.TextBlock
        $sIco.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe MDL2 Assets")
        $sIco.Text = $stIcon; $sIco.FontSize = 28; $sIco.VerticalAlignment = "Center"
        $sIco.Margin = New-Object System.Windows.Thickness(0,0,14,0)
        [System.Windows.Controls.Grid]::SetColumn($sIco, 0)
        [void]$sg.Children.Add($sIco)

        $sSp = New-Object System.Windows.Controls.StackPanel
        [System.Windows.Controls.Grid]::SetColumn($sSp, 1)
        $sTxt = New-Object System.Windows.Controls.TextBlock
        $sTxt.Text = $result.ScoreLabel
        $sTxt.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe UI")
        $sTxt.FontSize = 14; $sTxt.FontWeight = [System.Windows.FontWeights]::SemiBold
        $sTxt.Foreground = New-Object System.Windows.Media.SolidColorBrush(
            [System.Windows.Media.ColorConverter]::ConvertFromString($stColor))
        [void]$sSp.Children.Add($sTxt)

        $recTexts = @()
        foreach ($item in $result.Items) {
            if (-not $item.IsSection -and ($item.Status -eq 'CRIT' -or $item.Status -eq 'WARN')) {
                $recTexts += $item.Label
            }
        }
        if ($recTexts.Count -gt 0) {
            $sSub = New-Object System.Windows.Controls.TextBlock
            $recSummary = $recTexts[0..([math]::Min(2, $recTexts.Count - 1))]
            $sSub.Text = (T 'DiagRecommendPrefix' 'Se recomienda revisar:') + " " + ($recSummary -join '; ')
            if ($recTexts.Count -gt 3) { $sSub.Text += "..." }
            $sSub.TextWrapping = "Wrap"
            $sSub.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe UI")
            $sSub.FontSize = 11; $sSub.Margin = New-Object System.Windows.Thickness(0,3,0,0)
            $sSub.Foreground = New-Object System.Windows.Media.SolidColorBrush(
                [System.Windows.Media.ColorConverter]::ConvertFromString('#9BA4C0'))
            [void]$sSp.Children.Add($sSub)
        }
        [void]$sg.Children.Add($sSp)
        $sBox.Child = $sg
        [void]$resumenParent.Children.Add($sBox)
    }

    # -- Página Info Sistema --------------------------------------------------
    $el = $dWindow.FindName("txtInfoPcName");   if ($el) { $el.Text = $input.ComputerName }
    $el = $dWindow.FindName("txtInfoOs");       if ($el) { $el.Text = $input.OsVersion }
    $el = $dWindow.FindName("txtInfoCpu");      if ($el) { $el.Text = $input.CpuModel }
    $el = $dWindow.FindName("txtInfoRam");      if ($el) { $el.Text = "{0} GB libres de {1} GB" -f $input.RamFreeGB, $input.RamTotalGB }
    $el = $dWindow.FindName("txtInfoDisk");     if ($el) { $el.Text = "{0} GB libres de {1} GB" -f $input.DiskFreeGB, $input.DiskTotalGB }
    $el = $dWindow.FindName("txtInfoUptime");   if ($el) { $el.Text = "{0} horas" -f $input.UptimeHours }
    $el = $dWindow.FindName("txtInfoStartup");  if ($el) { $el.Text = "{0} programas" -f $input.StartupCount }
    $el = $dWindow.FindName("txtInfoServices"); if ($el) { $el.Text = "{0} activos ({1} bloatware)" -f $input.ServicesTotalCount, $input.ServicesBloatCount }

    # -- Navegación sidebar ---------------------------------------------------
    # Inicializar todos los nav items con borde izquierdo (transparente = inactivo)
    foreach ($n in $allPages) {
        $nav = $dWindow.FindName("btnNav$n")
        if ($nav) { $nav.BorderThickness = '3,0,0,0'; $nav.BorderBrush = [System.Windows.Media.Brushes]::Transparent }
    }

    # Función de navegación -- mismo patrón que OptionsWindow
    function Navigate-DiagPage {
        param([string]$PageName)
        foreach ($n in @('Resumen','Sistema','Limpieza','Disco','Seguridad','Inicio','Servicios','Red','InfoSistema')) {
            $pg = $dWindow.FindName("page$n")
            if ($pg) { $pg.Visibility = 'Collapsed' }
            $nv = $dWindow.FindName("btnNav$n")
            if ($nv) {
                $nv.Background = [System.Windows.Media.Brushes]::Transparent
                $nv.BorderBrush = [System.Windows.Media.Brushes]::Transparent
            }
        }
        $pg = $dWindow.FindName("page$PageName")
        if ($pg) { $pg.Visibility = 'Visible' }
        $nv = $dWindow.FindName("btnNav$PageName")
        if ($nv) {
            $nv.Background = New-Object System.Windows.Media.SolidColorBrush(
                [System.Windows.Media.ColorConverter]::ConvertFromString('#1A5BA3FF'))
            $nv.BorderBrush = New-Object System.Windows.Media.SolidColorBrush(
                [System.Windows.Media.ColorConverter]::ConvertFromString((Get-TC 'AccentBlue' '#5BA3FF')))
        }
        $title = $dWindow.FindName("txtSectionTitle")
        $navTxt = $dWindow.FindName("txtNav$PageName")
        if ($title -and $navTxt) { $title.Text = $navTxt.Text }
    }

    # Conectar clicks del sidebar
    $dWindow.FindName("btnNavResumen").Add_MouseLeftButtonDown({ Navigate-DiagPage 'Resumen' })
    $dWindow.FindName("btnNavSistema").Add_MouseLeftButtonDown({ Navigate-DiagPage 'Sistema' })
    $dWindow.FindName("btnNavLimpieza").Add_MouseLeftButtonDown({ Navigate-DiagPage 'Limpieza' })
    $dWindow.FindName("btnNavDisco").Add_MouseLeftButtonDown({ Navigate-DiagPage 'Disco' })
    $dWindow.FindName("btnNavSeguridad").Add_MouseLeftButtonDown({ Navigate-DiagPage 'Seguridad' })
    $dWindow.FindName("btnNavInicio").Add_MouseLeftButtonDown({ Navigate-DiagPage 'Inicio' })
    $dWindow.FindName("btnNavServicios").Add_MouseLeftButtonDown({ Navigate-DiagPage 'Servicios' })
    $dWindow.FindName("btnNavRed").Add_MouseLeftButtonDown({ Navigate-DiagPage 'Red' })
    $dWindow.FindName("btnNavInfoSistema").Add_MouseLeftButtonDown({ Navigate-DiagPage 'InfoSistema' })

    # Página inicial: Sistema
    Navigate-DiagPage 'Sistema'

    # -- Exportar TXT ---------------------------------------------------------
    $exportLines = $result.ExportLines
    $dWindow.FindName("btnExportDiag").Add_Click({
        $sd = New-Object System.Windows.Forms.SaveFileDialog
        try {
            $sd.Title            = (T "DiagExportBtn")
            $sd.Filter           = "Texto (*.txt)|*.txt|Todos (*.*)|*.*"
            $sd.DefaultExt       = "txt"
            $sd.FileName         = "DiagnosticoSistema_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"
            $sd.InitialDirectory = $script:OutputDir
            if ($sd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
                $exportLines | Out-File -FilePath $sd.FileName -Encoding UTF8
                Show-ThemedDialog -Title ((T "DiagExportDoneTitle")) `
                    -Message "$((T "DiagExportDoneMsg")):`n$($sd.FileName)" -Type "success"
            }
        } finally { $sd.Dispose() }
    })

    # -- Exportar CSV ---------------------------------------------------------
    $csvResultRef = $result
    $dWindow.FindName("btnExportCsv").Add_Click({
        $sd = New-Object System.Windows.Forms.SaveFileDialog
        try {
            $sd.Title            = (T "DiagExportCsvTitle" "Exportar CSV de diagnóstico")
            $sd.Filter           = "CSV (*.csv)|*.csv"
            $sd.DefaultExt       = "csv"
            $sd.FileName         = "DiagnosticoSistema_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
            $sd.InitialDirectory = $script:OutputDir
            if ($sd.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return }
            $csvPath = $sd.FileName
        } finally { $sd.Dispose() }
        try {
            $sw = [System.IO.StreamWriter]::new($csvPath, $false, [System.Text.Encoding]::UTF8)
            try {
                $sw.WriteLine('"Section","Status","Label","Detail","Action","Deduction"')
                $currentSection = ""
                foreach ($item in $csvResultRef.Items) {
                    if ($item.IsSection) {
                        $currentSection = $item.SectionTitle -replace '"','""'
                        continue
                    }
                    $st  = $item.Status   -replace '"','""'
                    $lb  = $item.Label    -replace '"','""'
                    $dt  = $item.Detail   -replace '"','""'
                    $ac  = if ($item.Action) { $item.Action -replace '"','""' } else { "" }
                    $dd  = $item.Deduction
                    $sw.WriteLine('"' + $currentSection + '","' + $st + '","' + $lb + '","' + $dt + '","' + $ac + '",' + $dd)
                }
            } finally { $sw.Close(); $sw.Dispose() }
            Show-ThemedDialog -Title ((T "DiagExportDoneTitle")) `
                -Message "$((T 'DiagExportCsvDone')):`n$csvPath" -Type "success"
        } catch {
            Show-ThemedDialog -Title "Error" -Message "Error: $($_.Exception.Message)" -Type "error"
        }
    })

    # -- Exportar JSON (server sync) ------------------------------------------
    $jsonResultRef = $result
    $jsonInputRef  = $input
    $dWindow.FindName("btnExportDiagJson").Add_Click({
        $sd = New-Object System.Windows.Forms.SaveFileDialog
        try {
            $sd.Title            = (T "DiagExportJsonTitle" "Exportar JSON de diagnóstico")
            $sd.Filter           = "JSON (*.json)|*.json"
            $sd.DefaultExt       = "json"
            $sd.FileName         = "DiagSync_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
            $sd.InitialDirectory = $script:OutputDir
            if ($sd.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return }
            $jsonPath = $sd.FileName
        } finally { $sd.Dispose() }
        try {
            $syncData = @{
                version      = $script:AppVersion
                timestamp    = (Get-Date -Format 'o')
                computerName = $env:COMPUTERNAME
                score        = $jsonResultRef.Score
                scoreLabel   = $jsonResultRef.ScoreLabel
                counts       = @{
                    ok   = $jsonResultRef.OkCount
                    warn = $jsonResultRef.WarnCount
                    crit = $jsonResultRef.CritCount
                    info = $jsonResultRef.InfoCount
                    skip = $jsonResultRef.SkipCount
                }
                items = @(foreach ($item in $jsonResultRef.Items) {
                    if ($item.IsSection) {
                        @{ type = 'section'; title = $item.SectionTitle; icon = $item.SectionIcon }
                    } else {
                        @{ type = 'check'; status = $item.Status; label = $item.Label
                           detail = $item.Detail; action = $item.Action; deduction = $item.Deduction }
                    }
                })
            }
            $json = $syncData | ConvertTo-Json -Depth 5
            [System.IO.File]::WriteAllText($jsonPath, $json, [System.Text.Encoding]::UTF8)
            Show-ThemedDialog -Title ((T "DiagExportDoneTitle")) `
                -Message "$((T 'DiagExportJsonDone')):`n$jsonPath" -Type "success"
        } catch {
            Show-ThemedDialog -Title "Error" -Message "Error: $($_.Exception.Message)" -Type "error"
        }
    })

    # -- Exportar HTML --------------------------------------------------------
    $diagInputRef  = $input
    $diagResultRef = $result
    $tplDir = Join-Path (Split-Path $script:XamlFolder -Parent) "templates"
    $dWindow.FindName("btnExportHtml").Add_Click({
        $tplPath = Join-Path $tplDir "analysisreport.html"
        if (-not (Test-Path $tplPath)) {
            Show-ThemedDialog -Title "Error" `
                -Message (T 'DiagHtmlTemplateNotFound' 'No se encontró la plantilla HTML') -Type "error"
            return
        }
        try {
            $tplContent = [System.IO.File]::ReadAllText($tplPath, [System.Text.Encoding]::UTF8)
            $htmlParams = New-Object SysOpt.Diagnostics.HtmlReportParams
            $htmlParams.TemplateHtml = $tplContent
            $htmlParams.AppVersion   = "v$($script:AppVersion)"
            # Logo base64 -- cargar sysopt1.png si existe
            $logoPath = Join-Path (Split-Path $script:XamlFolder -Parent) "img\sysopt1.png"
            if (Test-Path $logoPath) {
                $htmlParams.LogoBase64 = [System.Convert]::ToBase64String([System.IO.File]::ReadAllBytes($logoPath))
            }
            $htmlParams.AnalysisTime = Get-Date -Format "dd/MM/yyyy HH:mm:ss"
            $html = [SysOpt.Diagnostics.DiagnosticsEngine]::GenerateHtmlReport($diagInputRef, $diagResultRef, $htmlParams)
            # Guardar automáticamente en .\outputs
            $outputDir = Join-Path $PSScriptRoot "output"
            if (-not (Test-Path $outputDir)) { New-Item -ItemType Directory -Path $outputDir -Force | Out-Null }
            $outFileName = "InformeDiagnostico_$(Get-Date -Format 'yyyyMMdd_HHmmss').html"
            $outFilePath = Join-Path $outputDir $outFileName
            $html | Out-File -FilePath $outFilePath -Encoding UTF8
            Show-ThemedDialog -Title ((T "DiagExportDoneTitle")) `
                -Message "$((T 'DiagExportHtmlDone' 'Informe HTML generado')):`n$outFilePath" -Type "success"
            Start-Process $outFilePath
        } catch {
            Show-ThemedDialog -Title "Error" -Message "Error: $($_.Exception.Message)" -Type "error"
        }
    })

    # -- Cerrar ---------------------------------------------------------------
    $dWindow.FindName("btnCloseDiag").Add_Click({ $dWindow.Close() })

    # -- Asegurar que el sistema de toast está habilitado --
    try { [SysOpt.Toast.ToastManager]::Enabled = $true } catch { }

    # -- Toast: disparar al renderizar la ventana (evita que ShowDialog lo bloquee) -
    $dWindow.Add_ContentRendered({
        Show-Toast -Title (T "ToastAnalysisDoneTitle") -Message (T "ToastAnalysisDoneMsg") -Type "Info"
    })

    # -- Custom title bar: DragMove + close --
    $diagTitleBar = $dWindow.FindName("titleBarDiag")
    if ($null -ne $diagTitleBar) { $diagTitleBar.Add_MouseLeftButtonDown({ $dWindow.DragMove() }.GetNewClosure()) }
    $btnTitleCloseDiag2 = $dWindow.FindName("btnTitleCloseDiag")
    if ($null -ne $btnTitleCloseDiag2) { $btnTitleCloseDiag2.Add_Click({ $dWindow.Close() }.GetNewClosure()) }
    $dWindow.Add_Closed({ try { $window.Activate() } catch {} })

    $dWindow.Owner = $window
    $dWindow.ShowDialog() | Out-Null
}

# --- Show-ExportProgressDialog ---------------------------------------------
function global:Show-ExportProgressDialog {
    param([string]$OperationTitle = (T "Processing" "Procesando..."))

    # -- Construir la ventana 100% programáticamente -- sin FindName, sin Name= en XAML --
    # FindName falla con WindowStyle=None + AllowsTransparency=True antes de Show().
    # Al crear los controles directamente tenemos referencias directas, sin ambigüedad.

    $dlg = New-Object System.Windows.Window
    $dlg.Title                  = ""
    $dlg.Width                  = 460
    $dlg.SizeToContent          = "Height"
    $dlg.WindowStartupLocation  = "CenterOwner"
    $dlg.ResizeMode             = "NoResize"
    $dlg.WindowStyle            = "None"
    $dlg.AllowsTransparency     = $true
    $dlg.Background             = [System.Windows.Media.Brushes]::Transparent
    $dlg.Topmost                = $true
    try { $dlg.Owner = $window } catch {}

    # Sombra exterior
    $shadow = New-Object System.Windows.Media.Effects.DropShadowEffect
    $shadow.BlurRadius = 30; $shadow.ShadowDepth = 0; $shadow.Opacity = 0.6
    $shadow.Color = [System.Windows.Media.Colors]::Black

    # Border raíz
    $rootBorder = New-Object System.Windows.Controls.Border
    $rootBorder.Background   = [System.Windows.Media.BrushConverter]::new().ConvertFromString((Get-TC 'BgCardDark' '#131625'))
    $rootBorder.BorderBrush  = [System.Windows.Media.BrushConverter]::new().ConvertFromString((Get-TC 'AccentBlue' '#5BA3FF'))
    $rootBorder.BorderThickness = [System.Windows.Thickness]::new(1)
    $rootBorder.CornerRadius = [System.Windows.CornerRadius]::new(12)
    $rootBorder.Effect       = $shadow

    # StackPanel principal
    $sp = New-Object System.Windows.Controls.StackPanel
    $sp.Margin = [System.Windows.Thickness]::new(24,20,24,20)

    # -- Cabecera --
    $spHead = New-Object System.Windows.Controls.StackPanel
    $spHead.Orientation = "Horizontal"
    $spHead.Margin = [System.Windows.Thickness]::new(0,0,0,14)

    $iconBorder = New-Object System.Windows.Controls.Border
    $iconBorder.Width = 30; $iconBorder.Height = 30
    $iconBorder.CornerRadius = [System.Windows.CornerRadius]::new(7)
    $iconBorder.Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString((Get-TC 'AccentBlue' '#5BA3FF'))
    $iconBorder.Margin = [System.Windows.Thickness]::new(0,0,12,0)
    $iconBorder.VerticalAlignment = "Center"
    $tbIcon = New-Object System.Windows.Controls.TextBlock
    $tbIcon.Text = [char]0x21E9; $tbIcon.FontSize = 14; $tbIcon.FontWeight = "Bold"
    $tbIcon.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString((Get-TC 'BgDeep' '#0D0F1A'))
    $tbIcon.HorizontalAlignment = "Center"; $tbIcon.VerticalAlignment = "Center"
    $iconBorder.Child = $tbIcon

    $tbTitle = New-Object System.Windows.Controls.TextBlock
    $tbTitle.Text = (T "SnapProcessing"); $tbTitle.FontSize = 14; $tbTitle.FontWeight = "Bold"
    $tbTitle.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString((Get-TC 'TextPrimary' '#E8ECF4'))
    $tbTitle.VerticalAlignment = "Center"
    $tbTitle.FontFamily = [System.Windows.Media.FontFamily]::new("Segoe UI")

    $spHead.Children.Add($iconBorder) | Out-Null
    $spHead.Children.Add($tbTitle)    | Out-Null

    # -- Fase --
    $tbPhase = New-Object System.Windows.Controls.TextBlock
    $tbPhase.Text = (T "SnapInitializing"); $tbPhase.FontSize = 11.5
    $tbPhase.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString((Get-TC 'TextMuted' '#7880A0'))
    $tbPhase.TextTrimming = "CharacterEllipsis"
    $tbPhase.Margin = [System.Windows.Thickness]::new(0,0,0,10)
    $tbPhase.FontFamily = [System.Windows.Media.FontFamily]::new("Segoe UI")

    # -- Barra de progreso --
    $barTrack = New-Object System.Windows.Controls.Border
    $barTrack.Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString((Get-TC 'BgInput' '#1A1E2F'))
    $barTrack.CornerRadius = [System.Windows.CornerRadius]::new(6)
    $barTrack.Height = 14; $barTrack.Margin = [System.Windows.Thickness]::new(0,0,0,8)
    $barGrid = New-Object System.Windows.Controls.Grid
    $barFill = New-Object System.Windows.Controls.Border
    $barFill.Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString((Get-TC 'AccentBlue' '#5BA3FF'))
    $barFill.CornerRadius = [System.Windows.CornerRadius]::new(6)
    $barFill.HorizontalAlignment = "Left"; $barFill.Width = 0
    $barGrid.Children.Add($barFill) | Out-Null
    $barTrack.Child = $barGrid

    # -- % + ETA --
    $gridPct = New-Object System.Windows.Controls.Grid
    $gridPct.Margin = [System.Windows.Thickness]::new(0,0,0,4)
    $colStar = New-Object System.Windows.Controls.ColumnDefinition; $colStar.Width = [System.Windows.GridLength]::new(1, "Star")
    $colAuto = New-Object System.Windows.Controls.ColumnDefinition; $colAuto.Width = [System.Windows.GridLength]::Auto
    $gridPct.ColumnDefinitions.Add($colStar) | Out-Null
    $gridPct.ColumnDefinitions.Add($colAuto) | Out-Null

    $tbPct = New-Object System.Windows.Controls.TextBlock
    $tbPct.Text = "0%"; $tbPct.FontSize = 12; $tbPct.FontWeight = "Bold"
    $tbPct.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString((Get-TC 'AccentBlue' '#5BA3FF'))
    $tbPct.FontFamily = [System.Windows.Media.FontFamily]::new("Segoe UI")
    [System.Windows.Controls.Grid]::SetColumn($tbPct, 0)

    $tbEta = New-Object System.Windows.Controls.TextBlock
    $tbEta.Text = ""; $tbEta.FontSize = 11
    $tbEta.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString((Get-TC 'AccentGreen' '#4AE896'))
    $tbEta.HorizontalAlignment = "Right"
    $tbEta.FontFamily = [System.Windows.Media.FontFamily]::new("Segoe UI")
    [System.Windows.Controls.Grid]::SetColumn($tbEta, 1)

    $gridPct.Children.Add($tbPct) | Out-Null
    $gridPct.Children.Add($tbEta) | Out-Null

    # -- Contador --
    $tbCount = New-Object System.Windows.Controls.TextBlock
    $tbCount.Text = ""; $tbCount.FontSize = 10.5
    $tbCount.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString((Get-TC 'TextMuted' '#4A5270'))
    $tbCount.Margin = [System.Windows.Thickness]::new(0,0,0,14)
    $tbCount.FontFamily = [System.Windows.Media.FontFamily]::new("Segoe UI")

    # -- Botón segundo plano --
    $btn = New-Object System.Windows.Controls.Button
    $btn.Content = [string]([char]0x2193) + "  " + (T "SnapPutBackground" "Poner en segundo plano")
    $btn.Height = 32
    $btn.Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString((Get-TC 'BgInput' '#1A1E2F'))
    $btn.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString((Get-TC 'TextMuted' '#7880A0'))
    $btn.BorderBrush = [System.Windows.Media.BrushConverter]::new().ConvertFromString((Get-TC 'BorderSubtle' '#2A3050'))
    $btn.BorderThickness = [System.Windows.Thickness]::new(1)
    $btn.FontSize = 11.5
    $btn.FontFamily = [System.Windows.Media.FontFamily]::new("Segoe UI")
    $btn.Cursor = [System.Windows.Input.Cursors]::Hand
    $btn.HorizontalAlignment = "Right"
    $btn.Padding = [System.Windows.Thickness]::new(16,0,16,0)
    # GetNewClosure() captura $dlg por valor en el scope actual de la función,
    # evitando que el closure busque la variable en el scope del caller (que ya no existe).
    # _showTasksFn es una referencia al scope global para que el closure la encuentre.
    $script:_showTasksFn = ${function:Show-TasksWindow}
    $btn.Add_Click(({
        param()
        try { $dlg.Hide() } catch {}
        try { & $script:_showTasksFn } catch {}
    }.GetNewClosure()))

    # Ensamblar
    $sp.Children.Add($spHead)   | Out-Null
    $sp.Children.Add($tbPhase)  | Out-Null
    $sp.Children.Add($barTrack) | Out-Null
    $sp.Children.Add($gridPct)  | Out-Null
    $sp.Children.Add($tbCount)  | Out-Null
    $sp.Children.Add($btn)      | Out-Null
    $rootBorder.Child = $sp
    $dlg.Content = $rootBorder
    $dlg.Add_MouseLeftButtonDown(({ param(); try { $dlg.DragMove() } catch {} }.GetNewClosure()))

    return @{
        Window  = $dlg
        Title   = $tbTitle
        Phase   = $tbPhase
        BarFill = $barFill
        Pct     = $tbPct
        Eta     = $tbEta
        Count   = $tbCount
        BtnBg   = $btn
    }
}

# --- Show-FolderScanner ----------------------------------------------------
function global:Show-FolderScanner {
    param([string]$FolderPath)

    $fsXaml = [XamlLoader]::Load($script:XamlFolder, "FolderScannerWindow")
    $fsXaml = $ExecutionContext.InvokeCommand.ExpandString($fsXaml)

    $fsReader  = [System.Xml.XmlNodeReader]::new([xml]$fsXaml)
    $fsWindow  = [Windows.Markup.XamlReader]::Load($fsReader)
    $fsWindow.Owner = $window

    # -- Obtener controles --
    $fsPathLabel   = $fsWindow.FindName("fsPathLabel")
    $fsTotalSize   = $fsWindow.FindName("fsTotalSize")
    $fsFileCount   = $fsWindow.FindName("fsFileCount")
    $fsFilter      = $fsWindow.FindName("fsFilter")
    $fsFilterHint  = $fsWindow.FindName("fsFilterHint")
    $fsSortSize    = $fsWindow.FindName("fsSortSize")
    $fsSortName    = $fsWindow.FindName("fsSortName")
    $fsSortExt     = $fsWindow.FindName("fsSortExt")
    $fsListBox     = $fsWindow.FindName("fsListBox")
    $fsScanStatus  = $fsWindow.FindName("fsScanStatus")
    $fsScanProgress= $fsWindow.FindName("fsScanProgress")
    $fsScanCount   = $fsWindow.FindName("fsScanCount")
    $fsSelInfo     = $fsWindow.FindName("fsSelInfo")
    $fsBtnClose    = $fsWindow.FindName("fsBtnClose")
    $fsAdvToggle   = $fsWindow.FindName("fsAdvToggle")
    $fsAdvPanel    = $fsWindow.FindName("fsAdvPanel")
    $fsSizeMin     = $fsWindow.FindName("fsSizeMin")
    $fsSizeMax     = $fsWindow.FindName("fsSizeMax")
    $fsDateFrom    = $fsWindow.FindName("fsDateFrom")
    $fsDateTo      = $fsWindow.FindName("fsDateTo")
    $fsExtVideo    = $fsWindow.FindName("fsExtVideo")
    $fsExtAudio    = $fsWindow.FindName("fsExtAudio")
    $fsExtImage    = $fsWindow.FindName("fsExtImage")
    $fsExtDoc      = $fsWindow.FindName("fsExtDoc")
    $fsExtArchive  = $fsWindow.FindName("fsExtArchive")
    $fsExtOther    = $fsWindow.FindName("fsExtOther")
    $fsApplyFilters = $fsWindow.FindName("fsApplyFilters")
    $fsClearFilters = $fsWindow.FindName("fsClearFilters")
    $fsCtxMenu     = $fsListBox.ContextMenu
    $fsCtxPreview  = $fsCtxMenu.Items | Where-Object { $_.Name -eq "fsCtxPreview"  }
    $fsCtxLocation = $fsCtxMenu.Items | Where-Object { $_.Name -eq "fsCtxLocation" }
    $fsCtxDelete   = $fsCtxMenu.Items | Where-Object { $_.Name -eq "fsCtxDelete"   }

    $fsPathLabel.Text = $FolderPath
    $script:fsAllItems  = [System.Collections.Generic.List[object]]::new()
    $script:fsSortMode  = "size"   # "size" | "name" | "ext"
    $script:fsFilterTxt = ""
    $script:fsAdvEnabled = $false
    $script:fsSizeMinB   = 0
    $script:fsSizeMaxB   = 0
    $script:fsDateFromDt = $null
    $script:fsDateToDt   = $null
    $script:fsExtAll     = $true
    $script:fsExtEnabled = @{ video = $true; audio = $true; image = $true; doc = $true; archive = $true; other = $true }
    $script:fsActiveFilterCount = 0

    # -- Helper: formatear tamaño --
    function global:Format-FsSize([long]$b) {
        if ($b -ge 1GB) { return "{0:N2} GB" -f ($b / 1GB) }
        if ($b -ge 1MB) { return "{0:N1} MB" -f ($b / 1MB) }
        if ($b -ge 1KB) { return "{0:N0} KB" -f ($b / 1KB) }
        return "$b B"
    }

    # -- Helper: color por tamaño --
    function global:Get-FsSizeColor([long]$b) {
        if ($b -ge 1GB)  { return "#FF6B84" }
        if ($b -ge 100MB){ return "#FFB547" }
        if ($b -ge 10MB) { return "#5BA3FF" }
        return "#9BA4C0"
    }

    # -- Helper: icono por extensión --
    function global:Get-FsIcon([string]$ext) {
        switch ($ext.ToLower()) {
            {$_ -in @(".mp4",".mkv",".avi",".mov",".wmv",".ts",".m2ts")} { return "$([char]::ConvertFromUtf32(0x1F3AC))" }
            {$_ -in @(".mp3",".flac",".wav",".aac",".ogg",".m4a")}        { return "$([char]::ConvertFromUtf32(0x1F3B5))" }
            {$_ -in @(".jpg",".jpeg",".png",".gif",".bmp",".webp",".raw")} { return "$([char]::ConvertFromUtf32(0x1F5BC))" }
            {$_ -in @(".zip",".rar",".7z",".tar",".gz",".bz2")}           { return "$([char]::ConvertFromUtf32(0x1F4E6))" }
            {$_ -in @(".exe",".msi",".dll",".sys")}                        { return "$([char]0x2699)" }
            {$_ -in @(".pdf")}                                             { return "$([char]::ConvertFromUtf32(0x1F4C4))" }
            {$_ -in @(".doc",".docx",".odt")}                              { return "$([char]::ConvertFromUtf32(0x1F4DD))" }
            {$_ -in @(".xls",".xlsx",".csv")}                              { return "$([char]::ConvertFromUtf32(0x1F4CA))" }
            {$_ -in @(".ppt",".pptx")}                                     { return "$([char]::ConvertFromUtf32(0x1F4D1))" }
            {$_ -in @(".iso",".img",".vhd",".vmdk")}                       { return "$([char]::ConvertFromUtf32(0x1F4BF))" }
            {$_ -in @(".ps1",".py",".js",".ts",".cs",".cpp",".h")}        { return "$([char]::ConvertFromUtf32(0x1F4DC))" }
            default                                                         { return "$([char]::ConvertFromUtf32(0x1F4C4))" }
        }
    }

    # -- Refrescar la lista con filtro y orden actuales --
    # -- Helper: categorizar extensión para filtros avanzados --
    function global:Get-FsExtCategory([string]$ext) {
        switch ($ext.ToLower()) {
            { $_ -in @('mp4','mkv','avi','mov','wmv','flv','webm','m4v','mpg','mpeg','3gp') } { return 'video' }
            { $_ -in @('mp3','wav','flac','aac','ogg','wma','m4a','opus','aiff') } { return 'audio' }
            { $_ -in @('jpg','jpeg','png','gif','bmp','svg','webp','ico','tiff','tif','psd','raw','cr2') } { return 'image' }
            { $_ -in @('pdf','doc','docx','xls','xlsx','ppt','pptx','txt','rtf','odt','csv','md','html','htm','xml') } { return 'doc' }
            { $_ -in @('zip','rar','7z','tar','gz','bz2','iso','cab','xz','zst') } { return 'archive' }
            default { return 'other' }
        }
    }

    function global:Refresh-FsList {
        $fsListBox.ItemsSource = $null

        # Text filter
        $filtered = if ($script:fsFilterTxt -ne "") {
            $script:fsAllItems | Where-Object { $_.FullPath -like "*$($script:fsFilterTxt)*" }
        } else { $script:fsAllItems }

        # Advanced filters (single-pass foreach for performance)
        if ($script:fsAdvEnabled) {
            $adv = [System.Collections.Generic.List[object]]::new()
            foreach ($it in $filtered) {
                # Size filter
                if ($script:fsSizeMinB -gt 0 -and $it.SizeBytes -lt $script:fsSizeMinB) { continue }
                if ($script:fsSizeMaxB -gt 0 -and $it.SizeBytes -gt $script:fsSizeMaxB) { continue }
                # Date filter
                if ($null -ne $script:fsDateFromDt -or $null -ne $script:fsDateToDt) {
                    $modDate = $null
                    try { $modDate = [DateTime]::ParseExact($it.Modified.Trim(), "dd/MM/yyyy  HH:mm", $null) } catch {}
                    if ($null -ne $modDate) {
                        if ($null -ne $script:fsDateFromDt -and $modDate -lt $script:fsDateFromDt) { continue }
                        if ($null -ne $script:fsDateToDt -and $modDate -gt $script:fsDateToDt.AddDays(1)) { continue }
                    }
                }
                # Extension filter
                if (-not $script:fsExtAll) {
                    $cat = Get-FsExtCategory $it.Ext
                    if (-not $script:fsExtEnabled[$cat]) { continue }
                }
                $adv.Add($it)
            }
            $filtered = $adv
        }

        $sorted = switch ($script:fsSortMode) {
            "name" { $filtered | Sort-Object DisplayName }
            "ext"  { $filtered | Sort-Object Ext, DisplayName }
            default{ $filtered | Sort-Object SizeBytes -Descending }
        }

        $maxB = [long]0
        foreach ($it in $script:fsAllItems) { if ($it.SizeBytes -gt $maxB) { $maxB = $it.SizeBytes } }
        if ($maxB -le 0) { $maxB = 1 }

        $rows = [System.Collections.Generic.List[object]]::new([Math]::Max(1, $script:fsAllItems.Count))
        foreach ($it in $sorted) {
            $it.BarW = [Math]::Max(4, [int](($it.SizeBytes / $maxB) * 700))
            $rows.Add($it)
        }
        $fsListBox.ItemsSource = $rows

        # Update counts (filtered view)
        $filteredBytes = [long]0
        foreach ($it in $rows) { $filteredBytes += $it.SizeBytes }
        $fsTotalSize.Text = Format-FsSize $filteredBytes
        $fsFileCount.Text = "$($rows.Count) $((T 'FsFiles'))"
        if ($script:fsAdvEnabled -and $script:fsActiveFilterCount -gt 0) {
            $fsFileCount.Text += "  ($($script:fsActiveFilterCount) $(T 'FsActiveFilters'))"
        }
    }

    # -- Escaneo streaming con ConcurrentQueue (nunca bloquea la UI) --
    $script:fsScanQueue  = [System.Collections.Concurrent.ConcurrentQueue[object]]::new()
    $script:fsScanDone   = $false
    $script:fsTotalBytes = [long]0

    $scanScript = {
        param(
            [string]$root,
            [System.Collections.Concurrent.ConcurrentQueue[object]]$queue,
            [ref]$done
        )
        try {
            $di = [System.IO.DirectoryInfo]::new($root)
            foreach ($f in $di.EnumerateFiles("*", [System.IO.SearchOption]::AllDirectories)) {
                try {
                    $queue.Enqueue([PSCustomObject]@{
                        P = $f.FullName
                        N = $f.Name
                        B = $f.Length
                        X = $f.Extension
                        M = $f.LastWriteTime.ToString("dd/MM/yyyy  HH:mm")
                    })
                } catch {}
            }
        } catch {}
        $done.Value = $true
    }

    $rsFs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
    $rsFs.Open()
    $psFs = [System.Management.Automation.PowerShell]::Create()
    $psFs.Runspace = $rsFs
    [void]$psFs.AddScript($scanScript).AddParameter("root", $FolderPath).AddParameter("queue", $script:fsScanQueue).AddParameter("done", ([ref]$script:fsScanDone))
    $asyncFs = $psFs.BeginInvoke()

    # Lote adaptativo: en equipos con poca RAM disponible se reduce automáticamente
    $availMB = [Math]::Round([SystemDataCollector]::GetRamSnapshot().FreeBytes / 1MB)
    $BATCH = if ($availMB -lt 2048) { 50 } elseif ($availMB -lt 4096) { 150 } else { 300 }

    $script:_scanTimer = New-Object System.Windows.Threading.DispatcherTimer
    $scanTimer = $script:_scanTimer
    # Intervalo adaptativo: más lento si hay poca RAM libre
    $scanIntervalMs = if ($availMB -lt 2048) { 250 } elseif ($availMB -lt 4096) { 180 } else { 120 }
    $scanTimer.Interval = [TimeSpan]::FromMilliseconds($scanIntervalMs)
    $scanTimer.Add_Tick({
        # Drena hasta $BATCH items de la queue
        $processed = 0
        $item = $null
        while ($processed -lt $BATCH -and $script:fsScanQueue.TryDequeue([ref]$item)) {
            $ext  = if ($item.X) { $item.X } else { "" }
            $icon = Get-FsIcon $ext
            $sc   = Get-FsSizeColor $item.B
            $script:fsAllItems.Add([PSCustomObject]@{
                FullPath    = $item.P
                DisplayName = $item.N
                SizeBytes   = $item.B
                SizeStr     = Format-FsSize $item.B
                SizeColor   = $sc
                Ext         = $ext.TrimStart(".")
                Modified    = $item.M
                Icon        = $icon
                NameColor   = "#E8ECF4"
                BarC        = $sc
                BarW        = 0
            })
            $script:fsTotalBytes += $item.B
            $processed++
            $item = $null  # liberar referencia al objeto de cola
        }

        # Actualizar contador en vivo
        $cnt = $script:fsAllItems.Count
        if ($cnt -gt 0) {
            $fsScanStatus.Text = "$((T "ScanDefaultName"))...   $cnt $((T "FsFiles"))  *  $(Format-FsSize $script:fsTotalBytes)"
            $fsScanCount.Text  = "$cnt $((T "FsFiles"))"
        }

        # ¿Terminado? Queue vacía Y runspace señaliza done
        if ($script:fsScanDone -and $script:fsScanQueue.IsEmpty) {
            $scanTimer.Stop()

            # Limpiar runspace
            try { $psFs.Stop()  } catch {}
            try { $psFs.Dispose() } catch {}
            try { $rsFs.Close(); $rsFs.Dispose() } catch {}

            # Liberar memoria del proceso -- trabajar como el gestor de RAM de SysOpt
            [System.GC]::Collect()
            [System.GC]::WaitForPendingFinalizers()
            [System.GC]::Collect()
            try {
                # [DLL] WseTrim -- cargado al inicio en el bloque de DLLs
                if (([System.Management.Automation.PSTypeName]'WseTrim').Type) {
                    [WseTrim]::TrimCurrentProcess()
                }
            } catch {}

            $fsScanProgress.IsIndeterminate = $false
            $fsScanProgress.Value           = 100
            $cnt2 = $script:fsAllItems.Count
            $fsScanStatus.Text = "$([char]0x2705)  $((T "FsScanDone")) -- $cnt2 $((T "FsFiles"))  *  $(Format-FsSize $script:fsTotalBytes)"
            Write-Log ("[SCAN] Completado: {0} archivos  |  {1}  |  ruta: {2}" -f $cnt2, (Format-FsSize $script:fsTotalBytes), $FolderPath) -Level "INFO" -NoUI
            Show-Toast -Title (T "ToastFolderScanDoneTitle" "Explorador listo") `
                       -Message "$cnt2 $(T 'FsFiles' 'archivos')  *  $(Format-FsSize $script:fsTotalBytes)" `
                       -Type "Info"
            $fsScanCount.Text  = "$cnt2 $((T "FsFiles"))"
            $fsTotalSize.Text  = Format-FsSize $script:fsTotalBytes
            $fsFileCount.Text  = "$cnt2 $((T "FsFiles"))"
            Refresh-FsList
        }
    })
    $scanTimer.Start()

    # -- Filtro en tiempo real --
    $fsFilter.Add_TextChanged({
        $script:fsFilterTxt = $fsFilter.Text
        $fsFilterHint.Visibility = if ($fsFilter.Text -eq "") {
            [System.Windows.Visibility]::Visible
        } else {
            [System.Windows.Visibility]::Collapsed
        }
        Refresh-FsList
    })

    # -- Advanced filter handlers --
    $_fbc = [System.Windows.Media.BrushConverter]::new()
    $fsAdvToggle.Add_Click({
        if ($fsAdvPanel.Visibility -eq [System.Windows.Visibility]::Collapsed) {
            $fsAdvPanel.Visibility = [System.Windows.Visibility]::Visible
            $fsAdvToggle.Content = (T 'FsAdvFiltersHide' ([string]([char]0x2699) + " Ocultar"))
            $fsAdvToggle.Background = ($_fbc.ConvertFromString((Get-TC 'ComboSelected' '#132040')))
            $fsAdvToggle.Foreground = ($_fbc.ConvertFromString((Get-TC 'AccentBlue' '#5BA3FF')))
        } else {
            $fsAdvPanel.Visibility = [System.Windows.Visibility]::Collapsed
            $fsAdvToggle.Content = (T 'FsAdvFilters' ([string]([char]0x2699) + " Filtros"))
            $fsAdvToggle.Background = ($_fbc.ConvertFromString((Get-TC 'BgInput' '#1A1E2F')))
            $fsAdvToggle.Foreground = ($_fbc.ConvertFromString((Get-TC 'TextSecondary' '#9BA4C0')))
        }
    })

    $fsApplyFilters.Add_Click({
        $script:fsAdvEnabled = $true
        $script:fsActiveFilterCount = 0
        # Size
        $script:fsSizeMinB = 0; $script:fsSizeMaxB = 0
        try { if ($fsSizeMin.Text -ne "") { $script:fsSizeMinB = [long]([double]$fsSizeMin.Text * 1MB); $script:fsActiveFilterCount++ } } catch {}
        try { if ($fsSizeMax.Text -ne "") { $script:fsSizeMaxB = [long]([double]$fsSizeMax.Text * 1MB); $script:fsActiveFilterCount++ } } catch {}
        # Date
        $script:fsDateFromDt = $null; $script:fsDateToDt = $null
        try { if ($fsDateFrom.Text -ne "") { $script:fsDateFromDt = [DateTime]::ParseExact($fsDateFrom.Text.Trim(), "dd/MM/yyyy", $null); $script:fsActiveFilterCount++ } } catch {}
        try { if ($fsDateTo.Text -ne "") { $script:fsDateToDt = [DateTime]::ParseExact($fsDateTo.Text.Trim(), "dd/MM/yyyy", $null); $script:fsActiveFilterCount++ } } catch {}
        # Extension
        $script:fsExtEnabled.video   = $fsExtVideo.IsChecked
        $script:fsExtEnabled.audio   = $fsExtAudio.IsChecked
        $script:fsExtEnabled.image   = $fsExtImage.IsChecked
        $script:fsExtEnabled.doc     = $fsExtDoc.IsChecked
        $script:fsExtEnabled.archive = $fsExtArchive.IsChecked
        $script:fsExtEnabled.other   = $fsExtOther.IsChecked
        $script:fsExtAll = ($script:fsExtEnabled.Values | Where-Object { -not $_ }).Count -eq 0
        if (-not $script:fsExtAll) { $script:fsActiveFilterCount++ }
        Refresh-FsList
    })

    $fsClearFilters.Add_Click({
        $script:fsAdvEnabled = $false
        $script:fsSizeMinB = 0; $script:fsSizeMaxB = 0
        $script:fsDateFromDt = $null; $script:fsDateToDt = $null
        $script:fsExtAll = $true
        $script:fsActiveFilterCount = 0
        foreach ($k in @('video','audio','image','doc','archive','other')) { $script:fsExtEnabled[$k] = $true }
        $fsSizeMin.Text = ""; $fsSizeMax.Text = ""
        $fsDateFrom.Text = ""; $fsDateTo.Text = ""
        $fsExtVideo.IsChecked = $true; $fsExtAudio.IsChecked = $true
        $fsExtImage.IsChecked = $true; $fsExtDoc.IsChecked = $true
        $fsExtArchive.IsChecked = $true; $fsExtOther.IsChecked = $true
        Refresh-FsList
    })

    $bc_ = [System.Windows.Media.BrushConverter]::new()
    # -- Botones de ordenación --
    $fsSortSize.Add_Click({
        $script:fsSortMode = "size"
        $fsSortSize.Background = ($bc_.ConvertFromString((Get-TC 'ComboSelected' '#132040')))
        $fsSortSize.Foreground = ($bc_.ConvertFromString((Get-TC 'AccentBlue'    '#5BA3FF')))
        $fsSortName.Background = ($bc_.ConvertFromString((Get-TC 'BgInput'       '#1A1E2F')))
        $fsSortName.Foreground = ($bc_.ConvertFromString((Get-TC 'TextSecondary' '#9BA4C0')))
        $fsSortExt.Background  = ($bc_.ConvertFromString((Get-TC 'BgInput'       '#1A1E2F')))
        $fsSortExt.Foreground  = ($bc_.ConvertFromString((Get-TC 'TextSecondary' '#9BA4C0')))
        Refresh-FsList
    })
    $fsSortName.Add_Click({
        $script:fsSortMode = "name"
        $fsSortName.Background = ($bc_.ConvertFromString((Get-TC 'ComboSelected' '#132040')))
        $fsSortName.Foreground = ($bc_.ConvertFromString((Get-TC 'AccentBlue'    '#5BA3FF')))
        $fsSortSize.Background = ($bc_.ConvertFromString((Get-TC 'BgInput'       '#1A1E2F')))
        $fsSortSize.Foreground = ($bc_.ConvertFromString((Get-TC 'TextSecondary' '#9BA4C0')))
        $fsSortExt.Background  = ($bc_.ConvertFromString((Get-TC 'BgInput'       '#1A1E2F')))
        $fsSortExt.Foreground  = ($bc_.ConvertFromString((Get-TC 'TextSecondary' '#9BA4C0')))
        Refresh-FsList
    })
    $fsSortExt.Add_Click({
        $script:fsSortMode = "ext"
        $fsSortExt.Background  = ($bc_.ConvertFromString((Get-TC 'ComboSelected' '#132040')))
        $fsSortExt.Foreground  = ($bc_.ConvertFromString((Get-TC 'AccentBlue'    '#5BA3FF')))
        $fsSortSize.Background = ($bc_.ConvertFromString((Get-TC 'BgInput'       '#1A1E2F')))
        $fsSortSize.Foreground = ($bc_.ConvertFromString((Get-TC 'TextSecondary' '#9BA4C0')))
        $fsSortName.Background = ($bc_.ConvertFromString((Get-TC 'BgInput'       '#1A1E2F')))
        $fsSortName.Foreground = ($bc_.ConvertFromString((Get-TC 'TextSecondary' '#9BA4C0')))
        Refresh-FsList
    })

    # -- Info de selección --
    $fsListBox.Add_SelectionChanged({
        $sel = $fsListBox.SelectedItem
        if ($null -ne $sel) {
            $fsSelInfo.Text = "$($sel.DisplayName)   *   $($sel.SizeStr)   *   $($sel.Modified)"
        } else { $fsSelInfo.Text = "" }
    })

    # -- Doble clic -> abrir --
    $fsListBox.Add_MouseDoubleClick({
        $sel = $fsListBox.SelectedItem
        if ($null -ne $sel -and (Test-Path $sel.FullPath)) {
            try { Start-Process $sel.FullPath } catch {
                Show-ThemedDialog -Title ((T "ErrOpenFileTitle")) `
                    -Message "$((T "ErrOpenFileDetail"))`n$($_.Exception.Message)" -Type "error"
            }
        }
    })

    # -- Menú contextual de archivos --
    $fsCtxMenu.Add_Opened({
        $sel = $fsListBox.SelectedItem
        $has = $null -ne $sel -and (Test-Path $sel.FullPath)
        $fsCtxPreview.IsEnabled  = $has
        $fsCtxLocation.IsEnabled = $has
        $fsCtxDelete.IsEnabled   = $has
    })

    $fsCtxPreview.Add_Click({
        $sel = $fsListBox.SelectedItem
        if ($null -ne $sel -and (Test-Path $sel.FullPath)) {
            try { Start-Process $sel.FullPath } catch {
                Show-ThemedDialog -Title ((T "ErrOpenFileTitle")) `
                    -Message "No se puede abrir el archivo.`n$($_.Exception.Message)" -Type "error"
            }
        }
    })

    $fsCtxLocation.Add_Click({
        $sel = $fsListBox.SelectedItem
        if ($null -ne $sel -and (Test-Path $sel.FullPath)) {
            # Abrir explorador seleccionando el archivo
            Start-Process "explorer.exe" "/select,`"$($sel.FullPath)`""
        }
    })

    $fsCtxDelete.Add_Click({
        $sel = $fsListBox.SelectedItem
        if ($null -eq $sel) { return }
        $confirm = Show-ThemedDialog -Title ((T "DlgConfirmDeleteTitle")) `
            -Message "$((T "DlgConfirmDeleteFileMsg"))`n`n$($sel.FullPath)`n`n$((T "DlgSize")): $($sel.SizeStr)`n`n$((T "DlgCannotUndo"))" `
            -Type "warning" -Buttons "YesNo"
        if ($confirm) {
            try {
                Remove-Item -Path $sel.FullPath -Force -ErrorAction Stop
                $script:fsAllItems.Remove($sel) | Out-Null
                $fsScanStatus.Text = "$([char]::ConvertFromUtf32(0x1F5D1))  $(T 'Deleted' 'Eliminado'): $($sel.FullPath)"
                Refresh-FsList
            } catch {
Set-SplashProgress 98 (T "SplashLoading98" "Herramientas de diagnóstico...")
                Show-ThemedDialog -Title ((T "DlgDeleteError")) `
                    -Message "$(T 'ErrDeleting' 'Error al eliminar'):`n$($_.Exception.Message)" -Type "error"
            }
        }
    })

    # -- Cerrar --
    $fsBtnClose.Add_Click({
        $scanTimer.Stop()
        $script:fsScanDone = $true          # señaliza al runspace que pare
        try { $psFs.Stop()    } catch {}
        try { $psFs.Dispose() } catch {}
        try { $rsFs.Close(); $rsFs.Dispose() } catch {}
        [System.GC]::Collect()
        $fsWindow.Close()
    })
    $fsWindow.Add_Closed({
        $scanTimer.Stop()
        $script:fsScanDone = $true
        try { $psFs.Stop()    } catch {}
        try { $psFs.Dispose() } catch {}
        try { $rsFs.Close(); $rsFs.Dispose() } catch {}
        [System.GC]::Collect()
        try { $window.Activate() } catch {}
    })

    $fsWindow.ShowDialog() | Out-Null
}

# --- Show-OptionsWindow ----------------------------------------------------
function global:Show-OptionsWindow {
    param([string]$StartPage = "interface")
    $optXaml = [XamlLoader]::Load($script:XamlFolder, "OptionsWindow")
    $optXaml = $ExecutionContext.InvokeCommand.ExpandString($optXaml)
    try {
        $optReader = [System.Xml.XmlNodeReader]::new([xml]$optXaml)
        $optWin    = [Windows.Markup.XamlReader]::Load($optReader)
        $optWin.Owner = $window

        # -- Custom title bar: DragMove + close --
        $optTitleBar = $optWin.FindName("titleBarOpt")
        if ($null -ne $optTitleBar) { $optTitleBar.Add_MouseLeftButtonDown({ $optWin.DragMove() }.GetNewClosure()) }
        $btnTitleCloseOpt = $optWin.FindName("btnTitleCloseOpt")
Set-SplashProgress 95 (T "SplashLoading95" "Ventana de opciones...")
        if ($null -ne $btnTitleCloseOpt) { $btnTitleCloseOpt.Add_Click({ $optWin.Close() }.GetNewClosure()) }
        $optWin.Add_Closed({ try { $window.Activate() } catch {} })

        # -- FindName all controls --
        $cmbTheme       = $optWin.FindName("cmbTheme")
        $cmbLang        = $optWin.FindName("cmbLang")
        $tglDebugLog    = $optWin.FindName("tglDebugLog")
        $tglToast       = $optWin.FindName("tglToast")
        $btnNavInterface= $optWin.FindName("btnNavInterface")
        $btnNavBehavior = $optWin.FindName("btnNavBehavior")
        $txtNavInterface= $optWin.FindName("txtNavInterface")
        $txtNavBehavior = $optWin.FindName("txtNavBehavior")
        $pageInterface  = $optWin.FindName("pageInterface")
        $pageBehavior   = $optWin.FindName("pageBehavior")
        $scrollInterface = $optWin.FindName("scrollInterface")
        $scrollBehavior  = $optWin.FindName("scrollBehavior")
        $scrollAbout     = $optWin.FindName("scrollAbout")
        $btnToastTest       = $optWin.FindName("btnToastTest")
        $cmbToastDuration   = $optWin.FindName("cmbToastDuration")
        $cmbToastCorner     = $optWin.FindName("cmbToastCorner")

        # Named elements for dynamic theming
        $borderSidebar  = $optWin.FindName("borderSidebar")
        $optBgRect      = $optWin.FindName("optBgRect")
        $cardTheme      = $optWin.FindName("cardTheme")
        $cardLang       = $optWin.FindName("cardLang")
        $cardToast          = $optWin.FindName("cardToast")
        $cardToastTest      = $optWin.FindName("cardToastTest")
        $cardToastDuration  = $optWin.FindName("cardToastDuration")
        $cardToastCorner    = $optWin.FindName("cardToastCorner")
        $cardDebug      = $optWin.FindName("cardDebug")
        $txtOptHeader   = $optWin.FindName("txtOptHeader")
        $txtThemeSection= $optWin.FindName("txtThemeSection")
        $txtLangSection = $optWin.FindName("txtLangSection")
        $txtToastSection= $optWin.FindName("txtToastSection")
        $txtDebugSection= $optWin.FindName("txtDebugSection")
        $txtThemeLabel  = $optWin.FindName("txtThemeLabel")
        $txtLangLabel   = $optWin.FindName("txtLangLabel")
        $txtToastLabel  = $optWin.FindName("txtToastLabel")
        $txtToastDesc   = $optWin.FindName("txtToastDesc")
        $txtDebugLabel  = $optWin.FindName("txtDebugLabel")
        $txtDebugDesc   = $optWin.FindName("txtDebugDesc")
        $txtOptHint     = $optWin.FindName("txtOptHint")
        $txtToastTestLabel   = $optWin.FindName("txtToastTestLabel")
        $txtToastTestDesc    = $optWin.FindName("txtToastTestDesc")
        $txtToastDurationLabel = $optWin.FindName("txtToastDurationLabel")
        $txtToastDurationDesc  = $optWin.FindName("txtToastDurationDesc")
        $txtToastCornerLabel   = $optWin.FindName("txtToastCornerLabel")
        $txtToastCornerDesc    = $optWin.FindName("txtToastCornerDesc")
        $btnOptApply    = $optWin.FindName("btnOptApply")
        $btnOptClose    = $optWin.FindName("btnOptClose")
        # -- About section controls --
        $pageAbout      = $optWin.FindName("pageAbout")
        $btnNavAbout    = $optWin.FindName("btnNavAbout")
        $txtNavAbout    = $optWin.FindName("txtNavAbout")
        $runNavAbout    = $optWin.FindName("runNavAbout")
        $aboutLogoOpt   = $optWin.FindName("aboutLogoOpt")
        $txtAboutSubtitle = $optWin.FindName("txtAboutSubtitle")
        $txtAboutDeveloper= $optWin.FindName("txtAboutDeveloper")
        $lnkGithubOpt   = $optWin.FindName("lnkGithubOpt")
        $txtAboutCopyright= $optWin.FindName("txtAboutCopyright")
        $btnChangelog   = $optWin.FindName("btnChangelog")
        $btnLicense     = $optWin.FindName("btnLicense")
        $buttonsPanel   = $optWin.FindName("buttonsPanel")
        # -- Module system controls --
        $btnNavModules   = $optWin.FindName("btnNavModules")
        $txtNavModules   = $optWin.FindName("txtNavModules")
        $scrollModules   = $optWin.FindName("scrollModules")
        $pageModules     = $optWin.FindName("pageModules")
        $btnModInstall   = $optWin.FindName("btnModInstall")
        $lblModCount     = $optWin.FindName("lblModCount")
        $icModules       = $optWin.FindName("icModules")
        $tglSafeMode     = $optWin.FindName("tglSafeMode")
        $cardSafeMode    = $optWin.FindName("cardSafeMode")
        $txtSafeModeSection = $optWin.FindName("txtSafeModeSection")
        $txtSafeModeLabel   = $optWin.FindName("txtSafeModeLabel")
        $txtSafeModeDesc    = $optWin.FindName("txtSafeModeDesc")

        # -- [NEW] Output Panel default state toggle --
        $tglOutputCollapsed = $optWin.FindName("tglOutputCollapsed")

        $bc = [System.Windows.Media.BrushConverter]::new()

        # -- Sync toggles with current state --
        if ($null -ne $tglDebugLog) {
            $tglDebugLog.IsChecked = [LogEngine]::DebugEnabled
        }
        # Safe Mode toggle
        if ($tglSafeMode) {
            $tglSafeMode.IsChecked = ($script:SafeMode -eq $true)
        }
        # Output Panel default state toggle
        if ($tglOutputCollapsed) {
            $tglOutputCollapsed.IsChecked = $(if ($null -ne $global:_sysoptOutputDefaultCollapsed) { $global:_sysoptOutputDefaultCollapsed } else { ($script:OutputDefaultCollapsed -eq $true) })
        }
        if ($null -ne $tglToast) {
            $tglToast.IsChecked = if (([System.Management.Automation.PSTypeName]"SysOpt.Toast.ToastManager").Type) {
                [SysOpt.Toast.ToastManager]::Enabled
            } else { $true }
        }

        # -- Toast Duration ComboBox --
        if ($null -ne $cmbToastDuration) {
            $durationOptions = @(
                @{ Label = (T "OptToastDur3s"  "3 segundos");  Ms = 3000  }
                @{ Label = (T "OptToastDur4s"  "4 segundos");  Ms = 4000  }
                @{ Label = (T "OptToastDur5s"  "5 segundos");  Ms = 5000  }
                @{ Label = (T "OptToastDur7s"  "7 segundos");  Ms = 7000  }
                @{ Label = (T "OptToastDur10s" "10 segundos"); Ms = 10000 }
            )
            $currentDurMs = if (([System.Management.Automation.PSTypeName]"SysOpt.Toast.ToastManager").Type) {
                [SysOpt.Toast.ToastManager]::DefaultDurationMs
            } else { 4000 }
            foreach ($opt in $durationOptions) {
                $cbi = New-Object System.Windows.Controls.ComboBoxItem
                $cbi.Content = $opt.Label; $cbi.Tag = $opt.Ms
                $cbi.Background = [System.Windows.Media.Brushes]::Transparent
                $cbi.Foreground = $bc.ConvertFromString((Get-TC "TextPrimary" "#E8EAF6"))
                [void]$cmbToastDuration.Items.Add($cbi)
                if ($opt.Ms -eq $currentDurMs) { $cmbToastDuration.SelectedItem = $cbi }
            }
            if ($cmbToastDuration.SelectedItem -eq $null) { $cmbToastDuration.SelectedIndex = 1 }
            $cmbToastDuration.Foreground = $bc.ConvertFromString((Get-TC "TextPrimary" "#E8EAF6"))
        }

        # -- Toast Corner ComboBox --
        if ($null -ne $cmbToastCorner) {
            $cornerOptions = @(
                @{ Label = (T "OptToastCornerBR" "$([char]0x2198) Abajo derecha");  Value = "BottomRight" }
                @{ Label = (T "OptToastCornerBL" "$([char]0x2199) Abajo izquierda"); Value = "BottomLeft"  }
                @{ Label = (T "OptToastCornerTR" "$([char]0x2197) Arriba derecha"); Value = "TopRight"    }
                @{ Label = (T "OptToastCornerTL" "$([char]0x2196) Arriba izquierda"); Value = "TopLeft"     }
            )
            $currentCorner = if (([System.Management.Automation.PSTypeName]"SysOpt.Toast.ToastManager").Type) {
                [SysOpt.Toast.ToastManager]::Corner.ToString()
            } else { "BottomRight" }
            foreach ($opt in $cornerOptions) {
                $cbi = New-Object System.Windows.Controls.ComboBoxItem
                $cbi.Content = $opt.Label; $cbi.Tag = $opt.Value
                $cbi.Background = [System.Windows.Media.Brushes]::Transparent
                $cbi.Foreground = $bc.ConvertFromString((Get-TC "TextPrimary" "#E8EAF6"))
                [void]$cmbToastCorner.Items.Add($cbi)
                if ($opt.Value -eq $currentCorner) { $cmbToastCorner.SelectedItem = $cbi }
            }
            if ($cmbToastCorner.SelectedItem -eq $null) { $cmbToastCorner.SelectedIndex = 0 }
            $cmbToastCorner.Foreground = $bc.ConvertFromString((Get-TC "TextPrimary" "#E8EAF6"))
        }


        # -- Modules list refresh --
        $global:_sysoptRefreshModules = {
            if (-not $icModules) { return }
            $icModules.Items.Clear()
            $modules = Get-InstalledModules

            if ($lblModCount) {
                $lblModCount.Text = "$($modules.Count) $(T 'ModInstalledCount' 'módulos instalados')"
            }

            foreach ($mod in $modules) {
                $border = [System.Windows.Controls.Border]::new()
                $border.CornerRadius = [System.Windows.CornerRadius]::new(6)
                $border.Padding = [System.Windows.Thickness]::new(12,10,12,10)
                $border.Margin = [System.Windows.Thickness]::new(0,4,0,4)
                $border.Background = [System.Windows.Media.SolidColorBrush]::new(
                    [System.Windows.Media.ColorConverter]::ConvertFromString((Get-TC 'BgDeep' '#0D0F1A')))

                $dock = [System.Windows.Controls.DockPanel]::new()

                # Right side: toggle + delete button
                $btnPanel = [System.Windows.Controls.StackPanel]::new()
                $btnPanel.Orientation = 'Horizontal'
                $btnPanel.SetValue([System.Windows.Controls.DockPanel]::DockProperty,
                    [System.Windows.Controls.Dock]::Right)

                # Toggle enable/disable
                $tgl = [System.Windows.Controls.Primitives.ToggleButton]::new()
                $tgl.IsChecked = $mod.Enabled
                try { $tgl.Style = $optWin.FindResource('Win11Toggle') } catch {}
                $tgl.Tag = $mod.Id
                $tgl.Margin = [System.Windows.Thickness]::new(8,0,8,0)
                $tgl.VerticalAlignment = 'Center'
                $modId = $mod.Id
                $tgl.Add_Click({
                    param($sender, $e)
                    $id = $sender.Tag
                    if ($sender.IsChecked) {
                        Enable-SysOptModule $id
                    } else {
                        Disable-SysOptModule $id
                    }
                }.GetNewClosure())


                # Delete button
                $btnDel = [System.Windows.Controls.Button]::new()
                $btnDel.Content = "$([char]::ConvertFromUtf32(0x1F5D1))"
                $btnDel.Tag = $mod.Id
                $btnDel.Cursor = [System.Windows.Input.Cursors]::Hand
                $btnDel.FontSize = 14
                $btnDel.Background = [System.Windows.Media.Brushes]::Transparent
                $btnDel.Foreground = [System.Windows.Media.SolidColorBrush]::new(
                    [System.Windows.Media.ColorConverter]::ConvertFromString('#F85149'))
                $btnDel.BorderThickness = [System.Windows.Thickness]::new(0)
                $btnDel.Padding = [System.Windows.Thickness]::new(6,2,6,2)
                $btnDel.VerticalAlignment = 'Center'
                $btnDel.Add_Click({
                    param($sender, $e)
                    Uninstall-SysOptModule $sender.Tag
                    & $global:_sysoptRefreshModules
                }.GetNewClosure())

                $btnPanel.Children.Add($tgl) | Out-Null
                $btnPanel.Children.Add($btnDel) | Out-Null
                $dock.Children.Add($btnPanel) | Out-Null

                # Left side: module info
                $info = [System.Windows.Controls.StackPanel]::new()

                $header = [System.Windows.Controls.StackPanel]::new()
                $header.Orientation = 'Horizontal'

                $icon = [System.Windows.Controls.TextBlock]::new()
                $icon.Text = $mod.Icon
                $icon.FontSize = 18
                $icon.Margin = [System.Windows.Thickness]::new(0,0,8,0)
                $icon.VerticalAlignment = 'Center'
                $header.Children.Add($icon) | Out-Null

                $name = [System.Windows.Controls.TextBlock]::new()
                $name.Text = "$($mod.Name)  v$($mod.Version)"
                $name.FontSize = 13
                $name.FontWeight = [System.Windows.FontWeights]::SemiBold
                $name.Foreground = [System.Windows.Media.SolidColorBrush]::new(
                    [System.Windows.Media.ColorConverter]::ConvertFromString((Get-TC 'TextPrimary' '#E8EAF6')))
                $name.VerticalAlignment = 'Center'
                $header.Children.Add($name) | Out-Null

                # Status badge
                $statusBadge = [System.Windows.Controls.TextBlock]::new()
                $statusBadge.FontSize = 10
                $statusBadge.Margin = [System.Windows.Thickness]::new(10,0,0,0)
                $statusBadge.VerticalAlignment = 'Center'
                if ($mod.Enabled) {
                    $statusBadge.Text = "$([char]0x25CF) $(T 'ModEnabled' 'Habilitado')"
                    $statusBadge.Foreground = [System.Windows.Media.SolidColorBrush]::new(
                        [System.Windows.Media.ColorConverter]::ConvertFromString('#4ADE80'))
                } else {
                    $statusBadge.Text = "$([char]0x25CF) $(T 'ModDisabled' 'Deshabilitado')"
                    $statusBadge.Foreground = [System.Windows.Media.SolidColorBrush]::new(
                        [System.Windows.Media.ColorConverter]::ConvertFromString('#6B7494'))
                }
                $header.Children.Add($statusBadge) | Out-Null
                $info.Children.Add($header) | Out-Null

                if ($mod.Description) {
                    $desc = [System.Windows.Controls.TextBlock]::new()
                    $desc.Text = $mod.Description
                    $desc.FontSize = 11
                    $desc.Foreground = [System.Windows.Media.SolidColorBrush]::new(
                        [System.Windows.Media.ColorConverter]::ConvertFromString((Get-TC 'TextSecondary' '#9BA4C0')))
                    $desc.TextWrapping = 'Wrap'
                    $desc.Margin = [System.Windows.Thickness]::new(26,2,0,0)
                    $info.Children.Add($desc) | Out-Null
                }

                if ($mod.Author -or $mod.Category) {
                    $meta = [System.Windows.Controls.TextBlock]::new()
                    $parts = @()
                    if ($mod.Author)   { $parts += $mod.Author }
                    if ($mod.Category) { $parts += $mod.Category }
                    $meta.Text = $parts -join ' * '
                    $meta.FontSize = 10
                    $meta.Foreground = [System.Windows.Media.SolidColorBrush]::new(
                        [System.Windows.Media.ColorConverter]::ConvertFromString((Get-TC 'TextMuted' '#6B7494')))
                    $meta.Margin = [System.Windows.Thickness]::new(26,2,0,0)
                    $info.Children.Add($meta) | Out-Null
                }

                $dock.Children.Add($info) | Out-Null
                $border.Child = $dock
                $icModules.Items.Add($border) | Out-Null
            }

            # Empty state
            if ($modules.Count -eq 0) {
                $empty = [System.Windows.Controls.TextBlock]::new()
                $empty.Text = T 'ModNoModules' 'No hay módulos instalados'
                $empty.FontSize = 13
                $empty.Foreground = [System.Windows.Media.SolidColorBrush]::new(
                    [System.Windows.Media.ColorConverter]::ConvertFromString((Get-TC 'TextMuted' '#6B7494')))
                $empty.HorizontalAlignment = 'Center'
                $empty.Margin = [System.Windows.Thickness]::new(0,30,0,30)
                $icModules.Items.Add($empty) | Out-Null
            }
        }.GetNewClosure()

        # -- Install module handler --
        if ($btnModInstall) {
            $btnModInstall.Add_Click({
                Add-Type -AssemblyName System.Windows.Forms
                $ofd = [System.Windows.Forms.OpenFileDialog]::new()
                $ofd.Title = T "ModSelectZip" "Seleccionar módulo (ZIP)"
                $ofd.Filter = "ZIP files (*.zip)|*.zip"
                if ($ofd.ShowDialog() -eq 'OK') {
                    $result = Install-SysOptModule -ZipPath $ofd.FileName
                    if ($result) {
                        & $global:_sysoptRefreshModules
                    }
                }
            }.GetNewClosure())
        }

        # -- Navigation: page switching --
        $script:_optCurrentPage = $StartPage

        $selectNav = {
            param([string]$Page)
            $script:_optCurrentPage = $Page
            # Reset all pages (ScrollViewers wrap the StackPanels)
            if ($scrollInterface) { $scrollInterface.Visibility = "Collapsed" }
            if ($scrollBehavior)  { $scrollBehavior.Visibility  = "Collapsed" }
            if ($scrollAbout)     { $scrollAbout.Visibility     = "Collapsed" }
            if ($scrollModules)   { $scrollModules.Visibility   = "Collapsed" }
            # Hide Aplicar/Cerrar on About page
            if ($buttonsPanel) {
                $buttonsPanel.Visibility = if ($Page -eq "about" -or $Page -eq "modules") { "Collapsed" } else { "Visible" }
            }
            foreach ($btn in @($btnNavInterface, $btnNavBehavior, $btnNavAbout, $btnNavModules)) {
                if ($btn) { $btn.Background = [System.Windows.Media.Brushes]::Transparent }
            }
            foreach ($txt in @($txtNavInterface, $txtNavBehavior, $txtNavAbout, $txtNavModules)) {
                if ($txt) {
                    $txt.Foreground = $bc.ConvertFromString((Get-TC 'TextSecondary' '#9BA4C0'))
                    $txt.FontWeight = [System.Windows.FontWeights]::Normal
                }
            }
            # Activate selected page
            switch ($Page) {
                "interface" {
                    if ($scrollInterface) { $scrollInterface.Visibility = "Visible" }
                    $btnNavInterface.Background = $bc.ConvertFromString((Get-TC 'ComboSelected' '#1E3060'))
                    $txtNavInterface.Foreground = $bc.ConvertFromString((Get-TC 'AccentBlue' '#5BA3FF'))
                    $txtNavInterface.FontWeight = [System.Windows.FontWeights]::SemiBold
                }
                "behavior" {
                    if ($scrollBehavior) { $scrollBehavior.Visibility = "Visible" }
                    $btnNavBehavior.Background = $bc.ConvertFromString((Get-TC 'ComboSelected' '#1E3060'))
                    $txtNavBehavior.Foreground = $bc.ConvertFromString((Get-TC 'AccentBlue' '#5BA3FF'))
                    $txtNavBehavior.FontWeight = [System.Windows.FontWeights]::SemiBold
                }
                "about" {
                    if ($scrollAbout) { $scrollAbout.Visibility = "Visible" }
                    if ($btnNavAbout) { $btnNavAbout.Background = $bc.ConvertFromString((Get-TC 'ComboSelected' '#1E3060')) }
                    if ($txtNavAbout) {
                        $txtNavAbout.Foreground = $bc.ConvertFromString((Get-TC 'AccentBlue' '#5BA3FF'))
                        $txtNavAbout.FontWeight = [System.Windows.FontWeights]::SemiBold
                    }
                }
                "modules" {
                    if ($scrollModules) { $scrollModules.Visibility = "Visible" }
                    if ($btnNavModules) { $btnNavModules.Background = $bc.ConvertFromString((Get-TC 'ComboSelected' '#1E3060')) }
                    if ($txtNavModules) {
                        $txtNavModules.Foreground = $bc.ConvertFromString((Get-TC 'AccentBlue' '#5BA3FF'))
                        $txtNavModules.FontWeight = [System.Windows.FontWeights]::SemiBold
                    }
                    # Refresh modules list on navigate
                    & $global:_sysoptRefreshModules
                }
            }
        }.GetNewClosure()
        & $selectNav $StartPage

        $btnNavInterface.Add_MouseLeftButtonDown({
            & $selectNav "interface"
        }.GetNewClosure())
        $btnNavBehavior.Add_MouseLeftButtonDown({
            & $selectNav "behavior"
        }.GetNewClosure())

        # -- About nav handler --
        if ($btnNavAbout) {
            $btnNavAbout.Add_MouseLeftButtonDown({
                & $selectNav "about"
            }.GetNewClosure())
        }

        # -- Modules nav handler --
        if ($btnNavModules) {
            $btnNavModules.Add_MouseLeftButtonDown({
                & $selectNav "modules"
            }.GetNewClosure())
        }

        # -- About section wiring --
        # Load logo from main window
        if ($null -ne $aboutLogoOpt -and $null -ne $imgLogo -and $null -ne $imgLogo.Source) {
            $aboutLogoOpt.Source = $imgLogo.Source
        }
        # GitHub link handler
        if ($null -ne $lnkGithubOpt) {
            $lnkGithubOpt.Add_RequestNavigate({
                param($sender, $e)
                Start-Process $e.Uri.AbsoluteUri
                $e.Handled = $true
            })
        }

        # -- Easter egg: 4 clicks on logo -> Breakout --
        if ($null -ne $aboutLogoOpt) {
            $_egg = @{ clicks = 0; last = [DateTime]::MinValue }
            $aboutLogoOpt.Add_MouseLeftButtonDown({
                $now = [DateTime]::Now
                if (($now - $_egg.last).TotalMilliseconds -gt 1500) { $_egg.clicks = 0 }
                $_egg.clicks++
                $_egg.last = $now
                if ($_egg.clicks -ge 4) {
                    $_egg.clicks = 0
                    Show-BreakoutGame
                }
            }.GetNewClosure())
        }


        # Changelog button handler -- pre-capture script-scope vars for closure
        if ($null -ne $btnChangelog) {
            $_xf = $script:XamlFolder
            # Pre-format AppNotes hashtable -> readable string
            $_an = ""
            if ($null -ne $script:AppNotes -and $script:AppNotes.Cambios) {
                $sb  = [System.Text.StringBuilder]::new()
                $bw  = 56  # box inner width
                $sep = [string]::new([char]'?', $bw + 2)
                foreach ($ver in $script:AppNotes.Cambios.Keys) {
                    $entry  = $script:AppNotes.Cambios[$ver]
                    $header = "  ? $ver -- $($entry.Titulo)  "
                    if ($header.Length -lt $bw) { $header = $header.PadRight($bw) }

                    # -- Version box --
                    [void]$sb.AppendLine("?$([string]::new([char]'=', $bw))?")
                    [void]$sb.AppendLine("|$header|")
                    [void]$sb.AppendLine("?$([string]::new([char]'=', $bw))?")
                    [void]$sb.AppendLine("")

                    # -- Group items by [TAG] --
                    $groups = [ordered]@{}
                    foreach ($item in $entry.Items) {
                        if ($item -match '^\[([^\]]+)\]\s*(.+)$') {
                            $tag  = $Matches[1]
                            $text = $Matches[2]
                        } else {
                            $tag  = 'MISC'
                            $text = $item
                        }
                        if (-not $groups.Contains($tag)) { $groups[$tag] = [System.Collections.Generic.List[string]]::new() }
                        $groups[$tag].Add($text)
                    }

                    foreach ($tag in $groups.Keys) {
                        $tagLabel = "- $tag "
                        $fill     = [Math]::Max(1, $bw - $tagLabel.Length - 1)
                        [void]$sb.AppendLine("  +$tagLabel$([string]::new([char]'-', $fill))")
                        foreach ($it in $groups[$tag]) {
                            [void]$sb.AppendLine("  |  * $it")
                        }
                        [void]$sb.AppendLine("  |")
                    }
                    [void]$sb.AppendLine($sep)
                    [void]$sb.AppendLine("")
                }
                $_an = $sb.ToString()
            }
            $btnChangelog.Add_Click({
                try {
                    $clXaml = [XamlLoader]::Load($_xf, "ChangelogWindow")
                    $clXaml = $ExecutionContext.InvokeCommand.ExpandString($clXaml)
                    $clReader = [System.Xml.XmlNodeReader]::new([xml]$clXaml)
                    $clWin    = [Windows.Markup.XamlReader]::Load($clReader)
                    $clWin.Owner = $optWin
                    $clTitleBar = $clWin.FindName("titleBarCL")
                    if ($null -ne $clTitleBar) { $clTitleBar.Add_MouseLeftButtonDown({ $clWin.DragMove() }.GetNewClosure()) }
                    $btnTitleCloseCL = $clWin.FindName("btnTitleCloseCL")
                    if ($null -ne $btnTitleCloseCL) { $btnTitleCloseCL.Add_Click({ $clWin.Close() }.GetNewClosure()) }
                    $clTxt = $clWin.FindName("txtCLContent")
                    if ($null -ne $clTxt) {
                        $clTxt.Text = $_an
                    }
                    $clClose = $clWin.FindName("btnCLClose")
                    if ($null -ne $clClose) {
                        $clClose.Add_Click({ $clWin.Close() }.GetNewClosure())
                    }
                    [void]$clWin.ShowDialog()
                } catch {
                    Write-Log ("[OPTIONS] " + (T 'ErrOpenChangelog' 'Error opening changelog') + " $_") -Level ERR
                }
            }.GetNewClosure())
        }

        # License button handler
        if ($null -ne $btnLicense) {
            $_licPath = Join-Path $script:AppDir "LICENSE"
            $_xfLic = $script:XamlFolder
            $btnLicense.Add_Click({
                try {
                    $licContent = ""
                    if (Test-Path $_licPath) {
                        $licContent = [System.IO.File]::ReadAllText($_licPath, [System.Text.Encoding]::UTF8)
                    } else {
                        $licContent = T 'LicenseNotFound' 'No se encontró el archivo LICENSE.'
                    }
                    $licXaml = [XamlLoader]::Load($_xfLic, "LicenseWindow")
                    $licXaml = $ExecutionContext.InvokeCommand.ExpandString($licXaml)
                    $licReader = [System.Xml.XmlNodeReader]::new([xml]$licXaml)
                    $licWin    = [Windows.Markup.XamlReader]::Load($licReader)
                    $licWin.Owner = $optWin
                    $licTitleBar = $licWin.FindName("titleBarLIC")
                    if ($null -ne $licTitleBar) { $licTitleBar.Add_MouseLeftButtonDown({ $licWin.DragMove() }.GetNewClosure()) }
                    $btnTitleCloseLIC = $licWin.FindName("btnTitleCloseLIC")
                    if ($null -ne $btnTitleCloseLIC) { $btnTitleCloseLIC.Add_Click({ $licWin.Close() }.GetNewClosure()) }
                    $licTxt = $licWin.FindName("txtLICContent")
                    if ($null -ne $licTxt) {
                        $licTxt.Text = $licContent
                    }
                    $licClose = $licWin.FindName("btnLICClose")
                    if ($null -ne $licClose) {
                        $licClose.Add_Click({ $licWin.Close() }.GetNewClosure())
                    }
                    [void]$licWin.ShowDialog()
                } catch {
                    Write-Log ("[OPTIONS] " + (T 'ErrOpenLicense' 'Error opening license') + " $_") -Level ERR
                }
            }.GetNewClosure())
        }

        # -- Poblar ComboBox de temas --
        $themeNames = [ThemeEngine]::ListThemes($script:ThemesDir)
        foreach ($tn in $themeNames) {
            $meta = [ThemeEngine]::GetThemeMeta((Join-Path $script:ThemesDir "$tn.theme"))
            $displayName = if ($meta.ContainsKey("Name")) { $meta["Name"] } else { $tn }
            $item = New-Object System.Windows.Controls.ComboBoxItem
            $item.Content    = $displayName
            $item.Tag        = $tn
            $item.Foreground = $bc.ConvertFromString((Get-TC "TextPrimary" "#E8EAF6"))
            $item.Background = [System.Windows.Media.Brushes]::Transparent
            [void]$cmbTheme.Items.Add($item)
            if ($tn -eq $script:CurrentTheme) { $cmbTheme.SelectedItem = $item }
        }
        $cmbTheme.Foreground = $bc.ConvertFromString((Get-TC "TextPrimary" "#E8EAF6"))
        if ($cmbTheme.SelectedItem -eq $null -and $cmbTheme.Items.Count -gt 0) {
            $cmbTheme.SelectedIndex = 0
        }

        # -- Poblar ComboBox de idiomas --
        $langCodes = [LangEngine]::ListLanguages($script:LangDir)
        foreach ($lc in $langCodes) {
            $meta = [LangEngine]::GetLangMeta((Join-Path $script:LangDir "$lc.lang"))
            $displayName = if ($meta.ContainsKey("Name")) { $meta["Name"] } else { $lc }
            $item = New-Object System.Windows.Controls.ComboBoxItem
            $item.Content    = $displayName
            $item.Tag        = $lc
            $item.Foreground = $bc.ConvertFromString((Get-TC "TextPrimary" "#E8EAF6"))
            $item.Background = [System.Windows.Media.Brushes]::Transparent
            [void]$cmbLang.Items.Add($item)
            if ($lc -eq $script:CurrentLang) { $cmbLang.SelectedItem = $item }
        }
        $cmbLang.Foreground = $bc.ConvertFromString((Get-TC "TextPrimary" "#E8EAF6"))
        if ($cmbLang.SelectedItem -eq $null -and $cmbLang.Items.Count -gt 0) {
            $cmbLang.SelectedIndex = 0
        }

        # -- [FIX] Apply dark theme to ALL ComboBoxes at initial load --
        # Sin esto, los ComboBox usan el template WPF por defecto (blanco)
        foreach ($cb in @($cmbTheme, $cmbLang, $cmbToastDuration, $cmbToastCorner)) {
            if ($null -ne $cb) { Apply-ComboBoxDarkTheme $cb }
        }

        # -- Helper: Apply theme to Options window dynamically --
        $applyOptTheme = {
            $bcc = [System.Windows.Media.BrushConverter]::new()
            try { $optBgRect.Fill        = $bcc.ConvertFromString((Get-TC 'BgDeep'        '#0D0F1A')) } catch {}
            try { $optWin.Background     = $bcc.ConvertFromString((Get-TC 'BgDeep'        '#0D0F1A')) } catch {}
            try { $borderSidebar.Background = $bcc.ConvertFromString((Get-TC 'BgCard'     '#161925')) } catch {}
            foreach ($card in @($cardTheme, $cardLang, $cardToast, $cardToastTest, $cardToastDuration, $cardToastCorner, $cardDebug)) {
                try { if ($card) { $card.Background = $bcc.ConvertFromString((Get-TC 'BgCard' '#161925')) } } catch {}
            }
            # Section headers
            foreach ($tb in @($txtThemeSection, $txtLangSection, $txtToastSection, $txtDebugSection, $txtOptHint)) {
                try { if ($tb) { $tb.Foreground = $bcc.ConvertFromString((Get-TC 'TextMuted' '#6B7494')) } } catch {}
            }
            # Labels primary
            foreach ($tb in @($txtThemeLabel, $txtLangLabel, $txtToastLabel, $txtDebugLabel, $txtToastTestLabel, $txtToastDurationLabel, $txtToastCornerLabel)) {
                try { if ($tb) { $tb.Foreground = $bcc.ConvertFromString((Get-TC 'TextPrimary' '#E8EAF6')) } } catch {}
            }
            # Labels secondary
            foreach ($tb in @($txtToastDesc, $txtDebugDesc, $txtToastTestDesc, $txtToastDurationDesc, $txtToastCornerDesc)) {
                try { if ($tb) { $tb.Foreground = $bcc.ConvertFromString((Get-TC 'TextSecondary' '#9BA4C0')) } } catch {}
            }
            # About section theming
            foreach ($tb in @($txtAboutSubtitle, $txtAboutCopyright)) {
                try { if ($tb) { $tb.Foreground = $bcc.ConvertFromString((Get-TC 'TextMuted' '#6B7494')) } } catch {}
            }
            try { if ($txtAboutDeveloper) { $txtAboutDeveloper.Foreground = $bcc.ConvertFromString((Get-TC 'TextSecondary' '#9BA4C0')) } } catch {}
            try {
                if ($btnChangelog) {
                    $btnChangelog.Background  = $bcc.ConvertFromString((Get-TC 'BtnSecondaryBg' '#1E2235'))
                    $btnChangelog.BorderBrush = $bcc.ConvertFromString((Get-TC 'AccentBlue'     '#5BA3FF'))
                    $btnChangelog.Foreground  = $bcc.ConvertFromString((Get-TC 'AccentBlue'     '#5BA3FF'))
                }
            } catch {}
            # Title
            try { $txtOptHeader.Foreground = $bcc.ConvertFromString((Get-TC 'TextPrimary' '#E8EAF6')) } catch {}
            # Buttons
            try {
                $btnOptApply.Background  = $bcc.ConvertFromString((Get-TC 'BtnSecondaryBg' '#1E2235'))
                $btnOptApply.BorderBrush = $bcc.ConvertFromString((Get-TC 'AccentBlue'     '#5BA3FF'))
                $btnOptApply.Foreground  = $bcc.ConvertFromString((Get-TC 'AccentBlue'     '#5BA3FF'))
            } catch {}
            try {
                $btnOptClose.Background  = $bcc.ConvertFromString((Get-TC 'HdrBtnBg'      '#1E2235'))
                $btnOptClose.BorderBrush = $bcc.ConvertFromString((Get-TC 'HdrBtnBorder'  '#2A2F48'))
                $btnOptClose.Foreground  = $bcc.ConvertFromString((Get-TC 'TextSecondary' '#9BA4C0'))
            } catch {}
            try {
                $btnToastTest.Background  = $bcc.ConvertFromString((Get-TC 'BtnSecondaryBg' '#1E2235'))
                $btnToastTest.BorderBrush = $bcc.ConvertFromString((Get-TC 'AccentBlue'     '#5BA3FF'))
                $btnToastTest.Foreground  = $bcc.ConvertFromString((Get-TC 'AccentBlue'     '#5BA3FF'))
            } catch {}
            # Install Module button
            try {
                if ($btnModInstall) {
                    $btnModInstall.Background = $bcc.ConvertFromString((Get-TC 'BtnModInstallBg' '#A47CFF'))
                    $btnModInstall.Foreground = $bcc.ConvertFromString((Get-TC 'BtnModInstallFg' '#FFFFFF'))
                }
            } catch {}
            # Re-select current nav
            & $selectNav $script:_optCurrentPage
            # ComboBoxes
            try {
                $allCbs = [ThemeApplier]::GetVisualChildren($optWin) | Where-Object { $_ -is [System.Windows.Controls.ComboBox] }
                foreach ($cb in $allCbs) { Apply-ComboBoxDarkTheme $cb }
            } catch {}
        }.GetNewClosure()

        # -- Botón Aplicar --
        $btnOptApply.Add_Click({
            $selectedTheme = $cmbTheme.SelectedItem.Tag
            $selectedLang  = $cmbLang.SelectedItem.Tag

            # Aplicar idioma si cambió
            if ($selectedLang -ne $script:CurrentLang) {
                Write-Log ("[CFG] Idioma cambiado: {0} -> {1}" -f $script:CurrentLang, $selectedLang) -Level "INFO" -NoUI
                Load-Language -LangCode $selectedLang
            }

            # Aplicar tema si cambió
            if ($selectedTheme -ne $script:CurrentTheme) {
                Write-Log ("[CFG] Tema cambiado: {0} -> {1}" -f $script:CurrentTheme, $selectedTheme) -Level "INFO" -NoUI
                $optWin.Hide()
                Apply-ThemeWithProgress -ThemeName $selectedTheme
                $optWin.Show()
                # [THEME] Aplicar tema dinámicamente a la ventana de opciones
                & $applyOptTheme
            }

            # Aplicar debug toggle
            if ($null -ne $tglDebugLog) {
                $newDebug = ($tglDebugLog.IsChecked -eq $true)
                [LogEngine]::DebugEnabled = $newDebug
                Update-WindowTitle
                # Sync toast debug flag
                if (([System.Management.Automation.PSTypeName]"SysOpt.Toast.ToastManager").Type) {
                    [SysOpt.Toast.ToastManager]::Debug = $newDebug
                }
                Write-Log ("[CFG] Debug logging: {0}" -f $(if ($newDebug) {"ON"} else {"OFF"})) -Level "INFO" -NoUI
            }

            # Aplicar toast toggle
            if ($null -ne $tglToast) {
                $toastOn = ($tglToast.IsChecked -eq $true)
                if (([System.Management.Automation.PSTypeName]"SysOpt.Toast.ToastManager").Type) {
                    [SysOpt.Toast.ToastManager]::Enabled = $toastOn
                }
                Write-Log ("[CFG] Toast notifications: {0}" -f $(if ($toastOn) {"ON"} else {"OFF"})) -Level "INFO" -NoUI
            }

            # Aplicar toast duration
            if ($null -ne $cmbToastDuration -and $null -ne $cmbToastDuration.SelectedItem) {
                $newDurMs = [int]$cmbToastDuration.SelectedItem.Tag
                if (([System.Management.Automation.PSTypeName]"SysOpt.Toast.ToastManager").Type) {
                    [SysOpt.Toast.ToastManager]::DefaultDurationMs = $newDurMs
                }
                Write-Log ("[CFG] Toast duration: {0}ms" -f $newDurMs) -Level "INFO" -NoUI
            }

            # Aplicar toast corner
            if ($null -ne $cmbToastCorner -and $null -ne $cmbToastCorner.SelectedItem) {
                $newCorner = $cmbToastCorner.SelectedItem.Tag
                if (([System.Management.Automation.PSTypeName]"SysOpt.Toast.ToastManager").Type) {
                    try {
                        $tc = [SysOpt.Toast.ToastCorner]::$newCorner
                        [SysOpt.Toast.ToastManager]::Corner = $tc
                    } catch {}
                }
                Write-Log ("[CFG] Toast corner: {0}" -f $newCorner) -Level "INFO" -NoUI
            }

            # Safe Mode
            if ($tglSafeMode) {
                $global:_sysoptSafeMode = ($tglSafeMode.IsChecked -eq $true)
                $script:SafeMode = $global:_sysoptSafeMode
            }

            # Output Panel default state
            if ($tglOutputCollapsed) {
                $global:_sysoptOutputDefaultCollapsed = ($tglOutputCollapsed.IsChecked -eq $true)
                $script:OutputDefaultCollapsed = $global:_sysoptOutputDefaultCollapsed
                Write-Log ("[CFG] Output panel default collapsed: {0}" -f $global:_sysoptOutputDefaultCollapsed) -Level "INFO" -NoUI
            }

            try { Save-Settings } catch {}
        }.GetNewClosure())

        # -- Botón Test Toast --
        if ($null -ne $btnToastTest) {
            $btnToastTest.Add_Click({
                Show-Toast -Title (T 'ToastTestTitle') -Message (T 'ToastTestMsg') -Type "Info"
            }.GetNewClosure())
        }

        # -- Botón Cerrar --
        $btnOptClose.Add_Click({ $optWin.Close() }.GetNewClosure())

        # -- Tematizar ventana de opciones al cargar --
        $optWin.Add_Loaded({
            try { & $applyOptTheme } catch {}
            try {
                $allCbs = [ThemeApplier]::GetVisualChildren($optWin) | Where-Object { $_ -is [System.Windows.Controls.ComboBox] }
                foreach ($cb in $allCbs) { Apply-ComboBoxDarkTheme $cb }
            } catch {}
        }.GetNewClosure())

        $optWin.ShowDialog() | Out-Null
    } catch {
        Show-ThemedDialog -Title (T 'DlgError' 'Error') `
            -Message "$(T 'ErrOpenOptions' 'Error al abrir opciones:')`n$($_.Exception.Message)" -Type "error"
    }
}

# --- Show-SfcDismWindow ----------------------------------------------------
function global:Show-SfcDismWindow {
    param([switch]$AutoRunSfc, [switch]$AutoRunDism, [switch]$IsDryRun)

    # -- Admin check ----------------------------------------------------------
    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $isAdmin) {
        Show-ThemedDialog -Title (T "SfcDismTitle") -Message (T "SfcDismNeedAdmin") -Type "warning"
        return
    }

    $script:_sdIsDryRun = [bool]$IsDryRun

    # -- Load XAML ------------------------------------------------------------
    $sdXaml  = [XamlLoader]::Load($script:XamlFolder, "SfcDismWindow")
    $sdXaml  = $ExecutionContext.InvokeCommand.ExpandString($sdXaml)
    $sReader = [System.Xml.XmlNodeReader]::new([xml]$sdXaml)
    $sdWin   = [Windows.Markup.XamlReader]::Load($sReader)

    # -- Find named elements --------------------------------------------------
    $titleBar   = $sdWin.FindName("titleBarSD")
    $script:_sdBtnClose   = $sdWin.FindName("btnCloseSfcDism")
    $script:_sdTxtStep    = $sdWin.FindName("txtSfcDismStep")
    $script:_sdProgBar    = $sdWin.FindName("progSfcDism")
    $script:_sdTxtConsole = $sdWin.FindName("txtSfcDismConsole")
    $script:_sdTxtElapsed = $sdWin.FindName("txtSfcDismElapsed")
    $script:_sdBtnSfc     = $sdWin.FindName("btnRunSfc")
    $script:_sdBtnDism    = $sdWin.FindName("btnRunDism")
    $script:_sdBtnBoth    = $sdWin.FindName("btnRunBoth")
    $script:_sdBtnCancel  = $sdWin.FindName("btnCancelSfcDism")

    # -- Draggable title bar --------------------------------------------------
    $script:_sfcDismWin = $sdWin
    $titleBar.Add_MouseLeftButtonDown({ $script:_sfcDismWin.DragMove() })

    # -- Shared state (script-scope for cross-handler access) -----------------
    $script:_sdProc      = $null        # Current child process
    $script:_sdStartTime = $null        # Timer epoch
    $script:_sdCbsSize   = 0            # CBS.log read offset (SFC)
    $script:_sdDismFile  = $null        # Temp file for DISM stdout
    $script:_sdDismPos   = 0            # DISM file read offset
    $script:_sdMode      = 'idle'       # idle | sfc | dism | both-sfc | both-dism
    $script:_sdPollN     = 0            # Tick counter for 2-second poll

    $script:_sdCbsLogPath = "$env:SystemRoot\Logs\CBS\CBS.log"

    # -- Helper: set button enabled state -------------------------------------
    $script:_sdSetButtons = {
        param([bool]$running)
        $script:_sdBtnSfc.IsEnabled    = -not $running
        $script:_sdBtnDism.IsEnabled   = -not $running
        $script:_sdBtnBoth.IsEnabled   = -not $running
        $script:_sdBtnCancel.IsEnabled = $running
        $script:_sdBtnClose.IsEnabled  = -not $running
    }

    # -- Helper: finish a run -------------------------------------------------
    $script:_sdFinish = {
        param([string]$msg)
        $script:_sdProgBar.IsIndeterminate = $false
        $script:_sdProgBar.Value = 100
        $script:_sdTimer.Stop()
        $script:_sdTxtStep.Text = $msg
        & $script:_sdSetButtons $false
        if ($script:_sdDismFile -and (Test-Path $script:_sdDismFile -ErrorAction SilentlyContinue)) {
            Remove-Item $script:_sdDismFile -Force -ErrorAction SilentlyContinue
        }
        # Signal the optimization timer that SFC/DISM repair is complete
        $script:_sfcDismDone = $true
        Write-ConsoleMain "$([char]::ConvertFromUtf32(0x1F6E1)) $(T 'SfcDismTitle'): $msg"
    }

    # -- Helper: start SFC or DISM --------------------------------------------
    $script:_sdStartTool = {
        param([string]$tool, [bool]$asBoth)

        & $script:_sdSetButtons $true
        $script:_sdProgBar.IsIndeterminate = $true
        $script:_sdStartTime = [DateTime]::Now
        $script:_sdPollN     = 0

        if ($tool -eq 'sfc') {
            $script:_sdMode = if ($asBoth) { 'both-sfc' } else { 'sfc' }
            $sfx = if ($script:_sdIsDryRun) { 'DryRun' } else { '' }
            $script:_sdTxtStep.Text = T "SfcDismRunningSfc$sfx"
            $script:_sdTxtConsole.AppendText("$(T "SfcDismSfcHeader$sfx")`r`n")
            $script:_sdTxtConsole.AppendText("  $(T "SfcDismSfcNote$sfx")`r`n")
            $script:_sdTxtConsole.AppendText("  $(T 'SfcDismPollingCbs')`r`n`r`n")

            # Record CBS.log size BEFORE starting SFC
            try {
                $script:_sdCbsSize = if (Test-Path $script:_sdCbsLogPath) {
                    (Get-Item $script:_sdCbsLogPath).Length
                } else { 0 }
            } catch { $script:_sdCbsSize = 0 }

            # Start SFC hidden (no redirect -- SFC uses WriteConsoleW internally)
            $psi = New-Object System.Diagnostics.ProcessStartInfo
            $psi.FileName        = "sfc.exe"
            $psi.Arguments       = if ($script:_sdIsDryRun) { "/verifyonly" } else { "/scannow" }
            $psi.UseShellExecute = $false
            $psi.CreateNoWindow  = $true
            try {
                $script:_sdProc = [System.Diagnostics.Process]::Start($psi)
            } catch {
                $script:_sdTxtConsole.AppendText("  ERROR: $_`r`n")
                $script:_sdMode = 'idle'; & $script:_sdSetButtons $false
                $script:_sdProgBar.IsIndeterminate = $false; return
            }
        }
        elseif ($tool -eq 'dism') {
            $script:_sdMode = if ($asBoth) { 'both-dism' } else { 'dism' }
            $sfx = if ($script:_sdIsDryRun) { 'DryRun' } else { '' }
            $script:_sdTxtStep.Text = T "SfcDismRunningDism$sfx"
            $script:_sdTxtConsole.AppendText("$(T "SfcDismDismHeader$sfx")`r`n")
            $script:_sdTxtConsole.AppendText("  $(T "SfcDismDismNote$sfx")`r`n`r`n")

            # DISM uses WriteFile -> redirect works. Pipe to temp file, poll it.
            $script:_sdDismFile = [System.IO.Path]::Combine(
                [System.IO.Path]::GetTempPath(), "sysopt_dism_out.txt")
            $script:_sdDismPos = 0
            try { if (Test-Path $script:_sdDismFile) { Remove-Item $script:_sdDismFile -Force } } catch { }

            $psi = New-Object System.Diagnostics.ProcessStartInfo
            $psi.FileName        = "cmd.exe"
            $dismCmd = if ($script:_sdIsDryRun) { "/online /cleanup-image /checkhealth" } else { "/online /cleanup-image /restorehealth" }
            $psi.Arguments       = "/c dism $dismCmd > `"$($script:_sdDismFile)`" 2>&1"
            $psi.UseShellExecute = $false
            $psi.CreateNoWindow  = $true
            try {
                $script:_sdProc = [System.Diagnostics.Process]::Start($psi)
            } catch {
                $script:_sdTxtConsole.AppendText("  ERROR: $_`r`n")
                $script:_sdMode = 'idle'; & $script:_sdSetButtons $false
                $script:_sdProgBar.IsIndeterminate = $false; return
            }
        }

        $script:_sdTimer.Start()
        $script:_sdTxtConsole.ScrollToEnd()
    }

    # -- DispatcherTimer (1-second tick) --------------------------------------
    $script:_sdTimer = New-Object System.Windows.Threading.DispatcherTimer
    $script:_sdTimer.Interval = [TimeSpan]::FromSeconds(1)
    $script:_sdTimer.Add_Tick({

        # Elapsed time
        if ($script:_sdStartTime) {
            $e = [DateTime]::Now - $script:_sdStartTime
            $script:_sdTxtElapsed.Text = "$(T 'SfcDismElapsed') $($e.ToString('mm\:ss'))"
        }

        # Poll every 2 seconds
        $script:_sdPollN++
        if ($script:_sdPollN % 2 -eq 0) {

            # -- Poll CBS.log (SFC) ---------------------------------------
            if ($script:_sdMode -match 'sfc') {
                try {
                    if (Test-Path $script:_sdCbsLogPath) {
                        $sz = (Get-Item $script:_sdCbsLogPath).Length
                        if ($sz -gt $script:_sdCbsSize) {
                            $fs = New-Object System.IO.FileStream(
                                $script:_sdCbsLogPath, 'Open', 'Read', 'ReadWrite')
                            $fs.Seek($script:_sdCbsSize, 'Begin') | Out-Null
                            $rd  = New-Object System.IO.StreamReader($fs)
                            $new = $rd.ReadToEnd()
                            $rd.Close(); $fs.Close()
                            $script:_sdCbsSize = $sz

                            $new -split "`n" |
                                Where-Object { $_ -match '\[SR\]' } |
                                ForEach-Object { $script:_sdTxtConsole.AppendText("  $($_.Trim())`r`n") }
                            $script:_sdTxtConsole.ScrollToEnd()
                        }
                    }
                } catch { }
            }

            # -- Poll temp file (DISM) ------------------------------------
            if ($script:_sdMode -match 'dism' -and $script:_sdDismFile) {
                try {
                    if (Test-Path $script:_sdDismFile) {
                        # Use FileStream with ReadWrite sharing to avoid locking
                        # conflict with cmd.exe which holds the file open for writing
                        $fs = New-Object System.IO.FileStream(
                            $script:_sdDismFile, 'Open', 'Read', 'ReadWrite')
                        if ($fs.Length -gt $script:_sdDismPos) {
                            $fs.Seek($script:_sdDismPos, 'Begin') | Out-Null
                            # DISM redirected writes in OEM codepage
                            $enc = [System.Text.Encoding]::GetEncoding(
                                [System.Globalization.CultureInfo]::CurrentCulture.TextInfo.OEMCodePage)
                            $rd  = New-Object System.IO.StreamReader($fs, $enc)
                            $new = $rd.ReadToEnd()
                            $script:_sdDismPos = $fs.Length
                            $rd.Close(); $fs.Close()

                            $new -split "`n" | ForEach-Object {
                                $l = $_.Trim()
                                if ($l) { $script:_sdTxtConsole.AppendText("  $l`r`n") }
                            }
                            $script:_sdTxtConsole.ScrollToEnd()
                        } else {
                            $fs.Close()
                        }
                    }
                } catch { }
            }
        }

        # -- Check process exit -------------------------------------------
        if ($script:_sdProc -and $script:_sdProc.HasExited) {
            $code = $script:_sdProc.ExitCode
            $script:_sdProc = $null
            $script:_sdTxtConsole.AppendText("`r`n  $(T 'SfcDismExitCode') $code`r`n`r`n")

            switch ($script:_sdMode) {
                'both-sfc' {
                    $script:_sdTxtConsole.AppendText("$(T 'SfcDismSfcDone')`r`n`r`n")
                    $script:_sdTxtConsole.ScrollToEnd()
                    # Continuar con DISM automáticamente
                    & $script:_sdStartTool 'dism' $true
                }
                'both-dism' {
                    $script:_sdTxtConsole.AppendText("$(T 'SfcDismDismDone')`r`n")
                    & $script:_sdFinish (T 'SfcDismBothDone')
                }
                'sfc' {
                    $script:_sdTxtConsole.AppendText("$(T 'SfcDismSfcDone')`r`n")
                    & $script:_sdFinish (T 'SfcDismSfcDone')
                }
                'dism' {
                    $script:_sdTxtConsole.AppendText("$(T 'SfcDismDismDone')`r`n")
                    & $script:_sdFinish (T 'SfcDismDismDone')
                }
            }
            $script:_sdTxtConsole.ScrollToEnd()
        }
    })

    # -- Button handlers ------------------------------------------------------
    $script:_sdBtnSfc.Add_Click({  $script:_sdTxtConsole.Clear(); & $script:_sdStartTool 'sfc'  $false })
    $script:_sdBtnDism.Add_Click({ $script:_sdTxtConsole.Clear(); & $script:_sdStartTool 'dism' $false })
    $script:_sdBtnBoth.Add_Click({ $script:_sdTxtConsole.Clear(); & $script:_sdStartTool 'sfc'  $true  })

    $script:_sdBtnCancel.Add_Click({
        if ($script:_sdProc -and -not $script:_sdProc.HasExited) {
            try { $script:_sdProc.Kill() } catch { }
            $script:_sdProc = $null
        }
        $script:_sdTimer.Stop()
        $script:_sdMode = 'idle'
        $script:_sdProgBar.IsIndeterminate = $false; $script:_sdProgBar.Value = 0
        $script:_sdTxtStep.Text = T 'SfcDismCancelled'
        $script:_sdTxtConsole.AppendText("`r`n$(T 'SfcDismCancelled')`r`n")
        $script:_sdTxtConsole.ScrollToEnd()
        & $script:_sdSetButtons $false
        if ($script:_sdDismFile -and (Test-Path $script:_sdDismFile)) {
            Remove-Item $script:_sdDismFile -Force -ErrorAction SilentlyContinue
        }
    })

    # -- Close ----------------------------------------------------------------
    $script:_sdBtnClose.Add_Click({ $script:_sfcDismWin.Close() })
    $sdWin.Add_Closed({
        $script:_sdTimer.Stop()
        if ($script:_sdProc -and -not $script:_sdProc.HasExited) {
            try { $script:_sdProc.Kill() } catch { }
        }
        # Signal completion so the optimization timer knows we're done
        $script:_sfcDismDone = $true
        try { $window.Activate() } catch { }
    })

    # -- Auto-run (cuando se llama desde Start-Optimization) ------------------
    if ($AutoRunSfc -and $AutoRunDism) {
        $sdWin.Add_Loaded({ & $script:_sdStartTool 'sfc' $true })
    } elseif ($AutoRunSfc) {
        $sdWin.Add_Loaded({ & $script:_sdStartTool 'sfc' $false })
    } elseif ($AutoRunDism) {
        $sdWin.Add_Loaded({ & $script:_sdStartTool 'dism' $false })
    }

    # -- Show non-modal (UI stays responsive, optimization runs in parallel) --
    $sdWin.Owner = $window
    $sdWin.Show()
}

# --- Show-StartupManager ---------------------------------------------------
function global:Show-StartupManager {
    $startupXaml = [XamlLoader]::Load($script:XamlFolder, "StartupManagerWindow")
    $startupXaml = $ExecutionContext.InvokeCommand.ExpandString($startupXaml)

    $sReader    = [System.Xml.XmlNodeReader]::new([xml]$startupXaml)
    $sWindow    = [Windows.Markup.XamlReader]::Load($sReader)
    $sGrid      = $sWindow.FindName("StartupGrid")
    $sStatus    = $sWindow.FindName("StartupStatus")
    $btnApply   = $sWindow.FindName("btnApplyStartup")
    $btnClose   = $sWindow.FindName("btnCloseStartup")
    $titleBar   = $sWindow.FindName("titleBar")

    # Drag por la barra de título (no se puede hacer en XAML puro sin code-behind)
    $script:_startupWin = $sWindow
    $titleBar.Add_MouseLeftButtonDown({ $script:_startupWin.DragMove() })

    # -- Obtener entradas de inicio vía DLL --------------------------------------
    $rawEntries = [SysOpt.StartupManager.StartupEngine]::GetEntries()
    $startupTable = New-Object System.Collections.ObjectModel.ObservableCollection[object]
    foreach ($e in $rawEntries) {
        $startupTable.Add([PSCustomObject]@{
            Enabled      = $e.Enabled
            Name         = $e.Name
            Command      = $e.Command
            Source       = $e.Source
            Location     = $e.RegPath
            OriginalName = $e.Name
            FilePath     = $e.FilePath
        })
    }
    $sGrid.ItemsSource = $startupTable
    $sStatus.Text = "$($startupTable.Count) $((T "StartupEntriesFound"))"

    $btnApply.Add_Click({
        # Construir lista de StartupEntry desde la tabla UI con el estado actual del checkbox
        $entryList = New-Object "System.Collections.Generic.List[SysOpt.StartupManager.StartupEntry]"
        foreach ($item in $startupTable) {
            $se = New-Object SysOpt.StartupManager.StartupEntry
            $se.Name         = $item.OriginalName
            $se.OriginalName = $item.OriginalName
            $se.Command      = $item.Command
            $se.RegPath      = $item.Location
            $se.Source       = $item.Source
            $se.Enabled      = $item.Enabled
            $se.Type         = if ($item.Source -eq 'Startup Folder') { 'StartupFolder' } else { 'Registry' }
            $se.FilePath     = if ($item.FilePath) { $item.FilePath } else { '' }
            $entryList.Add($se)
        }
        # ApplyChanges devuelve un ApplyResult con .Enabled, .Disabled, .Errors
        $result   = [SysOpt.StartupManager.StartupEngine]::ApplyChanges($entryList)
        $enabled  = $result.Enabled
        $disabled = $result.Disabled
        $errors   = $result.Errors

        $msg = (T 'StartupChangesResult' '{0} habilitadas, {1} deshabilitadas, {2} errores') -f $enabled, $disabled, $errors
        if ($errors -gt 0 -and $result.ErrorDetails.Count -gt 0) {
            $msg += "`n`n" + ($result.ErrorDetails -join "`n")
        }
        $type = if ($errors -gt 0) { "warning" } else { "success" }
        Show-ThemedDialog -Title (T 'StartupChangesApplied' 'Cambios aplicados') -Message $msg -Type $type
        Write-ConsoleMain "$([char]0x2699) Startup Manager: $enabled $(T 'StartupToggleEnable'), $disabled $(T 'StartupToggleDisable')"

        # [FIX-BUG3] Cerrar ventana automáticamente tras aplicar para continuar
        # con el resto de la optimización (ShowDialog se desbloquea -> flujo continúa)
        $script:_startupWin.Close()
    })

    $script:_startupWin = $sWindow
    $btnClose.Add_Click({ $script:_startupWin.Close() })
    $sWindow.Add_Closed({ try { $window.Activate() } catch {} })
    $sWindow.Owner = $window
    $sWindow.ShowDialog() | Out-Null
}

# --- Show-TasksWindow ------------------------------------------------------
function global:Show-TasksWindow {
    # Si ya está abierta, traerla al frente
    if ($null -ne $script:TasksWin -and $script:TasksWin.IsVisible) {
        try { $script:TasksWin.Activate() } catch {}
        return
    }

    $twXaml = [XamlLoader]::Load($script:XamlFolder, "TasksWindow")
    $reader = [System.Xml.XmlReader]::Create([System.IO.StringReader]::new($twXaml))
    $tw     = [System.Windows.Markup.XamlReader]::Load($reader)
    try { $tw.Owner = $window } catch {}

    # -- Custom title bar: DragMove + close --
    $twTitleBar = $tw.FindName("titleBarTasks")
    if ($null -ne $twTitleBar) { $twTitleBar.Add_MouseLeftButtonDown({ $tw.DragMove() }.GetNewClosure()) }
    $btnTitleCloseTasks = $tw.FindName("btnTitleCloseTasks")
    if ($null -ne $btnTitleCloseTasks) { $btnTitleCloseTasks.Add_Click({ $tw.Close() }.GetNewClosure()) }
    $tw.Add_Closed({ try { $window.Activate() } catch {} })

    # -- Apply translations to TasksWindow -----------------------------
    $tw.Title = (T 'TasksWindowTitle' 'Tareas en Segundo Plano') + " -- SysOpt"
    # Title bar text
    $twTitleBarText = $tw.FindName('txtTitleBarTasks')
    if ($null -ne $twTitleBarText) { $twTitleBarText.Text = (T 'TasksWindowTitle' 'Tareas en Segundo Plano') + " -- SysOpt" }
    # Header title
    $twTitle = $tw.FindName('txtTasksTitle')
    if ($null -ne $twTitle) { $twTitle.Text = "$([char]::ConvertFromUtf32(0x1F4CB))  " + (T 'TasksWindowTitle' 'Tareas en Segundo Plano') }
    # Subtitle
    $twSub = $tw.FindName('txtTasksSubtitle')
    if ($null -ne $twSub) { $twSub.Text = T 'TasksNoActive' 'Sin tareas activas' }
    # Clear button
    $btnClearT = $tw.FindName('btnTasksClearDone')
    if ($null -ne $btnClearT) {
        $btnClearT.Content = "$([char]::ConvertFromUtf32(0x1F9F9))  " + (T 'TasksClearCompleted' 'Limpiar completadas')
        $btnClearT.ToolTip = T 'TasksClearTip' 'Elimina las tareas ya completadas o fallidas'
    }
    # Status bar
    $twStatus = $tw.FindName('txtTasksStatus')
    if ($null -ne $twStatus) {
        $twStatus.Text = "Pool: 0 " + (T 'TaskActive' 'activa(s)') + " * 0 " + (T 'TaskCompletedShort' 'completada(s)')
    }


    # -- Inyectar TB_* brushes del tema actual ---------------------------------
    $themedRd = New-ThemedWindowResources
    foreach ($k in @($themedRd.Keys)) {
        $tw.Resources[$k] = $themedRd[$k]
    }
    # Registrar para actualizaciones futuras de tema
    $script:ThemedWindows.Add($tw)

    $script:lbTasksWin           = $tw.FindName("lbTasks")
    $script:txtTasksSubtitleWin  = $tw.FindName("txtTasksSubtitle")
    $script:txtTasksStatusWin    = $tw.FindName("txtTasksStatus")
    $btnClear                    = $tw.FindName("btnTasksClearDone")

    $btnClear.Add_Click({

        $pool = $script:TaskPool
        if ($null -eq $pool) { return }

        $snapshot = @($pool.Keys)
        foreach ($k in $snapshot) {
            $t = $null
            # TryGetValue es seguro aunque la clave haya desaparecido entre Keys y aquí
            if ($pool.TryGetValue($k, [ref]$t) -and $null -ne $t -and $t.Status -ne "running") {
                $removed = $null
                $pool.TryRemove($k, [ref]$removed) | Out-Null
            }
        }
        Refresh-TasksPanel
    })

    # -- Menú contextual de tareas: pausar / reanudar / cancelar --------------
    # El ContextMenu vive en el DataTemplate, por lo que su evento Click
    # burbujea hasta la ListBox. Lo capturamos con AddHandler en el propio lb.
    $lbCtx = $script:lbTasksWin

    # -- ContextMenuOpening -- propaga Tag del item al CM y MenuItems ------------
    # Los TB_* se resuelven desde Application.Current.Resources (se sincronizan
    # en window.Add_Loaded y en cada Apply-ThemeWithProgress).
    # El unico trabajo aqui es poner el Id de la tarea en CM.Tag y MenuItem.Tag
    # porque el DataContext del ContextMenu popup esta desconectado del binding.
    $lbCtx.AddHandler(
        [System.Windows.FrameworkElement]::ContextMenuOpeningEvent,
        [System.Windows.Controls.ContextMenuEventHandler]{
            param($sCmo, $eCmo)
            try {
                # Subir por el arbol visual hasta el Border que tiene el ContextMenu
                $el = $eCmo.OriginalSource
                $border = $el; $steps = 0
                while ($null -ne $border -and $steps -lt 20) {
                    if ($border -is [System.Windows.Controls.Border] -and $null -ne $border.ContextMenu) { break }
                    $border = [System.Windows.Media.VisualTreeHelper]::GetParent($border)
                    $steps++
                }
                if ($null -eq $border -or $null -eq $border.ContextMenu) { return }
                $cm = $border.ContextMenu
                # Apply theme brushes to ContextMenu popup (fallback if DynamicResource fails)
                try {
                    $appRes = [System.Windows.Application]::Current.Resources
                    $bg = $appRes["TB_1A1E2F"]; if ($null -ne $bg) { $cm.Background = $bg }
                    $bd = $appRes["TB_3A4468"]; if ($null -ne $bd) { $cm.BorderBrush = $bd }
                    $fg = $appRes["TB_E8ECF4"]
                    foreach ($mi in $cm.Items) {
                        if ($mi -is [System.Windows.Controls.MenuItem] -and $null -ne $fg) {
                            # Only set if not already colored by theme style
                            if ($null -eq $mi.ReadLocalValue([System.Windows.Controls.Control]::ForegroundProperty) -or
                                $mi.ReadLocalValue([System.Windows.Controls.Control]::ForegroundProperty) -eq [System.Windows.DependencyProperty]::UnsetValue) {
                                $mi.Foreground = $fg
                            }
                        }
                    }
                } catch {}
                # Translate menu items by index (0=Pause, 1=Resume, skip separator, 2=Cancel)
                $miIdx = 0
                foreach ($mi in $cm.Items) {
                    if ($mi -is [System.Windows.Controls.MenuItem]) {
                        switch ($miIdx) {
                            0 { $mi.Header = "$([char]0x23F8)   " + (T "TaskPause" "Pausar tarea") }
                            1 { $mi.Header = "$([char]0x25B6)  " + (T "TaskResume" "Reanudar tarea") }
                            2 { $mi.Header = "$([char]0x26D4)  " + (T "TaskCancel" "Cancelar tarea") }
                        }
                        $miIdx++
                    }
                }

                # Propagar Id de la tarea al Tag del CM y de cada MenuItem
                $dc     = $border.DataContext
                $taskId = if ($null -ne $dc -and $null -ne $dc.Id) { [string]$dc.Id } else { "" }
                $cm.Tag = $taskId
                foreach ($mi in $cm.Items) {
                    if ($mi -is [System.Windows.Controls.MenuItem]) { $mi.Tag = $taskId }
                }
            } catch {}
        }
    )

    $lbCtx.AddHandler(
        [System.Windows.Controls.MenuItem]::ClickEvent,
        [System.Windows.RoutedEventHandler]{
            param($s2, $e2)
            $mi = $e2.OriginalSource
            if (-not ($mi -is [System.Windows.Controls.MenuItem])) { return }
            $taskId = [string]$mi.Tag
            if ([string]::IsNullOrEmpty($taskId)) { return }

            switch ($mi.Header) {
                { $_ -like "*Pausar*" }    { Pause-Task  -Id $taskId }
                { $_ -like "*Reanudar*" }  { Resume-Task -Id $taskId }
                { $_ -like "*Cancelar*" }  {
                    $t = $null
                    $tName = if ($script:TaskPool.TryGetValue($taskId, [ref]$t) -and $null -ne $t) { $t.Name } else { $taskId }
                    $ok = Show-ThemedDialog -Title ((T "TaskConfirmCancelTitle")) `
                        -Message "$((T "TaskConfirmCancelMsg")) '$tName'?" -Type "confirm"
                    if ($ok) { Cancel-Task -Id $taskId }
                }
            }
        }
    )

    $tw.Add_Closed(({
        $script:TasksWin            = $null
        $script:lbTasksWin          = $null
        $script:txtTasksSubtitleWin = $null
        $script:txtTasksStatusWin   = $null
        # Desregistrar del registro de ventanas temáticas
        try { $script:ThemedWindows.Remove($tw) | Out-Null } catch {}
    }.GetNewClosure()))

    $script:TasksWin = $tw
    Refresh-TasksPanel
    $tw.Show()
}

# --- Show-ThemedDialog -----------------------------------------------------
function global:Show-ThemedDialog {
    param(
        [string]$Title,
        [string]$Message,
        [ValidateSet("info","warning","error","success","question")]
        [string]$Type = "info",
        [ValidateSet("OK","YesNo")]
        [string]$Buttons = "OK"
    )

    $iconChar  = switch ($Type) {
        "info"     { "$([char]0x2139)" }
        "warning"  { "$([char]0x26A0)" }
        "error"    { "$([char]0x274C)" }
        "success"  { "$([char]0x2705)" }
        "question" { "$([char]0x2753)" }
    }
    $accentColor = switch ($Type) {
        "info"     { "#5BA3FF" }
        "warning"  { "#FFB547" }
        "error"    { "#FF6B84" }
        "success"  { "#4AE896" }
        "question" { "#9B7EFF" }
    }
    # accentBg: usa claves de tema para que sea compatible con temas claros y oscuros
    $accentBg = switch ($Type) {
        "info"     { Get-TC 'DryRunBg'       '#0D1E35' }
        "warning"  { Get-TC 'BgStatusWarn'   '#2B1E0A' }
        "error"    { Get-TC 'BgStatusErr'    '#2B0D12' }
        "success"  { Get-TC 'BgStatusOk'     '#0D2B1A' }
        "question" { Get-TC 'BgStatusWarn' '#2A2010' }
    }

    # Escapar caracteres especiales XML para evitar romper el XAML
    $Title   = $Title   -replace '&','&amp;' -replace '"','&quot;' -replace "'","&apos;" -replace '<','&lt;' -replace '>','&gt;'
    $Message = $Message -replace '&','&amp;' -replace '"','&quot;' -replace "'","&apos;" -replace '<','&lt;' -replace '>','&gt;'

    $btnOkXaml = if ($Buttons -eq "OK") {
        "<Button Name=`"btnOK`" Content=`"$((T 'DlgBtnOK' 'Aceptar'))`" Width=`"100`" Height=`"34`" Margin=`"0`"
                 Background=`"$accentColor`" Foreground=`"$(Get-TC 'BgDeep' '#0D0F1A')`" BorderThickness=`"0`"
                 FontWeight=`"Bold`" FontSize=`"12`" Cursor=`"Hand`" IsDefault=`"True`"/>"
    } else {
        "<StackPanel Orientation=`"Horizontal`" HorizontalAlignment=`"Right`" Margin=`"0`">
            <Button Name=`"btnNo`"  Content=`"No`"  Width=`"90`" Height=`"34`" Margin=`"0,0,8,0`"
                    Background=`"$(Get-TC 'BtnSecondaryBg' '#1A1E2F')`" Foreground=`"$(Get-TC 'TextMuted' '#7880A0')`"
                    BorderBrush=`"$(Get-TC 'BorderSubtle' '#252B40')`" BorderThickness=`"1`"
                    FontSize=`"12`" Cursor=`"Hand`" IsCancel=`"True`"/>
            <Button Name=`"btnYes`" Content=`"$((T "DlgBtnYes"))`"  Width=`"90`" Height=`"34`"
                    Background=`"$accentColor`" Foreground=`"$(Get-TC 'BgDeep' '#0D0F1A')`" BorderThickness=`"0`"
                    FontWeight=`"Bold`" FontSize=`"12`" Cursor=`"Hand`" IsDefault=`"True`"/>
        </StackPanel>"
    }

    $dlgXaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="" Width="420" SizeToContent="Height"
        WindowStartupLocation="CenterOwner"
        ResizeMode="NoResize" WindowStyle="None"
        AllowsTransparency="True" Background="Transparent"
        Topmost="True">
    <Border Background="$(Get-TC 'BgCardDark' '#131625')" CornerRadius="12"
            BorderBrush="$accentColor" BorderThickness="1">
        <Border.Effect>
            <DropShadowEffect BlurRadius="30" ShadowDepth="0" Opacity="0.6" Color="$(Get-TC 'ConsoleBg' '#000000')"/>
        </Border.Effect>
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="Auto"/>
            </Grid.RowDefinitions>

            <!-- Header con icono y título -->
            <Border Grid.Row="0" Background="$accentBg" CornerRadius="11,11,0,0"
                    BorderBrush="$accentColor" BorderThickness="0,0,0,1" Padding="20,16">
                <StackPanel Orientation="Horizontal">
                    <Border Width="32" Height="32" CornerRadius="8"
                            Background="$accentColor" Margin="0,0,14,0" VerticalAlignment="Center">
                        <TextBlock Text="$iconChar" FontSize="16" FontWeight="Bold"
                                   Foreground="$(Get-TC 'BgDeep' '#0D0F1A')"
                                   HorizontalAlignment="Center" VerticalAlignment="Center"/>
                    </Border>
                    <TextBlock Text="$Title" FontSize="14" FontWeight="Bold"
                               Foreground="$(Get-TC 'TextPrimary' '#E8ECF4')" VerticalAlignment="Center"
                               FontFamily="Syne, Segoe UI"/>
                </StackPanel>
            </Border>

            <!-- Mensaje -->
            <Border Grid.Row="1" Padding="22,18,22,14">
                <TextBlock Text="$Message" Foreground="$(Get-TC 'TextSecondary' '#B0BACC')" FontSize="12.5"
                           TextWrapping="Wrap" LineHeight="20"
                           FontFamily="Segoe UI"/>
            </Border>

            <!-- Botones -->
            <Border Grid.Row="2" Padding="22,0,22,18">
                $btnOkXaml
            </Border>
        </Grid>
    </Border>
</Window>
"@

    $dlgReader = [System.Xml.XmlNodeReader]::new([xml]$dlgXaml)
    $dlg = [Windows.Markup.XamlReader]::Load($dlgReader)
    try { $dlg.Owner = $window } catch {}

    $result = $false
    if ($Buttons -eq "OK") {
        $dlg.FindName("btnOK").Add_Click({ $dlg.DialogResult = $true; $dlg.Close() })
    } else {
        $script:_themedDlgRef = $dlg
        $dlg.FindName("btnYes").Add_Click({ $script:_dlgResult = $true;  $script:_themedDlgRef.Close() })
        $dlg.FindName("btnNo").Add_Click({  $script:_dlgResult = $false; $script:_themedDlgRef.Close() })
    }

    # Arrastrar la ventana por cualquier parte
    $script:_themedDlgRef = $dlg
    $dlg.Add_MouseLeftButtonDown({ $script:_themedDlgRef.DragMove() })

    $script:_dlgResult = $false
    $dlg.ShowDialog() | Out-Null
    return $script:_dlgResult
}

# --- Show-ThemedInput ------------------------------------------------------
function global:Show-ThemedInput {
    param(
        [string]$Title,
        [string]$Prompt,
        [string]$Default = ""
    )

    # Escapar caracteres especiales XML para evitar romper el XAML
    $Title  = $Title  -replace '&','&amp;' -replace '"','&quot;' -replace "'","&apos;" -replace '<','&lt;' -replace '>','&gt;'
    $Prompt = $Prompt -replace '&','&amp;' -replace '"','&quot;' -replace "'","&apos;" -replace '<','&lt;' -replace '>','&gt;'

    $dlgXaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="" Width="440" SizeToContent="Height"
        WindowStartupLocation="CenterOwner"
        ResizeMode="NoResize" WindowStyle="None"
        AllowsTransparency="True" Background="Transparent"
        Topmost="True">
    <Border Background="$(Get-TC 'BgCardDark' '#131625')" CornerRadius="12"
            BorderBrush="$(Get-TC 'AccentBlue' '#5BA3FF')" BorderThickness="1">
        <Border.Effect>
            <DropShadowEffect BlurRadius="30" ShadowDepth="0" Opacity="0.6" Color="$(Get-TC 'ConsoleBg' '#000000')"/>
        </Border.Effect>
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="Auto"/>
            </Grid.RowDefinitions>

            <!-- Header -->
            <Border Grid.Row="0" Background="$(Get-TC 'DryRunBg' '#0D1E35')" CornerRadius="11,11,0,0"
                    BorderBrush="$(Get-TC 'AccentBlue' '#5BA3FF')" BorderThickness="0,0,0,1" Padding="20,16">
                <StackPanel Orientation="Horizontal">
                    <Border Width="32" Height="32" CornerRadius="8"
                            Background="$(Get-TC 'AccentBlue' '#5BA3FF')" Margin="0,0,14,0" VerticalAlignment="Center">
                        <TextBlock Text="?" FontSize="16" FontWeight="Bold"
                                   Foreground="$(Get-TC 'BgDeep' '#0D0F1A')"
                                   HorizontalAlignment="Center" VerticalAlignment="Center"/>
                    </Border>
                    <TextBlock Text="$Title" FontSize="14" FontWeight="Bold"
                               Foreground="$(Get-TC 'TextPrimary' '#E8ECF4')" VerticalAlignment="Center"
                               FontFamily="Syne, Segoe UI"/>
                </StackPanel>
            </Border>

            <!-- Prompt -->
            <Border Grid.Row="1" Padding="22,16,22,8">
                <TextBlock Text="$Prompt" Foreground="$(Get-TC 'TextSecondary' '#B0BACC')" FontSize="12"
                           TextWrapping="Wrap" FontFamily="Segoe UI"/>
            </Border>

            <!-- TextBox -->
            <Border Grid.Row="2" Padding="22,0,22,16">
                <TextBox Name="txtInput"
                         Background="$(Get-TC 'BgDeep' '#0D0F1A')" Foreground="$(Get-TC 'TextPrimary' '#E8ECF4')"
                         BorderBrush="$(Get-TC 'BorderSubtle' '#2A3448')" BorderThickness="1"
                         CaretBrush="$(Get-TC 'AccentBlue' '#5BA3FF')" SelectionBrush="$(Get-TC 'ComboSelected' '#1A3A5C')"
                         FontSize="13" Padding="10,8"
                         FontFamily="JetBrains Mono, Consolas"/>
            </Border>

            <!-- Botones -->
            <Border Grid.Row="3" Padding="22,0,22,18">
                <StackPanel Orientation="Horizontal" HorizontalAlignment="Right">
                    <Button Name="btnCancel" Content="$(T 'BtnCancel' 'Cancelar')" Width="100" Height="34" Margin="0,0,8,0"
                            Background="$(Get-TC 'BgInput' '#1A1E2F')" Foreground="$(Get-TC 'TextMuted' '#7880A0')" BorderBrush="$(Get-TC 'BorderSubtle' '#252B40')" BorderThickness="1"
                            FontSize="12" Cursor="Hand" IsCancel="True"/>
                    <Button Name="btnOK" Content="$(T 'DlgBtnOK' 'Aceptar')" Width="100" Height="34"
                            Background="$(Get-TC 'AccentBlue' '#5BA3FF')" Foreground="$(Get-TC 'BgDeep' '#0D0F1A')" BorderThickness="0"
                            FontWeight="Bold" FontSize="12" Cursor="Hand" IsDefault="True"/>
                </StackPanel>
            </Border>
        </Grid>
    </Border>
</Window>
"@

    $dlgReader = [System.Xml.XmlNodeReader]::new([xml]$dlgXaml)
    $dlg = [Windows.Markup.XamlReader]::Load($dlgReader)
    try { $dlg.Owner = $window } catch {}

    $txtInput = $dlg.FindName("txtInput")
    $txtInput.Text = $Default
    $txtInput.SelectAll()

    # Guardar referencias en $script: para que los closures de Add_Click puedan accederlas
    $script:_themedInputDlg = $dlg
    $script:_themedInputTxt = $txtInput

    $dlg.Add_MouseLeftButtonDown({ $script:_themedInputDlg.DragMove() })
    $dlg.Add_ContentRendered({ $script:_themedInputTxt.Focus() })

    $script:_inputResult = $null
    $dlg.FindName("btnOK").Add_Click({
        $script:_inputResult = $script:_themedInputTxt.Text
        $script:_themedInputDlg.Close()
    })
    $dlg.FindName("btnCancel").Add_Click({
        $script:_inputResult = $null
        $script:_themedInputDlg.Close()
    })

    $dlg.ShowDialog() | Out-Null
    return $script:_inputResult
}

# --- Show-WizardWindow -----------------------------------------------------
function global:Show-WizardWindow {
    param([hashtable]$Report)

    $wizXaml = [XamlLoader]::Load($script:XamlFolder, "WizardWindow")
    $wizXaml = $ExecutionContext.InvokeCommand.ExpandString($wizXaml)
    $wizReader = [System.Xml.XmlNodeReader]::new([xml]$wizXaml)
    $wizWin = [Windows.Markup.XamlReader]::Load($wizReader)
    $wizWin.Owner = $window
    $script:_wizWin = $wizWin

    # -- Find controls --
    $titleBarWiz   = $wizWin.FindName("titleBarWiz")
    $btnTitleClose  = $wizWin.FindName("btnTitleCloseWiz")
    $wizPage1      = $wizWin.FindName("wizPage1")
    $wizPage2      = $wizWin.FindName("wizPage2")
    $wizPage3      = $wizWin.FindName("wizPage3")
    $panelAll      = $wizWin.FindName("wizPanelAll")
    $panelProblems = $wizWin.FindName("wizPanelProblems")
    $panelRepair   = $wizWin.FindName("wizPanelRepair")
    $btnNext       = $wizWin.FindName("btnWizNext")
    $btnRepair     = $wizWin.FindName("btnWizRepair")
    $btnClose      = $wizWin.FindName("btnWizClose")
    $stepBadge1    = $wizWin.FindName("stepBadge1")
    $stepBadge2    = $wizWin.FindName("stepBadge2")
    $stepBadge3    = $wizWin.FindName("stepBadge3")
    $stepText1     = $wizWin.FindName("stepText1")
    $stepText2     = $wizWin.FindName("stepText2")
    $stepText3     = $wizWin.FindName("stepText3")

    $bc = [System.Windows.Media.BrushConverter]::new()

    # -- Drag title bar --
    # [FIX] Usar $script:_wizWin en vez de .GetNewClosure() para consistencia con btnNext/btnRepair
    if ($titleBarWiz) { $titleBarWiz.Add_MouseLeftButtonDown({ $script:_wizWin.DragMove() }) }
    if ($btnTitleClose) { $btnTitleClose.Add_Click({ $script:_wizWin.Close() }) }
    if ($btnClose) { $btnClose.Add_Click({ $script:_wizWin.Close() }) }

    # -- Build DiagInput from Report hashtable --
    $input = New-Object SysOpt.Diagnostics.DiagInput
    foreach ($key in $Report.Keys) {
        try {
            $prop = $input.GetType().GetProperty($key)
            if ($prop) {
                $val = $Report[$key]
                $t = $prop.PropertyType
                if     ($t -eq [int])    { $val = [int]$val }
                elseif ($t -eq [double]) { $val = [double]$val }
                elseif ($t -eq [string]) { $val = [string]$val }
                elseif ($t -eq [bool])   { $val = [bool]$val }
                $prop.SetValue($input, $val, $null)
            }
        } catch { }
    }

    if (-not $input.ComputerName) { $input.ComputerName = $env:COMPUTERNAME }
    try {
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
        if ($os -and -not $input.OsVersion) {
            $input.OsVersion = $os.Caption
            $input.RamTotalGB = [math]::Round([double]$os.TotalVisibleMemorySize / 1048576, 1)
            $input.RamFreeGB  = [math]::Round([double]$os.FreePhysicalMemory / 1048576, 1)
        }
    } catch {}
    try {
        if ($input.StartupCount -eq 0) {
            $input.StartupCount = ([SysOpt.StartupManager.StartupEngine]::GetEntries()).Count
        }
    } catch {}

    # -- BUG FIX: Quick security/network collection --------------------------
    # DiagnosticData (from optimizer runspace) only contains cleanup/RAM/disk fields.
    # Without this block, DiagnosticsEngine would show false CRITs for AV, Firewall,
    # and Network even when everything is configured correctly.
    try {
        $avData = Get-CimInstance -Namespace "root/SecurityCenter2" -ClassName AntiVirusProduct -ErrorAction SilentlyContinue
        if ($avData) {
            $input.AntivirusName    = $avData[0].displayName
            $input.AntivirusEnabled = (([int]$avData[0].productState -band 0x1000) -ne 0)
        }
    } catch {}
    try {
        $fwProfiles = Get-NetFirewallProfile -ErrorAction SilentlyContinue
        $winFwOn    = @($fwProfiles | Where-Object { $_.Enabled -eq $true }).Count -gt 0
        $fwProd     = Get-CimInstance -Namespace "root\SecurityCenter2" -ClassName FirewallProduct -ErrorAction SilentlyContinue
        if ($winFwOn) {
            $input.FirewallEnabled = $true;  $input.FirewallName = 'Windows Firewall'
        } elseif ($fwProd -and $fwProd.Count -gt 0) {
            $input.FirewallEnabled = $true;  $input.FirewallName = ($fwProd | Select-Object -First 1).displayName
        }
    } catch {}
    try {
        $ping = (New-Object System.Net.NetworkInformation.Ping).Send('8.8.8.8', 2000)
        $input.NetworkConnected = ($ping.Status -eq [System.Net.NetworkInformation.IPStatus]::Success)
        if ($input.NetworkConnected) {
            try {
                [void][System.Net.Dns]::GetHostEntry('www.microsoft.com')
                $input.DnsResolutionOk = $true
            } catch { $input.DnsResolutionOk = $false }
        }
    } catch {}
    try {
        $u = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -ErrorAction SilentlyContinue
        $input.UacLevel = if ($u.EnableLUA -eq 0) { 0 } elseif ($u.ConsentPromptBehaviorAdmin -le 0) { 1 } elseif ($u.ConsentPromptBehaviorAdmin -le 3) { 2 } else { 3 }
    } catch { $input.UacLevel = 3 }
    try {
        # SFC/CBS.log -- refleja el resultado de sfc /verifyonly si fue ejecutado
        $cbsPath = "$env:windir\Logs\CBS\CBS.log"
        if (Test-Path $cbsPath) {
            $cbsTail = Get-Content $cbsPath -Tail 50 -ErrorAction SilentlyContinue | Out-String
            if     ($cbsTail -match 'no integrity violations') { $input.SfcStatus = 'OK';      $input.SfcDetail = (T 'DiagSfcOkDetail' 'Sin problemas de integridad') }
            elseif ($cbsTail -match 'corrupt|violation')       { $input.SfcStatus = 'WARN';    $input.SfcDetail = (T 'DiagSfcWarnDetail' 'Se detectaron archivos corruptos') }
            else                                                { $input.SfcStatus = 'UNKNOWN'; $input.SfcDetail = (T 'DiagSfcUnknownDetail' 'No se encontraron resultados recientes de SFC') }
        } else { $input.SfcStatus = 'UNKNOWN' }
    } catch {}

    # -- Run diagnostics via DLL --
    $diagResult = [SysOpt.Diagnostics.DiagnosticsEngine]::Analyze($input)

    # -- Process through WizardEngine DLL --
    $wizResult = [SysOpt.Wizard.WizardEngine]::ProcessDiagnostics($diagResult)

    # -- Helper: Add row to panel (UI only -- colors from DLL) --
    $addRow = {
        param($panel, $wizItem, [bool]$showSection = $false)
        $statusIcon   = [SysOpt.Wizard.WizardEngine]::GetStatusIcon($wizItem.Status)
        $statusBg     = [SysOpt.Wizard.WizardEngine]::GetStatusBackground($wizItem.Status)
        $statusBorder = [SysOpt.Wizard.WizardEngine]::GetStatusBorderColor($wizItem.Status)

        # Override with theme colors if available
        $themedBg = switch ($wizItem.Status) {
            'OK'    { Get-TC 'BgStatusOk'   $statusBg }
            'WARN'  { Get-TC 'BgStatusWarn'  $statusBg }
            'CRIT'  { Get-TC 'BgStatusErr'   $statusBg }
            default { Get-TC 'CtxHover'      $statusBg }
        }

        $row = New-Object System.Windows.Controls.Border
        $row.CornerRadius = New-Object System.Windows.CornerRadius(6)
        $row.Padding = New-Object System.Windows.Thickness(10,6,10,6)
        $row.Margin = New-Object System.Windows.Thickness(0,2,0,2)
        $row.Background = $bc.ConvertFromString($themedBg)
        $row.BorderBrush = $bc.ConvertFromString($statusBorder)
        $row.BorderThickness = New-Object System.Windows.Thickness(1)

        $sp = New-Object System.Windows.Controls.StackPanel
        $sp.Orientation = "Horizontal"

        $ico = New-Object System.Windows.Controls.TextBlock
        $ico.Text = $statusIcon; $ico.FontSize = 12; $ico.VerticalAlignment = "Center"
        $ico.Margin = New-Object System.Windows.Thickness(0,0,8,0)
        [void]$sp.Children.Add($ico)

        if ($showSection) {
            $sec = New-Object System.Windows.Controls.TextBlock
            $sec.Text = "[$($wizItem.Section)] "; $sec.FontSize = 10
            $sec.FontWeight = [System.Windows.FontWeights]::Bold
            $sec.Foreground = $bc.ConvertFromString((Get-TC 'AccentBlue' '#5BA3FF'))
            $sec.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe UI")
            $sec.VerticalAlignment = "Center"
            [void]$sp.Children.Add($sec)
        }

        $lbl = New-Object System.Windows.Controls.TextBlock
        $lbl.Text = $wizItem.Label; $lbl.FontSize = 11
        $lbl.FontWeight = [System.Windows.FontWeights]::SemiBold
        $lbl.Foreground = $bc.ConvertFromString((Get-TC 'TextPrimary' '#E8ECF4'))
        $lbl.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe UI")
        $lbl.VerticalAlignment = "Center"; $lbl.TextWrapping = "Wrap"
        [void]$sp.Children.Add($lbl)

        if ($wizItem.Detail) {
            $dtl = New-Object System.Windows.Controls.TextBlock
            $dtl.Text = " -- $($wizItem.Detail)"; $dtl.FontSize = 10
            $dtl.Foreground = $bc.ConvertFromString((Get-TC 'TextMuted' '#6B7494'))
            $dtl.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe UI")
            $dtl.VerticalAlignment = "Center"; $dtl.TextWrapping = "Wrap"
            [void]$sp.Children.Add($dtl)
        }

        $row.Child = $sp
        [void]$panel.Children.Add($row)
    }

    # -- Populate Page 1: All entries (from WizardEngine) --
    foreach ($item in $wizResult.AllItems) {
        & $addRow $panelAll $item $true
    }

    # -- Populate Page 2: Problems only (from WizardEngine) --
    if (-not $wizResult.HasProblems) {
        $noProb = New-Object System.Windows.Controls.TextBlock
        $noProb.Text = T 'WizNoProblems' 'No se detectaron problemas. ¡Tu equipo está en buen estado!'
        $noProb.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe UI")
        $noProb.FontSize = 13; $noProb.Margin = New-Object System.Windows.Thickness(0,10,0,0)
        $noProb.Foreground = $bc.ConvertFromString((Get-TC 'GoodGreen' '#4AE896'))
        [void]$panelProblems.Children.Add($noProb)
    } else {
        foreach ($item in $wizResult.ProblemItems) {
            & $addRow $panelProblems $item $true
        }
    }

    # -- Populate Page 3: Repair checklist (from WizardEngine) --
    $script:_wizRepairChecks = @{}

    foreach ($task in $wizResult.RepairTasks) {
        $row = New-Object System.Windows.Controls.Border
        $row.CornerRadius = New-Object System.Windows.CornerRadius(6)
        $row.Padding = New-Object System.Windows.Thickness(10,6,10,6)
        $row.Margin = New-Object System.Windows.Thickness(0,2,0,2)
        $row.Background = $bc.ConvertFromString((Get-TC 'BgCard' '#161925'))
        $row.BorderBrush = $bc.ConvertFromString((Get-TC 'BorderSubtle' '#252B40'))
        $row.BorderThickness = New-Object System.Windows.Thickness(1)

        $cb = New-Object System.Windows.Controls.CheckBox
        $cb.IsChecked = $task.Recommended
        $cb.Tag = $task.Key
        $cb.VerticalAlignment = "Center"
        $cb.Margin = New-Object System.Windows.Thickness(0,0,0,0)

        $content = New-Object System.Windows.Controls.StackPanel
        $content.Orientation = "Horizontal"

        $lblTxt = New-Object System.Windows.Controls.TextBlock
        $lblTxt.Text = $task.Label
        $lblTxt.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe UI")
        $lblTxt.FontSize = 12
        $lblTxt.Foreground = $bc.ConvertFromString((Get-TC 'TextPrimary' '#E8ECF4'))
        $lblTxt.VerticalAlignment = "Center"
        [void]$content.Children.Add($lblTxt)

        if ($task.Recommended) {
            $recBadge = New-Object System.Windows.Controls.Border
            $recBadge.CornerRadius = New-Object System.Windows.CornerRadius(4)
            $recBadge.Padding = New-Object System.Windows.Thickness(6,1,6,1)
            $recBadge.Margin = New-Object System.Windows.Thickness(8,0,0,0)
            $recBadge.Background = $bc.ConvertFromString('#1A5BA3FF')
            $recTxt = New-Object System.Windows.Controls.TextBlock
            $recTxt.Text = T 'WizRecommended' 'Recomendado'
            $recTxt.FontFamily = New-Object System.Windows.Media.FontFamily("Segoe UI")
            $recTxt.FontSize = 9; $recTxt.FontWeight = [System.Windows.FontWeights]::Bold
            $recTxt.Foreground = $bc.ConvertFromString((Get-TC 'AccentBlue' '#5BA3FF'))
            $recBadge.Child = $recTxt
            [void]$content.Children.Add($recBadge)
        }

        $cb.Content = $content
        $row.Child = $cb
        [void]$panelRepair.Children.Add($row)
        $script:_wizRepairChecks[$task.Key] = $cb
    }

    # -- Step navigation --
    # [FIX-BUG2] Usar $script: scope para evitar problemas de closure en event handlers.
    # GetNewClosure() captura variables locales en un módulo separado, pero el scriptblock
    # $updateStep NO se re-vincula al módulo, causando que $wizPage1, $bc, etc. sean $null
    # al ejecutarse -- el click silenciosamente no hace nada.
    $script:_wizCurrentStep = 1
    # $script:_wizWin ya asignado al crear la ventana (línea ~8050)

    $script:_wizUpdateStep = {
        param([int]$step)
        $w = $script:_wizWin
        $script:_wizCurrentStep = $step
        $w.FindName("wizPage1").Visibility = if ($step -eq 1) { 'Visible' } else { 'Collapsed' }
        $w.FindName("wizPage2").Visibility = if ($step -eq 2) { 'Visible' } else { 'Collapsed' }
        $w.FindName("wizPage3").Visibility = if ($step -eq 3) { 'Visible' } else { 'Collapsed' }
        $w.FindName("btnWizNext").Visibility = if ($step -lt 3) { 'Visible' } else { 'Collapsed' }
        $w.FindName("btnWizRepair").Visibility = if ($step -eq 3) { 'Visible' } else { 'Collapsed' }

        $bc_ = [System.Windows.Media.BrushConverter]::new()
        $ab  = Get-TC 'AccentBlue' '#5BA3FF'
        $mc  = Get-TC 'TextMuted' '#6B7494'
        $sc  = Get-TC 'BorderSubtle' '#252B40'

        foreach ($i in 1..3) {
            $badge = $w.FindName("stepBadge$i")
            $text  = $w.FindName("stepText$i")
            if ($i -le $step) {
                $badge.Background = $bc_.ConvertFromString($ab)
                $text.Foreground  = $bc_.ConvertFromString($ab)
                $text.FontWeight  = [System.Windows.FontWeights]::SemiBold
            } else {
                $badge.Background = $bc_.ConvertFromString($sc)
                $text.Foreground  = $bc_.ConvertFromString($mc)
                $text.FontWeight  = [System.Windows.FontWeights]::Normal
            }
        }
    }

    $btnNext.Add_Click({
        if ($script:_wizCurrentStep -lt 3) {
            & $script:_wizUpdateStep ($script:_wizCurrentStep + 1)
        }
    })

    # -- Repair button -- uses DLL for checkbox mapping --
    # [FIX] NO usar .GetNewClosure() -- crea un módulo aislado donde $script:_wizRepairChecks es $null
    # Mismo patrón que btnNext: usar $script:_wizWin en vez de $wizWin local
    $btnRepair.Add_Click({
        if ($null -eq $script:_wizRepairChecks) { return }
        $selectedTasks = @()
        foreach ($kv in $script:_wizRepairChecks.GetEnumerator()) {
            if ($kv.Value.IsChecked) {
                $selectedTasks += $kv.Key
            }
        }
        if ($selectedTasks.Count -eq 0) {
            Show-ThemedDialog -Title (T 'WizNoTasksTitle' 'Sin tareas') `
                -Message (T 'WizNoTasksMsg' 'No has seleccionado ninguna tarea de reparación.') -Type 'info'
            return
        }

        $script:_wizWin.Close()

        # Get checkbox mapping from DLL
        $taskCheckMap = [SysOpt.Wizard.WizardEngine]::GetTaskCheckboxMap()

        # Uncheck all optimization checkboxes first
        foreach ($cb in $script:AllOptCheckboxes) { $cb.IsChecked = $false }

        # Check selected tasks using DLL mapping
        foreach ($key in $selectedTasks) {
            if ($taskCheckMap.ContainsKey($key)) {
                $cbName = $taskCheckMap[$key]
                $cbVar = Get-Variable -Name $cbName -ValueOnly -ErrorAction SilentlyContinue
                if ($null -ne $cbVar) { $cbVar.IsChecked = $true }
            }
        }

        # Also check BackupRegistry if CleanRegistry is selected
        if ('CleanRegistry' -in $selectedTasks) {
            $chkBackupRegistry.IsChecked = $true
        }

        # Run real optimization (not dry-run)
        Start-Optimization -DryRunOverride $false
    })

    # Start on page 1
    & $script:_wizUpdateStep 1

    [void]$wizWin.ShowDialog()
}

# --- Start-DiskScan --------------------------------------------------------
function global:Start-DiskScan {
    param([string]$RootPath)

    if (-not (Test-Path $RootPath -ErrorAction SilentlyContinue)) {
        Write-Log "[SCAN] Ruta no encontrada: $RootPath" -Level "WARN" -NoUI
        Show-ThemedDialog -Title (T "DiskPathNotFound" "Ruta no encontrada") -Message "$(T 'DiskPathNotFound' 'Ruta no encontrada'): $RootPath" -Type "error"
        return
    }
    Write-Log ("[SCAN] Iniciando escaneo de disco: {0}" -f $RootPath) -Level "INFO" -NoUI

    # Señalizar parada al runspace anterior y esperar a que confirme la parada
    # WaitOne(500) bloquea máximo 500ms hasta que el handle complete -- evita
    # que Reset() se ejecute con el hilo de escaneo anterior todavía activo.
    # [CTK] Cancel() señaliza el token -> ScanCtl211.Stop bridge devuelve true
    # PScanner211 lee ScanCtl211.Stop que ahora revisa _token.IsCancellationRequested
    [ScanTokenManager]::Cancel()
    if ($null -ne $script:DiskScanAsync -and -not $script:DiskScanAsync.IsCompleted) {
        $script:DiskScanAsync.AsyncWaitHandle.WaitOne(500) | Out-Null
    }
    [ScanCtl211]::Reset()
    [ScanTokenManager]::RequestNew()
    [ScanCtl211]::SetToken([ScanTokenManager]::Token)   # bridge nuevo token

    $script:CollapsedPaths.Clear()
    $script:CachedChildMap = $null      # Invalidar caché al iniciar nuevo escaneo
    $script:AllScannedItems.Clear()
    if ($null -ne $script:LiveIndexMap) { $script:LiveIndexMap.Clear() }

    $btnDiskScan.IsEnabled  = $false
    $btnDiskStop.IsEnabled  = $true
    $txtDiskScanStatus.Text = "$((T "ScanStartingMsg")) $RootPath ..."
    if ($null -ne $btnSnapshotSave) {
        $btnSnapshotSave.IsEnabled = $false
        $txtSnapshotName.IsEnabled = $false
        $txtSnapshotName.Text      = ""
    }
    if ($null -ne $btnDedup) { $btnDedup.IsEnabled = $false }
    $pbDiskScan.IsIndeterminate = $true
    $pbDiskScan.Value = 0

    # Cola compartida: el hilo de fondo mete objetos, el timer de UI los consume
    $script:ScanQueue = [System.Collections.Concurrent.ConcurrentQueue[object[]]]::new()

    # [PAUSE] Estado de pausa compartido entre hilo UI y runspace de escaneo
    $script:ScanPauseState = [hashtable]::Synchronized(@{ Paused = $false })

    # [OPT] Usar List<object> en lugar de ObservableCollection para la UI.
    # ObservableCollection dispara CollectionChanged por cada Add() individual -- con miles
    # de carpetas esto presiona enormemente el sistema de binding WPF y el GC.
    # Usamos una List normal y llamamos lbDiskTree.Items.Refresh() solo en batches.
    # LiveItems eliminado: AllScannedItems+LiveIndexMap es la única fuente de verdad.
    $script:LiveItems = [System.Collections.Generic.Dictionary[string,int]]::new(
        [System.StringComparer]::OrdinalIgnoreCase)  # clave -> índice en AllScannedItems
    $script:LiveList  = [System.Collections.Generic.List[object]]::new(2048)
    $lbDiskTree.ItemsSource = $script:LiveList

    # -- [A1] Hilo de fondo: escáner PARALELO en C# via ParallelScanner ------
    # Solo emite CARPETAS (estilo TreeSize). Paralelismo en nivel shallow (depth<=1)
    # para máximo throughput en NVMe sin crear un exceso de threads en discos HDD.
    # La cola es ConcurrentQueue<object[]> -- array posicional:
    #   [0]=Key [1]=ParentKey [2]=Name [3]=Size [4]=Files [5]=Dirs [6]=Done [7]=Depth
    $bgScript = {
        param([string]$Root,
              [System.Collections.Concurrent.ConcurrentQueue[object[]]]$Q,
              [hashtable]$PauseState)

        try {
            $topDirs = try { [System.IO.Directory]::GetDirectories($Root) } catch { @() }
            [ScanCtl211]::Total = $topDirs.Length + 1

            # Llamar al escáner C# paralelo para cada carpeta de primer nivel
            # Pasamos $Root como parentKey para que aparezcan bajo ::ROOT:: en la UI
            foreach ($d in $topDirs) {
                if ([ScanCtl211]::Stop) { break }
                # [PAUSE] Spinwait mientras la UI pida pausa (intervalo 100ms para no quemar CPU)
                while ($PauseState.Paused -and -not [ScanCtl211]::Stop) {
                    [System.Threading.Thread]::Sleep(100)
                }
                if ([ScanCtl211]::Stop) { break }
                [PScanner211]::ScanDir($d, 0, '::ROOT::', $Q) | Out-Null
            }
            [ScanCtl211]::Done++
        } catch {}
    }

    $rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
    $rs.ApartmentState = "STA"; $rs.Open()
    $ps = [System.Management.Automation.PowerShell]::Create()
    $ps.Runspace = $rs
    # en el nuevo runspace para que los tipos C# sean resolubles desde el hilo de fondo
    $sharedAsmPath = [ScanCtl211].Assembly.Location
    if ($sharedAsmPath -and (Test-Path $sharedAsmPath)) {
        [void]$rs.SessionStateProxy.InvokeCommand.InvokeScript(
            "`$null = [System.Reflection.Assembly]::LoadFrom('$sharedAsmPath')"
        )
    }
    [void]$ps.AddScript($bgScript).AddParameter("Root", $RootPath).AddParameter("Q", $script:ScanQueue).AddParameter("PauseState", $script:ScanPauseState)
    # Set DefaultRunspace so C# code can resolve PS types if needed
    $rs.SessionStateProxy.SetVariable("ErrorActionPreference", "SilentlyContinue")
    $script:DiskScanRunspace = $rs
    $script:DiskScanPS    = $ps
    $script:DiskScanAsync = $ps.BeginInvoke()

    # -- Registrar tarea con hooks de control ---------------------------------
    $scanTask = Register-Task -Id "diskscan" -Name "$(T 'DiskScanTask' 'Escaneo'): $RootPath" -Icon "$([char]::ConvertFromUtf32(0x1F50D))" -IconBg (Get-TC 'BgStatusInfo' '#1A2F4A')
    $scanTask.CancelFn = {
        [ScanTokenManager]::Cancel()   # bridge -> ScanCtl211.Stop = true automático
        if ($null -ne $script:btnDiskStop) {
            try { $script:btnDiskStop.IsEnabled = $false } catch {}
        }
        $script:txtDiskScanStatus.Text = "$([char]0x26D4) $((T "ScanCancelledFromPanel"))"
    }
    $scanTask.PauseFn = {
        $script:ScanPauseState.Paused = $true
        $script:txtDiskScanStatus.Text = "$([char]0x23F8) $(T 'DiskScanPaused' 'Escaneo pausado')"
        if ($null -ne $script:btnDiskStop) {
            try { $script:btnDiskStop.Content = "$([char]0x25B6)  " + (T "BtnResume" "Reanudar") } catch {}
        }
    }
    $scanTask.ResumeFn = {
        $script:ScanPauseState.Paused = $false
        $script:txtDiskScanStatus.Text = "$((T "ScanDefaultName"))..."
        if ($null -ne $script:btnDiskStop) {
            try { $script:btnDiskStop.Content = "$([char]0x23F9)  $((T "BtnStop"))" } catch {}
        }
    }

    # -- Timer UI: drena la cola y actualiza lista cada 300 ms ------------------
    # LiveIndexMap: clave->posición en LiveList para actualizaciones O(1)
    $script:LiveIndexMap = [System.Collections.Generic.Dictionary[string,int]]::new(
        [System.StringComparer]::OrdinalIgnoreCase)

    $script:SortTickCounter = 0
    $script:GcTickCounter   = 0   # [OPT] para GC periódico durante scan

    # [FIX-CLOSURE] uiTimer debe estar en $script: para que Add_Tick pueda llamar a .Stop()
    if ($null -ne $script:DiskUiTimer) { try { $script:DiskUiTimer.Stop() } catch {} }
    $script:DiskUiTimer = New-Object System.Windows.Threading.DispatcherTimer
    $script:DiskUiTimer.Interval = [TimeSpan]::FromMilliseconds(300)
    $script:DiskUiTimer.Add_Tick({
        $total = [ScanCtl211]::Total
        $done  = [ScanCtl211]::Done
        $cur   = [ScanCtl211]::Current

        if ($total -gt 0) {
            $pbDiskScan.IsIndeterminate = $false
            $pbDiskScan.Value = [math]::Min(99, [math]::Round($done / $total * 100))
        }

        $lw = if ($lbDiskTree.ActualWidth -gt 100) { $lbDiskTree.ActualWidth - 270 } else { 400 }

        # Procesar hasta 600 mensajes por tick
        $anyUpdate   = $false
        $listChanged = $false
        $processed   = 0
        $msg = $null
        # [OPT] Batch adaptativo: más items con cola llena, menos cuando está vacía
        $batchLimit = [math]::Min(1200, [math]::Max(200, $script:ScanQueue.Count + $processed))
        while ($processed -lt $batchLimit -and ($null -ne $script:ScanQueue) -and $script:ScanQueue.TryDequeue([ref]$msg)) {
            $processed++
            $key       = [string]$msg[0]
            $parentKey = if ($msg[1]) { [string]$msg[1] } else { '::ROOT::' }
            $msgName   = [string]$msg[2]
            $msgSize   = [long]$msg[3]
            $msgFiles  = [int]$msg[4]
            $msgDirs   = [int]$msg[5]
            $msgDone   = [bool]$msg[6]
            $depth     = [int]$msg[7]
            $indent    = "$([math]::Max(4, $depth * 22)),0,0,0"

            if (-not $msgDone) {
                # Placeholder -- solo si no existe ya en AllScannedItems
                if (-not $script:LiveItems.ContainsKey($key)) {
                    $entry = New-Object DiskItem_v211
                    $entry.DisplayName      = $msgName
                    $entry.FullPath         = $key
                    $entry.ParentPath       = $parentKey
                    $entry.SizeBytes        = -1L
                    $entry.SizeStr          = [char]0x2026
                    $entry.SizeColor        = "#8B96B8"
                    $entry.PctStr           = [char]0x2014
                    $entry.FileCount        = [char]0x2026
                    $entry.DirCount         = 0
                    $entry.IsDir            = $true
                    $entry.HasChildren      = $false
                    $entry.Icon             = [char]0xD83D + [char]0xDCC1
                    $entry.Indent           = $indent
                    $entry.BarWidth         = 0.0
                    $entry.BarColor         = "#3A4468"
                    $entry.TotalPct         = 0.0
                    $entry.Depth            = $depth
                    $entry.ToggleIcon       = [char]0x25B6
                    $entry.ToggleVisibility = "Collapsed"
                    $idx = $script:AllScannedItems.Count
                    $script:AllScannedItems.Add($entry)
                    $script:LiveItems[$key] = $idx   # índice en AllScannedItems
                    # Añadir a LiveList solo si ningún ancestro está colapsado
                    $hidden = $false
                    $pp = $parentKey
                    while ($pp -and $pp -ne '::ROOT::') {
                        if ($script:CollapsedPaths.Contains($pp)) { $hidden = $true; break }
                        $pp2 = try { [System.IO.Path]::GetDirectoryName($pp) } catch { $null }
                        $pp = if ($pp2 -and $pp2 -ne $pp) { $pp2 } else { $null }
                    }
                    if (-not $hidden) { $script:LiveList.Add($entry); $listChanged = $true }
                }
            } else {
                # Datos reales de carpeta completada
                $sz     = $msgSize
                $sc     = if ($sz -ge 10GB) {"#FF6B84"} elseif ($sz -ge 1GB) {"#FFB547"} elseif ($sz -ge 100MB) {"#5BA3FF"} else {"#B0BACC"}
                $szStr  = [Formatter]::FormatBytes([long]$sz)
                $fc     = "$msgFiles arch.  $msgDirs carp."
                $hasCh  = $msgDirs -gt 0

                if ($script:LiveItems.ContainsKey($key)) {
                    # Actualizar el objeto existente en AllScannedItems directamente
                    $ex = $script:AllScannedItems[$script:LiveItems[$key]]
                    $ex.SizeBytes        = $sz
                    $ex.SizeStr          = $szStr
                    $ex.SizeColor        = $sc
                    $ex.FileCount        = $fc
                    $ex.DirCount         = $msgDirs
                    $ex.HasChildren      = $hasCh
                    $ex.BarColor         = $sc
                    $ex.ToggleVisibility = if ($hasCh) {"Visible"} else {"Collapsed"}
                    $ex.ToggleIcon       = if ($script:CollapsedPaths.Contains($key)) { [char]0x25B6 } else { [char]0x25BC }
                } else {
                    $ne = New-Object DiskItem_v211
                    $ne.DisplayName      = $msgName
                    $ne.FullPath         = $key
                    $ne.ParentPath       = $parentKey
                    $ne.SizeBytes        = $sz
                    $ne.SizeStr          = $szStr
                    $ne.SizeColor        = $sc
                    $ne.PctStr           = [char]0x2014
                    $ne.FileCount        = $fc
                    $ne.DirCount         = $msgDirs
                    $ne.IsDir            = $true
                    $ne.HasChildren      = $hasCh
                    $ne.Icon             = [char]0xD83D + [char]0xDCC1
                    $ne.Indent           = $indent
                    $ne.BarWidth         = 0.0
                    $ne.BarColor         = $sc
                    $ne.TotalPct         = 0.0
                    $ne.Depth            = $depth
                    $ne.ToggleIcon       = if ($script:CollapsedPaths.Contains($key)) { [char]0x25B6 } else { [char]0x25BC }
                    $ne.ToggleVisibility = if ($hasCh) {"Visible"} else {"Collapsed"}
                    $idx2 = $script:AllScannedItems.Count
                    $script:AllScannedItems.Add($ne)
                    $script:LiveItems[$key] = $idx2
                    $hidden2 = $false
                    $pp3 = $parentKey
                    while ($pp3 -and $pp3 -ne '::ROOT::') {
                        if ($script:CollapsedPaths.Contains($pp3)) { $hidden2 = $true; break }
                        $pp4 = try { [System.IO.Path]::GetDirectoryName($pp3) } catch { $null }
                        $pp3 = if ($pp4 -and $pp4 -ne $pp3) { $pp4 } else { $null }
                    }
                    if (-not $hidden2) { $script:LiveList.Add($ne); $listChanged = $true }
                }
                $anyUpdate = $true
            }
            $msg = $null
        }

        # [OPT] Notificar WPF solo una vez por batch (no por cada Add)
        if ($listChanged) {
            $lbDiskTree.Items.Refresh()
        }

        # [A2] Actualizar porcentajes en tiempo real
        if ($anyUpdate) {
            $rtTotal = 0L
            foreach ($v in $script:AllScannedItems) {
                if ($v.Depth -eq 0 -and $v.SizeBytes -gt 0) { $rtTotal += $v.SizeBytes }
            }
            if ($rtTotal -gt 0) {
                $lw2 = if ($lbDiskTree.ActualWidth -gt 100) { $lbDiskTree.ActualWidth - 270 } else { 400 }
                foreach ($s in $script:AllScannedItems) {
                    if ($s.SizeBytes -gt 0) {
                        $pct2 = [math]::Round($s.SizeBytes / $rtTotal * 100, 1)
                        $s.PctStr   = "$pct2%"
                        $s.TotalPct = $pct2
                        $s.BarWidth = [double][math]::Max(0, [math]::Round($pct2 / 100 * $lw2))
                    }
                }
            }
        }

        # Re-ordenar por tamaño cada ~5 ticks (~1.5 s)
        $script:SortTickCounter++
        if ($anyUpdate -and $script:SortTickCounter % 5 -eq 0) {
            Refresh-DiskView -RebuildMap
        }

        # [OPT] GC periódico durante el scan -- cada 20 ticks (~6 s)
        # Libera strings intermedios, arrays de la cola C# y objetos temporales PS
        $script:GcTickCounter++
        if ($script:GcTickCounter % 20 -eq 0) {
            [GC]::Collect(0, [GCCollectionMode]::Optimized)
        }

        if ($anyUpdate) {
            $cnt = $script:AllScannedItems.Count
            $tot = [ScanCtl211]::Total; $don = [ScanCtl211]::Done
            $pctScan = if ($tot -gt 0) { [int]([math]::Min(99, $don * 100 / $tot)) } else { 0 }
            Update-Task -Id "diskscan" -Pct $pctScan -Detail "$cnt $(T 'Folders' 'carpetas') * $don/$tot"
            $txtDiskScanStatus.Text = "$((T "ScanDefaultName"))$([char]0x2026)  $cnt $((T "DiskFolders"))  $([char]0x00B7)  $don/$tot  $([char]0x00B7)  $cur"
        }

        # ¿Terminó el runspace?
        if ($null -ne $script:DiskScanAsync -and $script:DiskScanAsync.IsCompleted) {
            $drainMsg = $null
            while (($null -ne $script:ScanQueue) -and $script:ScanQueue.TryDequeue([ref]$drainMsg)) {
                $dk       = [string]$drainMsg[0]
                $dpk      = if ($drainMsg[1]) { [string]$drainMsg[1] } else { '::ROOT::' }
                $dn       = [string]$drainMsg[2]
                $dsz      = [long]$drainMsg[3]
                $dfiles   = [int]$drainMsg[4]
                $ddirs    = [int]$drainMsg[5]
                $ddone    = [bool]$drainMsg[6]
                $ddepth   = [int]$drainMsg[7]
                $dindent  = "$([math]::Max(4, $ddepth * 22)),0,0,0"

                if (-not $ddone) {
                    if (-not $script:LiveItems.ContainsKey($dk)) {
                        $de = New-Object DiskItem_v211
                        $de.DisplayName = $dn; $de.FullPath = $dk; $de.ParentPath = $dpk
                        $de.SizeBytes = -1L; $de.SizeStr = [char]0x2026; $de.SizeColor = "#8B96B8"
                        $de.PctStr = [char]0x2014; $de.FileCount = [char]0x2026; $de.DirCount = 0
                        $de.IsDir = $true; $de.HasChildren = $false
                        $de.Icon = [char]0xD83D + [char]0xDCC1
                        $de.Indent = $dindent; $de.BarWidth = 0.0; $de.BarColor = "#3A4468"
                        $de.TotalPct = 0.0; $de.Depth = $ddepth
                        $de.ToggleIcon = [char]0x25B6; $de.ToggleVisibility = "Collapsed"
                        $didx = $script:AllScannedItems.Count
                        $script:AllScannedItems.Add($de)
                        $script:LiveItems[$dk] = $didx
                    }
                } else {
                    $dsc    = if ($dsz -ge 10GB) {"#FF6B84"} elseif ($dsz -ge 1GB) {"#FFB547"} elseif ($dsz -ge 100MB) {"#5BA3FF"} else {"#B0BACC"}
                    $dszStr = [Formatter]::FormatBytes([long]$dsz)
                    $dhch   = $ddirs -gt 0
                    if ($script:LiveItems.ContainsKey($dk)) {
                        $dex = $script:AllScannedItems[$script:LiveItems[$dk]]
                        $dex.SizeBytes = $dsz; $dex.SizeStr = $dszStr; $dex.SizeColor = $dsc
                        $dex.FileCount = "$dfiles arch.  $ddirs carp."; $dex.DirCount = $ddirs
                        $dex.HasChildren = $dhch; $dex.BarColor = $dsc
                        $dex.ToggleVisibility = if ($dhch) {"Visible"} else {"Collapsed"}
                    } else {
                        $dne = New-Object DiskItem_v211
                        $dne.DisplayName = $dn; $dne.FullPath = $dk; $dne.ParentPath = $dpk
                        $dne.SizeBytes = $dsz; $dne.SizeStr = $dszStr; $dne.SizeColor = $dsc
                        $dne.PctStr = [char]0x2014; $dne.FileCount = "$dfiles arch.  $ddirs carp."
                        $dne.DirCount = $ddirs; $dne.IsDir = $true; $dne.HasChildren = $dhch
                        $dne.Icon = [char]0xD83D + [char]0xDCC1; $dne.Indent = $dindent
                        $dne.BarWidth = 0.0; $dne.BarColor = $dsc; $dne.TotalPct = 0.0; $dne.Depth = $ddepth
                        $dne.ToggleIcon = [char]0x25BC; $dne.ToggleVisibility = if ($dhch) {"Visible"} else {"Collapsed"}
                        $didx2 = $script:AllScannedItems.Count
                        $script:AllScannedItems.Add($dne)
                        $script:LiveItems[$dk] = $didx2
                    }
                }
                $drainMsg = $null
            }

            # [OPT] ScanQueue vaciada -- liberar referencia para que el GC recoja los arrays
            $script:ScanQueue = $null

$script:DiskUiTimer.Stop()
            try { $script:DiskScanPS.EndInvoke($script:DiskScanAsync) | Out-Null } catch {}
            try { $script:DiskScanPS.Dispose(); $script:DiskScanRunspace.Close(); $script:DiskScanRunspace.Dispose() } catch {}
            $script:DiskScanAsync = $null
            $script:DiskScanPS    = $null

            # Calcular tamaño total: suma de todas las carpetas de primer nivel (Depth=0)
            $gt2 = 0L
            foreach ($v in $script:AllScannedItems) {
                if ($v.Depth -eq 0 -and $v.SizeBytes -gt 0) { $gt2 += $v.SizeBytes }
            }

            # Asignar porcentajes y corregir ToggleVisibility final en todos los items
            if ($gt2 -gt 0) {
                foreach ($s in $script:AllScannedItems) {
                    if ($s.SizeBytes -gt 0) {
                        $pct = [math]::Round($s.SizeBytes / $gt2 * 100, 1)
                        $bw  = [math]::Max(0, [math]::Round($pct / 100 * $lw))
                        $s.PctStr   = "$pct%"
                        $s.TotalPct = $pct
                        $s.BarWidth = [double]$bw
                    }
                    # Asegurar ToggleVisibility correcto según HasChildren real
                    if ($s.IsDir) {
                        $s.ToggleVisibility = if ($s.HasChildren) { "Visible" } else { "Collapsed" }
                        $s.ToggleIcon       = if ($script:CollapsedPaths.Contains($s.FullPath)) { "?" } else { "?" }
                    }
                }
            }

            # Reconstruir LiveList final respetando colapsos (o filtro activo)
            $script:LiveIndexMap.Clear()
            if (-not [string]::IsNullOrWhiteSpace($script:FilterText)) {
                Apply-DiskFilter $script:FilterText
            } else {
                Refresh-DiskView -RebuildMap
            }
            # [OPT] Notificar WPF de la reconstrucción de LiveList (sustituye ObservableCollection)
            $lbDiskTree.Items.Refresh()

            # [OPT] Compactar listas y liberar RAM al SO tras escaneo completo
            $script:AllScannedItems.TrimExcess()
            $script:LiveList.TrimExcess()
            # Liberar el LiveItems index map (ya no se necesita hasta el próximo scan)
            $script:LiveItems.Clear()
            Invoke-AggressiveGC

            $pbDiskScan.IsIndeterminate = $false
            $pbDiskScan.Value = 100
            $btnDiskScan.IsEnabled = $true
            $btnDiskStop.IsEnabled = $false
            $btnExportCsv.IsEnabled    = $true
            $btnExportJson.IsEnabled   = $true
            $btnDiskReport.IsEnabled   = $true  # Informe HTML
            $btnDedup.IsEnabled        = $true
            $btnSnapshotSave.IsEnabled    = $true
            $txtSnapshotName.IsEnabled    = $true
            $txtSnapshotName.Text         = "$((T "ScanDefaultName")) $(Get-Date -Format 'dd/MM/yyyy HH:mm')"
            $txtSnapshotName.SelectAll()

            $gtStr2 = [Formatter]::FormatBytes([long]$gt2)
            $emoji = if ([ScanCtl211]::Stop) { "$([char]0x26D4)" } else { "$([char]0x2705)" }
            $txtDiskScanStatus.Text = "$emoji  $($script:AllScannedItems.Count) elementos  *  $gtStr2  *  $(Get-Date -Format 'HH:mm:ss')"
            $wasStop = [ScanCtl211]::Stop
            if (-not $wasStop) {
                Show-Toast -Title (T "ToastDiskScanDoneTitle" "Escaneo completado") `
                           -Message "$($script:AllScannedItems.Count) $(T 'ToastDiskScanDoneItems' 'elementos') * $gtStr2" `
                           -Type "Success"
            }
            Complete-Task -Id "diskscan" -IsError:$wasStop -Detail "$($script:AllScannedItems.Count) elementos * $gtStr2"
        }
    })
$script:DiskUiTimer.Start()
}

# --- Start-Optimization ----------------------------------------------------
function global:Start-Optimization {
    param([bool]$DryRunOverride = $false)

    if ($chkCleanRegistry.IsChecked -and -not $chkBackupRegistry.IsChecked -and -not $DryRunOverride) {
        $warn = Show-ThemedDialog -Title ((T "DlgRegistryNoBackupTitle")) `
            -Message ((T "DlgRegistryNoBackupMsg")) `
            -Type "warning" -Buttons "YesNo"
        if (-not $warn) { return }
    }

    if (-not [string]::IsNullOrWhiteSpace($ConsoleOutput.Text)) {
        $clearWarn = Show-ThemedDialog -Title ((T "DlgClearConsoleTitle")) `
            -Message ((T "DlgClearConsoleMsgExt")) `
            -Type "question" -Buttons "YesNo"
        if (-not $clearWarn) { return }
    }

    # Contar tareas seleccionadas
    # Mapa checkbox -> (Nombre tarea, Clave options)
    $taskMap = @(
        @($chkOptimizeDisks,  (T "ChkOptimizeDisks" "Optimizar discos"), "OptimizeDisks"),
        @($chkRecycleBin,     "Vaciar papelera",  "RecycleBin"),
        @($chkTempFiles,      "Temp Windows",     "TempFiles"),
        @($chkUserTemp,       "Temp Usuario",     "UserTemp"),
        @($chkWUCache,        "WU Cache",         "WUCache"),
        @($chkChkdsk,         "CHKDSK",           "Chkdsk"),
        @($chkClearMemory,    "Liberar RAM",      "ClearMemory"),
        @($chkCloseProcesses, (T "ChkCloseProcesses" "Cerrar procesos"),  "CloseProcesses"),
        @($chkDNSCache,       "DNS",              "DNSCache"),
        @($chkBrowserCache,   (T "ChkBrowserCache" "Navegadores"),      "BrowserCache"),
        @($chkBackupRegistry, (T "ChkBackupRegistry" "Backup registro"),  "BackupRegistry"),
        @($chkCleanRegistry,  (T "ChkCleanRegistry" "Limpiar registro"), "CleanRegistry"),
        @($chkSFC,            "SFC",              "SFC"),
        @($chkDISM,           "DISM",             "DISM"),
        @($chkEventLogs,      "Event Logs",       "EventLogs")
    )
    $selectedTasks = @($taskMap | Where-Object { $_[0].IsChecked } | ForEach-Object { $_[1] })

    # [N8] ShowStartup se maneja en el hilo principal antes del runspace
    if ($chkShowStartup.IsChecked) {
        Show-StartupManager
    }

    if ($selectedTasks.Count -eq 0 -and -not $chkShowStartup.IsChecked) {
        Show-ThemedDialog -Title ((T "DlgNoTasksTitle")) `
            -Message (T "OptSelectAtLeastOne" "Por favor, selecciona al menos una opción.") -Type "warning"
        return
    }

    if ($selectedTasks.Count -eq 0) { return }   # Solo ShowStartup fue marcado, ya se procesó

    $isDryRun  = $DryRunOverride -or $chkDryRun.IsChecked
    $modeLabel = if ($isDryRun) { "$([char]::ConvertFromUtf32(0x1F50D)) MODO ANÁLISIS (sin cambios)" } else { "$([char]0x26A1) EJECUCIÓN REAL" }

    $confirm = Show-ThemedDialog -Title ((T "DlgConfirmOptTitle")) `
        -Message "$(T 'OptMode' 'Modo'): $modeLabel`n`n$(T 'OptStartWith' '¿Iniciar con') $($selectedTasks.Count) $(T 'OptTasks' 'tareas')?`n* $($selectedTasks -join "`n* ")" `
        -Type "question" -Buttons "YesNo"
    if (-not $confirm) {
        Write-Log "[OPT] Optimización cancelada por el usuario antes de iniciar." -Level "INFO" -NoUI
        return
    }
    Write-Log ("-- Inicio de optimización --------------------------------") -Level "INFO" -NoUI
    Write-Log ("[OPT] Modo          : {0}" -f $(if ($isDryRun) {"ANÁLISIS (dry-run)"} else {"REAL"})) -Level "INFO" -NoUI
    Write-Log ("[OPT] Tareas ({0,2})  : {1}" -f $selectedTasks.Count, ($selectedTasks -join " | ")) -Level "INFO" -NoUI
    Write-Log ("[OPT] Tema activo   : {0}  |  Idioma: {1}" -f $script:CurrentTheme, $script:CurrentLang) -Level "INFO" -NoUI

    # Preparar UI
    $btnStart.IsEnabled      = $false
    $btnDryRun.IsEnabled     = $false
    if ($null -ne $btnWizard) { $btnWizard.IsEnabled = $false }
    $btnSelectAll.IsEnabled  = $false
    $btnCancel.IsEnabled     = $true
    foreach ($cb in $script:AllCheckboxes) { $cb.IsEnabled = $false }

    $ConsoleOutput.Clear()
    $ProgressBar.Value  = 0
    $ProgressText.Text  = "0%"
    $TaskText.Text      = (T "SnapInitializing")

    $script:CancelSource  = New-Object System.Threading.CancellationTokenSource
    $script:WasCancelled  = $false

    $options = @{ 'DryRun' = $isDryRun; 'AutoRestart' = $chkAutoRestart.IsChecked; '_DllDir' = $script:_libsDir }
    foreach ($t in $taskMap) { $options[$t[2]] = $t[0].IsChecked }

    # -- [N8b] SFC/DISM: ventana independiente en paralelo con el runspace -----
    # Show() non-modal: la ventana principal sigue responsive y el runspace
    # arranca en paralelo.  El timer de completado espera a que ambos terminen.
    $script:_sfcDismDone = $true   # default: no SFC/DISM selected -> already "done"
    if ($options['SFC'] -or $options['DISM']) {
        if ($isDryRun) {
            # Modo análisis: mostrar ventana SFC/DISM con verificación (sfc /verifyonly + dism /checkhealth)
            $script:_sfcDismDone = $false
            Show-SfcDismWindow -AutoRunSfc:([bool]$options['SFC']) -AutoRunDism:([bool]$options['DISM']) -IsDryRun:$true
            # Desactivar para que OptimizerEngine no los vuelva a ejecutar en el runspace
            $options['SFC']  = $false
            $options['DISM'] = $false
        } else {
            # Modo real: mostrar ventana SFC/DISM con reparación completa
            $script:_sfcDismDone = $false
            Show-SfcDismWindow -AutoRunSfc:([bool]$options['SFC']) -AutoRunDism:([bool]$options['DISM']) -IsDryRun:$false
            # Desactivar para que OptimizerEngine no los vuelva a ejecutar en el runspace
            $options['SFC']  = $false
            $options['DISM'] = $false
        }
    }

    $runspace = [runspacefactory]::CreateRunspace()
    $runspace.ApartmentState = "STA"
    $runspace.ThreadOptions  = "ReuseThread"
    $runspace.Open()

    # Variable compartida para recibir el informe de diagnóstico del runspace
    # FIX: inyectar via SessionStateProxy en lugar de pasar como [ref] en AddArgument.
    # Pasar [ref] como argumento posicional rompe el binding de TODOS los params del script.
    $script:DiagReportData   = $null
    $script:LastRunWasDryRun = $isDryRun
    $diagReportRef = [ref]$script:DiagReportData
    $script:DiagReportRef    = $diagReportRef
    $runspace.SessionStateProxy.SetVariable('DiagReportRef', $diagReportRef)

    # -- Pre-resolver claves lang para el runspace (no hereda funciones) --
    $langRS = @{
        'OptCurrentTask'  = (T 'OptCurrentTask'  'Tarea actual')
        'OptRestarting'   = (T 'OptRestarting'    'Reiniciando el sistema en 10 segundos...')
        'OptRestartingIn' = (T 'OptRestartingIn'  'Reiniciando en {0} segundos...')
    }
    $runspace.SessionStateProxy.SetVariable('LangRS', $langRS)

    $powershell = [powershell]::Create()
    $powershell.Runspace = $runspace
    $powershell.AddScript($OptimizationScript)
    $powershell.AddArgument($window)
    $powershell.AddArgument($ConsoleOutput)
    $powershell.AddArgument($ProgressBar)
    $powershell.AddArgument($StatusText)
    $powershell.AddArgument($ProgressText)
    $powershell.AddArgument($TaskText)
    $powershell.AddArgument($options)
    $powershell.AddArgument($script:CancelSource.Token) | Out-Null

    $handle = $powershell.BeginInvoke()

    $script:ActivePowershell = $powershell
    $script:ActiveRunspace   = $runspace
    $script:ActiveHandle     = $handle
    $script:UI_BtnStart      = $btnStart
    $script:UI_BtnDryRun     = $btnDryRun
    $script:UI_BtnWizard     = $btnWizard
    $script:UI_BtnSelectAll  = $btnSelectAll
    $script:UI_BtnCancel     = $btnCancel
    $script:UI_Checkboxes    = $script:AllCheckboxes
    $script:UI_ProgressBar   = $ProgressBar
    $script:UI_ProgressText  = $ProgressText
    $script:UI_TaskText      = $TaskText
    $script:UI_StatusText    = $StatusText
    $script:UI_ConsoleOutput = $ConsoleOutput

    $timer = New-Object System.Windows.Threading.DispatcherTimer
    $timer.Interval = [TimeSpan]::FromMilliseconds(500)
    $script:ActiveTimer = $timer

    $timer.Add_Tick({
        $runspaceDone = $false
        try {
            if ($script:ActiveHandle -and $script:ActiveHandle.IsCompleted) {
                $runspaceDone = $true
            }
        } catch {
            $runspaceDone = $true   # error al comprobar -> asumir terminado
        }

        # -- Wait for BOTH: runspace AND SFC/DISM window (if open) --------
        if ($runspaceDone -and -not $script:_sfcDismDone) {
            # Runspace finished but SFC/DISM still running -- show status, keep waiting
            $script:UI_TaskText.Text = T 'SfcDismWaitingForRepair' 'Esperando finalización de SFC/DISM...'
            $script:UI_ProgressBar.IsIndeterminate = $true
            return
        }

        if ($runspaceDone -and $script:_sfcDismDone) {
            $script:ActiveTimer.Stop()
            $script:UI_ProgressBar.IsIndeterminate = $false

            try {
                $script:ActivePowershell.EndInvoke($script:ActiveHandle)
            } catch {
                $errMsg = $_.Exception.Message
                $inner  = if ($_.Exception.InnerException) { " | Inner: $($_.Exception.InnerException.Message)" } else { "" }
                Write-Log "[RUNSPACE] Error: $errMsg$inner" -Level "ERR" -NoUI
                $window.Dispatcher.Invoke([action]{
                    $script:UI_ConsoleOutput.AppendText("[ERROR RUNSPACE] $errMsg$inner`n")
                    $script:UI_ConsoleOutput.ScrollToEnd()
                })
            }
            # Capturar errores del stream (errores no-terminantes del runspace)
            if ($script:ActivePowershell.Streams.Error.Count -gt 0) {
                foreach ($streamErr in $script:ActivePowershell.Streams.Error) {
                    $se = "[RUNSPACE] Stream error: $($streamErr.ToString()) | Script: $($streamErr.InvocationInfo.ScriptName) línea $($streamErr.InvocationInfo.ScriptLineNumber)"
                    Write-Log $se -Level "ERR" -NoUI
                }
            }
            try { $script:ActivePowershell.Dispose()  } catch { }
            try { $script:ActiveRunspace.Close()      } catch { }
            try { $script:ActiveRunspace.Dispose()    } catch { }

            $cs = $script:CancelSource
            $script:CancelSource = $null
            if ($null -ne $cs) { try { $cs.Dispose() } catch { } }

            # Reset UI
            $script:UI_ProgressBar.Value  = 0
            $script:UI_ProgressText.Text  = "0%"
            $script:UI_TaskText.Text      = ""
            $script:UI_StatusText.Text    = (T "StatusReady" "Listo para optimizar")

            $script:UI_BtnStart.IsEnabled     = $true
            $script:UI_BtnDryRun.IsEnabled    = $true
            if ($null -ne $script:UI_BtnWizard) { $script:UI_BtnWizard.IsEnabled = $true }
            $script:UI_BtnSelectAll.IsEnabled = $true
            $script:UI_BtnCancel.IsEnabled    = $false
            $script:UI_BtnCancel.Content      = "$([char]0x26D4) $((T "BtnCancel"))"
            foreach ($cb in $script:UI_Checkboxes) { $cb.IsEnabled = $true }

            # Actualizar info del sistema al finalizar
            Update-SystemInfo

            # FIX: leer datos del análisis desde PSReference (el runspace actualiza .Value,
            # no $script:DiagReportData directamente -- bug de [ref] cross-runspace)
            if ($null -ne $script:DiagReportRef -and $null -ne $script:DiagReportRef.Value) {
                $script:DiagReportData = $script:DiagReportRef.Value
            }

            if ($script:WasCancelled) {
                # BUG FIX: resetear WizardMode también si se cancela
                $script:WizardMode = $false
                Write-Log "[OPT] Proceso cancelado por el usuario." -Level "WARN" -NoUI
                Show-Toast -Title (T "OptProcessCancelled") -Message (T "OptProcessCancelled") -Type "Warning"
                Write-ConsoleMain "[!] $(T 'OptProcessCancelled')"
            } elseif ($script:LastRunWasDryRun -and $null -ne $script:DiagReportData) {
                Write-Log "[OPT] Análisis (dry-run) completado con informe de diagnóstico." -Level "INFO" -NoUI
                Show-Toast -Title (T "ToastAnalysisDoneTitle") -Message (T "ToastAnalysisDoneMsg") -Type "Info"
                if ($script:WizardMode) {
                    $script:WizardMode = $false
                    Show-WizardWindow -Report $script:DiagReportData
                } else {
                    Show-DiagnosticReport -Report $script:DiagReportData
                }
            } elseif ($script:LastRunWasDryRun) {
                # Dry run sin datos (tareas no recogen diagData) -> mensaje simple
                # BUG FIX: resetear WizardMode si no hay datos de diagnóstico
                $script:WizardMode = $false
                Write-Log "[OPT] Análisis (dry-run) completado." -Level "INFO" -NoUI
                Show-Toast -Title (T "ToastAnalysisDoneTitle") -Message (T "ToastAnalysisDoneMsg") -Type "Info"
                Write-ConsoleMain "$([char]0x2705) $(T 'OptAnalysisDoneMsg')"
            } else {
                Write-Log "-- Fin de optimización -----------------------------------" -Level "INFO" -NoUI
                Write-Log "[OPT] Optimización real completada correctamente." -Level "INFO" -NoUI
                Show-Toast -Title (T "ToastOptDoneTitle") -Message (T "ToastOptDoneMsg") -Type "Success"
                Write-ConsoleMain "$([char]0x2705) $(T 'OptDoneMsg')"
            }
            $script:WasCancelled = $false
        }
    })
    $timer.Start()
}

# ===============================================================================
# [FASE 6] Sistema de Módulos -- Motor de plugins
# ===============================================================================

function global:Initialize-ModuleSystem {
    <#
    .SYNOPSIS
        Inicializa el motor de módulos. v3.3.0: lógica de I/O y JSON parsing
        delegada a [ModuleEngine] (SysOpt.Modules.dll) para rendimiento.
        Fast path: caché JSON en %TEMP%\SysOpt\module-cache.json
        Dot-source y UI permanecen en PS1 (no pueden vivir en C#).
    #>
    param([hashtable]$PreReadDlls = $null)
    $script:ModulesDir      = Join-Path $script:AppDir "modules"
    $script:LoadedModules   = @{}
    $script:_modCachePath   = [IO.Path]::Combine($env:TEMP, "SysOpt", "module-cache.json")

    # [C#] Crear directorios y modules.json si no existen
    $script:ModulesJsonPath = [ModuleEngine]::EnsureDirectories($script:ModulesDir)

    # [C#] Registry nativo -- Dictionary<string, RegistryEntry>
    $script:ModulesRegistryNative = [ModuleEngine]::ReadRegistry($script:ModulesJsonPath)

    # [C#] Fast/Slow path para caché
    $usedCache = [ModuleEngine]::IsCacheValid($script:_modCachePath, $script:ModulesJsonPath)
    if (-not $usedCache) {
        [ModuleEngine]::BuildCache($script:ModulesJsonPath, $script:ModulesDir, $script:_modCachePath)
        Write-Log "[MOD] Registry + caché reconstruida (C#, slow path)" -Level DBG
    } else {
        Write-Log "[MOD] Caché válida (C#, fast path)" -Level DBG
    }

    # [C#] Obtener módulos habilitados ordenados por loadOrder
    $enabledIds = [ModuleEngine]::GetEnabledModuleIds($script:ModulesJsonPath)

    foreach ($moduleId in $enabledIds) {
        try {
            $modulePath   = Join-Path $script:ModulesDir $moduleId
            # [C#] Leer manifest nativo (cache-first, luego disco)
            $manifest = if ($usedCache) {
                [ModuleEngine]::ReadCachedManifest($script:_modCachePath, $moduleId)
            } else { $null }
            if (-not $manifest) {
                $manifest = [ModuleEngine]::ReadManifest((Join-Path $modulePath "module.json"))
            }
            if (-not $manifest) {
                Write-Log "[MOD] '$moduleId' no tiene module.json -- saltando" -Level WARN
                continue
            }

            # [C#] Validar versión mínima
            if (-not [ModuleEngine]::IsCompatible($manifest, $script:AppVersion)) {
                Write-Log "[MOD] '$moduleId' requiere v$($manifest.MinSysOptVersion), actual v$($script:AppVersion) -- saltando" -Level WARN
                continue
            }

            # -- [FIX+OPT] Cargar DLLs (pre-leídas desde BG si disponible, sino ReadAllBytes) --
            $libsDir = Join-Path $modulePath "libs"
            if (Test-Path $libsDir) {
                Get-ChildItem -Path $libsDir -Filter "*.dll" | ForEach-Object {
                    try {
                        $dllPath = $_.FullName
                        $bytes = if ($PreReadDlls -and $PreReadDlls.ContainsKey($dllPath)) {
                            [byte[]]$PreReadDlls[$dllPath]
                        } else {
                            [System.IO.File]::ReadAllBytes($dllPath)
                        }
                        [System.Reflection.Assembly]::Load([byte[]]$bytes) | Out-Null
                        Write-Log "[MOD] DLL cargada (byte-array): $($_.Name)" -Level DBG
                    } catch {
                        Write-Log "[MOD] Error cargando DLL $($_.Name): $_" -Level WARN
                    }
                }
            }

            # [PS1] Dot-source entry point (debe ejecutarse en el runspace actual)
            $entryPath = Join-Path $modulePath $manifest.EntryPoint
            if (Test-Path $entryPath) {
                . $entryPath
                Write-Log "[MOD] '$moduleId' v$($manifest.Version) cargado" -Level INFO
            } else {
                Write-Log "[MOD] Entry point no encontrado: $entryPath" -Level WARN
                continue
            }

            # -- Cargar lang del módulo si existe --------------------------
            $modLangDir = Join-Path $modulePath "lang"
            if (Test-Path $modLangDir) {
                $modLangFile = Join-Path $modLangDir "$($script:CurrentLang).lang"
                if (-not (Test-Path $modLangFile)) {
                    $modLangFile = Join-Path $modLangDir "en-us.lang"
                }
                if (Test-Path $modLangFile) {
                    try {
                        $modDict = [LangEngine]::ParseLangFile($modLangFile)
                        foreach ($k in $modDict.Keys) {
                            if (-not $script:LangDict.ContainsKey($k)) {
                                $script:LangDict[$k] = $modDict[$k]
                            }
                        }
                        Write-Log "[MOD] '$moduleId' lang merged: $([IO.Path]::GetFileName($modLangFile))" -Level DBG
                    } catch {
                        Write-Log "[MOD] '$moduleId' error cargando lang: $_" -Level WARN
                    }
                }
            }

            $script:LoadedModules[$moduleId] = @{
                Manifest = $manifest   # ahora es [ModuleManifest] C# (PascalCase)
                Path     = $modulePath
                TabItem  = $null
            }
        } catch {
            Write-Log "[MOD] Error cargando '$moduleId': $_" -Level WARN
        }
    }

    Write-Log "[MOD] Motor inicializado (C#): $($script:LoadedModules.Count) módulos cargados" -Level INFO
}

function global:Mount-ModuleTabs {
    <# Crea TabItems dinámicos en tabMain para cada módulo habilitado. #>
    if ($script:SafeMode -or -not $script:LoadedModules -or $script:LoadedModules.Count -eq 0) {
        return
    }
    # Ordenar por LoadOrder usando el registry nativo C#
    $sortedIds = $script:LoadedModules.Keys | Sort-Object {
        if ($script:ModulesRegistryNative.ContainsKey($_)) {
            $script:ModulesRegistryNative[$_].LoadOrder
        } else { 999 }
    }
    foreach ($moduleId in $sortedIds) {
        try { Mount-SingleModuleTab $moduleId }
        catch { Write-Log "[MOD] Error montando tab '$moduleId': $_" -Level WARN }
    }
}

function global:Mount-SingleModuleTab {
    param([string]$ModuleId)
    if (-not $script:LoadedModules.ContainsKey($ModuleId)) { return }
    $mod = $script:LoadedModules[$ModuleId]
    $manifest = $mod.Manifest  # [ModuleManifest] C# -- PascalCase properties

    $tabItem = [System.Windows.Controls.TabItem]::new()
    $tabItem.Header = $manifest.TabHeader
    $safeName = ($manifest.TabName -replace '[^a-zA-Z0-9_]', '_')
    if ($safeName -and $safeName -match '^[a-zA-Z_]') {
        $tabItem.Name = $safeName
    } else {
        $tabItem.Name = "tabModule_$($ModuleId -replace '[^a-zA-Z0-9_]', '_')"
    }
    $tabItem.Tag = "module:$ModuleId"
    $tabItem.Foreground = [System.Windows.Media.SolidColorBrush]::new(
        [System.Windows.Media.ColorConverter]::ConvertFromString((Get-TC 'TextPrimary' '#E8EAF6')))

    $xamlPath = Join-Path $mod.Path $manifest.UiXaml
    if (Test-Path $xamlPath) {
        try {
            $xamlContent = Get-Content -Path $xamlPath -Raw -Encoding UTF8
            # [SECURITY] Safe theme substitution -- {{TC:ColorName:default}} only
            $xamlContent = [regex]::Replace($xamlContent, '\{\{TC:([^:}]+):([^}]+)\}\}', {
                param($m)
                Get-TC $m.Groups[1].Value $m.Groups[2].Value
            })
            $reader = [System.Xml.XmlReader]::Create([System.IO.StringReader]::new($xamlContent))
            $tabContent = [System.Windows.Markup.XamlReader]::Load($reader)
            $tabItem.Content = $tabContent
        } catch {
            Write-Log "[MOD] Error loading XAML for '$ModuleId': $_" -Level WARN
        }
    }
    if (-not $tabItem.Content) {
        $placeholder = [System.Windows.Controls.TextBlock]::new()
        $placeholder.Text = "$($manifest.Icon)  $($manifest.Name)"
        $placeholder.Foreground = [System.Windows.Media.Brushes]::White
        $placeholder.FontSize = 16
        $placeholder.Margin = [System.Windows.Thickness]::new(20)
        $tabItem.Content = $placeholder
    }

    $script:tabMain.Items.Add($tabItem) | Out-Null
    $mod.TabItem = $tabItem
    Write-Log "[MOD] Tab montado: $($manifest.TabHeader)" -Level DBG

    # -- Post-mount callback: Initialize-ModuleUI_{id} ---------------------
    # Permite a módulos complejos vincular eventos a sus controles XAML
    # tras la carga. Convención: function global:Initialize-ModuleUI_office { param($Content) ... }
    $safeId   = $ModuleId -replace '[^a-zA-Z0-9_]', '_'
    $initName = "Initialize-ModuleUI_$safeId"
    if (Get-Command $initName -ErrorAction SilentlyContinue) {
        try {
            & $initName $tabItem.Content
            Write-Log "[MOD] UI callback ejecutado: $initName" -Level DBG
        } catch {
            Write-Log "[MOD] Error en UI callback '$initName': $_" -Level WARN
        }
    }
}

function global:Unmount-ModuleTab {
    param([string]$ModuleId)
    if ($script:LoadedModules.ContainsKey($ModuleId)) {
        $mod = $script:LoadedModules[$ModuleId]
        if ($mod.TabItem -and $script:tabMain.Items.Contains($mod.TabItem)) {
            $script:tabMain.Items.Remove($mod.TabItem)
            $mod.TabItem = $null
            Write-Log "[MOD] Tab desmontado: $ModuleId" -Level DBG
        }
    }
}

function global:Install-SysOptModule {
    param([string]$ZipPath)
    try {
        # [C#] Leer manifest desde ZIP + validar (sin extraer todo)
        $manifest = [ModuleEngine]::ReadManifestFromZip($ZipPath)
        $validation = [ModuleEngine]::ValidateManifest($manifest, $script:AppVersion)
        if (-not $validation.IsValid) {
            throw ($validation.Errors -join "; ")
        }

        $moduleId  = $manifest.Id
        $targetDir = Join-Path $script:ModulesDir $moduleId

        # Si ya existe, preguntar actualización
        $wasEnabled = $false
        if (Test-Path $targetDir) {
            $existing = [ModuleEngine]::ReadManifest((Join-Path $targetDir "module.json"))
            $existName = if ($existing) { $existing.Name } else { $moduleId }
            $existVer  = if ($existing) { $existing.Version } else { "?" }
            $confirm = Show-ThemedDialog `
                -Title (T "ModInstallUpdate" "Actualizar módulo") `
                -Message "$(T 'ModAlreadyInstalled' 'El módulo ya está instalado')`n`n$existName v$existVer -> v$($manifest.Version)`n`n$(T 'ModConfirmUpdate' '¿Desea actualizar?')" `
                -Type "question" -Buttons "YesNo"
            if ($confirm -ne 'Yes') { return $null }

            # -- [FIX] Deshabilitar módulo antes de actualizar (libera DLLs del tab/UI) --
            if ($script:ModulesRegistryNative.ContainsKey($moduleId) -and
                $script:ModulesRegistryNative[$moduleId].Enabled) {
                $wasEnabled = $true
                Disable-SysOptModule $moduleId
                Write-Log "[MOD] '$moduleId' deshabilitado temporalmente para actualización" -Level INFO
            }
            Remove-Item -Path $targetDir -Recurse -Force
        }

        # [C#] Extraer ZIP con protección path-traversal
        [ModuleEngine]::ExtractModuleZip($ZipPath, $targetDir)

        # [C#] Actualizar registry nativo
        $loadOrder = [ModuleEngine]::GetNextLoadOrder($script:ModulesRegistryNative)
        $entry = [ModuleEngine]::CreateRegistryEntry($manifest.Version, $loadOrder)
        $script:ModulesRegistryNative[$moduleId] = $entry
        Save-ModulesRegistry

        Write-Log "[MOD] '$moduleId' v$($manifest.Version) instalado (C#)" -Level INFO

        # -- [FIX] Re-habilitar módulo si estaba activo antes de la actualización --
        if ($wasEnabled) {
            Enable-SysOptModule $moduleId
            Write-Log "[MOD] '$moduleId' re-habilitado tras actualización" -Level INFO
        }

        Show-Toast -Title (T "ModInstalled" "Módulo instalado") `
            -Message "$($manifest.Name) v$($manifest.Version)" -Type "Success"
        return $manifest
    } catch {
        Write-Log "[MOD] Error instalando módulo: $_" -Level WARN
        Show-ThemedDialog -Title (T "ModInstallError" "Error de instalación") `
            -Message "$_" -Type "error"
        return $null
    }
}

function global:Enable-SysOptModule {
    param([string]$ModuleId)
    # [C#] Actualizar registry
    if ($script:ModulesRegistryNative.ContainsKey($ModuleId)) {
        $script:ModulesRegistryNative[$ModuleId].Enabled = $true
    }
    Save-ModulesRegistry

    # Cargar módulo en runtime
    $modulePath = Join-Path $script:ModulesDir $ModuleId
    $manifest = [ModuleEngine]::ReadManifest((Join-Path $modulePath "module.json"))

    if ($manifest) {
        # -- [FIX] Cargar DLLs del módulo ANTES del dot-source (byte-array = no file lock) --
        $libsDir = Join-Path $modulePath "libs"
        if (Test-Path $libsDir) {
            Get-ChildItem -Path $libsDir -Filter "*.dll" | ForEach-Object {
                try {
                    [byte[]]$bytes = [System.IO.File]::ReadAllBytes($_.FullName)
                    [System.Reflection.Assembly]::Load([byte[]]$bytes) | Out-Null
                    Write-Log "[MOD] DLL cargada (byte-array): $($_.Name)" -Level DBG
                } catch {
                    Write-Log "[MOD] Error cargando DLL $($_.Name): $_" -Level WARN
                }
            }
        }

        $entryPath = Join-Path $modulePath $manifest.EntryPoint
        if (Test-Path $entryPath) { . $entryPath }

        # -- [FIX] Cargar lang del módulo --
        $modLangDir = Join-Path $modulePath "lang"
        if (Test-Path $modLangDir) {
            $modLangFile = Join-Path $modLangDir "$($script:CurrentLang).lang"
            if (-not (Test-Path $modLangFile)) {
                $modLangFile = Join-Path $modLangDir "en-us.lang"
            }
            if (Test-Path $modLangFile) {
                try {
                    $modDict = [LangEngine]::ParseLangFile($modLangFile)
                    foreach ($k in $modDict.Keys) {
                        if (-not $script:LangDict.ContainsKey($k)) {
                            $script:LangDict[$k] = $modDict[$k]
                        }
                    }
                    Write-Log "[MOD] '$ModuleId' lang merged" -Level DBG
                } catch {}
            }
        }

        $script:LoadedModules[$ModuleId] = @{
            Manifest = $manifest; Path = $modulePath; TabItem = $null
        }
        Mount-SingleModuleTab $ModuleId
    }
    Write-Log "[MOD] '$ModuleId' habilitado" -Level INFO
}

function global:Disable-SysOptModule {
    param([string]$ModuleId)
    if ($script:ModulesRegistryNative.ContainsKey($ModuleId)) {
        $script:ModulesRegistryNative[$ModuleId].Enabled = $false
    }
    Save-ModulesRegistry
    Unmount-ModuleTab $ModuleId

    # -- [FIX] Limpiar variables de script del módulo --
    # Nota: Las DLLs cargadas con Load(byte[]) no bloquean archivos.
    # No es posible descargarlas del AppDomain, pero al estar cargadas por byte-array
    # los archivos en disco están libres para ser eliminados o reemplazados.
    $script:LoadedModules.Remove($ModuleId)

    # Limpiar funciones globales del módulo
    $safeId = $ModuleId -replace '[^a-zA-Z0-9_]', '_'

    # Call module-specific cleanup if available (releases icons, caches, etc.)
    $cleanupFunc = "Cleanup-ModuleUI_$safeId"
    if (Get-Command $cleanupFunc -ErrorAction SilentlyContinue) {
        try { & $cleanupFunc } catch {
            Write-Log "[MOD] Cleanup error for '$ModuleId': $_" -Level WARN
        }
        try { Remove-Item "Function:\$cleanupFunc" -Force -ErrorAction SilentlyContinue } catch {}
    }

    $initFunc = "Initialize-ModuleUI_$safeId"
    if (Get-Command $initFunc -ErrorAction SilentlyContinue) {
        try { Remove-Item "Function:\$initFunc" -Force -ErrorAction SilentlyContinue } catch {}
    }

    Write-Log "[MOD] '$ModuleId' deshabilitado (tab desmontado, recursos liberados)" -Level INFO
}

function global:Uninstall-SysOptModule {
    param([string]$ModuleId)
    $modulePath = Join-Path $script:ModulesDir $ModuleId
    $manifest = [ModuleEngine]::ReadManifest((Join-Path $modulePath "module.json"))
    $moduleName = if ($manifest) { $manifest.Name } else { $ModuleId }

    $confirm = Show-ThemedDialog `
        -Title (T "ModUninstall" "Desinstalar módulo") `
        -Message "$(T 'ModConfirmUninstall' '¿Está seguro de que desea desinstalar') $($moduleName)?" `
        -Type "question" -Buttons "YesNo"
    if ($confirm -ne 'Yes') { return }

    Unmount-ModuleTab $ModuleId
    $script:LoadedModules.Remove($ModuleId)

    if (Test-Path $modulePath) { Remove-Item -Path $modulePath -Recurse -Force }
    if ($script:ModulesRegistryNative.ContainsKey($ModuleId)) {
        $script:ModulesRegistryNative.Remove($ModuleId)
    }
    Save-ModulesRegistry

    Write-Log "[MOD] '$ModuleId' desinstalado" -Level INFO
    Show-Toast -Title (T "ModUninstalled" "Módulo desinstalado") -Message $moduleName -Type "Info"
}

function global:Save-ModulesRegistry {
    # [C#] Atomic write + cache rebuild en C# nativo
    [ModuleEngine]::SaveRegistry($script:ModulesJsonPath, $script:ModulesRegistryNative)
    [ModuleEngine]::BuildCache($script:ModulesJsonPath, $script:ModulesDir, $script:_modCachePath)
}

function global:Update-ModuleCache {
    # [C#] Delegado completamente a ModuleEngine
    try {
        [ModuleEngine]::BuildCache($script:ModulesJsonPath, $script:ModulesDir, $script:_modCachePath)
        Write-Log "[MOD] Caché actualizada (C#)" -Level DBG
    } catch {
        Write-Log "[MOD] Error actualizando caché: $_" -Level DBG
    }
}

function global:Get-InstalledModules {
    <# [C#] Delegado a ModuleEngine -- devuelve ModuleInfo[] #>
    return [ModuleEngine]::GetInstalledModules(
        $script:ModulesJsonPath, $script:ModulesDir, $script:_modCachePath)
}

