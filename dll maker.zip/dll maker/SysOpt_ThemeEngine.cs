// =============================================================================
//  SysOpt.ThemeEngine.dll  —  v1.1
//  Hot-swap de temas WPF sin reiniciar la aplicación.
//
//  Cambios v1.1:
//    - HexToBrush ya NO llama Freeze() — brushes frozen no se pueden asignar
//      a propiedades de controles en vivo (lanzaba InvalidOperationException).
//    - VisualWalker amplía ProcessElement a: Button, Label, CheckBox/RadioButton,
//      ListBox, ListBoxItem, StackPanel, Grid, Panel, Rectangle, Ellipse, Shape,
//      Run (via TextBlock.Inlines), ProgressBar, Expander, GroupBox.
//    - SwapFgBrush/SwapBgBrush: helpers genéricos con Func<> setter.
//    - Walk() combina árbol visual + lógico (cubre DataTemplate items).
//
//  Uso:  [SysOpt.ThemeEngine]::ApplyTheme($window, $themeHashtable, $defaults)
//  Req.: PresentationCore, PresentationFramework, WindowsBase (.NET 4.7.2+ o .NET 6+)
// =============================================================================

using System;
using System.Collections;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Shapes;

namespace SysOpt
{
    public sealed class ThemeApplyResult
    {
        public bool   Success           { get; internal set; }
        public int    ResourcesUpdated  { get; internal set; }
        public int    ControlsWalked    { get; internal set; }
        public int    ColorsReplaced    { get; internal set; }
        public string ErrorMessage      { get; internal set; } = string.Empty;
        public double ElapsedMs         { get; internal set; }

        public override string ToString() =>
            Success
                ? $"[ThemeEngine v1.1] OK — {ResourcesUpdated} RD brushes, {ColorsReplaced} reemplazos en {ControlsWalked} nodos ({ElapsedMs:F1} ms)"
                : $"[ThemeEngine v1.1] ERROR — {ErrorMessage}";
    }

    public static class ThemeEngine
    {
        public static string Version => "1.1";

        private static readonly Dictionary<string, string> s_darkDefaults =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "#FF0D0F1A", "BgDeep"        },
            { "#FF131625", "BgCard"        },
            { "#FF1A1E2F", "BgInput"       },
            { "#FF1A2035", "BgInput"       },
            { "#FF1A2540", "BgInput"       },
            { "#FF252B40", "BorderSubtle"  },
            { "#FF3A4468", "BorderHover"   },
            { "#FF5BA3FF", "AccentBlue"    },
            { "#FF3D8EFF", "AccentBlue"    },
            { "#FFE8ECF4", "TextPrimary"   },
            { "#FFD4D9E8", "TextPrimary"   },
            { "#FFF0F3FA", "TextPrimary"   },
            { "#FFE0E8F4", "TextPrimary"   },
            { "#FFB0BACC", "TextSecondary" },
            { "#FFD0D8F0", "TextSecondary" },
            { "#FF7BA8E0", "TextSecondary" },
            { "#FF7880A0", "TextMuted"     },
            { "#FF9BA4C0", "TextMuted"     },
            { "#FF8B96B8", "TextMuted"     },
            { "#FF6B7A9E", "TextMuted"     },
            { "#FF6B7599", "TextMuted"     },
            { "#FF4A5068", "TextMuted"     },
            { "#FF2EDFBF", "AccentCyan"    },
            { "#FF6ABDA0", "AccentCyan"    },
            { "#FFFFB547", "AccentAmber"   },
            { "#FFC0933A", "AccentAmber"   },
            { "#FFFF6B84", "AccentRed"     },
            { "#FF4AE896", "AccentGreen"   },
            { "#FF5AE88A", "AccentGreen"   },
            { "#FF9B7EFF", "AccentPurple"  },
            { "#FFC07AFF", "AccentPurple"  },
            { "#FF3A2010", "BgCard"        },
            { "#FF1A4A35", "BgCard"        },
        };

        private static readonly Dictionary<string, string> s_resourceMap =
            new Dictionary<string, string>(StringComparer.Ordinal)
        {
            { "BgDeep",        "BgDeep"        },
            { "BgCard",        "BgCard"        },
            { "BgCardHover",   "BgInput"       },
            { "BorderSubtle",  "BorderSubtle"  },
            { "BorderActive",  "AccentBlue"    },
            { "AccentBlue",    "AccentBlue"    },
            { "AccentCyan",    "AccentCyan"    },
            { "AccentAmber",   "AccentAmber"   },
            { "AccentRed",     "AccentRed"     },
            { "AccentGreen",   "AccentGreen"   },
            { "TextPrimary",   "TextPrimary"   },
            { "TextSecondary", "TextSecondary" },
            { "TextMuted",     "TextMuted"     },
        };

        // ── API principal ─────────────────────────────────────────────────────

        public static ThemeApplyResult ApplyTheme(
            Window window, IDictionary theme, IDictionary defaults = null)
        {
            var result = new ThemeApplyResult();
            if (window == null) { result.ErrorMessage = "window es null";   return result; }
            if (theme == null || theme.Count == 0)
                                { result.ErrorMessage = "theme está vacío"; return result; }

            var sw = System.Diagnostics.Stopwatch.StartNew();
            try
            {
                var colorLookup = BuildColorLookup(theme, defaults);

                result.ResourcesUpdated = UpdateResourceDictionary(window.Resources, colorLookup);
                UpdateProgressGradient(window.Resources, colorLookup);

                if (colorLookup.TryGetValue("BgDeep", out var bgHex))
                {
                    var b = HexToBrush(bgHex);
                    if (b != null) window.Background = b;
                }

                var brushMap = BuildBrushMap(colorLookup);
                var walker   = new VisualWalker(brushMap, colorLookup);
                walker.Walk(window);

                result.ControlsWalked = walker.ControlsVisited;
                result.ColorsReplaced = walker.ColorsReplaced;
                result.Success        = true;
            }
            catch (Exception ex) { result.ErrorMessage = ex.Message; }

            sw.Stop();
            result.ElapsedMs = sw.Elapsed.TotalMilliseconds;
            return result;
        }

        // Sobrecarga para Hashtable nativo de PowerShell
        public static ThemeApplyResult ApplyTheme(Window window, Hashtable theme, Hashtable defaults = null)
            => ApplyTheme(window, (IDictionary)theme, (IDictionary)defaults);

        // ── Utilidades públicas ───────────────────────────────────────────────

        /// <summary>
        /// Hex → SolidColorBrush MUTABLE (sin Freeze).
        /// Los brushes frozen lanzan InvalidOperationException al asignarlos a controles en vivo.
        /// </summary>
        public static SolidColorBrush HexToBrush(string hex)
        {
            if (string.IsNullOrWhiteSpace(hex)) return null;
            try   { return new SolidColorBrush((Color)ColorConverter.ConvertFromString(hex)); }
            catch { return null; }
        }

        public static Color? HexToColor(string hex)
        {
            if (string.IsNullOrWhiteSpace(hex)) return null;
            try   { return (Color)ColorConverter.ConvertFromString(hex); }
            catch { return null; }
        }

        // ── Helpers internos ──────────────────────────────────────────────────

        private static Dictionary<string, string> BuildColorLookup(IDictionary theme, IDictionary defaults)
        {
            var r = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            if (defaults != null)
                foreach (DictionaryEntry kv in defaults)
                    if (kv.Key is string k && kv.Value is string v && !string.IsNullOrWhiteSpace(v))
                        r[k] = v;
            foreach (DictionaryEntry kv in theme)
                if (kv.Key is string k && kv.Value is string v && !string.IsNullOrWhiteSpace(v))
                    r[k] = v;
            return r;
        }

        private static int UpdateResourceDictionary(ResourceDictionary res, Dictionary<string, string> lookup)
        {
            int count = 0;
            foreach (var entry in s_resourceMap)
            {
                if (!lookup.TryGetValue(entry.Value, out var hex)) continue;
                var color = HexToColor(hex);
                if (color == null) continue;
                try
                {
                    if (res[entry.Key] is SolidColorBrush brush)
                    {
                        if (brush.IsFrozen)
                            res[entry.Key] = new SolidColorBrush(color.Value);  // reemplazar frozen
                        else
                            brush.Color = color.Value;                           // mutar mutable
                        count++;
                    }
                }
                catch { }
            }
            return count;
        }

        private static void UpdateProgressGradient(ResourceDictionary res, Dictionary<string, string> lookup)
        {
            try
            {
                var pg = res["ProgressGradient"] as LinearGradientBrush;
                if (pg == null || pg.GradientStops.Count < 2) return;
                if (lookup.TryGetValue("ProgressStart", out var sh)) { var c = HexToColor(sh); if (c.HasValue) pg.GradientStops[0].Color = c.Value; }
                if (lookup.TryGetValue("ProgressEnd",   out var eh)) { var c = HexToColor(eh); if (c.HasValue) pg.GradientStops[1].Color = c.Value; }
            }
            catch { }
        }

        private static Dictionary<string, SolidColorBrush> BuildBrushMap(Dictionary<string, string> lookup)
        {
            var map = new Dictionary<string, SolidColorBrush>(StringComparer.OrdinalIgnoreCase);
            foreach (var entry in s_darkDefaults)
            {
                if (map.ContainsKey(entry.Key)) continue;
                if (!lookup.TryGetValue(entry.Value, out var hex)) continue;
                var b = HexToBrush(hex);
                if (b != null) map[entry.Key] = b;
            }
            return map;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  RECORRIDO DEL ÁRBOL VISUAL + LÓGICO
    // ─────────────────────────────────────────────────────────────────────────

    internal sealed class VisualWalker
    {
        private readonly Dictionary<string, SolidColorBrush> _brushMap;
        private readonly Dictionary<string, string>           _lookup;
        private readonly HashSet<int>                         _visited = new HashSet<int>();

        private readonly SolidColorBrush _bgInput, _txtPri, _txtSec, _txtMut;
        private readonly SolidColorBrush _bdrHov, _consoleBg, _consoleFg;

        public int ControlsVisited { get; private set; }
        public int ColorsReplaced  { get; private set; }

        public VisualWalker(Dictionary<string, SolidColorBrush> brushMap, Dictionary<string, string> lookup)
        {
            _brushMap  = brushMap;
            _lookup    = lookup;
            _bgInput   = Get("BgInput");
            _txtPri    = Get("TextPrimary");
            _txtSec    = Get("TextSecondary");
            _txtMut    = Get("TextMuted");
            _bdrHov    = Get("BorderHover");
            _consoleBg = Get("ConsoleBg");
            _consoleFg = Get("ConsoleFg");
        }

        private SolidColorBrush Get(string key) =>
            _lookup.TryGetValue(key, out var hex) ? ThemeEngine.HexToBrush(hex) : null;

        public void Walk(DependencyObject root)
        {
            if (root == null) return;
            var stack = new Stack<DependencyObject>();
            stack.Push(root);

            while (stack.Count > 0)
            {
                var el = stack.Pop();
                if (el == null) continue;

                int id = System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(el);
                if (!_visited.Add(id)) continue;

                ControlsVisited++;
                ProcessElement(el);

                // Árbol visual
                try
                {
                    int n = VisualTreeHelper.GetChildrenCount(el);
                    for (int i = 0; i < n; i++)
                    { var ch = VisualTreeHelper.GetChild(el, i) as DependencyObject; if (ch != null) stack.Push(ch); }
                }
                catch { }

                // Árbol lógico (DataTemplates, TabItems, ItemsControl, etc.)
                try
                {
                    foreach (var lc in LogicalTreeHelper.GetChildren(el))
                        if (lc is DependencyObject dep) stack.Push(dep);
                }
                catch { }
            }
        }

        private void ProcessElement(DependencyObject el)
        {
            try
            {
                switch (el)
                {
                    case TextBlock tb:
                        ColorsReplaced += Swap(tb.Foreground, b => tb.Foreground = b);
                        foreach (var inline in tb.Inlines)
                            if (inline is Run run)
                                ColorsReplaced += Swap(run.Foreground, b => run.Foreground = b);
                        break;

                    case Border border:
                        ColorsReplaced += Swap(border.Background,   b => border.Background   = b);
                        ColorsReplaced += Swap(border.BorderBrush,  b => border.BorderBrush  = b);
                        break;

                    case Button btn:
                        ColorsReplaced += Swap(btn.Background, b => btn.Background = b);
                        ColorsReplaced += Swap(btn.Foreground, b => btn.Foreground = b);
                        break;

                    case TextBox tb2:
                        ColorsReplaced += Swap(tb2.Background, b => tb2.Background = b);
                        if (_txtPri != null) { tb2.Foreground = _txtPri; ColorsReplaced++; }
                        if (tb2.Name == "ConsoleOutput")
                        {
                            if (_consoleBg != null) { tb2.Background = _consoleBg; ColorsReplaced++; }
                            if (_consoleFg != null) { tb2.Foreground = _consoleFg; ColorsReplaced++; }
                        }
                        break;

                    case Label lbl:
                        ColorsReplaced += Swap(lbl.Foreground, b => lbl.Foreground = b);
                        ColorsReplaced += Swap(lbl.Background, b => lbl.Background = b);
                        break;

                    case ToggleButton toggle:   // CheckBox y RadioButton
                        ColorsReplaced += Swap(toggle.Foreground, b => toggle.Foreground = b);
                        ColorsReplaced += Swap(toggle.Background, b => toggle.Background = b);
                        break;

                    case ComboBox combo:
                        if (_bgInput != null) { combo.Background  = _bgInput; ColorsReplaced++; }
                        if (_txtPri  != null) { combo.Foreground  = _txtPri;  ColorsReplaced++; }
                        if (_bdrHov  != null) { combo.BorderBrush = _bdrHov;  ColorsReplaced++; }
                        break;

                    case ListBox lb:
                        ColorsReplaced += Swap(lb.Background, b => lb.Background = b);
                        ColorsReplaced += Swap(lb.Foreground, b => lb.Foreground = b);
                        break;

                    case ListBoxItem lbi:
                        ColorsReplaced += Swap(lbi.Background, b => lbi.Background = b);
                        ColorsReplaced += Swap(lbi.Foreground, b => lbi.Foreground = b);
                        break;

                    case TabControl tab:
                        if (_bgInput != null) { tab.Background = _bgInput; ColorsReplaced++; }
                        break;

                    case ProgressBar pb:
                        ColorsReplaced += Swap(pb.Background, b => pb.Background = b);
                        break;

                    case Panel panel:   // StackPanel, Grid, WrapPanel, DockPanel…
                        ColorsReplaced += Swap(panel.Background, b => panel.Background = b);
                        break;

                    case Shape shape:   // Rectangle, Ellipse, Path…
                        ColorsReplaced += Swap(shape.Fill,   b => shape.Fill   = b);
                        ColorsReplaced += Swap(shape.Stroke, b => shape.Stroke = b);
                        break;

                    case GroupBox gb:
                        ColorsReplaced += Swap(gb.Foreground, b => gb.Foreground = b);
                        ColorsReplaced += Swap(gb.Background, b => gb.Background = b);
                        break;

                    case Expander exp:
                        ColorsReplaced += Swap(exp.Foreground, b => exp.Foreground = b);
                        ColorsReplaced += Swap(exp.Background, b => exp.Background = b);
                        break;
                }
            }
            catch { }
        }

        /// <summary>
        /// Si el brush actual es SolidColorBrush y su ARGB está en el mapa,
        /// invoca el setter con el brush del nuevo tema y devuelve 1.
        /// </summary>
        private int Swap(Brush current, Action<SolidColorBrush> setter)
        {
            if (current is SolidColorBrush scb &&
                _brushMap.TryGetValue(scb.Color.ToString(), out var newBrush))
            {
                setter(newBrush);
                return 1;
            }
            return 0;
        }
    }
}
