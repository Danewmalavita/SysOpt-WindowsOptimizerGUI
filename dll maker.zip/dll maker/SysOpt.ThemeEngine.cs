// =============================================================================
//  SysOpt.ThemeEngine.dll  —  v1.1
//  C# 5 compatible — compila con csc.exe del .NET Framework 4.0.30319
//  sin /langversion (usa el default del compilador incluido en Windows).
//
//  Sin: switch pattern matching, out var, =>, $"", is Type varname en if
//  Con: if/else encadenado, out variable separada, string.Format, cast explícito
// =============================================================================

using System;
using System.Collections;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Shapes;

namespace SysOpt
{
    public sealed class ThemeApplyResult
    {
        public bool   Success          { get; internal set; }
        public int    ResourcesUpdated { get; internal set; }
        public int    ControlsWalked  { get; internal set; }
        public int    ColorsReplaced  { get; internal set; }
        public string ErrorMessage    { get; internal set; }
        public double ElapsedMs       { get; internal set; }

        public ThemeApplyResult() { ErrorMessage = string.Empty; }

        public override string ToString()
        {
            if (Success)
                return string.Format(
                    "[ThemeEngine v1.1] OK — {0} RD brushes, {1} reemplazos en {2} nodos ({3:F1} ms)",
                    ResourcesUpdated, ColorsReplaced, ControlsWalked, ElapsedMs);
            return "[ThemeEngine v1.1] ERROR — " + ErrorMessage;
        }
    }

    public static class ThemeEngine
    {
        public static string Version { get { return "1.1"; } }

        // Colores hardcoded del tema dark-default → clave semántica del tema
        private static readonly Dictionary<string, string> s_darkDefaults =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "#FF0D0F1A", "BgDeep"        },
            { "#FF131625", "BgCard"        },
            { "#FF1A1E2F", "BgInput"       },
            { "#FF1A2035", "BgInput"       },
            { "#FF1A2540", "BgInput"       },
            { "#FF252B40", "BorderSubtle"  },
            { "#FF3A4468", "BorderHover"   },
            { "#FF5BA3FF", "AccentBlue"    },
            { "#FF3D8EFF", "AccentBlue"    },
            { "#FFE8ECF4", "TextPrimary"   },
            { "#FFD4D9E8", "TextPrimary"   },
            { "#FFF0F3FA", "TextPrimary"   },
            { "#FFE0E8F4", "TextPrimary"   },
            { "#FFB0BACC", "TextSecondary" },
            { "#FFD0D8F0", "TextSecondary" },
            { "#FF7BA8E0", "TextSecondary" },
            { "#FF7880A0", "TextMuted"     },
            { "#FF9BA4C0", "TextMuted"     },
            { "#FF8B96B8", "TextMuted"     },
            { "#FF6B7A9E", "TextMuted"     },
            { "#FF6B7599", "TextMuted"     },
            { "#FF4A5068", "TextMuted"     },
            { "#FF2EDFBF", "AccentCyan"    },
            { "#FF6ABDA0", "AccentCyan"    },
            { "#FFFFB547", "AccentAmber"   },
            { "#FFC0933A", "AccentAmber"   },
            { "#FFFF6B84", "AccentRed"     },
            { "#FF4AE896", "AccentGreen"   },
            { "#FF5AE88A", "AccentGreen"   },
            { "#FF9B7EFF", "AccentPurple"  },
            { "#FFC07AFF", "AccentPurple"  },
            { "#FF3A2010", "BgCard"        },
            { "#FF1A4A35", "BgCard"        },
        };

        // Claves del ResourceDictionary WPF → clave semántica del tema
        private static readonly Dictionary<string, string> s_resourceMap =
            new Dictionary<string, string>(StringComparer.Ordinal)
        {
            { "BgDeep",         "BgDeep"         },
            { "BgCard",         "BgCard"         },
            { "BgCardHover",    "BgInput"        },
            { "BgInput",        "BgInput"        },
            { "BorderSubtle",   "BorderSubtle"   },
            { "BorderActive",   "AccentBlue"     },
            { "BorderHover",    "BorderHover"    },
            { "AccentBlue",     "AccentBlue"     },
            { "AccentCyan",     "AccentCyan"     },
            { "AccentAmber",    "AccentAmber"    },
            { "AccentRed",      "AccentRed"      },
            { "AccentGreen",    "AccentGreen"    },
            { "TextPrimary",    "TextPrimary"    },
            { "TextSecondary",  "TextSecondary"  },
            { "TextMuted",      "TextMuted"      },
            { "BtnPrimaryBg",   "BtnPrimaryBg"   },
            { "BtnPrimaryFg",   "BtnPrimaryFg"   },
            { "BtnSecondaryBg", "BtnSecondaryBg" },
            { "BtnCyanBg",      "BtnCyanBg"      },
            { "BtnCyanFg",      "BtnCyanFg"      },
            { "BtnAmberBg",     "BtnAmberBg"     },
            { "BtnAmberFg",     "BtnAmberFg"     },
            { "BtnDangerBg",    "BtnDangerBg"    },
            { "BtnDangerFg",    "BtnDangerFg"    },
            { "BtnGhostBg",     "BtnGhostBg"     },
            { "BtnGhostBorder", "BtnGhostBorder" },
            { "ComboHover",     "ComboHover"     },
            { "CtxHover",       "CtxHover"       },
            { "CtxSepFill",     "CtxSepFill"     },
            { "HdrBtnHover",    "HdrBtnHover"    },
            { "LbItemHover",    "LbItemHover"    },
            { "TabSelectedBg",  "TabSelectedBg"  },
            { "TabHoverBg",     "TabHoverBg"     },
            { "BgCardDark",     "BgCardDark"     },
        };

        // ── API principal ─────────────────────────────────────────────────────

        public static ThemeApplyResult ApplyTheme(Window window, IDictionary theme, IDictionary defaults)
        {
            var result = new ThemeApplyResult();
            if (window == null)
            {
                result.ErrorMessage = "window es null";
                return result;
            }
            if (theme == null || theme.Count == 0)
            {
                result.ErrorMessage = "theme esta vacio";
                return result;
            }

            var sw = System.Diagnostics.Stopwatch.StartNew();
            try
            {
                var colorLookup = BuildColorLookup(theme, defaults);

                result.ResourcesUpdated = UpdateResourceDictionary(window.Resources, colorLookup);
                UpdateProgressGradient(window.Resources, colorLookup);

                string bgHex;
                if (colorLookup.TryGetValue("BgDeep", out bgHex))
                {
                    var b = HexToBrush(bgHex);
                    if (b != null) window.Background = b;
                }

                var brushMap = BuildBrushMap(colorLookup);
                var walker   = new VisualWalker(brushMap, colorLookup);
                walker.Walk(window);

                result.ControlsWalked = walker.ControlsVisited;
                result.ColorsReplaced = walker.ColorsReplaced;
                result.Success        = true;
            }
            catch (Exception ex)
            {
                result.ErrorMessage = ex.Message;
            }

            sw.Stop();
            result.ElapsedMs = sw.Elapsed.TotalMilliseconds;
            return result;
        }

        // Sobrecarga sin defaults (C#5: no optional params con tipos ref en overloads — sobrecarga explícita)
        public static ThemeApplyResult ApplyTheme(Window window, IDictionary theme)
        {
            return ApplyTheme(window, theme, null);
        }

        // Sobrecargas para Hashtable nativo de PowerShell
        public static ThemeApplyResult ApplyTheme(Window window, Hashtable theme, Hashtable defaults)
        {
            return ApplyTheme(window, (IDictionary)theme, (IDictionary)defaults);
        }

        public static ThemeApplyResult ApplyTheme(Window window, Hashtable theme)
        {
            return ApplyTheme(window, (IDictionary)theme, null);
        }

        // ── Utilidades públicas ───────────────────────────────────────────────

        // Hex -> SolidColorBrush MUTABLE (sin Freeze — frozen brushes no se
        // pueden asignar a propiedades de controles en vivo)
        public static SolidColorBrush HexToBrush(string hex)
        {
            if (string.IsNullOrEmpty(hex) || hex.Trim().Length == 0) return null;
            try
            {
                var color = (Color)ColorConverter.ConvertFromString(hex);
                return new SolidColorBrush(color);
            }
            catch { return null; }
        }

        public static Nullable<Color> HexToColor(string hex)
        {
            if (string.IsNullOrEmpty(hex) || hex.Trim().Length == 0)
                return null;
            try
            {
                return (Color)ColorConverter.ConvertFromString(hex);
            }
            catch { return null; }
        }

        // ── Helpers internos ──────────────────────────────────────────────────

        private static Dictionary<string, string> BuildColorLookup(IDictionary theme, IDictionary defaults)
        {
            var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            if (defaults != null)
            {
                foreach (DictionaryEntry kv in defaults)
                {
                    string k = kv.Key as string;
                    string v = kv.Value as string;
                    if (k != null && v != null && v.Trim().Length > 0)
                        result[k] = v;
                }
            }

            foreach (DictionaryEntry kv in theme)
            {
                string k = kv.Key as string;
                string v = kv.Value as string;
                if (k != null && v != null && v.Trim().Length > 0)
                    result[k] = v;
            }

            return result;
        }

        private static int UpdateResourceDictionary(ResourceDictionary res, Dictionary<string, string> lookup)
        {
            int count = 0;
            foreach (var entry in s_resourceMap)
            {
                string hex;
                if (!lookup.TryGetValue(entry.Value, out hex)) continue;

                var colorNullable = HexToColor(hex);
                if (colorNullable == null) continue;
                Color color = colorNullable.Value;

                try
                {
                    var brush = res[entry.Key] as SolidColorBrush;
                    if (brush == null) continue;
                    if (brush.IsFrozen)
                        res[entry.Key] = new SolidColorBrush(color);
                    else
                        brush.Color = color;
                    count++;
                }
                catch { }
            }
            return count;
        }

        private static void UpdateProgressGradient(ResourceDictionary res, Dictionary<string, string> lookup)
        {
            try
            {
                var pg = res["ProgressGradient"] as LinearGradientBrush;
                if (pg == null || pg.GradientStops.Count < 2) return;

                string hex;
                if (lookup.TryGetValue("ProgressStart", out hex))
                {
                    var c = HexToColor(hex);
                    if (c != null) pg.GradientStops[0].Color = c.Value;
                }
                if (lookup.TryGetValue("ProgressEnd", out hex))
                {
                    var c = HexToColor(hex);
                    if (c != null) pg.GradientStops[1].Color = c.Value;
                }
            }
            catch { }
        }

        private static Dictionary<string, SolidColorBrush> BuildBrushMap(Dictionary<string, string> lookup)
        {
            var map = new Dictionary<string, SolidColorBrush>(StringComparer.OrdinalIgnoreCase);
            foreach (var entry in s_darkDefaults)
            {
                if (map.ContainsKey(entry.Key)) continue;
                string hex;
                if (!lookup.TryGetValue(entry.Value, out hex)) continue;
                var b = HexToBrush(hex);
                if (b != null) map[entry.Key] = b;
            }
            return map;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  RECORRIDO DEL ÁRBOL VISUAL + LÓGICO
    //  ProcessElement usa if/else en vez de switch con pattern matching (C#5)
    // ─────────────────────────────────────────────────────────────────────────

    internal sealed class VisualWalker
    {
        private readonly Dictionary<string, SolidColorBrush> _brushMap;
        private readonly Dictionary<string, string>           _lookup;
        private readonly HashSet<int>                         _visited;

        private readonly SolidColorBrush _bgInput;
        private readonly SolidColorBrush _txtPri;
        private readonly SolidColorBrush _bdrHov;
        private readonly SolidColorBrush _consoleBg;
        private readonly SolidColorBrush _consoleFg;

        public int ControlsVisited { get; private set; }
        public int ColorsReplaced  { get; private set; }

        public VisualWalker(Dictionary<string, SolidColorBrush> brushMap, Dictionary<string, string> lookup)
        {
            _brushMap  = brushMap;
            _lookup    = lookup;
            _visited   = new HashSet<int>();

            _bgInput   = GetBrush("BgInput");
            _txtPri    = GetBrush("TextPrimary");
            _bdrHov    = GetBrush("BorderHover");
            _consoleBg = GetBrush("ConsoleBg");
            _consoleFg = GetBrush("ConsoleFg");
        }

        private SolidColorBrush GetBrush(string key)
        {
            string hex;
            if (_lookup.TryGetValue(key, out hex))
                return ThemeEngine.HexToBrush(hex);
            return null;
        }

        public void Walk(DependencyObject root)
        {
            if (root == null) return;
            var stack = new Stack<DependencyObject>();
            stack.Push(root);

            while (stack.Count > 0)
            {
                var el = stack.Pop();
                if (el == null) continue;

                int id = System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(el);
                if (!_visited.Add(id)) continue;

                ControlsVisited++;
                ProcessElement(el);

                // Árbol visual
                try
                {
                    int n = VisualTreeHelper.GetChildrenCount(el);
                    for (int i = 0; i < n; i++)
                    {
                        var ch = VisualTreeHelper.GetChild(el, i) as DependencyObject;
                        if (ch != null) stack.Push(ch);
                    }
                }
                catch { }

                // Árbol lógico (DataTemplates, TabItems, ItemsControl...)
                try
                {
                    foreach (object lc in LogicalTreeHelper.GetChildren(el))
                    {
                        var dep = lc as DependencyObject;
                        if (dep != null) stack.Push(dep);
                    }
                }
                catch { }
            }
        }

        private void ProcessElement(DependencyObject el)
        {
            try
            {
                // TextBlock
                var tb = el as TextBlock;
                if (tb != null)
                {
                    ColorsReplaced += Swap(tb.Foreground, delegate(SolidColorBrush b) { tb.Foreground = b; });
                    foreach (Inline inline in tb.Inlines)
                    {
                        var run = inline as Run;
                        if (run != null)
                            ColorsReplaced += Swap(run.Foreground, delegate(SolidColorBrush b) { run.Foreground = b; });
                    }
                    return;
                }

                // TextBox
                var tb2 = el as TextBox;
                if (tb2 != null)
                {
                    ColorsReplaced += Swap(tb2.Background, delegate(SolidColorBrush b) { tb2.Background = b; });
                    if (_txtPri != null) { tb2.Foreground = _txtPri; ColorsReplaced++; }
                    if (tb2.Name == "ConsoleOutput")
                    {
                        if (_consoleBg != null) { tb2.Background = _consoleBg; ColorsReplaced++; }
                        if (_consoleFg != null) { tb2.Foreground = _consoleFg; ColorsReplaced++; }
                    }
                    return;
                }

                // ComboBox — antes de Control genérico
                var combo = el as ComboBox;
                if (combo != null)
                {
                    if (_bgInput != null) { combo.Background  = _bgInput; ColorsReplaced++; }
                    if (_txtPri  != null) { combo.Foreground  = _txtPri;  ColorsReplaced++; }
                    if (_bdrHov  != null) { combo.BorderBrush = _bdrHov;  ColorsReplaced++; }
                    return;
                }

                // TabControl — antes de Control genérico
                var tab = el as TabControl;
                if (tab != null)
                {
                    if (_bgInput != null) { tab.Background = _bgInput; ColorsReplaced++; }
                    return;
                }

                // ListBoxItem — antes de ListBox
                var lbi = el as ListBoxItem;
                if (lbi != null)
                {
                    ColorsReplaced += Swap(lbi.Background, delegate(SolidColorBrush b) { lbi.Background = b; });
                    ColorsReplaced += Swap(lbi.Foreground, delegate(SolidColorBrush b) { lbi.Foreground = b; });
                    return;
                }

                // ListBox
                var lb = el as ListBox;
                if (lb != null)
                {
                    ColorsReplaced += Swap(lb.Background, delegate(SolidColorBrush b) { lb.Background = b; });
                    ColorsReplaced += Swap(lb.Foreground, delegate(SolidColorBrush b) { lb.Foreground = b; });
                    return;
                }

                // Button — antes de ToggleButton
                var btn = el as Button;
                if (btn != null)
                {
                    ColorsReplaced += Swap(btn.Background, delegate(SolidColorBrush b) { btn.Background = b; });
                    ColorsReplaced += Swap(btn.Foreground, delegate(SolidColorBrush b) { btn.Foreground = b; });
                    return;
                }

                // ToggleButton (CheckBox, RadioButton)
                var toggle = el as ToggleButton;
                if (toggle != null)
                {
                    ColorsReplaced += Swap(toggle.Foreground, delegate(SolidColorBrush b) { toggle.Foreground = b; });
                    ColorsReplaced += Swap(toggle.Background, delegate(SolidColorBrush b) { toggle.Background = b; });
                    return;
                }

                // Label
                var lbl = el as Label;
                if (lbl != null)
                {
                    ColorsReplaced += Swap(lbl.Foreground, delegate(SolidColorBrush b) { lbl.Foreground = b; });
                    ColorsReplaced += Swap(lbl.Background, delegate(SolidColorBrush b) { lbl.Background = b; });
                    return;
                }

                // ProgressBar
                var pb = el as ProgressBar;
                if (pb != null)
                {
                    ColorsReplaced += Swap(pb.Background, delegate(SolidColorBrush b) { pb.Background = b; });
                    return;
                }

                // GroupBox
                var gb = el as GroupBox;
                if (gb != null)
                {
                    ColorsReplaced += Swap(gb.Foreground, delegate(SolidColorBrush b) { gb.Foreground = b; });
                    ColorsReplaced += Swap(gb.Background, delegate(SolidColorBrush b) { gb.Background = b; });
                    return;
                }

                // Expander
                var exp = el as Expander;
                if (exp != null)
                {
                    ColorsReplaced += Swap(exp.Foreground, delegate(SolidColorBrush b) { exp.Foreground = b; });
                    ColorsReplaced += Swap(exp.Background, delegate(SolidColorBrush b) { exp.Background = b; });
                    return;
                }

                // Border
                var border = el as Border;
                if (border != null)
                {
                    ColorsReplaced += Swap(border.Background,  delegate(SolidColorBrush b) { border.Background  = b; });
                    ColorsReplaced += Swap(border.BorderBrush, delegate(SolidColorBrush b) { border.BorderBrush = b; });
                    return;
                }

                // Panel (StackPanel, Grid, WrapPanel, DockPanel...)
                var panel = el as Panel;
                if (panel != null)
                {
                    ColorsReplaced += Swap(panel.Background, delegate(SolidColorBrush b) { panel.Background = b; });
                    return;
                }

                // Shape (Rectangle, Ellipse, Path...)
                var shape = el as Shape;
                if (shape != null)
                {
                    ColorsReplaced += Swap(shape.Fill,   delegate(SolidColorBrush b) { shape.Fill   = b; });
                    ColorsReplaced += Swap(shape.Stroke, delegate(SolidColorBrush b) { shape.Stroke = b; });
                    return;
                }
            }
            catch { }
        }

        // Si el brush actual está en el mapa de reemplazos, invoca el setter y devuelve 1
        private int Swap(Brush current, Action<SolidColorBrush> setter)
        {
            var scb = current as SolidColorBrush;
            if (scb == null) return 0;
            SolidColorBrush newBrush;
            if (_brushMap.TryGetValue(scb.Color.ToString(), out newBrush))
            {
                setter(newBrush);
                return 1;
            }
            return 0;
        }
    }
}
