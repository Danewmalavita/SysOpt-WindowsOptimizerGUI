# =============================================================================
# SysOpt_DLL_Integration.ps1
# Fragmento de integracion - reemplaza los 3 bloques Add-Type inline del .ps1
# por cargas de DLL externas con Add-Type -Path
#
# Estructura de carpetas esperada:
#   SysOpt.ps1
#   libs\
#     SysOpt.MemoryHelper.dll
#     SysOpt.DiskEngine.dll
#     SysOpt.WseTrim.dll
# =============================================================================

$script:LibsPath = Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) "libs"

function Assert-LibExists($dllName) {
    $path = Join-Path $script:LibsPath $dllName
    if (-not (Test-Path $path)) {
        [System.Windows.MessageBox]::Show(
            "No se encontro la libreria requerida:`n$path`n`nAsegurate de que la carpeta 'libs' esta junto al script.",
            "SysOpt - Libreria faltante",
            [System.Windows.MessageBoxButton]::OK,
            [System.Windows.MessageBoxImage]::Error
        ) | Out-Null
        exit 1
    }
    return $path
}

# =============================================================================
# REEMPLAZA BLOQUE 1 (linea ~238 original):
#   Add-Type @" ... MemoryHelper ... "@
# =============================================================================
if (-not ([System.Management.Automation.PSTypeName]'MemoryHelper').Type) {
    $dllPath = Assert-LibExists "SysOpt.MemoryHelper.dll"
    Add-Type -Path $dllPath -ErrorAction Stop
}

# =============================================================================
# REEMPLAZA BLOQUE 2 (linea ~261 original):
#   Add-Type @" ... DiskItem_v211 / DiskItemToggle_v230 / ScanCtl211 / PScanner211 ... "@
# =============================================================================
if (-not ([System.Management.Automation.PSTypeName]'DiskItem_v211').Type) {
    $dllPath = Assert-LibExists "SysOpt.DiskEngine.dll"
    Add-Type -Path $dllPath -ErrorAction Stop
}

# =============================================================================
# REEMPLAZA BLOQUE 3 (linea ~6637 original, dentro del timer de fscan):
#   Add-Type -TypeDefinition @' ... WseTrim2 ... '@
#
# Bloque original en el script:
#     try {
#         $proc = [System.Diagnostics.Process]::GetCurrentProcess()
#         Add-Type -TypeDefinition @'
#             using System;using System.Runtime.InteropServices;
#             public class WseTrim2{...}
#         '@ -ErrorAction SilentlyContinue
#         [WseTrim2]::SetProcessWorkingSetSize($proc.Handle, [IntPtr](-1), [IntPtr](-1)) | Out-Null
#     } catch {}
#
# Reemplazar por:
# =============================================================================
if (-not ([System.Management.Automation.PSTypeName]'WseTrim').Type) {
    $dllPath = Assert-LibExists "SysOpt.WseTrim.dll"
    Add-Type -Path $dllPath -ErrorAction SilentlyContinue
}

# Llamada equivalente en el timer fsScan (~linea 6641):
#   ANTES:  [WseTrim2]::SetProcessWorkingSetSize($proc.Handle, [IntPtr](-1), [IntPtr](-1)) | Out-Null
#   AHORA:  [WseTrim]::TrimCurrentProcess()