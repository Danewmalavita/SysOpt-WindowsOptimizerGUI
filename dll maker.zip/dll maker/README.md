# SysOpt DLLs — Librerías externas C#

Proyectos C# extraídos de los bloques `Add-Type` inline de `SysOpt v2.5.0`.
Compilar a DLL externo elimina la recompilación por sesión y prepara la base para v3.0.

---

## Inventario de Add-Type en SysOpt v2.5.0

| # | DLL | Clases | Línea original | Descripción |
|---|-----|--------|---------------|-------------|
| 1 | `SysOpt.MemoryHelper.dll` | `MemoryHelper` | ~238 | Win32 API: EmptyWorkingSet, OpenProcess, SetSystemFileCacheSize |
| 2 | `SysOpt.DiskEngine.dll` | `DiskItem_v211`, `DiskItemToggle_v230`, `ScanCtl211`, `PScanner211` | ~261 | Motor completo del Explorador de Disco |
| 3 | `SysOpt.WseTrim.dll` | `WseTrim` (original: `WseTrim2`) | ~6637 | SetProcessWorkingSetSize inline dentro del timer fsScan |

> **Add-Type -AssemblyName** (líneas 178–182) no generan DLL propio — son referencias
> a assemblies del sistema (`PresentationFramework`, `System.Windows.Forms`, etc.) y se mantienen como están.

---

## Estructura del proyecto

```
SysOpt_DLLs/
├── build_all.bat                    ← Compila los 3 proyectos → libs/
├── SysOpt_DLL_Integration.ps1       ← Fragmento listo para pegar en SysOpt.ps1
│
├── SysOpt.MemoryHelper/
│   ├── SysOpt.MemoryHelper.csproj
│   └── src/MemoryHelper.cs
│
├── SysOpt.DiskEngine/
│   ├── SysOpt.DiskEngine.csproj
│   └── src/DiskEngine.cs
│
└── SysOpt.WseTrim/
    ├── SysOpt.WseTrim.csproj
    └── src/WseTrim.cs
```

---

## Build

**Requisito:** .NET SDK (cualquier versión >= 6 funciona para compilar a `net462`)

```batch
cd SysOpt_DLLs
build_all.bat
```

Los DLLs se generan en `libs\`:
```
libs\
  SysOpt.MemoryHelper.dll
  SysOpt.DiskEngine.dll
  SysOpt.WseTrim.dll
```

---

## Integración en SysOpt.ps1

### Estructura de carpetas

```
SysOpt.ps1
libs\
  SysOpt.MemoryHelper.dll
  SysOpt.DiskEngine.dll
  SysOpt.WseTrim.dll
```

### Cambios en el script

**Eliminar los 3 bloques `Add-Type` con código C# inline** y sustituirlos por:

```powershell
# Bloque 1 — reemplaza el Add-Type de MemoryHelper (~línea 238)
if (-not ([System.Management.Automation.PSTypeName]'MemoryHelper').Type) {
    Add-Type -Path "$PSScriptRoot\libs\SysOpt.MemoryHelper.dll" -ErrorAction Stop
}

# Bloque 2 — reemplaza el Add-Type de DiskItem/ScanCtl/PScanner (~línea 261)
if (-not ([System.Management.Automation.PSTypeName]'DiskItem_v211').Type) {
    Add-Type -Path "$PSScriptRoot\libs\SysOpt.DiskEngine.dll" -ErrorAction Stop
}

# Bloque 3 — reemplaza WseTrim2 inline dentro del timer fsScan (~línea 6637)
if (-not ([System.Management.Automation.PSTypeName]'WseTrim').Type) {
    Add-Type -Path "$PSScriptRoot\libs\SysOpt.WseTrim.dll" -ErrorAction SilentlyContinue
}
```

**Cambio de llamada para WseTrim** (línea ~6641):
```powershell
# ANTES:
[WseTrim2]::SetProcessWorkingSetSize($proc.Handle, [IntPtr](-1), [IntPtr](-1)) | Out-Null

# DESPUÉS (la DLL expone un método de conveniencia):
[WseTrim]::TrimCurrentProcess()
```

---

## Target Framework

Todos los proyectos compilan contra **`net462`** (`.NET Framework 4.6.2`).

Razón: PowerShell 5.1 — el runtime que ejecuta SysOpt — corre sobre .NET Framework 4.x.
Un DLL compilado para `net6` o `net8` **no** puede cargarse con `Add-Type -Path` en PS 5.1.

---

## Por qué esto mejora el script

| Aspecto | Add-Type inline (antes) | Add-Type -Path / DLL (después) |
|---------|------------------------|-------------------------------|
| Recompilación | En cada sesión de PS | Solo en el primer `Add-Type -Path` del proceso |
| Reutilización | Imposible entre scripts | Cualquier script del mismo proceso puede cargar el DLL |
| Mantenimiento | Código C# mezclado con PS | C# en proyectos propios, versionables y testeables |
| Error TYPE_ALREADY_EXISTS | Requiere guards `if (-not ...)` | El guard sigue siendo necesario, pero el compile ya no ocurre |
| Tiempo de arranque | ~200–500 ms de compile | < 5 ms de carga de DLL ya compilado |
