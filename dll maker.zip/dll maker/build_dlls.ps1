#Requires -Version 3
<#
.SYNOPSIS
    SysOpt DLLs - Build script autonomo
.DESCRIPTION
    Compila los 3 DLLs de SysOpt usando csc.exe del .NET Framework (ya incluido
    en Windows 10/11). NO requiere .NET SDK ni Visual Studio.
    Los fuentes C# estan embebidos en este script.
    Salida: .\libs\  (copiar la carpeta junto a SysOpt.ps1)
.NOTES
    Ejecutar como: powershell -ExecutionPolicy Bypass -File build_dlls.ps1
    O desde PowerShell: .\build_dlls.ps1
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# -----------------------------------------------------------------------------
# Buscar csc.exe del .NET Framework
# -----------------------------------------------------------------------------
$cscCandidates = @(
    'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
    'C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe'
)
# Fallback: buscar cualquier v4.x disponible
foreach ($base in @('C:\Windows\Microsoft.NET\Framework64', 'C:\Windows\Microsoft.NET\Framework')) {
    if (Test-Path $base) {
        Get-ChildItem $base -Directory -Filter 'v4*' | Sort-Object Name -Descending | ForEach-Object {
            $cscCandidates += Join-Path $_.FullName 'csc.exe'
        }
    }
}

$csc = $cscCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1

if (-not $csc) {
    Write-Host '[ERROR] No se encontro csc.exe.' -ForegroundColor Red
    Write-Host '        Se esperaba en: C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
    Write-Host '        .NET Framework 4.x deberia estar instalado en cualquier Windows 10/11.'
    Read-Host 'Pulsa Enter para salir'
    exit 1
}

Write-Host "[INFO]  Compilador : $csc" -ForegroundColor Cyan

# Refs del Framework (misma carpeta que csc.exe)
$fwDir = Split-Path $csc
$refs  = "/reference:`"$fwDir\System.dll`" /reference:`"$fwDir\System.Core.dll`""

# Carpetas de salida y temporales
$outDir = Join-Path $PSScriptRoot 'libs'
$tmpDir = Join-Path $PSScriptRoot '_build_tmp'
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
New-Item -ItemType Directory -Force -Path $tmpDir | Out-Null

# -----------------------------------------------------------------------------
# Funcion de compilacion
# -----------------------------------------------------------------------------
function Invoke-CscBuild {
    param(
        [string]$Name,
        [string]$SourcePath
    )
    $dll     = Join-Path $outDir "$Name.dll"
    $cscArgs = "/target:library /out:`"$dll`" /optimize+ /nologo /utf8output $refs `"$SourcePath`""
    Write-Host "       csc $cscArgs" -ForegroundColor DarkGray

    $proc = Start-Process -FilePath $csc -ArgumentList $cscArgs `
                          -NoNewWindow -Wait -PassThru `
                          -RedirectStandardOutput (Join-Path $tmpDir "$Name.stdout") `
                          -RedirectStandardError  (Join-Path $tmpDir "$Name.stderr")
    if ($proc.ExitCode -ne 0) {
        Write-Host "[ERROR] Fallo al compilar $Name.dll  (ExitCode $($proc.ExitCode))" -ForegroundColor Red
        foreach ($log in @("$Name.stdout","$Name.stderr")) {
            $logPath = Join-Path $tmpDir $log
            if (Test-Path $logPath) {
                Get-Content $logPath | Where-Object { $_ -ne '' } |
                    ForEach-Object { Write-Host "  $_" -ForegroundColor Red }
            }
        }
        Remove-Item $tmpDir -Recurse -Force -ErrorAction SilentlyContinue
        Read-Host 'Pulsa Enter para salir'
        exit 1
    }
    Write-Host "        OK  ->  libs\$Name.dll" -ForegroundColor Green
}

# -----------------------------------------------------------------------------
# [1/3] SysOpt.MemoryHelper
#   Clases : MemoryHelper
#   Origen : Add-Type inline ~linea 238 de SysOpt v2.5.0
# -----------------------------------------------------------------------------
Write-Host ''
Write-Host '[1/3] Compilando SysOpt.MemoryHelper.dll ...' -ForegroundColor White

$src_MemoryHelper = @'
using System;
using System.Runtime.InteropServices;

public class MemoryHelper
{
    [DllImport("kernel32.dll")]
    public static extern bool SetSystemFileCacheSize(IntPtr min, IntPtr max, uint flags);

    [DllImport("psapi.dll")]
    public static extern bool EmptyWorkingSet(IntPtr hProcess);

    [DllImport("kernel32.dll")]
    public static extern IntPtr OpenProcess(uint access, bool inherit, int pid);

    [DllImport("kernel32.dll")]
    public static extern bool CloseHandle(IntPtr handle);
}
'@

$cs1 = Join-Path $tmpDir 'MemoryHelper.cs'
[System.IO.File]::WriteAllText($cs1, $src_MemoryHelper, [System.Text.Encoding]::UTF8)
Invoke-CscBuild -Name 'SysOpt.MemoryHelper' -SourcePath $cs1

# -----------------------------------------------------------------------------
# [2/3] SysOpt.DiskEngine
#   Clases : DiskItem_v211, DiskItemToggle_v230, ScanCtl211, PScanner211
#   Origen : Add-Type inline ~linea 261 de SysOpt v2.5.0
# -----------------------------------------------------------------------------
Write-Host ''
Write-Host '[2/3] Compilando SysOpt.DiskEngine.dll ...' -ForegroundColor White

$src_DiskEngine = @'
using System;
using System.ComponentModel;
using System.IO;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

public class DiskItem_v211
{
    public string DisplayName       { get; set; }
    public string FullPath          { get; set; }
    public string ParentPath        { get; set; }
    public long   SizeBytes         { get; set; }
    public string SizeStr           { get; set; }
    public string SizeColor         { get; set; }
    public string PctStr            { get; set; }
    public string FileCount         { get; set; }
    public int    DirCount          { get; set; }
    public bool   IsDir             { get; set; }
    public bool   HasChildren       { get; set; }
    public string Icon              { get; set; }
    public string Indent            { get; set; }
    public double BarWidth          { get; set; }
    public string BarColor          { get; set; }
    public double TotalPct          { get; set; }
    public int    Depth             { get; set; }
    public string ToggleVisibility  { get; set; }
    public string ToggleIcon        { get; set; }

    public DiskItem_v211()
    {
        ToggleVisibility = "Collapsed";
        ToggleIcon       = "\u25B6";
    }
}

public class DiskItemToggle_v230 : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler PropertyChanged;

    private void N(string p)
    {
        if (PropertyChanged != null)
            PropertyChanged(this, new PropertyChangedEventArgs(p));
    }

    public DiskItem_v211 Item { get; private set; }

    public DiskItemToggle_v230(DiskItem_v211 item) { Item = item; }

    public string ToggleVisibility
    {
        get { return Item.ToggleVisibility; }
        set { if (Item.ToggleVisibility != value) { Item.ToggleVisibility = value; N("ToggleVisibility"); } }
    }

    public string ToggleIcon
    {
        get { return Item.ToggleIcon; }
        set { if (Item.ToggleIcon != value) { Item.ToggleIcon = value; N("ToggleIcon"); } }
    }
}

public static class ScanCtl211
{
    private static volatile bool   _stop     = false;
    public  static int             _doneRef  = 0;
    public  static int             _totalRef = 0;
    private static volatile string _current  = "";

    public static bool   Stop    { get { return _stop;     } set { _stop     = value; } }
    public static int    Done    { get { return _doneRef;  } set { _doneRef   = value; } }
    public static int    Total   { get { return _totalRef; } set { _totalRef  = value; } }
    public static string Current { get { return _current;  } set { _current   = value; } }

    public static void Reset()
    {
        _stop = false; _doneRef = 0; _totalRef = 0; _current = "";
    }
}

public static class PScanner211
{
    private const int MAX_DEPTH = 64;

    public static long ScanDir(string path, int depth, string parentKey, ConcurrentQueue<object[]> q)
    {
        if (ScanCtl211.Stop)   return 0L;
        if (depth > MAX_DEPTH) return 0L;

        string dName = Path.GetFileName(path);
        if (string.IsNullOrEmpty(dName)) dName = path;

        q.Enqueue(new object[] { path, parentKey, dName, -1L, 0, 0, false, depth });

        long totalSize = 0L;
        int  fileCount = 0;

        try
        {
            string[] files = Directory.GetFiles(path);
            fileCount = files.Length;
            foreach (string f in files)
            {
                if (ScanCtl211.Stop) break;
                try { totalSize += new FileInfo(f).Length; } catch { }
            }
        }
        catch { }

        string[] subDirs;
        try   { subDirs = Directory.GetDirectories(path); }
        catch { subDirs = new string[0]; }

        Interlocked.Add(ref ScanCtl211._totalRef, subDirs.Length);
        long[] subSizes = new long[subDirs.Length];

        if (depth <= 1 && subDirs.Length > 1 && depth + 1 < MAX_DEPTH)
        {
            Parallel.For(0, subDirs.Length, new ParallelOptions { MaxDegreeOfParallelism = 4 }, i =>
            {
                if (ScanCtl211.Stop) return;
                ScanCtl211.Current = Path.GetFileName(subDirs[i]);
                subSizes[i]        = ScanDir(subDirs[i], depth + 1, path, q);
                Interlocked.Increment(ref ScanCtl211._doneRef);
            });
        }
        else
        {
            for (int i = 0; i < subDirs.Length; i++)
            {
                if (ScanCtl211.Stop) break;
                ScanCtl211.Current = Path.GetFileName(subDirs[i]);
                subSizes[i]        = ScanDir(subDirs[i], depth + 1, path, q);
                Interlocked.Increment(ref ScanCtl211._doneRef);
            }
        }

        foreach (long s in subSizes) totalSize += s;
        q.Enqueue(new object[] { path, parentKey, dName, totalSize, fileCount, subDirs.Length, true, depth });
        return totalSize;
    }
}
'@

$cs2 = Join-Path $tmpDir 'DiskEngine.cs'
[System.IO.File]::WriteAllText($cs2, $src_DiskEngine, [System.Text.Encoding]::UTF8)
Invoke-CscBuild -Name 'SysOpt.DiskEngine' -SourcePath $cs2

# -----------------------------------------------------------------------------
# [3/3] SysOpt.WseTrim
#   Clases : WseTrim  (era WseTrim2 inline)
#   Origen : Add-Type inline ~linea 6637 de SysOpt v2.5.0
# -----------------------------------------------------------------------------
Write-Host ''
Write-Host '[3/3] Compilando SysOpt.WseTrim.dll ...' -ForegroundColor White

$src_WseTrim = @'
using System;
using System.Runtime.InteropServices;

public class WseTrim
{
    [DllImport("kernel32.dll")]
    private static extern bool SetProcessWorkingSetSize(IntPtr hProcess, IntPtr dwMin, IntPtr dwMax);

    public static void TrimCurrentProcess()
    {
        var proc = System.Diagnostics.Process.GetCurrentProcess();
        SetProcessWorkingSetSize(proc.Handle, new IntPtr(-1), new IntPtr(-1));
    }

    public static void TrimProcess(IntPtr hProcess)
    {
        SetProcessWorkingSetSize(hProcess, new IntPtr(-1), new IntPtr(-1));
    }
}
'@

$cs3 = Join-Path $tmpDir 'WseTrim.cs'
[System.IO.File]::WriteAllText($cs3, $src_WseTrim, [System.Text.Encoding]::UTF8)
Invoke-CscBuild -Name 'SysOpt.WseTrim' -SourcePath $cs3

# -----------------------------------------------------------------------------
# [4/4] SysOpt.ThemeEngine
#   Clases : ThemeEngine, ThemeApplyResult, VisualWalker
#   Fuente : SysOpt.ThemeEngine.cs (en la misma carpeta que este script)
#   Notas  : csc.exe NO resuelve nombres cortos WPF — necesita rutas absolutas.
# -----------------------------------------------------------------------------

# Buscar un assembly WPF por nombre — función definida aquí (scope global del script)
function Find-WpfAssembly {
    param([string]$AsmName)
    $cscDir = Split-Path $script:csc
    $candidates = @(
        # Reference Assemblies del Developer Pack (preferido)
        "C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\$AsmName.dll"
        "C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.7.2\$AsmName.dll"
        "C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.7\$AsmName.dll"
        "C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.6.2\$AsmName.dll"
        # GAC_MSIL (la mayoría de assemblies WPF)
        "C:\Windows\Microsoft.NET\assembly\GAC_MSIL\$AsmName\*\$AsmName.dll"
        # GAC_64 — PresentationCore y otros van aquí en sistemas x64
        "C:\Windows\Microsoft.NET\assembly\GAC_64\$AsmName\*\$AsmName.dll"
        # GAC_32 — fallback para sistemas x86
        "C:\Windows\Microsoft.NET\assembly\GAC_32\$AsmName\*\$AsmName.dll"
        # Directorio del csc.exe
        "$cscDir\$AsmName.dll"
    )
    foreach ($candidate in $candidates) {
        $found = Get-Item $candidate -ErrorAction SilentlyContinue | Select-Object -Last 1
        if ($found) { return $found.FullName }
    }
    return ''
}

Write-Host ''
Write-Host '[4/4] Compilando SysOpt.ThemeEngine.dll ...' -ForegroundColor White

$teSource = Join-Path $PSScriptRoot 'SysOpt.ThemeEngine.cs'

if (-not (Test-Path $teSource)) {
    Write-Host "[WARN]  SysOpt.ThemeEngine.cs no encontrado en $PSScriptRoot" -ForegroundColor Yellow
    Write-Host "        Coloca SysOpt.ThemeEngine.cs junto a build_dlls.ps1 y vuelve a ejecutar." -ForegroundColor Yellow
} else {
    # Resolver rutas WPF
    $wpfNames   = @('PresentationCore','PresentationFramework','WindowsBase','System.Xaml')
    $wpfRefs    = ''
    $wpfMissing = @()

    foreach ($asmName in $wpfNames) {
        $asmPath = Find-WpfAssembly -AsmName $asmName
        if ($asmPath -ne '') {
            $wpfRefs += " /reference:`"$asmPath`""
            Write-Host "        ref: $asmPath" -ForegroundColor DarkGray
        } else {
            $wpfMissing += $asmName
            Write-Host "[WARN]  No encontrado: $asmName.dll" -ForegroundColor Yellow
        }
    }

    if ($wpfMissing.Count -gt 0) {
        Write-Host "[WARN]  Faltan assemblies WPF: $($wpfMissing -join ', ')" -ForegroundColor Yellow
        Write-Host "        Instala .NET Framework 4.7.2 Developer Pack:" -ForegroundColor Yellow
        Write-Host "        https://dotnet.microsoft.com/download/dotnet-framework" -ForegroundColor DarkGray
        Write-Host "        SysOpt funcionara en modo fallback PowerShell." -ForegroundColor Yellow
    } else {
        $teDll     = Join-Path $outDir 'SysOpt.ThemeEngine.dll'
        $teErrFile = Join-Path $tmpDir 'te_errors.txt'
        $teArgs    = "/target:library /out:`"$teDll`" /optimize+ /nologo /utf8output $refs $wpfRefs `"$teSource`""

        Write-Host "       csc $teArgs" -ForegroundColor DarkGray

        # Redirigir stdout+stderr al archivo de errores para capturar mensajes de csc.exe
        $teProc = Start-Process -FilePath $csc `
                                -ArgumentList $teArgs `
                                -NoNewWindow -Wait -PassThru `
                                -RedirectStandardOutput $teErrFile `
                                -RedirectStandardError  "$teErrFile.stderr"

        if ($teProc.ExitCode -ne 0) {
            Write-Host "[ERROR] ThemeEngine no compilo (ExitCode $($teProc.ExitCode))." -ForegroundColor Red
            foreach ($errLog in @($teErrFile, "$teErrFile.stderr")) {
                if (Test-Path $errLog) {
                    Get-Content $errLog | Where-Object { $_ -ne '' } |
                        ForEach-Object { Write-Host "  $_" -ForegroundColor Red }
                }
            }
            Write-Host "        SysOpt funcionara en modo fallback PowerShell." -ForegroundColor Yellow
        } else {
            Write-Host "        OK  ->  libs\SysOpt.ThemeEngine.dll" -ForegroundColor Green
            $x86Dir = Join-Path $outDir 'x86'
            if (Test-Path $x86Dir) {
                Copy-Item $teDll $x86Dir -Force
                Write-Host "        OK  ->  libs\x86\SysOpt.ThemeEngine.dll  (copia)" -ForegroundColor Green
            }
        }
    }
}

# -----------------------------------------------------------------------------
# Limpieza
# -----------------------------------------------------------------------------
Remove-Item $tmpDir -Recurse -Force -ErrorAction SilentlyContinue

Write-Host ''
Write-Host '-----------------------------------------------------------------------' -ForegroundColor DarkGray
Write-Host ' BUILD COMPLETADO' -ForegroundColor Green
Write-Host "  $outDir\" -ForegroundColor White
Write-Host '    SysOpt.MemoryHelper.dll'  -ForegroundColor Cyan
Write-Host '    SysOpt.DiskEngine.dll'    -ForegroundColor Cyan
Write-Host '    SysOpt.WseTrim.dll'       -ForegroundColor Cyan
Write-Host '    SysOpt.ThemeEngine.dll'   -ForegroundColor Cyan
Write-Host ''
Write-Host '  Copia la carpeta libs\ junto a SysOpt.ps1' -ForegroundColor Yellow
Write-Host '  (SysOpt.ThemeEngine.cs debe estar junto a build_dlls.ps1 para compilar ThemeEngine)' -ForegroundColor DarkGray
Write-Host '-----------------------------------------------------------------------' -ForegroundColor DarkGray
Write-Host ''
Read-Host 'Pulsa Enter para salir'