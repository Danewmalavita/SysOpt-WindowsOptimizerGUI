﻿#Requires -Version 3
<#
.SYNOPSIS
    Test-SysOptDLLs.ps1 - Diagnostico de carga de DLLs para SysOpt
.DESCRIPTION
    Comprueba cada DLL de SysOpt: existencia, carga, origen del assembly
    y tipos expuestos. Replica exactamente la logica de carga de SysOpt.ps1
    para verificar que el sistema cargara DLL o fallback inline.
.NOTES
    Ejecutar desde la misma carpeta que SysOpt.ps1:
        powershell -ExecutionPolicy Bypass -File Test-SysOptDLLs.ps1
    O con verbose para mas detalle:
        powershell -ExecutionPolicy Bypass -File Test-SysOptDLLs.ps1 -Verbose
#>
[CmdletBinding()]
param()

Set-StrictMode -Off
$ErrorActionPreference = 'Continue'

# --- Helpers de consola ------------------------------------------------------

function Write-Header($text) {
    Write-Host ""
    Write-Host ("=" * 62) -ForegroundColor DarkGray
    Write-Host "  $text" -ForegroundColor Cyan
    Write-Host ("=" * 62) -ForegroundColor DarkGray
}

function Write-Section($text) {
    Write-Host ""
    Write-Host "  -- $text" -ForegroundColor DarkGray
}

function Write-OK($text)   { Write-Host "  [OK]  $text" -ForegroundColor Green  }
function Write-WARN($text) { Write-Host "  [!!]  $text" -ForegroundColor Yellow }
function Write-FAIL($text) { Write-Host "  [XX]  $text" -ForegroundColor Red    }
function Write-INFO($text) { Write-Host "        $text" -ForegroundColor Gray   }

# --- Funcion principal de test por DLL --------------------------------------

function Test-DllLoad {
    param(
        [string]$DllName,          # ej: "SysOpt.MemoryHelper.dll"
        [string]$GuardType,        # tipo que actua como guard, ej: "MemoryHelper"
        [string[]]$ExpectedTypes,  # tipos que debe exponer el DLL
        [string[]]$ExpectedMethods # metodos spot-check (opcional)
    )

    Write-Header "$DllName"

    $libsDir = Join-Path $PSScriptRoot "libs"
    $dllPath = Join-Path $libsDir $DllName

    # 1. Existencia fisica
    Write-Section "Existencia en disco"
    Write-INFO "Ruta buscada : $dllPath"

    $dllExists = Test-Path $dllPath
    if ($dllExists) {
        Write-OK  "Archivo encontrado"
        $fi = Get-Item $dllPath
        Write-INFO "Tamano       : $([math]::Round($fi.Length / 1KB, 1)) KB"
        Write-INFO "Modificado   : $($fi.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss'))"
        # Hash rapido para verificar integridad
        try {
            $hash = (Get-FileHash $dllPath -Algorithm MD5).Hash
            Write-INFO "MD5          : $hash"
        } catch {}
    } else {
        Write-FAIL "Archivo NO encontrado en libs\"
        Write-WARN "SysOpt cargara el fallback inline (compilacion en tiempo de ejecucion)"
    }

    # 2. Estado del tipo en la sesion actual
    Write-Section "Estado del tipo en esta sesion PS"
    $alreadyLoaded = ([System.Management.Automation.PSTypeName]$GuardType).Type
    if ($null -ne $alreadyLoaded) {
        Write-WARN "Tipo '$GuardType' YA estaba cargado antes de este test"
        Write-INFO "Assembly origen: $($alreadyLoaded.Assembly.Location)"
        Write-INFO "Assembly nombre: $($alreadyLoaded.Assembly.GetName().Name)"
        $isFromDll = $alreadyLoaded.Assembly.Location -like "*$DllName*"
        if ($isFromDll) {
            Write-OK  "Cargado DESDE DLL externo"
        } elseif ([string]::IsNullOrEmpty($alreadyLoaded.Assembly.Location)) {
            Write-WARN "Cargado desde compilacion INLINE (Location vacia = ensamblado dinamico)"
        } else {
            Write-WARN "Cargado desde ubicacion inesperada"
        }
    } else {
        Write-INFO "Tipo '$GuardType' no cargado aun en esta sesion - se intentara cargar ahora"
    }

    # 3. Intento de carga (replica logica de SysOpt.ps1)
    Write-Section "Intento de carga"
    $loadedFrom = $null

    if ($null -eq ([System.Management.Automation.PSTypeName]$GuardType).Type) {
        if ($dllExists) {
            try {
                Add-Type -Path $dllPath -ErrorAction Stop
                $loadedFrom = "DLL_EXTERNO"
                Write-OK  "Add-Type -Path OK"
            } catch {
                Write-FAIL "Add-Type -Path fallo: $($_.Exception.Message)"
                $loadedFrom = "ERROR_DLL"
            }
        } else {
            Write-WARN "DLL no disponible - en SysOpt.ps1 se usaria el fallback inline"
            $loadedFrom = "FALLBACK_INLINE"
        }
    } else {
        $loadedFrom = "YA_CARGADO"
        Write-INFO "Tipo ya presente, no se recarga"
    }

    # 4. Verificacion de tipos esperados
    Write-Section "Tipos expuestos"
    $allTypesOk = $true
    foreach ($typeName in $ExpectedTypes) {
        $t = ([System.Management.Automation.PSTypeName]$typeName).Type
        if ($null -ne $t) {
            $origin = if ([string]::IsNullOrEmpty($t.Assembly.Location)) { "inline/dinamico" } else { $t.Assembly.Location }
            Write-OK  "$typeName"
            Write-INFO "  Assembly: $origin"
        } else {
            Write-FAIL "$typeName  NO encontrado"
            $allTypesOk = $false
        }
    }

    # 5. Spot-check de metodos
    if ($ExpectedMethods -and $ExpectedMethods.Count -gt 0) {
        Write-Section "Metodos spot-check"
        $mainType = ([System.Management.Automation.PSTypeName]$GuardType).Type
        if ($null -ne $mainType) {
            foreach ($methodName in $ExpectedMethods) {
                $method = $mainType.GetMethods() | Where-Object { $_.Name -eq $methodName }
                if ($method) {
                    Write-OK  "$GuardType::$methodName()"
                    Write-INFO "  Firma: $($method | Select-Object -First 1)"
                } else {
                    Write-FAIL "$GuardType::$methodName()  NO encontrado"
                }
            }
        }
    }

    # 6. Resumen
    Write-Section "Resumen"
    $sourceLabel = switch ($loadedFrom) {
        "DLL_EXTERNO"     { "DLL externo (libs\$DllName)" }
        "YA_CARGADO"      { "Sesion previa (ya estaba en memoria)" }
        "FALLBACK_INLINE" { "FALLBACK INLINE (DLL no encontrado)" }
        "ERROR_DLL"       { "ERROR al cargar DLL" }
        default           { $loadedFrom }
    }

    $color = switch ($loadedFrom) {
        "DLL_EXTERNO"     { "Green"  }
        "YA_CARGADO"      { "Cyan"   }
        "FALLBACK_INLINE" { "Yellow" }
        default           { "Red"    }
    }

    Write-Host ""
    Write-Host "  Origen de carga : " -NoNewline
    Write-Host $sourceLabel -ForegroundColor $color
    if ($allTypesOk) {
        Write-Host "  Tipos OK        : $($ExpectedTypes.Count)/$($ExpectedTypes.Count)" -ForegroundColor Green
    } else {
        Write-Host "  Tipos con error : revisar arriba" -ForegroundColor Red
    }

    return @{
        DllName    = $DllName
        DllExists  = $dllExists
        LoadedFrom = $loadedFrom
        TypesOk    = $allTypesOk
    }
}

# ================================================================
#  CABECERA
# ================================================================
Write-Host ""
Write-Host "  SysOpt DLL Diagnostic" -ForegroundColor White
Write-Host "  Script  : $PSCommandPath" -ForegroundColor DarkGray
Write-Host "  Directorio base: $PSScriptRoot" -ForegroundColor DarkGray
Write-Host "  PS Version      : $($PSVersionTable.PSVersion)" -ForegroundColor DarkGray
Write-Host "  .NET Runtime    : $([System.Runtime.InteropServices.RuntimeEnvironment]::GetRuntimeDirectory())" -ForegroundColor DarkGray

# Verificar carpeta libs\
$libsPath = Join-Path $PSScriptRoot "libs"
Write-Host ""
if (Test-Path $libsPath) {
    Write-Host "  Carpeta libs\   : ENCONTRADA" -ForegroundColor Green
    $dlls = Get-ChildItem $libsPath -Filter "*.dll" -ErrorAction SilentlyContinue
    Write-Host "  DLLs en libs\   : $($dlls.Count) archivo(s)" -ForegroundColor Gray
    foreach ($d in $dlls) {
        Write-Host "    - $($d.Name)  ($([math]::Round($d.Length/1KB,1)) KB)" -ForegroundColor DarkGray
    }
} else {
    Write-Host "  Carpeta libs\   : NO ENCONTRADA en $libsPath" -ForegroundColor Red
    Write-Host "  SysOpt usara compilacion inline para todos los tipos" -ForegroundColor Yellow
}

# ================================================================
#  TEST 1 - SysOpt.MemoryHelper.dll
# ================================================================
$r1 = Test-DllLoad `
    -DllName        "SysOpt.MemoryHelper.dll" `
    -GuardType      "MemoryHelper" `
    -ExpectedTypes  @("MemoryHelper") `
    -ExpectedMethods @("EmptyWorkingSet", "OpenProcess", "CloseHandle")

# ================================================================
#  TEST 2 - SysOpt.DiskEngine.dll
# ================================================================
$r2 = Test-DllLoad `
    -DllName        "SysOpt.DiskEngine.dll" `
    -GuardType      "DiskItem_v211" `
    -ExpectedTypes  @("DiskItem_v211", "DiskItemToggle_v230", "ScanCtl211", "PScanner211") `
    -ExpectedMethods @("Reset")

# ================================================================
#  TEST 3 - SysOpt.WseTrim.dll
# ================================================================
$r3 = Test-DllLoad `
    -DllName        "SysOpt.WseTrim.dll" `
    -GuardType      "WseTrim" `
    -ExpectedTypes  @("WseTrim") `
    -ExpectedMethods @("TrimCurrentProcess", "TrimProcess")

# ================================================================
#  RESUMEN GLOBAL
# ================================================================
Write-Host ""
Write-Host ("=" * 62) -ForegroundColor DarkGray
Write-Host "  RESUMEN GLOBAL" -ForegroundColor White
Write-Host ("=" * 62) -ForegroundColor DarkGray
Write-Host ""

$results = @($r1, $r2, $r3)
$allFromDll     = 0
$allFallback    = 0
$allPreloaded   = 0
$allError       = 0

foreach ($r in $results) {
    $icon = switch ($r.LoadedFrom) {
        "DLL_EXTERNO"     { "[OK]" }
        "YA_CARGADO"      { "[OK]" }
        "FALLBACK_INLINE" { "[!!]" }
        default           { "[XX]" }
    }
    $color = switch ($r.LoadedFrom) {
        "DLL_EXTERNO"     { "Green"  }
        "YA_CARGADO"      { "Cyan"   }
        "FALLBACK_INLINE" { "Yellow" }
        default           { "Red"    }
    }
    $label = switch ($r.LoadedFrom) {
        "DLL_EXTERNO"     { "DLL externo"; $allFromDll++    }
        "YA_CARGADO"      { "Ya cargado" ; $allPreloaded++  }
        "FALLBACK_INLINE" { "INLINE"      ; $allFallback++  }
        default           { "ERROR"       ; $allError++     }
    }
    Write-Host ("  {0,-4}  {1,-35}  {2}" -f $icon, $r.DllName, $label) -ForegroundColor $color
}

Write-Host ""
if ($allError -gt 0) {
    Write-Host "  Estado: ERRORES DE CARGA - revisar mensajes arriba" -ForegroundColor Red
} elseif ($allFallback -gt 0) {
    Write-Host "  Estado: PARCIAL - $allFallback DLL(s) usaran compilacion inline" -ForegroundColor Yellow
    Write-Host "          Copia los DLLs a la carpeta libs\ para usar DLL externo" -ForegroundColor Yellow
} else {
    Write-Host "  Estado: OK - todos los tipos cargaran desde DLL externo" -ForegroundColor Green
}

Write-Host ""
Write-Host ("=" * 62) -ForegroundColor DarkGray
Write-Host ""
Read-Host "Pulsa Enter para salir"
